#!/usr/bin/env bash

BASEPATH=$(cd `dirname $0`; pwd)

CURRENT_MODE=`cat /emas-deploy/output/rendered/env.yml | shyaml get-value emas_devops_commons.mode`
if [[ ${CURRENT_MODE} = "online" ]];then
    rm -f ${BASEPATH}/templates/emas-channel_deployment.yaml
    rm -f ${BASEPATH}/templates/emas-channel_service.yaml
    rm -f ${BASEPATH}/templates/emas-data-service_deployment.yaml
    rm -f ${BASEPATH}/templates/emas-data-service_service.yaml
fi
