#!/usr/bin/env bash

BASEPATH=$(cd `dirname $0`; pwd)

CURRENT_MODE=`cat /emas-deploy/output/rendered/env.yml | shyaml get-value emas_devops_commons.mode`
if [[ ${CURRENT_MODE} = "online" ]];then
    rm -f ${BASEPATH}/templates/eweex-test-manager_deployment.yaml
    rm -f ${BASEPATH}/templates/eweex-test-manager_service.yaml
fi
