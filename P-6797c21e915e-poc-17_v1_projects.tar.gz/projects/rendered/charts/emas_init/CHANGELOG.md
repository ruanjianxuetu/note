# 变更日志
此项目的所有显着更改将记录在此文件中。

## 2020-10-30 【release_2.4.x】
### 修改
- 公有云rocketmq 支持按部署的模块来创建topic，groupid

## 2020-10-27 【release_2.4.x】
### 修复
- 添加miniprogram sql初始化

## 2020-10-23 【release_2.4.x】
### 修复
- 修复chart过大导致部署失败的问题。sql文件放在镜像里面，不再通过configmap挂载。
- 原先accs_mysql 跟mysql 都初始化了所有sql，现在删除多余的配置，以支持使用同一个实例
- 删除重复的sql