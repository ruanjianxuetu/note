USE `emas`;
ALTER TABLE `emas_weex_publish_resource` ADD `use_zcache` tinyint(4) DEFAULT 0 COMMENT '是否使用预加载,0:不使用,1:使用';