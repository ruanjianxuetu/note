USE `emas`;
# Dump of table emas_weex_release_publish_task
# ------------------------------------------------------------

CREATE TABLE `emas_weex_release_publish_task` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `module_id` bigint(20) DEFAULT NULL COMMENT '模块ID',
  `publish_id` bigint(20) DEFAULT NULL COMMENT '发布单ID',
  `task_type` varchar(30) DEFAULT NULL COMMENT '任务类型',
  `is_zcache` tinyint(4) DEFAULT NULL COMMENT '是否使用zcache',
  `can_rollback` tinyint(4) DEFAULT 0 COMMENT '是否可回滚',
  `zcache_id` bigint(10) DEFAULT NULL COMMENT 'zcache的taskId',
  `status` varchar(20) NOT NULL DEFAULT '' COMMENT '状态，发布失败-1，待发布0，发布中1，发布完成2，回滚中3，已回滚4',
  `creator` varchar(30) NOT NULL DEFAULT '' COMMENT '创建人',
  `modifier` varchar(30) DEFAULT NULL COMMENT '修改人',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0 COMMENT '逻辑删除, 0正常，1删除',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='正式发布任务表';

# Dump of table emas_weex_release_publish_task_history
# ------------------------------------------------------------

CREATE TABLE `emas_weex_release_publish_task_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '数据库自增id',
  `task_id` bigint(20) DEFAULT NULL COMMENT '正式发布任务ID',
  `modifier` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '修改人',
  `action` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '操作：CREATE,ROLL_BACK',
  `status` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '状态',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '描述',
  `is_deleted` tinyint(4) DEFAULT NULL COMMENT '逻辑删除',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='正式发布任务历史表';
