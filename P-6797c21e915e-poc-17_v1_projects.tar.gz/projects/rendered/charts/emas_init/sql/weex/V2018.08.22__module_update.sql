USE `emas`;
ALTER TABLE `emas_weex_biz_line` ADD `product_id` bigint(20) DEFAULT NULL COMMENT '产品ID';
ALTER TABLE `emas_weex_module` ADD `product_id` bigint(20) DEFAULT NULL COMMENT '产品ID';
ALTER TABLE `emas_weex_module` MODIFY `biz_id` bigint(20) DEFAULT NULL;

CREATE TABLE `emas_weex_material_library` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `creator` varchar(30) DEFAULT NULL COMMENT '创建者',
  `modifier` varchar(30) DEFAULT NULL COMMENT '最近修改者',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `is_deleted` tinyint(4) DEFAULT NULL COMMENT '逻辑删除',
  `product_id` bigint(20) NOT NULL COMMENT '产品ID',
  `name` varchar(100) DEFAULT NULL COMMENT '资源名称',
  `source_type` varchar(50) DEFAULT 'LOCAL' COMMENT '资源来源',
  `source_url` varchar(255) DEFAULT NULL COMMENT '资源源地址',
  `distribute_url` varchar(255) DEFAULT NULL COMMENT '投放地址',
  `description` varchar(255) DEFAULT '' COMMENT '描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='weex素材库资源表';

CREATE TABLE `emas_weex_material_library_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `creator` varchar(30) DEFAULT NULL COMMENT '操作者',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `material_id` bigint(20) NOT NULL COMMENT '素材ID',
  `action` varchar(100) DEFAULT NULL COMMENT '操作名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='weex素材库资源历史';

CREATE TABLE `emas_weex_container_app_info` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `creator` varchar(30) DEFAULT NULL COMMENT '创建者',
  `modifier` varchar(30) DEFAULT NULL COMMENT '最近修改者',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `is_deleted` tinyint(4) DEFAULT NULL COMMENT '逻辑删除',
  `product_id` bigint(20) NOT NULL COMMENT '产品ID',
  `app_id` bigint(20) NOT NULL COMMENT '应用ID',
  `meta_project_id` bigint(20) NOT NULL COMMENT '元项目ID',
  `app_platform` varchar(50) DEFAULT NULL COMMENT 'app平台类型',
  `git_address` varchar(255) DEFAULT NULL COMMENT '代码库地址',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='跨平台容器app信息';
