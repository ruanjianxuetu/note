USE `emas`;
ALTER TABLE `emas_weex_publish_sheet` MODIFY `name` varchar(100) NOT NULL COMMENT '发布单名称';