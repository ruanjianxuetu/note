USE `emas`;
CREATE TABLE `emas_weex_pre_publish_sheet` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `creator` varchar(30) DEFAULT NULL COMMENT '创建者',
  `modifier` varchar(30) DEFAULT NULL COMMENT '最近修改者',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `is_deleted` tinyint(4) DEFAULT 0 COMMENT '逻辑删除',
  `module_id` bigint(20) NOT NULL COMMENT '模块ID',
  `build_id` bigint(20) NOT NULL COMMENT '构建ID',
  `status` varchar(255) DEFAULT NULL COMMENT '发布状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='跨平台预发布单表';

CREATE TABLE `emas_weex_pre_publish_resource` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `creator` varchar(30) DEFAULT NULL COMMENT '操作者',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `pre_publish_id` bigint(20) NOT NULL COMMENT '测试发布单ID',
  `resource_id` bigint(20) NOT NULL COMMENT '资源ID',
  `source_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '源地址',
  `pre_publish_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '预发布地址',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='跨平台预发布资源';
