USE `emas`;
# Dump of table emas_weex_publish_app
# ------------------------------------------------------------
CREATE TABLE `emas_weex_publish_app` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `publish_id` bigint(20) NOT NULL COMMENT '发布单ID',
  `app_id` bigint(30) DEFAULT NULL COMMENT '客户端应用appkey',
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0 COMMENT '逻辑删除, 0正常，1删除',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='发布客户端表';

# Dump of table emas_weex_publish_resource
# ------------------------------------------------------------
CREATE TABLE `emas_weex_publish_resource` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `publish_id` bigint(20) NOT NULL COMMENT '发布单ID',
  `resource_id` bigint(20) NOT NULL COMMENT '资源模块资源ID',
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0 COMMENT '逻辑删除, 0正常，1删除',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='发布资源表';

# Dump of table emas_weex_publish_sheet
# ------------------------------------------------------------
CREATE TABLE `emas_weex_publish_sheet` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `module_id` bigint(20) NOT NULL COMMENT '业务模块ID',
  `name` varchar(45) NOT NULL COMMENT '业务模块名',
  `version` varchar(128) DEFAULT NULL COMMENT '版本号',
  `creator` varchar(30) NOT NULL DEFAULT '' COMMENT '发布单创建人',
  `modifier` varchar(30) NOT NULL DEFAULT '' COMMENT '发布单最近修改人',
  `stage` varchar(20) NOT NULL COMMENT '发布阶段，未发布0，资源选择10，测试20，灰度发布30，正式发布40',
  `status` varchar(20) NOT NULL COMMENT '状态，待发布0，灰度中31，灰度发布失败32，灰度发布回滚中33，灰度发布回滚完成34，发布中41，发布完成42，发布失败43，正式发布回滚中44，正式发布已回滚45',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0 COMMENT '逻辑删除, 0正常，1删除',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='发布单表';

# Dump of table emas_weex_publish_sheet_history
# ------------------------------------------------------------
CREATE TABLE `emas_weex_publish_sheet_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `publish_id` bigint(20) NOT NULL COMMENT '发布单ID',
  `modifier` varchar(30) NOT NULL DEFAULT '' COMMENT '修改人',
  `action` varchar(20) DEFAULT NULL COMMENT '操作:ADD,MODIFY,DELETE',
  `publish_type` varchar(20) DEFAULT NULL COMMENT '发布类型:GRAY,FORMAL',
  `status` varchar(20) NOT NULL COMMENT '发布单状态',
  `result` varchar(20) DEFAULT NULL COMMENT '操作结果',
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0 COMMENT '逻辑删除, 0正常，1删除',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='发布单历史表';

