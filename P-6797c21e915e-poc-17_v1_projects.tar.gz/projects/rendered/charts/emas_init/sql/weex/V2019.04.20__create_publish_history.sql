USE `emas`;
CREATE TABLE `emas_weex_publish_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `publish_id` bigint(20) NOT NULL COMMENT '发布单ID',
  `modifier` varchar(30) NOT NULL DEFAULT '' COMMENT '修改人',
  `action` varchar(50) NOT NULL COMMENT '操作项',
  `from` varchar(20) DEFAULT NULL COMMENT '发布单原先状态',
  `to` varchar(20) DEFAULT NULL COMMENT '发布单当前状态',
  `note` varchar(255) DEFAULT NULL COMMENT '备注',
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0 COMMENT '逻辑删除, 0正常，1删除',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='发布单历史表';