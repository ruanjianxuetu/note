USE `emas`;
CREATE TABLE `emas_weex_publish_zcache_preset_record` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `creator` varchar(30) DEFAULT NULL COMMENT '创建者',
  `modifier` varchar(30) DEFAULT NULL COMMENT '最近修改者',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `is_deleted` tinyint(4) DEFAULT NULL COMMENT '逻辑删除',
  `app_id` bigint(20) NOT NULL COMMENT '容器appid',
  `publish_id` bigint(20) DEFAULT NULL COMMENT '发布单ID',
  `preset_zip_id` bigint(20) DEFAULT NULL COMMENT '预置包id',
  `preset_zip_url` varchar(255) DEFAULT NULL COMMENT '预置包地址',
  `preload_path` varchar(255) DEFAULT NULL COMMENT '预置包代码路径',
  `git_address` varchar(255) DEFAULT NULL COMMENT '预置包目标仓库',
  `git_branch` varchar(255) DEFAULT NULL COMMENT '预置包目标分支',
  `status` varchar(50) DEFAULT NULL COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5000 DEFAULT CHARSET=utf8 COMMENT='发布客户端表';