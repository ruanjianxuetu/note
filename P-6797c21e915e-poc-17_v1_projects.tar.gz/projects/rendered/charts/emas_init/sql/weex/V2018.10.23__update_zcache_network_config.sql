USE `emas`;
ALTER TABLE `emas_weex_zcache_version` ADD `update_model` tinyint(20) DEFAULT 0 COMMENT '0:仅WIFI更新,2:3g+更新,3:全部网络环境更新';