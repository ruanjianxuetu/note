USE `emas`;

CREATE TABLE IF NOT EXISTS `emas_weex_module_group` (
`id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
`group_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '模块分组名称',
`creator` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '模块分组创建者',
`description` varchar(255) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '模块分组描述',
`is_deleted` tinyint(4) DEFAULT NULL COMMENT '逻辑删除',
`product_id` bigint(20) NOT NULL COMMENT '模块所属产品ID',
`gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
`gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
PRIMARY KEY (`id`),
KEY `idx_gname` (`group_name`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='模块分组表';

CREATE TABLE IF NOT EXISTS `emas_weex_module_group_relation` (
`id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
`group_id` bigint(20) NOT NULL COMMENT '模块分组ID',
`module_id` bigint(20) NOT NULL COMMENT '模块ID',
`gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
`gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
PRIMARY KEY (`id`),
KEY `idx_gid` (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='模块分组关系表';