USE `emas`;
CREATE TABLE `emas_weex_publish_container_app` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `creator` varchar(30) DEFAULT NULL COMMENT '创建者',
  `modifier` varchar(30) DEFAULT NULL COMMENT '最近修改者',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `is_deleted` tinyint(4) DEFAULT NULL COMMENT '逻辑删除',
  `product_id` bigint(20) NOT NULL COMMENT '产品id',
  `native_publish_id` bigint(20) NOT NULL COMMENT 'native侧发布单ID',
  `app_id` bigint(20) NOT NULL COMMENT 'app id',
  `app_platform` varchar(50) DEFAULT NULL COMMENT 'app平台类型',
  `name` varchar(100) DEFAULT NULL COMMENT '发布单名称',
  `version` varchar(50) DEFAULT NULL COMMENT '版本号',
  `status` varchar(50) DEFAULT NULL COMMENT '状态',
  `tab_count` tinyint(4) DEFAULT NULL COMMENT 'tab页数量',
  `resource_ids` varchar(255) DEFAULT NULL COMMENT '首页内置资源ids',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5000 DEFAULT CHARSET=utf8 COMMENT='发布客户端表';