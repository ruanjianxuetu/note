USE `emas`;
alter table emas_weex_zcache_resource add `source_type` varchar(50) DEFAULT NULL COMMENT '资源来源类型';