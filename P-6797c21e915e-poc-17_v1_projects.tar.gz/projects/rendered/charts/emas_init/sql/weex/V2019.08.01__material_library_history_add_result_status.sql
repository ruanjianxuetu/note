USE `emas`;
-- 增加字段表示当前记录发布成功与否
ALTER TABLE `emas_weex_material_library` ADD COLUMN publish_status VARCHAR(100) DEFAULT NULL COMMENT '该条记录发布成功与否';

UPDATE `emas_weex_material_library` SET publish_status = 'PUBLISH_SUCCESS';