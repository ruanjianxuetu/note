USE `emas`;
# Dump of table emas_weex_gray_publish_task
# ------------------------------------------------------------
CREATE TABLE `emas_weex_gray_publish_version` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `module_id` bigint(20) DEFAULT NULL COMMENT '模块ID',
  `publish_id` bigint(20) DEFAULT NULL COMMENT '发布单ID',
  `publish_version` varchar(20) DEFAULT NULL COMMENT '发布单版本',
  `dy_publish_id` bigint(20) DEFAULT NULL COMMENT 'dy平台发布单ID',
  `status` varchar(20) NOT NULL DEFAULT '' COMMENT '状态',
  `creator` varchar(30) NOT NULL DEFAULT '' COMMENT '创建人',
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0 COMMENT '逻辑删除, 0正常，1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='灰度发布任务表';

# Dump of table emas_weex_gray_publish_task
# ------------------------------------------------------------
CREATE TABLE `emas_weex_gray_publish_task` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `module_id` bigint(20) DEFAULT NULL COMMENT '模块ID',
  `publish_id` bigint(20) DEFAULT NULL COMMENT '发布单ID',
  `dy_batch_id` bigint(20) DEFAULT NULL COMMENT '灰度批次ID',
  `expect_count` bigint(20) DEFAULT 0 COMMENT '计划通知数',
  `grayed_count` bigint(20) DEFAULT 0 COMMENT '实际灰度数',
  `app_infos` LONGTEXT DEFAULT NULL COMMENT '待发布的app及其版本信息',
  `start_time` datetime DEFAULT NULL COMMENT '创建时间',
  `end_time` datetime DEFAULT NULL COMMENT '创建时间',
  `status` varchar(20) NOT NULL DEFAULT '' COMMENT '状态',
  `creator` varchar(30) NOT NULL DEFAULT '' COMMENT '创建人',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0 COMMENT '逻辑删除, 0正常，1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='灰度发布任务表';

# Dump of table emas_weex_gray_resource
# ------------------------------------------------------------
CREATE TABLE `emas_weex_gray_resource` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `publish_resource_id` bigint(20) DEFAULT NULL COMMENT '发布单资源ID',
  `resource_id` bigint(20) DEFAULT NULL COMMENT '模块资源ID',
  `publish_id` bigint(20) DEFAULT NULL COMMENT '发布单ID',
  `gray_task_id` bigint(20) DEFAULT NULL COMMENT '灰度批次ID',
  `source_url` varchar(256) DEFAULT NULL COMMENT '资源源地址',
  `gray_url` varchar(256) DEFAULT NULL COMMENT '资源灰度投放地址',
  `distribute_url` varchar(256) DEFAULT NULL COMMENT '资源正式投放地址',
  `path` varchar(256) DEFAULT NULL COMMENT '相对路径',
  `md5` varchar(100) DEFAULT NULL COMMENT '资源md5',
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0 COMMENT '逻辑删除, 0正常，1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='灰度资源表';
