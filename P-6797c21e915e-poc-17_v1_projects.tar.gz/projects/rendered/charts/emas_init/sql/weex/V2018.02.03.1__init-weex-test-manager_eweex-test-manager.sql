USE `emas`;
CREATE TABLE `emas_weex_test_code` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `module_id` bigint(20) DEFAULT NULL COMMENT '模块ID',
  `record_id` bigint(20) DEFAULT NULL COMMENT '测试记录ID',
  `build_id` bigint(20) DEFAULT NULL COMMENT '构建ID',
  `name` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '任务名称',
  `type` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '测试类型',
  `trigger_type` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '触发类型',
  `creator` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '创建人',
  `status` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '任务状态',
  `result_info` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '粗略结果',
  `scm_address` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '源码地址',
  `scm_branch` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '源码分支',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `log_url` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '日志地址',
  `is_deleted` tinyint(4) DEFAULT 0 COMMENT '逻辑删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='源码测试任务表';

CREATE TABLE `emas_weex_test_bundle_record_group` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `module_id` bigint(20) DEFAULT NULL COMMENT '模块ID',
  `name` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '任务名称',
  `type` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '测试类型',
  `trigger_type` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '触发类型',
  `creator` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '创建人',
  `status` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '任务状态',
  `result_info` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '粗略结果',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `is_deleted` tinyint(4) DEFAULT 0 COMMENT '逻辑删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='jsbundle测试任务组';

CREATE TABLE `emas_weex_test_bundle_record` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `group_task_id` bigint(20) DEFAULT NULL COMMENT '任务组ID',
  `resource_id` bigint(20) DEFAULT NULL COMMENT '资源ID',
  `record_id` bigint(20) DEFAULT NULL COMMENT '测试记录ID',
  `name` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'bundle名称',
  `url` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '资源地址',
  `status` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '任务状态',
  `result_info` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '粗略结果',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `log_url` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '日志地址',
  `is_deleted` tinyint(4) DEFAULT 0 COMMENT '逻辑删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='jsbundle测试任务';
