USE `emas`;
update `emas_weex_module` set `type`='WEEX' where `type` is null;