USE `emas`;
CREATE TABLE `emas_weex_zcache_preset_zip` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0 COMMENT '逻辑删除, 0正常，1删除',
  `name` varchar(100) NOT NULL COMMENT '预置包名称',
  `preset_zip_url` varchar(256) DEFAULT NULL COMMENT '预置包地址',
  `zcache_version_ids`  varchar(256) DEFAULT NULL COMMENT '预置发布包信息',
  `md5` varchar(100) DEFAULT NULL COMMENT '资源md5',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='预加载版本表';

ALTER TABLE `emas_weex_zcache_version` ADD `version_time` bigint(20) DEFAULT NULL COMMENT '版本时间戳';