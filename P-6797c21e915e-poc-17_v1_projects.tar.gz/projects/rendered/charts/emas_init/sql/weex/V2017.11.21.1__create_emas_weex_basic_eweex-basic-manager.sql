USE `emas`;
# Dump of table emas_weex_biz_admin
# ------------------------------------------------------------
CREATE TABLE `emas_weex_biz_admin` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '数据库自增id',
  `biz_id` bigint(20) NOT NULL COMMENT '业务线id',
  `user_id` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '管理员用户id',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='业务线管理员表';

# Dump of table emas_weex_biz_line
# ------------------------------------------------------------
CREATE TABLE `emas_weex_biz_line` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `uid` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '所属用户id',
  `name` text COLLATE utf8_unicode_ci NOT NULL COMMENT '业务线名称',
  `biz_code` text COLLATE utf8_unicode_ci NOT NULL COMMENT '业务线标志code',
  `status` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '业务线状态',
  `is_deleted` tinyint(4) DEFAULT NULL COMMENT '逻辑删除',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '业务线描述',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `idx_biz_code` (`biz_code`(10)) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='业务线表';

# Dump of table emas_weex_module
# ------------------------------------------------------------
CREATE TABLE `emas_weex_module` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `biz_id` bigint(20) NOT NULL COMMENT '所属业务线ID',
  `module_code` text COLLATE utf8_unicode_ci NOT NULL COMMENT '模块标志code',
  `name` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '模块名称',
  `creator` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '创建人',
  `status` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '模块状态',
  `type` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '模块类型(冗余)',
  `os_type` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '系统类型(冗余)',
  `is_deleted` tinyint(4) DEFAULT NULL COMMENT '逻辑删除',
  `repo_add` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'repo地址',
  `branch` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '分支',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '描述',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `idx_biz_id_module_code` (`biz_id`,`module_code`(20)) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='模块表';

# Dump of table emas_weex_module_admin
# ------------------------------------------------------------
CREATE TABLE `emas_weex_module_admin` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `module_id` bigint(20) NOT NULL COMMENT '模块ID',
  `uid` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '用户ID',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='模块管理员表';

# Dump of table emas_weex_module_member
# ------------------------------------------------------------
CREATE TABLE `emas_weex_module_member` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `module_id` bigint(20) NOT NULL COMMENT '模块ID',
  `user_id` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '用户ID',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='模块成员表';

# Dump of table emas_weex_resource
# ------------------------------------------------------------
CREATE TABLE `emas_weex_resource` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `module_id` bigint(20) NOT NULL COMMENT '模块ID',
  `name` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '资源名称',
  `source_type` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '资源来源类型',
  `resource_type` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '资源存放类型',
  `creator` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '资源创建者',
  `operator` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '最近修改者',
  `build_id` bigint(20) DEFAULT NULL COMMENT '构建id',
  `status` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '状态',
  `url` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '资源源地址',
  `distribute_url` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '待投放地址',
  `size` int(11) DEFAULT NULL COMMENT '资源大小',
  `md5` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '资源MD5',
  `tip` int(11) DEFAULT NULL COMMENT '源MD5是否变化',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '描述',
  `is_deleted` int(11) DEFAULT NULL COMMENT '逻辑删除',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='weex资源表';

# Dump of table emas_weex_resource_history
# ------------------------------------------------------------
CREATE TABLE `emas_weex_resource_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '数据库自增id',
  `resource_id` bigint(20) DEFAULT NULL COMMENT '资源id',
  `operator` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '操作者用户id',
  `action` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '操作类型',
  `md5` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '资源MD5',
  `url` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '资源源地址',
  `distribute_url` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '资源待投放地址',
  `source_type` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '资源类型',
  `time` datetime DEFAULT NULL COMMENT '操作时间',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='模块资源历史表';


