USE `emas`;
ALTER TABLE `emas_weex_zcache_version` MODIFY `zapp_name` varchar(100) NOT NULL COMMENT '业务线code-模块code';