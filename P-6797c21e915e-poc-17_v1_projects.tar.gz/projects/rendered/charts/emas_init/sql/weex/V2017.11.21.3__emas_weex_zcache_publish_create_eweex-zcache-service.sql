USE `emas`;
# Dump of table emas_weex_zcache_app_config
# ------------------------------------------------------------

CREATE TABLE `emas_weex_zcache_app_config` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `version` bigint(20) NOT NULL COMMENT '版本,时间戳',
  `zcache_version_id` bigint(20) NOT NULL COMMENT '预加载版本ID',
  `app_key` varchar(20) NOT NULL COMMENT '客户端应用appkey',
  `app_version` varchar(20) DEFAULT NULL COMMENT '客户端应用appkey',
  `config_url` varchar(256) DEFAULT NULL COMMENT '全量配置文件地址',
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0 COMMENT '逻辑删除, 0正常，1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='预加载客户端配置表';



# Dump of table emas_weex_zcache_resource
# ------------------------------------------------------------

CREATE TABLE `emas_weex_zcache_resource` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `module_id` bigint(20) NOT NULL COMMENT '模块ID',
  `publish_id` bigint(20) NOT NULL COMMENT '发布单ID',
  `release_id` bigint(20) DEFAULT NULL COMMENT '正式发布任务ID',
  `zcache_version_id` bigint(20) NOT NULL COMMENT '预加载版本ID',
  `zcache_version` varchar(128) NOT NULL COMMENT '预加载版本号',
  `resource_id` bigint(20) NOT NULL COMMENT '资源模块资源ID',
  `publish_resource_id` bigint(20) DEFAULT NULL COMMENT '发布资源管理资源ID',
  `source_url` varchar(256) DEFAULT NULL COMMENT '资源源地址',
  `distribute_url` varchar(256) DEFAULT NULL COMMENT '资源投放地址',
  `md5` varchar(100) DEFAULT NULL COMMENT '资源md5',
  `crc32` bigint(20) DEFAULT 0 COMMENT '资源crc32',
  `size` bigint(20) DEFAULT 0 COMMENT '资源文件size',
  `path` varchar(256) DEFAULT NULL COMMENT '资源在zip包中的路径',
  `is_changed` tinyint(4) NOT NULL DEFAULT 0 COMMENT '全量版本以来是否发生过变化',
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0 COMMENT '逻辑删除, 0正常，1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='预加载资源表';



# Dump of table emas_weex_zcache_version
# ------------------------------------------------------------

CREATE TABLE `emas_weex_zcache_version` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `module_id` bigint(20) NOT NULL COMMENT '模块ID',
  `publish_id` bigint(20) NOT NULL COMMENT '发布单ID',
  `release_id` bigint(20) NOT NULL COMMENT '正式发布任务ID',
  `version` varchar(128) NOT NULL COMMENT '版本号',
  `status` tinyint(4) NOT NULL COMMENT '状态，发布失败-1，发布中1，发布完成2，已回滚4，发布成功5',
  `is_rollback_version` tinyint(4) NOT NULL COMMENT '0: 正常版本，1：回滚版本',
  `zip_url` varchar(256) DEFAULT NULL COMMENT '全量包地址',
  `incr_zip_url` varchar(256) DEFAULT NULL COMMENT '增量包地址',
  `type` varchar(45) NOT NULL DEFAULT '12' COMMENT '版本类型,12全量,13增量',
  `zapp_name` varchar(45) NOT NULL COMMENT '业务线code-模块code',
  `release_time` datetime DEFAULT NULL COMMENT '发布时间',
  `urlprefix` varchar(1024) DEFAULT NULL COMMENT 'prefix前缀',
  `mapping_url` varchar(1024) DEFAULT NULL COMMENT '资源拦截前缀',
  `max_zip_size` bigint(10) NOT NULL DEFAULT 500 COMMENT '全量包大小最大限制，KB',
  `max_file_count` bigint(10) NOT NULL DEFAULT 60 COMMENT '资源文件数最大限制',
  `priority` tinyint(4) NOT NULL DEFAULT 5 COMMENT '加载优先级（1-9）',
  `monitor_rate` tinyint(4) NOT NULL DEFAULT 5 COMMENT '采样率（1-5）',
  `attribute` varchar(1024) DEFAULT NULL COMMENT '版本的一些其他信息，json格式，目前不使用',
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0 COMMENT '逻辑删除, 0正常，1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='预加载版本表';
