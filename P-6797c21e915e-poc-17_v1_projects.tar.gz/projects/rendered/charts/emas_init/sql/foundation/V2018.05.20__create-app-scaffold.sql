USE `emas`;
CREATE TABLE `emas_app_scaffold` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `creator` varchar(255) NOT NULL DEFAULT '' COMMENT '创建人',
  `modifier` varchar(255) NOT NULL DEFAULT '' COMMENT '修改人',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0 COMMENT '是否删除',
  `app_id` bigint(20) unsigned NOT NULL COMMENT 'APP ID',
  `app_platform` varchar(32) NOT NULL COMMENT 'App平台类型，ANDROID,IOS',
  `config_filename` varchar(255) DEFAULT NULL COMMENT '配置文件名',
  `config_file_url` varchar(255) DEFAULT NULL COMMENT '配置文件地址',
  `status` varchar(32) DEFAULT 'UNKNOWN' COMMENT '脚手架状态',
  `scaffold_name` varchar(255) DEFAULT NULL COMMENT '脚手架文件名',
  `scaffold_url` varchar(255) DEFAULT NULL COMMENT '脚手架地址',
  `error_code` bigint(20) unsigned DEFAULT 0 COMMENT '错误代码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用脚手架表';

CREATE TABLE `emas_app_scaffold_sdk` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `creator` varchar(255) NOT NULL DEFAULT '' COMMENT '创建人',
  `modifier` varchar(255) NOT NULL DEFAULT '' COMMENT '修改人',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `code_name` varchar(255) NOT NULL DEFAULT '' COMMENT 'sdk名,代码层面的',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT 'sdk名',
  `description` varchar(255) DEFAULT NULL COMMENT 'sdk描述',
  `group_id` varchar(255) DEFAULT NULL COMMENT 'maven group id',
  `artifact_id` varchar(255) DEFAULT NULL COMMENT 'maven artifact id',
  `version` varchar(50) NOT NULL COMMENT 'sdk版本',
  `type` varchar(50) NOT NULL COMMENT 'FOUNDATION(基础类型) or ADVANCE(增强类型)',
  `app_platform` varchar(32) NOT NULL COMMENT 'sdk平台类型，ANDROID,IOS',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='移动端sdk表';