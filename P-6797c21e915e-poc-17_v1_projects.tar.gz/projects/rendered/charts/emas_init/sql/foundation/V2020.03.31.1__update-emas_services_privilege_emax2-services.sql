use emas;
INSERT INTO `emas_services_privilege` (`code`, `context_type`, `name`) VALUES
('701001', 'WPK', 'setting:app:edit'),
('701002', 'WPK', 'setting:member:edit'),
('701003', 'WPK', 'setting:project:edit'),
('701004', 'WPK', 'h5:dashboard'),
('701005', 'WPK', 'h5:first-screen'),
('701006', 'WPK', 'h5:crash'),
('701007', 'WPK', 'h5:blank-screen'),
('701008', 'WPK', 'h5:res-error'),
('701009', 'WPK', 'h5:ajax-analysis'),
('701010', 'WPK', 'h5:page-analysis'),
('701011', 'WPK', 'h5:custom-analysis'),
('701012', 'WPK', 'h5:advanced-analysis'),
('701013', 'WPK', 'setting:advanced:edit'),
('701014', 'WPK', 'h5:alarm');
