USE `emas`;
CREATE TABLE `emas_app_module` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gmt_create` datetime NOT NULL,
  `gmt_modified` datetime NOT NULL,
  `is_deleted` tinyint(4) NOT NULL,
  `creator` varchar(255) NOT NULL,
  `modifier` varchar(255) NOT NULL,
  `app_id` bigint(20) NOT NULL,
  `module_id` bigint(20) NOT NULL,
  `is_active` tinyint(4) NOT NULL COMMENT '是否绑定',
  PRIMARY KEY (`id`),
  KEY `idx_app_id` (`app_id`) USING BTREE,
  KEY `idx_module_id` (`module_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='应用模块关系表';
