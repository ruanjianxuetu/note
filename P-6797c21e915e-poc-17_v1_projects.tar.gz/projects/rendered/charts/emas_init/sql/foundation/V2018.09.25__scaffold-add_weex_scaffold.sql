USE `emas`;
BEGIN;
CREATE TABLE `emas_weex_scaffold_config` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `creator` varchar(255) NOT NULL DEFAULT '' COMMENT '创建人',
  `modifier` varchar(255) NOT NULL COMMENT '修改人',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `product_id` int(11) NOT NULL COMMENT '产品id',
  `advance_sdks` varchar(500) DEFAULT NULL COMMENT '选中的扩展sdk id，id从小到大排序，使用逗号连接',
  `index_tab_count` tinyint(4) DEFAULT NULL COMMENT '首页tab数量：0是非weex，1是单页，>1是多页',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- 修改COMMENT
ALTER TABLE emas_app_scaffold_sdk MODIFY app_platform varchar(32) NOT NULL DEFAULT '' COMMENT '脚手架sdk平台类型，ANDROID,IOS,WEEX';

CREATE TABLE `emas_weex_scaffold` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `creator` varchar(255) NOT NULL DEFAULT '' COMMENT '创建人',
  `modifier` varchar(255) NOT NULL DEFAULT '' COMMENT '修改人',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `app_id` bigint(20) unsigned NOT NULL COMMENT 'APP ID',
  `app_platform` varchar(32) NOT NULL DEFAULT '' COMMENT 'App平台类型：ANDROID,IOS',
  `config_filename` varchar(255) DEFAULT NULL COMMENT '配置文件名',
  `config_file_url` varchar(255) DEFAULT NULL COMMENT '配置文件地址',
  `status` varchar(32) DEFAULT 'UNKNOWN' COMMENT '脚手架状态：UNKNOWN,ERROR,BUILDING,SUCCESS',
  `scaffold_name` varchar(255) DEFAULT NULL COMMENT '脚手架文件名',
  `scaffold_url` varchar(255) DEFAULT NULL COMMENT '脚手架地址',
  `error_code` bigint(20) unsigned DEFAULT '0' COMMENT '错误代码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用脚手架表';

-- 初始化weex sdk数据
INSERT INTO `emas_app_scaffold_sdk` (`creator`, `modifier`, `gmt_create`, `gmt_modified`, `is_deleted`, `code_name`, `name`, `description`, `group_id`, `artifact_id`, `version`, `type`, `app_platform`)
VALUES
	('9999', '9999', '2018-05-29 11:56:57', '2018-05-29 12:01:59', 0, 'WEEX_CORE_SDK', 'weex sdk(必选)', 'weex底层核心SDK', NULL, NULL, '1.0.0', 'FOUNDATION', 'WEEX'),
	('9999', '9999', '2018-05-29 11:56:57', '2018-05-29 12:01:59', 0, 'WEEX_DEBUG_SDK', 'weex debug sdk(必选)', '真机调试weex页面相关的sdk', NULL, NULL, '1.0.0', 'FOUNDATION', 'WEEX'),
	('9999', '9999', '2018-05-29 11:56:57', '2018-05-29 12:01:59', 0, 'WEEX_CONTAINER_SDK', 'weex 容器sdk(必选)', '标准weex页面容器层面的抽象，包含页面跳转、降级等逻辑处理', NULL, NULL, '1.0.0', 'FOUNDATION', 'WEEX'),
	('9999', '9999', '2018-05-29 11:56:57', '2018-05-29 12:01:59', 0, 'WEEX_SCAN_SDK', '扫码sdk(开源)(必选)', '扫描二维码sdk，便于扫码预览weex页面', NULL, NULL, '1.0.0', 'FOUNDATION', 'WEEX'),
	('9999', '9999', '2018-05-29 11:56:57', '2018-05-29 12:01:59', 0, 'WEEX_PICTURE_SDK', '图片库(默认实现必选，用户可自定义实现)', '实现图片加载显示的sdk，默认提供一个开源SDK，可自行替换实现方案', NULL, NULL, '1.0.0', 'FOUNDATION', 'WEEX'),
	('9999', '9999', '2018-05-29 11:56:57', '2018-05-29 12:01:59', 0, 'WEEX-NETWORK-SDK', '网络库(默认实现必选，用户可自定义实现)', '实现网络请求调用的sdk，默认提供一个开源SDK，可自行替换实现方案', NULL, NULL, '1.0.0', 'FOUNDATION', 'WEEX'),
	('9999', '9999', '2018-05-29 11:56:57', '2018-05-29 12:01:59', 0, 'WEEX_ZCACHE_SDK', 'ZCache sdk(必选)', '缓存weex页面js bundle的sdk，提高页面秒开率，提高用户体验', NULL, NULL, '1.0.0', 'FOUNDATION', 'WEEX'),
	('9999', '9999', '2018-05-29 11:56:57', '2018-05-29 12:01:59', 0, 'WEEX_UI_SDK', 'weex-ui sdk（bindingx）(可选)', '开源的weex ui组件sdk依赖bindingx sdk，实现手势等复杂交互操作以60fps的帧率流畅执行，可用于自定义实现高性能富交互的体验需求', NULL, NULL, '1.0.0', 'ADVANCE', 'WEEX'),
	('9999', '9999', '2018-05-29 11:56:57', '2018-05-29 12:01:59', 0, 'WEEX_BUSINESS_COMPONENTS', '商业组件SDK', NULL, NULL, NULL, '1.0.0', 'ADVANCE', 'WEEX'),
	('9999', '9999', '2018-05-29 11:56:57', '2018-05-29 12:01:59', 0, 'WEEX_BUSINESS_CHARTS', '商业图表SDK', NULL, NULL, NULL, '1.0.0', 'ADVANCE', 'WEEX');
COMMIT;