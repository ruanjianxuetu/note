USE `emas`;
/*
 Navicat Premium Data Transfer

 Source Server         : emas-daily
 Source Server Type    : MySQL
 Source Server Version : 50720
 Source Host           : 10.125.13.65:3306
 Source Schema         : emas

 Target Server Type    : MySQL
 Target Server Version : 50720
 File Encoding         : 65001

 Date: 15/01/2018 11:51:31
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for emas_user
-- ----------------------------
CREATE TABLE `emas_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `uid` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `real_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nickname` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `company` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile_phone` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telephone` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(127) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(127) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(4) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of emas_user
-- ----------------------------
BEGIN;
INSERT INTO `emas_user` VALUES (10000, '10000', '管理员', 'admin@alibaba-inc.com', '管理员', NULL, '15588888888', NULL, '0D656B9A310F9CEFE65CD6E953EEC7E7528849CE517BE20A74570A72799493A69C708D0C49BAD47038550F672500FE0C', NULL, 0, '2017-12-21 16:40:53', '2017-12-21 16:40:53');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;

