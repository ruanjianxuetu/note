USE `emas`;
-- GIT_LAB配置项替换为SCM_CONFIG

BEGIN;
INSERT INTO `emas_services_system_config`(gmt_create, gmt_modified, is_deleted, creator, modifier, config_namespace, config_key, config_value, description) VALUES
(now(), now(), '0', '10000', '10000', 'SCM_CONFIG', 'SCM_TYPE', 'GITLAB', null),
(now(), now(), '0', '10000', '10000', 'SCM_CONFIG', 'SCM_SITE', 'http://10.125.60.155', null),
(now(), now(), '0', '10000', '10000', 'SCM_CONFIG', 'SCM_TOKEN', 'gitlab-token', null),
(now(), now(), '0', '10000', '10000', 'SCM_CONFIG', 'SCM_VERSION', '/api/v3', null),

(now(), now(), '0', '10000', '10007', 'SCM_CONFIG', 'GIT_ANDROID_MAIN_DEMO', 'git@gitlab.emas-ha.cn:root/Android-EMAS-Demo.git', NULL),
(now(), now(), '0', '10000', '10007', 'SCM_CONFIG', 'GIT_ANDROID_MAIN_DEMO_BRANCH', 'master', NULL),
(now(), now(), '0', '10000', '10007', 'SCM_CONFIG', 'GIT_ANDROID_BUNDLE_DEMO', 'git@gitlab.emas-ha.cn:root/FirstBundle.git', NULL),
(now(), now(), '0', '10000', '10007', 'SCM_CONFIG', 'GIT_ANDROID_BUNDLE_DEMO_BRANCH', 'master', NULL),
(now(), now(), '0', '10000', '10007', 'SCM_CONFIG', 'GIT_IOS_MAIN_DEMO', 'git@gitlab.emas-ha.cn:root/EMASDemo.git', NULL),
(now(), now(), '0', '10000', '10007', 'SCM_CONFIG', 'GIT_IOS_MAIN_DEMO_BRANCH', 'master', NULL),
(now(), now(), '0', '10000', '10007', 'SCM_CONFIG', 'GIT_IOS_BUNDLE_DEMO', 'git@gitlab.emas-ha.cn:root/EMASFirstBundle.git', NULL),
(now(), now(), '0', '10000', '10007', 'SCM_CONFIG', 'GIT_IOS_BUNDLE_DEMO_BRANCH', 'master', NULL),

(now(), now(), '0', '10000', '10000', 'COCOAPODS', 'COCOAPODS_ADDRESS', 'git@gitlab.emas-ha.cn:root/emas-specs.git', null);
COMMIT;
