USE `emas`;
CREATE TABLE `emas_module` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(255) NOT NULL COMMENT '名称',
  `platform` varchar(255) NOT NULL COMMENT '平台',
  `module_type` varchar(255) NOT NULL COMMENT '模块类型',
  `scm_address` varchar(512) NOT NULL COMMENT '代码仓库',
  `dep_key` varchar(512) NOT NULL COMMENT '依赖key',
  `cocoapods_name` varchar(255) DEFAULT NULL,
  `group_id` varchar(255) DEFAULT NULL,
  `artifact_id` varchar(255) DEFAULT NULL,
  `gav_type` varchar(255) DEFAULT NULL,
  `description` varchar(2048) DEFAULT NULL COMMENT '简介',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` tinyint(4) NOT NULL COMMENT '是否删除',
  `creator` varchar(255) NOT NULL COMMENT '创建人',
  `modifier` varchar(255) NOT NULL COMMENT '修改人',
  `private_app_id` bigint(20) DEFAULT NULL COMMENT '私有应用ID',
  PRIMARY KEY (`id`),
  KEY `idx_dep_key` (`dep_key`) USING BTREE,
  KEY `idx_name` (`name`) USING BTREE,
  KEY `idx_platform` (`platform`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='模块表';
