USE `emas`;
# 将默认用户(ID=10000)设置为系统管理员和超级管理员, 请务必保证角色ID正确
insert into `emas_services_role_user` ( `gmt_create`, `gmt_modified`, `creator`, `modifier`, `is_deleted`, `user_id`, `role_id`, `role_context_id`) values ( now(), now(), '10000', '10000', '0', '10000', '50000000', '0');
insert into `emas_services_role_user` ( `gmt_create`, `gmt_modified`, `creator`, `modifier`, `is_deleted`, `user_id`, `role_id`, `role_context_id`) values ( now(), now(), '10000', '10000', '0', '10000', '50000018', '0');
