USE `emas`;
-- 增加产品环境标签
BEGIN;

ALTER TABLE emas_product ADD COLUMN is_hidden tinyint(2) NOT NULL DEFAULT 0 COMMENT '隐藏标记';
ALTER TABLE emas_app ADD COLUMN is_hidden tinyint(2) NOT NULL DEFAULT 0 COMMENT '隐藏标记';

COMMIT;