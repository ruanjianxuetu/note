USE `emas`;
-- license_item_config table is no longer needed
DROP TABLE emas_license_item_config;

-- added two new column for license table
ALTER TABLE emas_license ADD COLUMN user_quota INT NULL COMMENT 'License 允许的用户数';
ALTER TABLE emas_license ADD COLUMN license_type INT NULL COMMENT 'License 类型';
ALTER TABLE emas_license ADD COLUMN self_sign BLOB NOT NULL COMMENT 'License 签名';
