USE `emas`;
# 增加应用类别字段
ALTER TABLE emas_app
ADD COLUMN app_category VARCHAR(64) NOT NULL DEFAULT 'APP' COMMENT '应用类别';