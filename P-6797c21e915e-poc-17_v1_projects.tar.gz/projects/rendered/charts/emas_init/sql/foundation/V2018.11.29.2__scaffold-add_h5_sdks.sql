USE `emas`;
BEGIN;
-- 增加weex_sdks、h5_sdks字段，删除advance_sdks
alter table emas_weex_scaffold_config add `weex_sdks` varchar(500) DEFAULT NULL COMMENT '所有选中的weex sdk id，id从小到大排序，使用逗号连接';
alter table emas_weex_scaffold_config add `h5_sdks` varchar(500) DEFAULT NULL COMMENT '所有选中的h5 sdk id，id从小到大排序，使用逗号连接';
update emas_weex_scaffold_config set weex_sdks = advance_sdks;
alter table emas_weex_scaffold_config drop column advance_sdks;

-- 修改COMMENT
ALTER TABLE emas_app_scaffold_sdk MODIFY app_platform varchar(32) NOT NULL DEFAULT '' COMMENT '脚手架sdk平台类型，ANDROID,IOS,WEEX,H5';

-- 初始H5 SDKs
INSERT INTO `emas_app_scaffold_sdk` (`creator`, `modifier`, `gmt_create`, `gmt_modified`, `is_deleted`, `code_name`, `name`, `description`, `group_id`, `artifact_id`, `version`, `type`, `app_platform`)
VALUES
	('9999', '9999', '2018-11-06 12:00:00', '2018-11-06 12:00:00', 0, 'H5_CONTAINER_SDK', 'H5 容器SDK(必选)', '一款移动端Hybrid解决方案 SDK（Windvane SDK），提供了良好的外部扩展功能，拥有功能插件化、事件机制、JSAPI 定制', NULL, NULL, '1.0.0', 'FOUNDATION', 'H5'),
	('9999', '9999', '2018-11-06 12:00:00', '2018-11-06 12:00:00', 0, 'H5_SCAN_SDK', '扫码SDK(开源)(必选)', '扫描二维码sdk，便于扫码预览H5页面', NULL, NULL, '1.0.0', 'FOUNDATION', 'H5'),
	('9999', '9999', '2018-11-06 12:00:00', '2018-11-06 12:00:00', 0, 'H5_ZCACHE_SDK', 'ZCache SDK(必选)', '缓存H5页面相关资源的SDK，提高页面秒开率，提高用户体验', NULL, NULL, '1.0.0', 'FOUNDATION', 'H5');

-- 规范文案
update emas_app_scaffold_sdk set name=replace(name,'sdk','SDK'), description=replace(description,'sdk','SDK') where `app_platform` in ("WEEX", "H5");
update emas_app_scaffold_sdk set name=replace(name,'weex','Weex'), description=replace(description,'weex','Weex') where `app_platform` in ("WEEX", "H5");
update emas_app_scaffold_sdk set name=replace(name,'ui','UI'), description=replace(description,'ui','UI') where `app_platform` in ("WEEX", "H5");

COMMIT;