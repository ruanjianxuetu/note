USE `emas`;
alter table emas_app add secret_type varchar(20) not null default 'PUBLIC' comment '应用私密类型';
update emas_app set secret_type = 'PUBLIC' where secret_type is null or secret_type = '';
