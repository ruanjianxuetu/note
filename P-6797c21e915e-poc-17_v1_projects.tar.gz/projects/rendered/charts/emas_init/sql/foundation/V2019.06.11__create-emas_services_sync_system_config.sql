USE `emas`;
-- 增加同步服务配置项，只有部署同步服务时必须

BEGIN;

INSERT INTO `emas_services_system_config`(gmt_create, gmt_modified, is_deleted, creator, modifier, config_namespace, config_key, config_value, description, priority) VALUES
(now(), now(), '0', '10000', '10000', 'SYNC_CONFIG', 'SYNC_PROTOCOL', 'SFTP', null, 10),
(now(), now(), '0', '10000', '10000', 'SYNC_CONFIG', 'SYNC_HOST', '', null, 20),
(now(), now(), '0', '10000', '10000', 'SYNC_CONFIG', 'SYNC_PORT', '', null, 30),
(now(), now(), '0', '10000', '10000', 'SYNC_CONFIG', 'SYNC_USERNAME', '', null, 40),
(now(), now(), '0', '10000', '10000', 'SYNC_CONFIG', 'SYNC_PASSWORD', '', null, 50),
(now(), now(), '0', '10000', '10000', 'SYNC_CONFIG', 'SYNC_PATH', '', null, 60);

COMMIT;
