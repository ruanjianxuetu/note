USE `emas`;
UPDATE `emas_app_scaffold_sdk` SET `name` = '移动监控SDK' where `code_name` = 'HA SDK';