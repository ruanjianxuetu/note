USE `emas`;
BEGIN;

INSERT INTO `emas_app_scaffold_sdk` (`creator`, `modifier`, `gmt_create`, `gmt_modified`, `is_deleted`, `code_name`, `name`, `description`, `group_id`, `artifact_id`, `version`, `type`, `app_platform`)
VALUES
('9999', '9999', now(), now(), 0, 'NATIVE_SDK', 'Native 研发', '提供应用的完整APK更新能力', '', '', '1.0.0', 'ADVANCE', 'IOS');

COMMIT;