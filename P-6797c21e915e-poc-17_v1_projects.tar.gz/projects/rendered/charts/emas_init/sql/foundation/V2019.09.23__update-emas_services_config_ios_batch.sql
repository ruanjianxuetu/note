USE `emas`;
-- ios发布增加更新推送流程，更新service流程配置
BEGIN;

delete from `emas_native_service_category_conf` where `service`='upload';

-- ios应用增加更新推送支持
INSERT INTO `emas_native_service_category_conf` (`id`, `gmt_create`, `gmt_modified`, `is_deleted`, `service`)
VALUES
(137, now(), now(), 0, 'batch'),
(138, now(), now(), 0, 'batch');

INSERT INTO `emas_native_service_selective_conf` (`id`, `gmt_create`, `gmt_modified`, `is_deleted`, `menu_id`, `service_id`, `is_required`)
VALUES
(119, now(), now(), 0, 63, 137, 1),
(120, now(), now(), 0, 68, 138, 1);

-- android应用将渠道包构建从 upload 改为 channel_build
INSERT INTO `emas_native_service_category_conf` (`id`, `gmt_create`, `gmt_modified`, `is_deleted`, `service`)
VALUES
(79, now(), now(), 0, 'channel_build'),
(95, now(), now(), 0, 'channel_build');

COMMIT;
