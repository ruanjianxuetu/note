USE `emas`;
CREATE TABLE `emas_product` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建日期',
  `gmt_modified` datetime NOT NULL COMMENT '修改日期',
  `creator` varchar(255) NOT NULL COMMENT '创建人',
  `modifier` varchar(255) NOT NULL COMMENT '修改人',
  `is_deleted` tinyint(4) NOT NULL COMMENT '是否删除',
  `name` varchar(255) NOT NULL COMMENT '名称',
  `description` varchar(2048) DEFAULT NULL COMMENT '简介',
  `icon` varchar(1024) NOT NULL COMMENT '图标路径',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_name` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='产品表';
