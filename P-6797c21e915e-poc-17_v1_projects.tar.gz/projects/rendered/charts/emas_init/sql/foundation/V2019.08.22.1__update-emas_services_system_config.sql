USE `emas`;
BEGIN;
INSERT INTO `emas_services_system_config`(gmt_create, gmt_modified, is_deleted, creator, modifier, config_namespace, config_key, config_value, description) VALUES
(now(), now(), '0', '10000', '10000', 'OSS', 'OSS_STORAGE_TYPE', '', null);
COMMIT;
