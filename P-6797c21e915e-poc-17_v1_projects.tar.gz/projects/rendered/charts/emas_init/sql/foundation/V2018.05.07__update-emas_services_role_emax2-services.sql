USE `emas`;
# 新增MNAAS应用管理员角色
insert into `emas_services_role` ( `gmt_create`, `gmt_modified`, `creator`, `modifier`, `is_deleted`, `role_context`, `name`, `privileges`) values
(now(), now(), '10000', '10000', '0', 'MNAAS_APPLICATION', 'ADMIN', '[]');
