USE `emas`;
-- 增加应用扩展信息字段
BEGIN;

alter table `emas_app` add `extra_info` varchar(4096) NOT NULL DEFAULT '' comment '应用扩展信息';

COMMIT;