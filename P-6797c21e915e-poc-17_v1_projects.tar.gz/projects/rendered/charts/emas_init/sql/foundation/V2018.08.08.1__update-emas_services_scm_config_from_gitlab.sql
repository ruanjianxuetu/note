USE `emas`;
-- 使用GIT_LAB配置更新SCM_CONFIG

BEGIN;
update emas_services_system_config scm, (select config_value from emas_services_system_config where config_namespace="GIT_LAB" and config_key="GIT_LAB_SITE") gitlab
set scm.config_value = gitlab.config_value where scm.config_namespace="SCM_CONFIG" and scm.config_key="SCM_SITE";

update emas_services_system_config scm, (select config_value from emas_services_system_config where config_namespace="GIT_LAB" and config_key="GIT_LAB_PRIVATE_TOKEN") gitlab
set scm.config_value = gitlab.config_value where scm.config_namespace="SCM_CONFIG" and scm.config_key="SCM_TOKEN";
COMMIT;
