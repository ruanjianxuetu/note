USE `emas`;
-- 增加iOS应用发布类型
BEGIN;

alter table `emas_app` add `publish_type` varchar(30) default null comment '应用发布类型';
update `emas_app` set `publish_type` = 'APP_STORE' where `publish_type` is null and `platform` = 'IOS';

COMMIT;