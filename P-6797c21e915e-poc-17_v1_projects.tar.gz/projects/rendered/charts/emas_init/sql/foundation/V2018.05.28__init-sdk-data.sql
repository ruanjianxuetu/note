USE `emas`;
INSERT INTO `emas_app_scaffold_sdk` (`creator`, `modifier`, `gmt_create`, `gmt_modified`, `is_deleted`, `code_name`, `name`, `description`, `group_id`, `artifact_id`, `version`, `type`, `app_platform`)
VALUES
	('9999', '9999', '2018-05-28 11:05:02', '2018-05-28 11:05:02', 0, 'UPDATE SDK', '应用更新SDK', '提供应用的完整APK更新能力、动态部署更新/DexPatch补丁更新能力', '', '', '1.0.0', 'FOUNDATION', 'ANDROID'),
	('9999', '9999', '2018-05-28 11:08:25', '2018-05-28 11:08:25', 0, 'HA SDK', '高可用SDK', '提供客户端整个性能、稳定性监控分析，包括crash、性能、日志、埋点等等', '', '', '1.0.0', 'FOUNDATION', 'ANDROID'),
	('9999', '9999', '2018-05-28 11:08:26', '2018-05-28 11:08:26', 0, 'WEEX SDK', 'WeexSDK', '一套构建高新能、可扩展的原生应用跨平台开发方案', '', '', '1.0.0', 'FOUNDATION', 'ANDROID'),
	('9999', '9999', '2018-05-28 11:08:26', '2018-05-28 11:08:26', 0, 'ATLAS SDK', 'Atlas组件化框架', '提供组件化架构、动态部署、DexPatch热修复能力', '', '', '1.0.0', 'FOUNDATION', 'ANDROID'),
	('9999', '9999', '2018-05-28 11:09:16', '2018-05-28 11:09:16', 0, 'UPDATE SDK', '应用更新SDK', '提供应用的完整APK更新能力、动态部署更新/DexPatch补丁更新能力', '', '', '1.0.0', 'FOUNDATION', 'IOS'),
	('9999', '9999', '2018-05-28 11:09:16', '2018-05-28 11:09:16', 0, 'HA SDK', '高可用SDK', '提供客户端整个性能、稳定性监控分析，包括crash、性能、日志、埋点等等', '', '', '1.0.0', 'FOUNDATION', 'IOS'),
	('9999', '9999', '2018-05-28 11:09:16', '2018-05-28 11:09:16', 0, 'WEEX SDK', 'WeexSDK', '一套构建高新能、可扩展的原生应用跨平台开发方案', '', '', '1.0.0', 'FOUNDATION', 'IOS'),
	('9999', '9999', '2018-05-29 11:56:57', '2018-05-29 12:01:59', 1, 'TestSDK', '铭至测试2', 'test test test!', NULL, NULL, '1.0.0', 'ADVANCE', 'ANDROID');