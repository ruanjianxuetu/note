USE `emas`;
# 新增超级管理员角色
INSERT INTO `emas_services_role`(gmt_create, gmt_modified, creator, modifier, is_deleted, role_context, name, privileges) VALUES
(now(), now(), '10000', '10000', '0', 'BASE_SYSTEM', 'SUPER_ADMIN', '[]');
