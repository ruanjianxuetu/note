USE `emas`;
CREATE TABLE IF NOT EXISTS `emas_services_template_info` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `name` varchar(200)  COMMENT '模板名称',
  `content` MEDIUMTEXT NOT NULL COMMENT '模板内容(html/text)',
  `utid` varchar(200) COMMENT '用户自己上传的唯一id',
  `own_id` varchar(200) COMMENT '模板所有者(userId/自定义)',
  `is_deleted` smallint(6) NOT NULL DEFAULT false COMMENT '逻辑删除字段',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=50000000 COMMENT='存储模板文件的表';

CREATE TABLE IF NOT EXISTS `emas_services_notification_info` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `biz_code` varchar(50) NOT NULL DEFAULT "emas" COMMENT '业务方字段，区分不同的接入方',
  `category` varchar(50) COMMENT '打包，构建，发布...',
  `sender` varchar(200) NOT NULL COMMENT '发送者',
  `receiver` varchar(200) NOT NULL COMMENT '接收者(多个使用逗号分隔)',
  `type` smallint(6) NOT NULL COMMENT '通知类型(1:MAIL,2: DINGTALK)',
  `status` smallint(6) NOT NULL COMMENT '通知状态(1:WAITING,2:SENDING,3:DONE,4:EXCEPTION,5:TIMEOUT)',
  `subject` varchar(200) COMMENT '内容的标题(部分类型可以为空)',
  `template_id` varchar(200) COMMENT '通知关联的模板',
  `template_params` varchar(400) COMMENT '渲染模板的参数',
  `content` varchar(800) COMMENT '文本型形式的通知，不关联模板',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `is_deleted` smallint(6) NOT NULL DEFAULT false COMMENT '逻辑删除字段',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=50000000 COMMENT='保存通知发送记录和状态的表';

CREATE TABLE IF NOT EXISTS `emas_services_inbox_info` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `biz_code` varchar(200) NOT NULL DEFAULT "emas" COMMENT '业务方字段，区分不同的模块(Native,weex,高可用)',
  `category` varchar(50) COMMENT '消息的分类，如：打包/构建/发布',
  `ext` varchar(50) COMMENT '扩展属性，后续用来区分系统消息与用户消息',
  `sender` varchar(200) NOT NULL COMMENT '发送者',
  `receiver` varchar(200) NOT NULL COMMENT '接收者(多个使用逗号分隔)',
  `status` smallint(6) NOT NULL COMMENT '消息状态(1:未读,2:已读)',
  `subject` varchar(200) COMMENT '内容的标题(部分类型可以为空)',
  `template_id` varchar(200) COMMENT '通知关联的模板',
  `template_params` varchar(400) COMMENT '渲染模板的参数',
  `content` varchar(800) COMMENT '文本型形式的通知，不关联模板',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `is_deleted` smallint(6) NOT NULL DEFAULT false COMMENT '逻辑删除字段',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=50000000 COMMENT='站内信记录表';

INSERT INTO `emas_services_template_info` (`id`, `gmt_create`, `gmt_modified`, `name`, `content`, `utid`, `own_id`, `is_deleted`)
VALUES
  (10001, '2017-12-19 14:08:28', '2017-12-19 14:08:28', 'PUBLISH_REGRESSION_START_NOTIFY', '你的项目“[[${projectName}]]”正在参加“[[${appName}]]”“[[${version}]]”版本的集成回归，请抓紧时间开始回归。<a th:href=\"@{${url}}\">点此访问</a>。如已回归通过，忽略此消息', 'PUBLISH_REGRESSION_START_NOTIFY', 'emas-publish', 0);

INSERT INTO `emas_services_template_info` (`id`, `gmt_create`, `gmt_modified`, `name`, `content`, `utid`, `own_id`, `is_deleted`)
VALUES
  (10011, '2017-12-22 21:05:23', '2018-01-04 21:17:04', 'BUILD_WORKFLOW_NOTIFY', '您本次的构建结果为 [[${buildResult}]]，构建任务ID [[${taskId}]]。<a th:href=\"@{${url}}\">点此访问</a>。', 'BUILD_WORKFLOW_NOTIFY', 'shiran', 0);

INSERT INTO `emas_services_template_info` (`gmt_create`, `gmt_modified`, `name`, `content`, `utid`, `own_id`, `is_deleted`)
VALUES
  (now(), now(), 'HOTFIX_CREATE_APPLY_NOTIFY', '您的应用 [[${appName}]]_[[${platform}]]_[[${appVersion}]] 新建了热修复发布单: [[${patchVersion}]]，类型: [[${patchType}]]，描述: [[${description}]]。<a th:href="@{${url}}">点此访问</a>。', 'HOTFIX_CREATE_APPLY_NOTIFY', 'hotfix-service', 0);

INSERT INTO `emas_services_template_info` (`gmt_create`, `gmt_modified`, `name`, `content`, `utid`, `own_id`, `is_deleted`)
VALUES
  (now(), now(), 'HOTFIX_PUBLISH_FULL_AMOUNT_NOTIFY', '您的应用 [[${appName}]]_[[${platform}]]_[[${appVersion}]] 执行了热修复全量发布: [[${patchVersion}]], 类型: [[${patchType}]]，描述: [[${description}]]。<a th:href="@{${url}}">点此访问</a>。', 'HOTFIX_PUBLISH_FULL_AMOUNT_NOTIFY', 'hotfix-service', 0);