USE `emas`;
update emas_services_system_config set config_value = '365' where config_key = 'OSS_FILE_HOLD_TIME' and config_namespace = 'OSS';