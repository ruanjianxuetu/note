USE `emas`;
CREATE TABLE IF NOT EXISTS `emas_license` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP  COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `is_deleted` smallint(6) NOT NULL DEFAULT false COMMENT '逻辑删除字段',
  `name` varchar(128) COMMENT '租户名',
  `tenant_id` varchar(64) NOT NULL UNIQUE COMMENT '租户 ID',
  `issue_date` datetime NOT NULL COMMENT '公钥颁发日期',
  `pub_key` blob NOT NULL COMMENT '公钥内容',
  PRIMARY KEY (`id`),
  KEY `tenant_id_index` (`tenant_id`) USING btree
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=50000000 COMMENT='存储租户公钥';

CREATE TABLE IF NOT EXISTS `emas_license_item` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `is_deleted` smallint(6) NOT NULL DEFAULT false COMMENT '逻辑删除字段',
  `tenant_id` varchar(64) NOT NULL COMMENT '租户 ID',
  `item_code` varchar(64) NOT NULL COMMENT '产品模块 ID',
  `valid_date` datetime NOT NULL COMMENT '有效期到',
  `last_renew_date` datetime COMMENT '上次更新时间',
  `sign` blob NOT NULL COMMENT '签名',
  PRIMARY KEY (`id`),
  KEY `tenant_id_index` (`tenant_id`) USING btree
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=50000000 COMMENT='模块签名';