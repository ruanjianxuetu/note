USE `emas`;
CREATE TABLE IF NOT EXISTS `emas_license_item_config` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `is_deleted` smallint(6) NOT NULL DEFAULT false COMMENT '逻辑删除字段',
  `service` varchar(64) NOT NULL COMMENT '服务模块名',
  `item_code` varchar(64) NOT NULL COMMENT '产品模块 ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=50000000 COMMENT='服务模块与产品对应关系';

INSERT INTO emas_license_item_config (service, item_code)
VALUES
('emas-build', 'native'),
('emas-build', 'weex'),
('emas-meta-project', 'native'),
('emas-publish', 'native'),
('emas-pubserver', 'native'),
('emas-pubserver', 'weex'),
('emas-workflow', 'native'),
('emas-integration', 'native'),
('emas-data-service', 'native'),
('emas-mcs', 'native'),
('emas-mcs', 'native'),
('eweex-basic-manager', 'weex'),
('eweex-gray-publish-service', 'weex'),
('eweex-publish-manager', 'weex'),
('eweex-release-publish-service', 'weex'),
('eweex-test-manager', 'weex'),
('eweex-zcache-service', 'weex'),
('eweex-zcache-gate', 'weex'),
('ha-weex', 'weex'),
('hotfix-service', 'native'),
('hotfix-gate','native'),
('emas-ha', 'ha');
