USE `emas`;
UPDATE `emas_services_role` SET `privileges` = '[100001,100002,101001,101002,102001,102002,103001,103002,104001]'
WHERE `role_context` = 'BASE_SYSTEM' AND `name` = 'ADMIN';