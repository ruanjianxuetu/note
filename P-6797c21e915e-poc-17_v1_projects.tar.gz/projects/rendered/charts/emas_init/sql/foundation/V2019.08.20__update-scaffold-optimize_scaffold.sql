USE `emas`;
BEGIN;

update `emas_app_scaffold_sdk` set `code_name` = 'NATIVE_SDK', `name`='Native 研发', `description`='提供应用的完整APK更新能力', `gmt_modified`=now(), `type`='ADVANCE' where `code_name`='UPDATE SDK';
update `emas_app_scaffold_sdk` set `code_name` = 'HA_SDK', `name`='移动监控', `description`='提供客户端整个性能、稳定性监控分析，包括crash、性能、日志、埋点', `gmt_modified`=now(), `type`='ADVANCE' where `code_name`='HA SDK';
update `emas_app_scaffold_sdk` set `code_name` = 'WEEX_SDK', `name`='跨平台', `description`='一套构建高性能、可扩展的原生应用跨平台开发方案', `gmt_modified`=now(), `type`='ADVANCE' where `code_name`='WEEX SDK';

INSERT INTO `emas_app_scaffold_sdk` (`creator`, `modifier`, `gmt_create`, `gmt_modified`, `is_deleted`, `code_name`, `name`, `description`, `group_id`, `artifact_id`, `version`, `type`, `app_platform`)
    VALUES
    ('9999', '9999', now(), now(), 0, 'NETWOKRS_SDK', '网络库', '无线客户端网络基础库，主要实现SPDY、HTTP协议，应用内长链接，SSL加密等网络功能', '', '', '1.0.0', 'FOUNDATION', 'ANDROID'),
    ('9999', '9999', now(), now(), 0, 'NETWOKRS_SDK', '网络库', '无线客户端网络基础库，主要实现SPDY、HTTP协议，应用内长链接，SSL加密等网络功能', '', '', '1.0.0', 'FOUNDATION', 'IOS'),
    ('9999', '9999', now(), now(), 0, 'UT_SDK', 'UT通道', '针对手机无线客户端推出的一套专业的数据采集分析', '', '', '1.0.0', 'FOUNDATION', 'ANDROID'),
    ('9999', '9999', now(), now(), 0, 'UT_SDK', 'UT通道', '针对手机无线客户端推出的一套专业的数据采集分析', '', '', '1.0.0', 'FOUNDATION', 'IOS'),
    ('9999', '9999', now(), now(), 0, 'ZIP_SDK', '解压/压缩', '用于压缩和解压缩文件的简单实用程序工具', '', '', '1.0.0', 'FOUNDATION', 'ANDROID'),
    ('9999', '9999', now(), now(), 0, 'ZIP_SDK', '解压/压缩', '用于压缩和解压缩文件的简单实用程序工具', '', '', '1.0.0', 'FOUNDATION', 'IOS'),
    ('9999', '9999', now(), now(), 0, 'HOTFIX_SDK', '热修复', '提供实时修复APP已有bug的能力', '', '', '1.0.0', 'ADVANCE', 'ANDROID'),
    ('9999', '9999', now(), now(), 0, 'HOTFIX_SDK', '热修复', '提供实时修复APP已有bug的能力', '', '', '1.0.0', 'ADVANCE', 'IOS'),
    ('9999', '9999', now(), now(), 0, 'API_GATEWAY_SDK', 'API网关', '针对不同网络场景的性能优化、访问鉴权、防刷等网络服务能力', '', '', '1.0.0', 'ADVANCE', 'ANDROID'),
    ('9999', '9999', now(), now(), 0, 'API_GATEWAY_SDK', 'API网关', '针对不同网络场景的性能优化、访问鉴权、防刷等网络服务能力', '', '', '1.0.0', 'ADVANCE', 'IOS'),
    ('9999', '9999', now(), now(), 0, 'ACCS_SDK', '通道服务', '提供全双工、低延时、高安全的通道', '', '', '1.0.0', 'ADVANCE', 'ANDROID'),
    ('9999', '9999', now(), now(), 0, 'ACCS_SDK', '通道服务', '提供全双工、低延时、高安全的通道', '', '', '1.0.0', 'ADVANCE', 'IOS'),
    ('9999', '9999', now(), now(), 0, 'PUSH_SDK', '推送服务', '提供自有通道和厂商通道能力', '', '', '1.0.0', 'ADVANCE', 'ANDROID'),
    ('9999', '9999', now(), now(), 0, 'PUSH_SDK', '推送服务', '提供自有通道和厂商通道能力', '', '', '1.0.0', 'ADVANCE', 'IOS'),
    ('9999', '9999', now(), now(), 0, 'ORANGE_SDK', '远程配置', '提供配置的下发、更新能力', '', '', '1.0.0', 'ADVANCE', 'ANDROID'),
    ('9999', '9999', now(), now(), 0, 'ORANGE_SDK', '远程配置', '提供配置的下发、更新能力', '', '', '1.0.0', 'ADVANCE', 'IOS');

COMMIT;