USE `emas`;
BEGIN;

insert into emas_services_privilege (code, context_type, name) values (106007, "BASE", "BASE_PRODUCT_APP_CREATE");

insert into `emas_services_privilege_tree`  (is_deleted,role_key,category,category_priority,privilege_name,privilege_priority) values (0,'BASE_SYSTEM@ADMIN','BASE_SYSTEM_ROOT',10,'BASE_PRODUCT_APP_CREATE',10);

insert into `emas_services_privilege_tree`  (is_deleted,role_key,category,category_priority,privilege_name,privilege_priority) values (0,'BASE_SYSTEM@NORMAL','BASE_SYSTEM_ROOT',10,'BASE_PRODUCT_APP_CREATE',10);

insert into `emas_services_privilege_tree`  (is_deleted,role_key,category,category_priority,privilege_name,privilege_priority) values (0,'FOUNDATION_APPLICATION@ADMIN','BASE_APPLICATION_ROOT',10,'BASE_PRODUCT_APP_READ',10);
insert into `emas_services_privilege_tree`  (is_deleted,role_key,category,category_priority,privilege_name,privilege_priority) values (0,'FOUNDATION_APPLICATION@ADMIN','BASE_APPLICATION_ROOT',10,'BASE_PRODUCT_APP_MODIFY',10);

insert into `emas_services_privilege_tree`  (is_deleted,role_key,category,category_priority,privilege_name,privilege_priority) values (0,'FOUNDATION_APPLICATION@DEV','BASE_APPLICATION_ROOT',10,'BASE_PRODUCT_APP_READ',10);

insert into `emas_services_privilege_tree`  (is_deleted,role_key,category,category_priority,privilege_name,privilege_priority) values (0,'FOUNDATION_APPLICATION@TEST','BASE_APPLICATION_ROOT',10,'BASE_PRODUCT_APP_READ',10);

delete from `emas_services_privilege_tree` where privilege_name in ("WEEX_BUILD_TRIGGER", "WEEX_RESOURCE_EDIT", "WEEX_RESOURCE_ADD");

update `emas_services_role` set  privileges = "[304003,305004,501002,305001,305002,501001,305003,302002,302003,303004,303002,303003]" where  role_context="WEEX_MODULE" and name = "ADMIN";

update `emas_services_role` set  privileges = "[304003,305004,501002,305001,305002,501001,305003,303004,303002,303003]" where  role_context="WEEX_MODULE" and name = "DEV";


update `emas_services_role` set privileges="[102001,102002,106007]" where role_context="BASE_SYSTEM" and name = "NORMAL";
update `emas_services_role` set privileges="[100001,104001,100002,105001,101001,105003,101002,105002,102001,106002,102002,106005,106006,103001,103002,106007]" where role_context="BASE_SYSTEM" and name = "ADMIN";

insert into emas_services_role (gmt_create,gmt_modified,creator,modifier,role_context,name,privileges,is_deleted) values (now(), now(), 1000, 1000, "FOUNDATION_APPLICATION", "ADMIN", "[102001,102002]", 0);
insert into emas_services_role (gmt_create,gmt_modified,creator,modifier,role_context,name,privileges,is_deleted) values (now(), now(), 1000, 1000, "FOUNDATION_APPLICATION", "DEV", "[102001]", 0);
insert into emas_services_role (gmt_create,gmt_modified,creator,modifier,role_context,name,privileges,is_deleted) values (now(), now(), 1000, 1000, "FOUNDATION_APPLICATION", "TEST", "[102001]", 0);

COMMIT;