use emas;
UPDATE `emas_services_role` SET gmt_modified=now(), privileges='[701001,701002,701003,701004,701005,701006,701007,701008,701009,701010,701011,701012,701013,701014,701015,701016,701017]' where role_context = 'WPK_PROJECT' and `name` = 'ADMIN';
UPDATE `emas_services_role` SET gmt_modified=now(), privileges='[701004,701005,701006,701007,701008,701009,701010,701012,701013,701014,701015,701016,701017]' where role_context = 'WPK_PROJECT' and `name` = 'DEVELOPER';
UPDATE `emas_services_role` SET gmt_modified=now(), privileges='[701004,701005,701006,701007,701008,701009,701010,701012,701013,701014,701015,701016,701017]' where role_context = 'WPK_PROJECT' and `name` = 'TESTER';
