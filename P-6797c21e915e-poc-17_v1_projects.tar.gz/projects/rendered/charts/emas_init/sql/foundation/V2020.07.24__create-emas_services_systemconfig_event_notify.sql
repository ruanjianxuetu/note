USE `emas`;
-- 增加HTTP event notify systemconfig 配置项

BEGIN;

INSERT INTO `emas_services_system_config` (`gmt_create`, `gmt_modified`, `is_deleted`, `creator`, `modifier`, `config_namespace`, `config_key`, `config_value`, `description`, `priority`)
VALUES
	(now(), now(), 0, '10000', '10000', 'EVENT_NOTIFY', 'NOTIFY_SECRET', '', NULL, 30),
	(now(), now(), 0, '10000', '10000', 'EVENT_NOTIFY', 'NOTIFY_URL', '', NULL, 20),
	(now(), now(), 0, '10000', '10000', 'EVENT_NOTIFY', 'NOTIFY_ENABLE', 'false', NULL, 10);

COMMIT;
