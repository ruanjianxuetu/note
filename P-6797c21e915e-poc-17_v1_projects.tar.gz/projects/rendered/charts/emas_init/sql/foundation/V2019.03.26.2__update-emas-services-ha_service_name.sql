USE `emas`;
UPDATE `emas_global_constants` SET `name` = '移动监控' where `value` = 'HA';