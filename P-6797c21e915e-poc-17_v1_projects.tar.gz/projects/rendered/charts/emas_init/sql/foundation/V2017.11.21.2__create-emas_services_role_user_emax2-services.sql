USE `emas`;
CREATE TABLE `emas_services_role_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `creator` varchar(32) NOT NULL COMMENT '创建人',
  `modifier` varchar(32) NOT NULL COMMENT '修改人',
  `is_deleted` tinyint(4) NOT NULL COMMENT '删除标记',
  `user_id` varchar(32) NOT NULL COMMENT '用户ID',
  `role_id` bigint(20) NOT NULL COMMENT '角色ID',
  `role_context_id` bigint(20) NOT NULL COMMENT '上下文ID',
  PRIMARY KEY (`id`),
  KEY `idx_context_id` (`role_context_id`) USING BTREE,
  KEY `idx_role_id` (`role_id`) USING BTREE,
  KEY `idx_user_id` (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='用户权限关系表';

