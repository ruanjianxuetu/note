USE `emas`;
CREATE TABLE IF NOT EXISTS `emas_global_constants` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `type` varchar(200) NOT NULL COMMENT '常量的分类',
  `name` varchar(200) NOT NULL COMMENT '常量名称',
  `value` varchar(200) NOT NULL COMMENT '常量值',
  `is_deleted` smallint(6) NOT NULL DEFAULT false COMMENT '逻辑删除字段',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=50000000 COMMENT='存储模板文件的表';