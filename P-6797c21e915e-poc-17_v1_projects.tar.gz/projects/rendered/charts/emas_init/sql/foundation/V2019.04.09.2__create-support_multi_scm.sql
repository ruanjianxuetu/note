USE `emas`;
BEGIN;
-- 增加 MULTI_SCM
INSERT INTO `emas_services_system_config` (`gmt_create`, `gmt_modified`, `is_deleted`, `creator`, `modifier`, `config_namespace`, `config_key`, `config_value`, `description`)
VALUES
(now(), now(), 0, '0', '0', 'SCM_CONFIG', 'MULTI_SCM', '', NULL);
UPDATE emas_services_system_config scm,
  (select config_value from emas_services_system_config where config_namespace="SCM_CONFIG" and config_key="SCM_TYPE") scm_type,
  (select config_value from emas_services_system_config where config_namespace="SCM_CONFIG" and config_key="SCM_SITE") scm_site,
  (select config_value from emas_services_system_config where config_namespace="SCM_CONFIG" and config_key="SCM_TOKEN") scm_token,
  (select config_value from emas_services_system_config where config_namespace="SCM_CONFIG" and config_key="SCM_VERSION") scm_version
set scm.config_value = concat('[{\"scm_type\": \"', scm_type.config_value, '\", \"scm_site\": \"', scm_site.config_value, '\", \"token\": \"', scm_token.config_value, '\", \"api_version\": \"', scm_version.config_value, '\" }]')
where scm.config_namespace="SCM_CONFIG" and scm.config_key="MULTI_SCM";

-- 增加 cocoapods SCM_TYPE
INSERT INTO `emas_services_system_config` (`gmt_create`, `gmt_modified`, `is_deleted`, `creator`, `modifier`, `config_namespace`, `config_key`, `config_value`, `description`)
VALUES (now(), now(), 0, '0', '0', 'COCOAPODS', 'COCOAPODS_SCM_TYPE', '', NULL);
UPDATE emas_services_system_config scm, (select config_value from emas_services_system_config where config_namespace="SCM_CONFIG" and config_key="SCM_TYPE") pods
set scm.config_value = pods.config_value where scm.config_namespace="COCOAPODS" and scm.config_key="COCOAPODS_SCM_TYPE";

-- 标记历史数据为删除状态
UPDATE emas_services_system_config set is_deleted=1 where config_key in ('SCM_TYPE', 'SCM_SITE', 'SCM_TOKEN', 'SCM_VERSION');

COMMIT;