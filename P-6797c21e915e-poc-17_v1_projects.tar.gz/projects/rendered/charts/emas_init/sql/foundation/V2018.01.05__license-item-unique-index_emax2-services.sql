USE `emas`;
ALTER TABLE `emas_license_item`
ADD UNIQUE INDEX `tenant_id_item_code_unique` (`tenant_id` ASC, `item_code` ASC);

ALTER TABLE `emas_license_item`
DROP INDEX `tenant_id_index` ;
