USE `emas`;
# MNAAS应用管理员权限配置
insert into `emas_services_privilege_tree` ( `is_deleted`, `role_key`, `category`, `category_priority`, `privilege_name`, `privilege_priority`)
values(0, 'MNAAS_APPLICATION@ADMIN', null, 10, 'NATIVE_APP_VIEW_SECRET', 10);