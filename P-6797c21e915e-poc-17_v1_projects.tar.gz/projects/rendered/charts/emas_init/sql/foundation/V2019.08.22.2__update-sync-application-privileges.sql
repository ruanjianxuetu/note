USE `emas`;
BEGIN;
delete from emas_services_role where role_context = 'HA_APPLICATION' and name = 'USER';
update emas_services_role set privileges = '[]' where role_context = 'WEEX_APPLICATION' and name = 'ADMIN';

delete from emas_services_role_user where role_id not in (select id from emas_services_role);

INSERT INTO `emas_services_role`(gmt_create, gmt_modified, creator, modifier, is_deleted, role_context, name, privileges) VALUES
(now(), now(), '10000', '10000', '0', 'WEEX_APPLICATION', 'DEV', '[]'),
(now(), now(), '10000', '10000', '0', 'WEEX_APPLICATION', 'TEST', '[]'),
(now(), now(), '10000', '10000', '0', 'HA_APPLICATION', 'DEV', '[]'),
(now(), now(), '10000', '10000', '0', 'HA_APPLICATION', 'TEST', '[]'),
(now(), now(), '10000', '10000', '0', 'MNAAS_APPLICATION', 'DEV', '[]'),
(now(), now(), '10000', '10000', '0', 'MNAAS_APPLICATION', 'TEST', '[]'),
(now(), now(), '10000', '10000', '0', 'AGOO_APPLICATION', 'DEV', '[]'),
(now(), now(), '10000', '10000', '0', 'AGOO_APPLICATION', 'TEST', '[]');
COMMIT;
