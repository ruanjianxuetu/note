USE `emas`;
BEGIN;
ALTER TABLE emas_workflow_process ADD COLUMN callback_url VARCHAR(1024) COMMENT '审批结束之后的回调地址';
COMMIT;
