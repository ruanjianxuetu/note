USE `emas`;
alter table emas_module add module_dep_type varchar(20) not null comment '模块依赖类型';
update emas_module set module_dep_type = 'SOURCE_DEP' where module_dep_type is null or module_dep_type = '';
alter table emas_module modify scm_address varchar(512);
