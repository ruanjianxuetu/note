USE `emas`;
INSERT INTO emas_license_item_config (service, item_code)
VALUES
('emas-meta-project', 'hotfix'),
('emas-pubserver', 'hotfix');

UPDATE emas_license_item_config SET item_code = 'hotfix'
WHERE service in ('hotfix-service', 'hotfix-gate');

