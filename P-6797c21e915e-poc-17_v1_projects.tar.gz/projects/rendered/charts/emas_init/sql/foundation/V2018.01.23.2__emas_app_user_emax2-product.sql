USE `emas`;
CREATE TABLE `emas_app_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `creator` varchar(255) NOT NULL COMMENT '创建人',
  `modifier` varchar(255) NOT NULL COMMENT '修改人',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` tinyint(4) NOT NULL COMMENT '是否删除',
  `app_id` bigint(20) NOT NULL COMMENT '应用ID',
  `user_id` varchar(255) NOT NULL COMMENT '用户ID',
  `role_context` varchar(50) NOT NULL COMMENT '角色上下文',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`) USING BTREE,
  KEY `idx_app_id` (`app_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='应用用户关系表';
