use emas;
INSERT INTO `emas_services_privilege` (`code`, `context_type`, `name`) VALUES 
('701015', 'WPK', 'setting:monitor:add'),
('701016', 'WPK', 'setting:monitor:edit'),
('701017', 'WPK', 'h5:health');
