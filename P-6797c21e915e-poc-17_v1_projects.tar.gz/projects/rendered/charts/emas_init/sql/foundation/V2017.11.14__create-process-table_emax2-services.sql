USE `emas`;
CREATE TABLE IF NOT EXISTS `emas_workflow_process` (
  `id` BIGINT(16) NOT NULL AUTO_INCREMENT,
  `status` INT NOT NULL DEFAULT 0 COMMENT '状态枚举',
  `category` VARCHAR(64) COMMENT '分类',
  `biz_code` VARCHAR(64) COMMENT '大模块分类',
  `creator` VARCHAR(64) NOT NULL COMMENT '发起者',
  `created_at` DATETIME NOT NULL COMMENT '发起时间',
  `context_id` BIGINT COMMENT '上下文 ID',
  `context_type` VARCHAR(16) NOT NULL COMMENT '上下文类型',
  `source_id` VARCHAR(64) COMMENT '来源任务 ID',
  `description` VARCHAR(1024) NOT NULL COMMENT '描述',
  `title` VARCHAR(256) NOT NULL COMMENT '审批流程标题',
  `modifier` VARCHAR(64) COMMENT '流程审批人',
  `finished_at` DATETIME COMMENT '结束时间',
  `modifier_comment` VARCHAR(1024) COMMENT '审批备注',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_deleted` bool DEFAULT false,
  PRIMARY KEY(`id`),
  KEY `by_creator` (`creator`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=50000000 COMMENT='流程表';

CREATE TABLE IF NOT EXISTS `emas_workflow_process_assignee` (
  `id` BIGINT(16) NOT NULL AUTO_INCREMENT,
  `process_id` BIGINT(16) NOT NULL,
  `assignee` VARCHAR(64) NOT NULL,
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_deleted` bool DEFAULT false,
  PRIMARY KEY (`id`),
  KEY `by_process_id` (`process_id`),
  KEY `by_assignee` (`assignee`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=50000000 COMMENT='流程审批人表';

