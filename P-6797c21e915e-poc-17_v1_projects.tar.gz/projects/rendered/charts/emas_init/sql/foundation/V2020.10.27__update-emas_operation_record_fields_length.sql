use emas;
BEGIN;

-- 延长日志记录字段长度
ALTER TABLE `emas_operation_record` CHANGE `old_value` `old_value` VARCHAR(5000) NULL DEFAULT NULL COMMENT '旧值';
ALTER TABLE `emas_operation_record` CHANGE `new_value` `new_value` VARCHAR(5000) NULL DEFAULT NULL COMMENT '新值';
ALTER TABLE `emas_operation_record` CHANGE `message` `message` VARCHAR(5000)  NULL DEFAULT NULL COMMENT '操作说明';

COMMIT;