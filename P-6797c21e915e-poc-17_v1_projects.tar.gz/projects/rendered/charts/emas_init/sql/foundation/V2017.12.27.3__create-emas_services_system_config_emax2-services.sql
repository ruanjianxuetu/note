USE `emas`;
CREATE TABLE `emas_services_system_config` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` tinyint(4) NOT NULL COMMENT '是否已删除',
  `creator` varchar(255) NOT NULL COMMENT '创建人',
  `modifier` varchar(255) NOT NULL COMMENT '修改人',
  `config_namespace` varchar(255) NOT NULL COMMENT '配置命名空间',
  `config_key` varchar(255) NOT NULL COMMENT '配置键',
  `config_value` varchar(1024) NOT NULL COMMENT '配置值',
  `description` varchar(1024) DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`id`),
  KEY `idx_config_key` (`config_key`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='基座服务-系统配置';

BEGIN;
INSERT INTO `emas_services_system_config`(gmt_create, gmt_modified, is_deleted, creator, modifier, config_namespace, config_key, config_value, description) VALUES
(now(), now(), '0', '10000', '10000', 'OSS', 'OSS_ACCESS_KEY_ID', 'LTAIlcWIBa3wXmqa', null),
(now(), now(), '0', '10000', '10000', 'OSS', 'OSS_SECRET_ACCESS_KEY', 'iZBry9UKtKOYWChi4qHVVCxp2eLeoF', null),
(now(), now(), '0', '10000', '10000', 'OSS', 'OSS_END_POINT', 'oss-cn-shenzhen.aliyuncs.com', null),
(now(), now(), '0', '10000', '10000', 'OSS', 'OSS_BUCKET', 'mobile-hub-dev-packagefiles', null),
(now(), now(), '0', '10000', '10000', 'OSS', 'OSS_FILE_HOLD_TIME', '50', null),

(now(), now(), '0', '10000', '10000', 'SYSTEM', 'SYSTEM_ACCESS_KEY', 'LTAIucMH1DWHuEYi', null),
(now(), now(), '0', '10000', '10000', 'SYSTEM', 'SYSTEM_ACCESS_KEY_SECRET', 'Vsd5WnmAkE9LL9iw9hUFUg7c3aSE3a', null),

(now(), now(), '0', '10000', '10000', 'NEXUS', 'NEXUS_REPO_ADDRESS', 'http://10.125.65.140:8081/nexus', null),
(now(), now(), '0', '10000', '10000', 'NEXUS', 'NEXUS_USER_NAME', 'mhub', null),
(now(), now(), '0', '10000', '10000', 'NEXUS', 'NEXUS_USER_PASSWORD', '1234567', null),
(now(), now(), '0', '10000', '10000', 'NEXUS', 'NEXUS_REPO_ID', 'releases', null),

(now(), now(), '0', '10000', '10000', 'GIT_LAB', 'GIT_LAB_SITE', 'http://10.125.60.155', null),
(now(), now(), '0', '10000', '10000', 'GIT_LAB', 'GIT_LAB_PRIVATE_TOKEN', 'QqnvjXfQco2FpFvTS7Py', null),
(now(), now(), '0', '10000', '10000', 'GIT_LAB', 'GIT_LAB_PROJECT_ID', '11', null),
(now(), now(), '0', '10000', '10000', 'GIT_LAB', 'GIT_LAB_API_VERSION', '/api/v3', null),

(now(), now(), '0', '10000', '10000', 'COCOAPODS', 'COCOAPODS_SITE', 'http://10.125.60.155', null),
(now(), now(), '0', '10000', '10000', 'COCOAPODS', 'COCOAPODS_PRIVATE_TOKEN', 'QqnvjXfQco2FpFvTS7Py', null),
(now(), now(), '0', '10000', '10000', 'COCOAPODS', 'COCOAPODS_PROJECT_ID', '11', null),
(now(), now(), '0', '10000', '10000', 'COCOAPODS', 'COCOAPODS_API_VERSION', '/api/v3', null),

(now(), now(), '0', '10000', '10000', 'CDN', 'CDN_DOMAIN', 'http://mobilehubdev.taobao.com', null),
(now(), now(), '0', '10000', '10000', 'CDN', 'CDN_OSS_BUCKET', 'mobile-hub-dev', null);
COMMIT;
