USE `emas`;
-- 增加日志操作记录
BEGIN;
CREATE TABLE `emas_operation_record` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `uuid` varchar(32) NOT NULL COMMENT '操作记录唯一标识',
  `app_key` varchar(31) DEFAULT NULL COMMENT 'appKey',
  `biz_name` varchar(20) NOT NULL COMMENT '所属业务名称',
  `object_type` varchar(63) DEFAULT NULL COMMENT '操作对象类型',
  `object_id` varchar(63) DEFAULT NULL COMMENT '操作对象id',
  `action` varchar(63) NOT NULL COMMENT '操作动作',
  `operator` varchar(31) NOT NULL COMMENT '操作人',
  `old_value` varchar(1023) DEFAULT NULL COMMENT '旧值',
  `new_value` varchar(1023) DEFAULT NULL COMMENT '新值',
  `message` varchar(4095) DEFAULT NULL COMMENT '操作说明',
  `gmt_create` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_biz_name` (`biz_name`),
  KEY `idx_biz_name_action` (`biz_name`, `action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户操作记录表';
COMMIT;
