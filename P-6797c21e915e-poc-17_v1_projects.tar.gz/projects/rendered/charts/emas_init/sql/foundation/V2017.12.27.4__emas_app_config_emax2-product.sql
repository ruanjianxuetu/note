USE `emas`;
CREATE TABLE `emas_app_config` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` tinyint(4) NOT NULL COMMENT '是否删除',
  `creator` varchar(255) NOT NULL COMMENT '创建人',
  `modifier` varchar(255) NOT NULL COMMENT '修改嗯',
  `app_id` bigint(20) NOT NULL COMMENT '应用ID',
  `scm_address` varchar(255) DEFAULT NULL COMMENT '仓库地址',
  `scm_branch` varchar(255) DEFAULT NULL COMMENT '仓库分支',
  PRIMARY KEY (`id`),
  KEY `idx_app_id` (`app_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='应用配置表';
