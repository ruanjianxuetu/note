USE `emas`;
-- 去掉Native项目中的自动化测试流程
BEGIN;

update `emas_native_service_selective_conf` set `is_deleted` = 1 where `id` in (49, 71, 89, 106);

COMMIT;
