USE `emas`;
delete from emas_app_scaffold_sdk where code_name = 'ATLAS SDK';
UPDATE  `emas_app_scaffold_sdk` SET description = '提供客户端应用整包发布更新的端侧能力支持' WHERE code_name = 'UPDATE SDK' and app_platform = 'ANDROID';

UPDATE `emas_services_system_config` SET config_value = 'dev_aar' where config_key = 'GIT_ANDROID_BUNDLE_DEMO_BRANCH';
UPDATE `emas_services_system_config` SET config_value = 'dev_poc_light' where config_key = 'GIT_ANDROID_MAIN_DEMO_BRANCH';
UPDATE `emas_services_system_config` SET config_value = 'dev_poc' where config_key = 'GIT_IOS_MAIN_DEMO_BRANCH';
