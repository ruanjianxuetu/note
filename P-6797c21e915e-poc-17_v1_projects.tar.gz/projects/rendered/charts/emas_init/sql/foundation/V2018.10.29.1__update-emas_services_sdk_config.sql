USE `emas`;
BEGIN;
INSERT INTO `emas_services_system_config`(gmt_create, gmt_modified, is_deleted, creator, modifier, config_namespace, config_key, config_value, description) VALUES
(now(), now(), '0', '10000', '10000', 'SDK_CONFIG', 'ORANGE_DOMAIN', '', null),
(now(), now(), '0', '10000', '10000', 'SDK_CONFIG', 'GATEWAY_DOMAIN', '', null);
COMMIT;
