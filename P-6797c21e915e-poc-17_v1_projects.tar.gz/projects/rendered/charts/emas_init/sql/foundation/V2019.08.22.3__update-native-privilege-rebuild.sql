USE `emas`;
BEGIN;
delete from emas_services_role where role_context = 'NATIVE_PROJECT' and name = 'TEST';
delete from emas_services_role where role_context = 'NATIVE_PROJECT' and name = 'DEPLOY';
delete from emas_services_role where role_context = 'NATIVE_MODULE';
delete from emas_services_role where role_context = 'NATIVE_PUBLISH_DOC';

delete from emas_services_privilege where context_type = 'NATIVE';

delete from emas_services_privilege_tree where role_key = 'NATIVE_INTG_AREA@ADMIN';
delete from emas_services_privilege_tree where role_key = 'NATIVE_APPLICATION@ADMIN';
delete from emas_services_privilege_tree where role_key = 'NATIVE_PUBLISH_DOC@ADMIN';
delete from emas_services_privilege_tree where role_key = 'NATIVE_APPLICATION@DEV';
delete from emas_services_privilege_tree where role_key = 'NATIVE_PROJECT@ADMIN';
delete from emas_services_privilege_tree where role_key = 'NATIVE_PROJECT@TEST';
delete from emas_services_privilege_tree where role_key = 'NATIVE_PROJECT@DEV';
delete from emas_services_privilege_tree where role_key = 'NATIVE_MODULE@ADMIN';
delete from emas_services_privilege_tree where role_key = 'NATIVE_APPLICATION@TEST';


update emas_services_role set privileges = '[200001,200002,200003,200004,200005,200006,200007,200008,200009,200010,200011,200012,200013,200014,200015,200016]' where role_context = 'NATIVE_APPLICATION' and name = 'ADMIN';
update emas_services_role set privileges = '[200001,200002,200003,200004,200005,200006,200007,200008,200009,200010,200011,200012,200014]' where role_context = 'NATIVE_APPLICATION' and name = 'DEV';
update emas_services_role set privileges = '[200013]' where role_context = 'NATIVE_APPLICATION' and name = 'TEST';
update emas_services_role set privileges = '[200002,200003,200004,200005,200006,200007,200008]' where role_context = 'NATIVE_PROJECT' and name = 'ADMIN';
update emas_services_role set privileges = '[200003,200004,200005,200006,200007,200008]' where role_context = 'NATIVE_PROJECT' and name = 'DEV';
update emas_services_role set privileges = '[200004,200006,200008,200010]' where role_context = 'NATIVE_INTG_AREA' and name = 'ADMIN';

insert into emas_services_privilege(code, context_type, name) values (200001,'NATIVE','NATIVE_PROJECT_CREATE');
insert into emas_services_privilege(code, context_type, name) values (200002,'NATIVE','NATIVE_PROJECT_ALTER');
insert into emas_services_privilege(code, context_type, name) values (200003,'NATIVE','NATIVE_PROJECT_CHANGE');
insert into emas_services_privilege(code, context_type, name) values (200004,'NATIVE','NATIVE_DEPENDENCY_MANAGE');
insert into emas_services_privilege(code, context_type, name) values (200005,'NATIVE','NATIVE_PROJECT_INTEGRATION_DOC');
insert into emas_services_privilege(code, context_type, name) values (200006,'NATIVE','NATIVE_BUILD_CONFIG');
insert into emas_services_privilege(code, context_type, name) values (200007,'NATIVE','NATIVE_PROJECT_DEPLOY');
insert into emas_services_privilege(code, context_type, name) values (200008,'NATIVE','NATIVE_PUBLISH_PROJECT_DOC');
insert into emas_services_privilege(code, context_type, name) values (200009,'NATIVE','NATIVE_INTG_CREATE');
insert into emas_services_privilege(code, context_type, name) values (200010,'NATIVE','NATIVE_INTG_MANAGE');
insert into emas_services_privilege(code, context_type, name) values (200011,'NATIVE','NATIVE_PUBLISH_MANAGE');
insert into emas_services_privilege(code, context_type, name) values (200012,'NATIVE','NATIVE_PUBLISH_CHANNEL_PACKAGE_MANAGE');
insert into emas_services_privilege(code, context_type, name) values (200013,'NATIVE','NATIVE_PUBLISH_REGRESSION');
insert into emas_services_privilege(code, context_type, name) values (200014,'NATIVE','NATIVE_PUBLISH_OUTCOME_MANAGE');
insert into emas_services_privilege(code, context_type, name) values (200015,'NATIVE','NATIVE_PUBLISH_PUSH_MANAGE');
insert into emas_services_privilege(code, context_type, name) values (200016,'NATIVE','NATIVE_GENERAL_CONFIG');

INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_INTG_AREA@ADMIN', 'NATIVE_INTG_DOC_ROOT', 10, 'NATIVE_DEPENDENCY_MANAGE', 10);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_INTG_AREA@ADMIN', 'NATIVE_INTG_DOC_ROOT', 10, 'NATIVE_BUILD_CONFIG', 20);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_INTG_AREA@ADMIN', 'NATIVE_INTG_DOC_ROOT', 10, 'NATIVE_PUBLISH_PROJECT_DOC', 30);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_INTG_AREA@ADMIN', 'NATIVE_INTG_DOC_ROOT', 10, 'NATIVE_INTG_MANAGE', 40);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@ADMIN', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_PROJECT_CREATE', 10);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@ADMIN', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_PROJECT_ALTER', 20);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@ADMIN', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_PROJECT_CHANGE', 30);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@ADMIN', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_DEPENDENCY_MANAGE', 40);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@ADMIN', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_PROJECT_INTEGRATION_DOC', 50);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@ADMIN', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_BUILD_CONFIG', 60);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@ADMIN', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_PROJECT_DEPLOY', 70);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@ADMIN', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_PUBLISH_PROJECT_DOC', 80);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@ADMIN', 'NATIVE_INTG_DOC_ROOT', 20, 'NATIVE_INTG_CREATE', 10);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@ADMIN', 'NATIVE_INTG_DOC_ROOT', 20, 'NATIVE_INTG_MANAGE', 20);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@ADMIN', 'NATIVE_APP_CONFIG_ROOT', 30, 'NATIVE_PUBLISH_MANAGE', 10);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@ADMIN', 'NATIVE_APP_CONFIG_ROOT', 30, 'NATIVE_PUBLISH_CHANNEL_PACKAGE_MANAGE', 20);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@ADMIN', 'NATIVE_APP_CONFIG_ROOT', 30, 'NATIVE_PUBLISH_REGRESSION', 30);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@ADMIN', 'NATIVE_APP_CONFIG_ROOT', 30, 'NATIVE_PUBLISH_OUTCOME_MANAGE', 40);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@ADMIN', 'NATIVE_APP_CONFIG_ROOT', 30, 'NATIVE_PUBLISH_PUSH_MANAGE', 50);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@ADMIN', 'NATIVE_APP_CONFIG_ROOT', 30, 'NATIVE_GENERAL_CONFIG', 60);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@DEV', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_PROJECT_CREATE', 10);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@DEV', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_PROJECT_ALTER', 20);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@DEV', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_PROJECT_CHANGE', 30);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@DEV', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_DEPENDENCY_MANAGE', 40);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@DEV', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_PROJECT_INTEGRATION_DOC', 50);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@DEV', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_BUILD_CONFIG', 60);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@DEV', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_PROJECT_DEPLOY', 70);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@DEV', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_PUBLISH_PROJECT_DOC', 80);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@DEV', 'NATIVE_INTG_DOC_ROOT', 20, 'NATIVE_INTG_CREATE', 10);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@DEV', 'NATIVE_INTG_DOC_ROOT', 20, 'NATIVE_INTG_MANAGE', 20);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@DEV', 'NATIVE_APP_CONFIG_ROOT', 30, 'NATIVE_PUBLISH_MANAGE', 10);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@DEV', 'NATIVE_APP_CONFIG_ROOT', 30, 'NATIVE_PUBLISH_CHANNEL_PACKAGE_MANAGE', 20);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@DEV', 'NATIVE_APP_CONFIG_ROOT', 30, 'NATIVE_PUBLISH_OUTCOME_MANAGE', 30);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_PROJECT@ADMIN', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_PROJECT_ALTER', 20);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_PROJECT@ADMIN', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_PROJECT_CHANGE', 30);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_PROJECT@ADMIN', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_DEPENDENCY_MANAGE', 40);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_PROJECT@ADMIN', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_PROJECT_INTEGRATION_DOC', 50);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_PROJECT@ADMIN', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_BUILD_CONFIG', 60);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_PROJECT@ADMIN', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_PROJECT_DEPLOY', 70);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_PROJECT@ADMIN', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_PUBLISH_PROJECT_DOC', 80);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_PROJECT@DEV', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_PROJECT_CHANGE', 30);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_PROJECT@DEV', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_DEPENDENCY_MANAGE', 40);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_PROJECT@DEV', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_PROJECT_INTEGRATION_DOC', 50);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_PROJECT@DEV', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_BUILD_CONFIG', 60);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_PROJECT@DEV', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_PROJECT_DEPLOY', 70);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_PROJECT@DEV', 'NATIVE_PROJECT_ROOT', 10, 'NATIVE_PUBLISH_PROJECT_DOC', 80);
INSERT INTO emas.emas_services_privilege_tree (is_deleted, role_key, category, category_priority, privilege_name, privilege_priority)
VALUES (0, 'NATIVE_APPLICATION@TEST', 'NATIVE_APP_CONFIG_ROOT', 10, 'NATIVE_PUBLISH_REGRESSION', 10);
COMMIT;
