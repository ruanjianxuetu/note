USE `emas`;
BEGIN;

-- CEPH_SUB_USER_ID->OSS_SUB_USER_ID, CEPH_SUB_USER_KEY->OSS_SUB_USER_KEY
UPDATE emas_services_system_config set config_key='OSS_SUB_USER_ID' where config_key='CEPH_SUB_USER_ID';
UPDATE emas_services_system_config set config_key='OSS_SUB_USER_KEY' where config_key='CEPH_SUB_USER_KEY';

-- add OSS_REGION_ID、OSS_HA_BUCKET
INSERT INTO `emas_services_system_config`(gmt_create, gmt_modified, is_deleted, creator, modifier, config_namespace, config_key, config_value, description)
       VALUES (now(), now(), 0, '0', '0', 'OSS', 'OSS_REGION_ID', '', NULL),
              (now(), now(), 0, '0', '0', 'OSS', 'OSS_HA_BUCKET', '', NULL);

-- 增加展示优先级字段
ALTER TABLE emas_services_system_config ADD COLUMN priority SMALLINT NULL DEFAULT 100 COMMENT '展示优先级';

UPDATE emas_services_system_config set priority=10 where config_key="OSS_REGION_ID";
UPDATE emas_services_system_config set priority=11 where config_key="OSS_END_POINT";
UPDATE emas_services_system_config set priority=12 where config_key="OSS_OUTER_END_POINT";
UPDATE emas_services_system_config set priority=20 where config_key="OSS_BUCKET";
UPDATE emas_services_system_config set priority=21 where config_key="OSS_HA_BUCKET";
UPDATE emas_services_system_config set priority=30 where config_key="OSS_ACCESS_KEY_ID";
UPDATE emas_services_system_config set priority=31 where config_key="OSS_SECRET_ACCESS_KEY";
UPDATE emas_services_system_config set priority=32 where config_key="OSS_SUB_USER_ID";
UPDATE emas_services_system_config set priority=33 where config_key="OSS_SUB_USER_KEY";

COMMIT;