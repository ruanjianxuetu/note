USE `emas`;
# 增加产品英文名字段
ALTER TABLE emas_product
ADD COLUMN en_name VARCHAR(255) NOT NULL COMMENT '产品英文名';
# 更新历史数据
update emas_product set en_name = id;