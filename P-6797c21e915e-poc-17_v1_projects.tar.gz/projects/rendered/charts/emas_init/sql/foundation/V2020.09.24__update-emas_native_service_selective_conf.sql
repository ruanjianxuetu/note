USE `emas`;
BEGIN;
update emas.emas_native_service_selective_conf set is_deleted = 0
where service_id
in
(SELECT id FROM emas.emas_native_service_category_conf where service="test");
INSERT INTO `emas`.`emas_native_service_category_conf` (`gmt_create`, `gmt_modified`, `is_deleted`, `service`) VALUES (now(), now(), '0', 'test');
INSERT INTO `emas`.`emas_native_service_selective_conf` (`gmt_create`, `gmt_modified`, `is_deleted`, `menu_id`, `service_id`, `is_required`) VALUES (now(), now(), '0', '51', '139', '1');
INSERT INTO `emas`.`emas_native_service_category_conf` (`gmt_create`, `gmt_modified`, `is_deleted`, `service`) VALUES (now(), now(), '0', 'test');
INSERT INTO `emas`.`emas_native_service_selective_conf` (`gmt_create`, `gmt_modified`, `is_deleted`, `menu_id`, `service_id`, `is_required`) VALUES (now(), now(), '0', '62', '140', '1');
COMMIT;
