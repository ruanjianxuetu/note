USE `emas`;
BEGIN;
-- 删除多余的插入的测试数据 "铭至测试2"
delete from emas_app_scaffold_sdk where code_name = 'TestSDK';

-- 删除多余没用的脚手架SCM_CONFIG
delete from emas_services_system_config where config_namespace='SCM_CONFIG'
       and config_key in ('GIT_ANDROID_MAIN_DEMO', 'GIT_ANDROID_MAIN_DEMO_BRANCH', 'GIT_ANDROID_BUNDLE_DEMO', 'GIT_ANDROID_BUNDLE_DEMO_BRANCH',
                          'GIT_IOS_MAIN_DEMO', 'GIT_IOS_MAIN_DEMO_BRANCH', 'GIT_IOS_BUNDLE_DEMO', 'GIT_IOS_BUNDLE_DEMO_BRANCH');

COMMIT;