USE `emas`;
BEGIN;
delete from emas_services_system_config where config_namespace="GIT_LAB";
COMMIT;
