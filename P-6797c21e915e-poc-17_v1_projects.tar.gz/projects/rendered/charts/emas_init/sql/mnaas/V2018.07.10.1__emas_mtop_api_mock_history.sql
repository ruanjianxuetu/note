USE `emas`;
CREATE TABLE `emas_mtop_api_mock_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `api` varchar(128) NOT NULL COMMENT 'api名称',
  `v` varchar(64) NOT NULL COMMENT 'api版本',
  `mock_version` int(10) unsigned NOT NULL COMMENT '配置版本',
  `editor` varchar(128) NOT NULL COMMENT '编辑者',
  `change_type` varchar(16) NOT NULL COMMENT '变更类型',
  `task_id` bigint(20) NOT NULL COMMENT '对应的任务id',
  `json` text NOT NULL COMMENT 'mock配置',
  `description` varchar(256) DEFAULT NULL COMMENT 'mock描述',
  PRIMARY KEY (`id`),
  KEY `idx_api_v` (`api`,`v`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='mock配置历史';