USE `emas`;
CREATE TABLE `emas_mtop_svr_app_administrator` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `creator` varchar(128) NOT NULL COMMENT '创建者',
  `modifier` varchar(128) COMMENT '修改者',
  `app_code` varchar(128) NOT NULL COMMENT '应用code',
  `user_id` varchar(60) NOT NULL COMMENT '用户id',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_svr_app_admin_code` (`app_code`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COMMENT='应用管理员表';


