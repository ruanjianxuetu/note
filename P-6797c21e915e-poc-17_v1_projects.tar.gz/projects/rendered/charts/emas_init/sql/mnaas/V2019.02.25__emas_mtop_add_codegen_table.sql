USE `emas`;
CREATE TABLE `emas_mtop_api_extend` (
                                      `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
                                      `gmt_create` datetime NOT NULL COMMENT '创建时间',
                                      `gmt_modified` datetime NOT NULL COMMENT '修改时间',
                                      `api` varchar(128) NOT NULL COMMENT 'API名称',
                                      `v` varchar(64) NOT NULL DEFAULT '' COMMENT 'API版本',
                                      `http_method` varchar(8) DEFAULT NULL COMMENT 'HTTP请求方式',
                                      `request_body_type` varchar(16) DEFAULT NULL COMMENT '请求body类型',
                                      `request_params` text COMMENT '请求body结构定义',
                                      `response_body_type` varchar(16) DEFAULT NULL COMMENT '响应body类型',
                                      `response_params` text COMMENT '响应body结构定义',
                                      PRIMARY KEY (`id`),
                                      UNIQUE KEY `uk_api_v` (`api`,`v`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COMMENT='API扩展信息表，用于sdk生成';

CREATE TABLE `emas_mtop_codegen_task` (
                                        `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
                                        `gmt_create` datetime NOT NULL COMMENT '创建时间',
                                        `gmt_modified` datetime NOT NULL COMMENT '修改时间',
                                        `creator` varchar(64) NOT NULL DEFAULT '' COMMENT '创建人',
                                        `app_codes` varchar(64) NOT NULL DEFAULT '' COMMENT '任务对应应用',
                                        `platform_type` varchar(16) NOT NULL DEFAULT '' COMMENT 'HTTP请求方式',
                                        `status` varchar(16) NOT NULL DEFAULT '' COMMENT '任务状态',
                                        `error_message` text COMMENT '错误信息',
                                        `file_name` varchar(64) DEFAULT NULL COMMENT '文件名',
                                        `file_size` int(10) DEFAULT NULL COMMENT '文件长度',
                                        `md5` varchar(33) DEFAULT NULL COMMENT '文件md5',
                                        `file_url` varchar(1024) DEFAULT NULL COMMENT '文件url',
                                        PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8 COMMENT='API sdk生成任务表';
