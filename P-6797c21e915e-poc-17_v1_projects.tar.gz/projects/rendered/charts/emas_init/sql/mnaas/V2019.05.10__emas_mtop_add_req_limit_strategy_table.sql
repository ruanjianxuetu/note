USE `emas`;
CREATE TABLE `emas_mtop_api_req_limit_strategy` (
                                                    `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
                                                    `gmt_create` datetime NOT NULL COMMENT '创建时间',
                                                    `gmt_modified` datetime NOT NULL COMMENT '修改时间',
                                                    `creator` varchar(128) NOT NULL COMMENT '创建者',
                                                    `modifier` varchar(128) NOT NULL DEFAULT '' COMMENT '修改者',
                                                    `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否已删除',
                                                    `name` varchar(128) NOT NULL DEFAULT '' COMMENT '策略组名称',
                                                    `time_mode` varchar(20) NOT NULL DEFAULT '' COMMENT '时间范围模式',
                                                    `time_param` varchar(512) DEFAULT '' COMMENT '时间相关参数',
                                                    `ip_mode` varchar(20) NOT NULL DEFAULT '' COMMENT 'ip过滤模式',
                                                    `ip_param` varchar(512) DEFAULT '' COMMENT 'ip相关参数',
                                                    `quota_mode` varchar(20) NOT NULL DEFAULT '' COMMENT '限流模式',
                                                    `quota_param` varchar(512) DEFAULT '' COMMENT '限流相关参数',
                                                    PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='限流表';

CREATE TABLE `emas_mtop_api_req_limit_binding` (
                                                   `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
                                                   `gmt_create` datetime NOT NULL COMMENT '创建时间',
                                                   `gmt_modified` datetime NOT NULL COMMENT '修改时间',
                                                   `creator` varchar(128) NOT NULL COMMENT '创建者',
                                                   `modifier` varchar(128) DEFAULT NULL COMMENT '修改者',
                                                   `api` varchar(128) NOT NULL COMMENT 'API名称',
                                                   `v` varchar(64) NOT NULL COMMENT 'API版本',
                                                   `strategy_id` bigint(20) NOT NULL COMMENT '绑定的策略id',
                                                   PRIMARY KEY (`id`),
                                                   UNIQUE KEY `uniq_binding` (`api`,`v`,`strategy_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COMMENT='限流表';
