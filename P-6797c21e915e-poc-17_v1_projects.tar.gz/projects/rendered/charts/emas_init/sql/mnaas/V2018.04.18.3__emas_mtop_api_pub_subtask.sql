USE `emas`;
CREATE TABLE `emas_mtop_api_pub_subtask` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `task_id` bigint(20) NOT NULL COMMENT '所属任务ID',
  `api` varchar(128) NOT NULL COMMENT 'API名称',
  `v` varchar(64) NOT NULL COMMENT 'API版本',
  `api_content` text NOT NULL COMMENT 'API快照',
  `api_metadata` text NOT NULL COMMENT 'API运行时数据',
  `api_version` int(11) NOT NULL COMMENT 'API变更版本号',
  `host_total` int(11) NOT NULL DEFAULT '0' COMMENT '主机总数',
  `success_count` int(11) NOT NULL DEFAULT '0' COMMENT '成功主机数',
  `fail_count` int(11) NOT NULL DEFAULT '0' COMMENT '失败主机数',
  `status` smallint(6) NOT NULL COMMENT '任务状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_task_id_api_v` (`task_id`,`api`,`v`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='发布子任务表';
