USE `emas`;
CREATE TABLE `emas_mtop_sas_realtime_global_overview` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `gmt_create` datetime NOT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  `stat_date` datetime NOT NULL COMMENT '统计时间',
  `count` bigint(20) NOT NULL COMMENT '请求总量',
  `fail_count` bigint(20) NOT NULL COMMENT '错误次数',
  `rt` bigint(20) NOT NULL COMMENT '平均rt',
  `qps` bigint(20) NOT NULL COMMENT '平均qps',
  `fail_rate` decimal(10,2) NOT NULL COMMENT '错误率',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_stat_date` (`stat_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='全局分钟级实时大盘';