USE `emas`;
ALTER TABLE `emas_mtop_develop_api`
  ADD COLUMN `logging_mode` TINYINT(4) NOT NULL DEFAULT 0 COMMENT '日志打印模式' AFTER `backend_protocol`;

ALTER TABLE `emas_mtop_product_api`
  ADD COLUMN `logging_mode` TINYINT(4) NOT NULL DEFAULT 0 COMMENT '日志打印模式' AFTER `backend_protocol`;
