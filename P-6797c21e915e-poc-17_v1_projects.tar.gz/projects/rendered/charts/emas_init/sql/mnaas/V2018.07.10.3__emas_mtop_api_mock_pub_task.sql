USE `emas`;
CREATE TABLE `emas_mtop_api_mock_pub_task` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `creator` varchar(128) NOT NULL COMMENT '创建者',
  `app_code` varchar(128) NOT NULL COMMENT '应用名',
  `status` smallint(6) NOT NULL COMMENT '任务状态',
  `api` varchar(128) NOT NULL COMMENT 'API名称',
  `v` varchar(64) NOT NULL COMMENT 'API版本',
  `mock_version` int(11) NOT NULL COMMENT 'Mock变更版本号',
  `pub_type` varchar(16) NOT NULL COMMENT '发布类型',
  `description` varchar(256) DEFAULT NULL COMMENT 'mock描述',
  `json` text NOT NULL COMMENT 'mock配置',
  `host_total` int(11) NOT NULL DEFAULT 0 COMMENT '主机总数',
  `success_count` int(11) NOT NULL DEFAULT 0 COMMENT '成功主机数',
  `fail_count` int(11) NOT NULL DEFAULT 0 COMMENT '失败主机数',
  PRIMARY KEY (`id`),
  KEY `idx_api_v` (`api`,`v`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='mock发布任务';