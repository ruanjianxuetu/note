USE `emas`;
ALTER TABLE `emas_mtop_develop_api`
  ADD COLUMN `param_mapping_mode` VARCHAR(16) NOT NULL DEFAULT "CUSTOM" AFTER `service_info`;

ALTER TABLE `emas_mtop_product_api`
  ADD COLUMN `param_mapping_mode` VARCHAR(16) NOT NULL DEFAULT "CUSTOM" AFTER `service_info`;
