USE `emas`;
CREATE TABLE `emas_mtop_api_pub_subtask_host` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `task_id` bigint(20) NOT NULL COMMENT '所属任务ID',
  `api` varchar(128) NOT NULL COMMENT 'API名称',
  `v` varchar(64) NOT NULL COMMENT 'API版本',
  `task_host` varchar(64) NOT NULL COMMENT '发布机器IP',
  `status` smallint(6) NOT NULL COMMENT '任务状态',
  `error_code` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_task_id_api_v_task_host` (`task_id`,`api`,`v`,`task_host`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
