USE `emas`;
CREATE TABLE IF NOT EXISTS `emas_vipserver_domain` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `domain` varchar(255) NOT NULL COMMENT '域名',
  `content` text NOT NULL COMMENT '内容',
  `managers` varchar(1020) NOT NULL COMMENT '管理员列表',
  `env` varchar(127) DEFAULT NULL COMMENT '环境',
  `protect_threshold` float NOT NULL COMMENT '保护阈值',
  `is_deleted` tinyint(4) NOT NULL COMMENT '是否删除',
  `creator` varchar(255) NOT NULL COMMENT '创建人',
  `modifier` varchar(255) NOT NULL COMMENT '修改人',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `idx_is_deleted_domain` (`is_deleted`,`domain`) USING BTREE,
  KEY `idx_gmt_modified` (`gmt_modified`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='VipServer域名表';