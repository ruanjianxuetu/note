USE `emas`;
ALTER TABLE `emas_mtop_svr_app`
  ADD COLUMN `auth_config` text DEFAULT NULL COMMENT '鉴权配置' AFTER `app_name`;
