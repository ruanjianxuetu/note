USE `emas`;
CREATE TABLE `emas_mtop_favourite_api` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `api` varchar(128) NOT NULL COMMENT 'API名称',
  `v` varchar(64) NOT NULL COMMENT 'API版本',
  `user_id` varchar(64) NOT NULL COMMENT '用户ID',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_api_v_user_id` (`api`,`v`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='API收藏夹';
