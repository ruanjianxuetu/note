USE `emas`;
CREATE TABLE `emas_mtop_api_mock_pub_task_host` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `task_id` bigint(20) unsigned NOT NULL COMMENT '关联的mock发布任务id',
  `task_host` varchar(64) NOT NULL COMMENT '发布机器IP',
  `status` smallint(6) NOT NULL COMMENT '任务状态',
  `error_code` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_task_id_task_host` (`task_id`,`task_host`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='mock发布任务详情';