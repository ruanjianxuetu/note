USE `emas`;
alter table emas_mtop_api_pub_subtask_host
    add column cluster varchar(20) not null default 'DEFAULT' comment '该机器所在的集群' after task_host;

alter table emas_mtop_api_pub_subtask_host
    drop index uk_task_id_api_v_task_host;

alter table emas_mtop_api_pub_subtask_host
    add constraint `uk_task_id_api_v_task_host_cluster` unique (`task_id`, `api`, `v`, `task_host`, `cluster`);

alter table emas_mtop_api_mock_pub_task_host
    add column cluster varchar(20) not null default 'DEFAULT' comment '该机器所在的集群' after task_host;

alter table emas_mtop_api_mock_pub_task_host
    drop index uk_task_id_task_host;

alter table emas_mtop_api_mock_pub_task_host
    add constraint `uk_task_id_task_host_cluster` unique (`task_id`, `task_host`, `cluster`);
