USE `emas`;
CREATE TABLE `emas_mtop_cors_config` (
                                      `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
                                      `gmt_create` datetime NOT NULL COMMENT '创建时间',
                                      `gmt_modified` datetime NOT NULL COMMENT '修改时间',
                                      `origins` TEXT DEFAULT NULL COMMENT '允许访问的origin',
                                      `expose_headers` TEXT DEFAULT NULL COMMENT '允许暴露的header',
                                      `expiration` bigint(20) NOT NULL DEFAULT 0 COMMENT 'Cors的缓存时间',
                                      PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COMMENT='全局的跨域配置存储表';
