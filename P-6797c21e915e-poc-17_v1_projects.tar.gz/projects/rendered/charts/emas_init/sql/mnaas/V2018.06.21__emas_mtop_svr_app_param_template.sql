USE `emas`;
CREATE TABLE `emas_mtop_svr_app_param_template` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `modifier` varchar(64) NOT NULL COMMENT '修改者',
  `app_code` varchar(128) NOT NULL COMMENT '应用名称',
  `template_name` varchar(128) NOT NULL COMMENT '模板名称',
  `request_params_json` text COMMENT '请求参数信息',
  `version` int(11) NOT NULL COMMENT '版本号',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_appCode_templateName` (`app_code`,`template_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用参数模板';