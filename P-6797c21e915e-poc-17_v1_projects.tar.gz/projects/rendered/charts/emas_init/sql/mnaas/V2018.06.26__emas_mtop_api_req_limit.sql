USE `emas`;
CREATE TABLE `emas_mtop_api_req_limit` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `creator` varchar(128) NOT NULL COMMENT '创建者',
  `modifier` varchar(128) COMMENT '修改者',
  `api` varchar(128) NOT NULL COMMENT 'API名称',
  `v` varchar(64) NOT NULL COMMENT 'API版本',
  `qps` bigint(20) NOT NULL COMMENT 'qps',
  `status` smallint(6) COMMENT '任务状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_api_req_limit` (`api`,`v`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COMMENT='限流表';
