USE `emas`;
CREATE TABLE `emas_mtop_sas_daily_api_detail` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL,
  `gmt_modified` datetime NOT NULL,
  `stat_date` varchar(20) NOT NULL DEFAULT '' COMMENT '聚合日期',
  `api` varchar(128) NOT NULL COMMENT 'API名称',
  `v` varchar(64) NOT NULL COMMENT 'API版本',
  `count` int(11) NOT NULL COMMENT '数量',
  `fail_count` int(11) NOT NULL COMMENT '异常数量',
  `rt` int(11) NOT NULL COMMENT '平均延迟,ms',
  `fail_rate` decimal(7,4) NOT NULL COMMENT '错误率',
  PRIMARY KEY (`id`),
  UNIQUE KEY `daily_api_detail_index` (`stat_date`,`api`,`v`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8;
