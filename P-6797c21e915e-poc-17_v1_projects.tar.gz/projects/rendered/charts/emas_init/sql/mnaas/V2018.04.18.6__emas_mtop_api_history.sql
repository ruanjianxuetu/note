USE `emas`;
CREATE TABLE `emas_mtop_api_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `api` varchar(128) NOT NULL COMMENT 'API名称',
  `v` varchar(64) NOT NULL COMMENT 'API版本',
  `modifier` varchar(128) NOT NULL COMMENT '修改者',
  `backend_protocol` varchar(64) NOT NULL COMMENT '后端服务类型',
  `api_data_json` text COMMENT 'API数据',
  `api_version` int(11) NOT NULL COMMENT '版本号',
  `change_type` varchar(16) NOT NULL COMMENT '变更类型',
  `task_id` bigint(20) DEFAULT NULL COMMENT '发布任务ID',
  `pub_env` varchar(16) DEFAULT NULL COMMENT '发布环境',
  `pub_status` smallint(6) DEFAULT NULL COMMENT '发布状态',
  `pub_desc` varchar(256) DEFAULT NULL COMMENT '发布说明',
  PRIMARY KEY (`id`),
  KEY `idx_api_v` (`api`,`v`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='API变更历史表';
