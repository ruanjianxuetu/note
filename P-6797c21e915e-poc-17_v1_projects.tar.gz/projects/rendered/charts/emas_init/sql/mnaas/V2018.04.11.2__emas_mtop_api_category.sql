USE `emas`;
CREATE TABLE `emas_mtop_api_category` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `creator` varchar(128) NOT NULL COMMENT '创建者',
  `modifier` varchar(128) COMMENT '修改者',
  `app_code` varchar(128) NOT NULL COMMENT '应用标识',
  `description` varchar(256) COMMENT '描述',
  `category_code` varchar(128) COMMENT '分组编码',
  `category_name` varchar(128) COMMENT '分组名称',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_app_category_code` (`app_code`,`category_code`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COMMENT='分组表';
