USE `emas`;
CREATE TABLE IF NOT EXISTS `emas_channel` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `channel_num` VARCHAR(64) NOT NULL COMMENT '渠道号',
  `partner_id` BIGINT(20) NOT NULL COMMENT '合作方ID',
  `status` TINYINT(4) NOT NULL COMMENT '状态: 0. 启用, 1. 停用',
  `description` VARCHAR(1024) NULL COMMENT '描述信息',
  `creator` VARCHAR(64) NOT NULL COMMENT '创建者',
  `modifier` VARCHAR(64) NULL COMMENT '修改者',
  `is_deleted` TINYINT(4) NULL COMMENT '是否删除',
  `gmt_create` DATETIME NOT NULL COMMENT '创建时间',
  `gmt_modified` DATETIME NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000  DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `emas_channel_partner` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `channel_type` VARCHAR(64)  NULL COMMENT '渠道类型 （预留）',
  `os_type` TINYINT(4)  NULL COMMENT '系统类型: 1. android, 2. ios',
  `partner_name` VARCHAR(128) NOT NULL COMMENT '合作方名称',
  `description` VARCHAR(1024) NULL COMMENT '描述信息',
  `creator` VARCHAR(64) NOT NULL COMMENT '创建者',
  `modifier` VARCHAR(64) NULL COMMENT '修改者',
  `is_deleted` TINYINT(4) NULL COMMENT '是否删除',
  `gmt_create` DATETIME NOT NULL COMMENT '创建时间',
  `gmt_modified` DATETIME NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000  DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `emas_channel_app_group` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `group_type` TINYINT(4) NOT NULL COMMENT '分组类型: 1.自有渠道 2.官网发布 3. 外部渠道',
  `group_name` VARCHAR(128) NOT NULL COMMENT '合作方名称',
  `app_id` BIGINT(20) NOT NULL COMMENT '应用id',
  `description` VARCHAR(1024) NULL COMMENT '描述信息',
  `creator` VARCHAR(64) NOT NULL COMMENT '创建者',
  `modifier` VARCHAR(64) NULL COMMENT '修改者',
  `is_deleted` TINYINT(4) NULL COMMENT '是否删除',
  `gmt_create` DATETIME NOT NULL COMMENT '创建时间',
  `gmt_modified` DATETIME NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000  DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `emas_channel_app_detail` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `channel_id` BIGINT(20) NOT NULL COMMENT '渠道id',
  `group_id` BIGINT(20) NOT NULL COMMENT '分组id',
  `app_id` BIGINT(20) NOT NULL COMMENT '应用id',
  `custom_channel_num` VARCHAR(128)  NULL COMMENT '自定义渠道号',
  `custom_template_name` VARCHAR(128)  NULL COMMENT '自定义app名称模板',
  `cdnPath` VARCHAR(128)  NULL COMMENT 'cdn路径',
  `cdnFileName` VARCHAR(128)  NULL COMMENT 'cdn包名',
  `description` VARCHAR(1024) NULL COMMENT '描述信息',
  `creator` VARCHAR(64) NOT NULL COMMENT '创建者',
  `modifier` VARCHAR(64) NULL COMMENT '修改者',
  `is_deleted` TINYINT(4) NULL COMMENT '是否删除',
  `gmt_create` DATETIME NOT NULL COMMENT '创建时间',
  `gmt_modified` DATETIME NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000  DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `emas_channel_app_config` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `app_id` BIGINT(20) NOT NULL UNIQUE COMMENT '应用id',
  `status` TINYINT(4) NOT NULL COMMENT '状态: 0. 启用, 1. 停用',
  `channel_num` VARCHAR(128) NULL COMMENT '默认渠道号',
  `creator` VARCHAR(64) NOT NULL COMMENT '创建者',
  `modifier` VARCHAR(64) NULL COMMENT '修改者',
  `is_deleted` TINYINT(4) NULL COMMENT '是否删除',
  `gmt_create` DATETIME NOT NULL COMMENT '创建时间',
  `gmt_modified` DATETIME NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000  DEFAULT CHARSET=utf8;




