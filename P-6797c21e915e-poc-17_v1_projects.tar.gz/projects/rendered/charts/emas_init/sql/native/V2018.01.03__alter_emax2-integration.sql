USE `emas`;
ALTER TABLE  `emas_native_intg_doc_cr` ADD COLUMN `app_id` bigint(20) NOT NULL;

ALTER TABLE  `emas_native_dep_archive`  ADD COLUMN  `scm_commit` varchar(1024) COLLATE utf8_unicode_ci DEFAULT '' COMMENT 'GITlog';

ALTER TABLE  `emas_native_dep_archive`  ADD COLUMN  `build_id` bigint(20) DEFAULT '0' COMMENT '构建ID';

ALTER TABLE  `emas_native_project_cr_release` ADD COLUMN `snapshot` tinyint(4) DEFAULT NULL COMMENT '是否是SNAPSHOT版本';

ALTER TABLE  `emas_native_project_cr_release`  CHANGE `commit` `scm_commit` VARCHAR(1024);