USE `emas`;
CREATE TABLE `emas_native_intg_area_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` tinyint(4) NOT NULL COMMENT '是否删除',
  `creator` varchar(255) NOT NULL COMMENT '创建人',
  `modifier` varchar(255) NOT NULL COMMENT '修改人',
  `intg_area_id` bigint(20) NOT NULL COMMENT '集成区ID',
  `operation` varchar(255) NOT NULL COMMENT '操作类型',
  `old_value` varchar(1024) DEFAULT NULL COMMENT '旧值',
  `new_value` varchar(1024) DEFAULT NULL COMMENT '新值',
  `remark` varchar(1024) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  KEY `idx_intg_area_id` (`intg_area_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='集成区操作日志表';

