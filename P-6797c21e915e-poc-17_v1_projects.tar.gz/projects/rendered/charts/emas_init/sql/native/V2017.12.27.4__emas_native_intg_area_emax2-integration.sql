USE `emas`;
CREATE TABLE `emas_native_intg_area` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `is_deleted` tinyint(4) DEFAULT NULL COMMENT '是否删除',
  `creator` varchar(255) DEFAULT NULL COMMENT '创建人',
  `modifier` varchar(255) DEFAULT NULL COMMENT '修改人',
  `name` varchar(255) DEFAULT NULL COMMENT '集成区名称',
  `app_id` bigint(20) DEFAULT NULL COMMENT '应用ID',
  `intg_area_type` varchar(255) DEFAULT NULL COMMENT '集成区类型',
  `intg_area_status` varchar(255) DEFAULT NULL COMMENT '集成区状态',
  `meta_project_id` bigint(20) DEFAULT NULL COMMENT '元项目ID',
  `scm_branch` varchar(1024) DEFAULT NULL COMMENT '分支',
  `module_white_list` varchar(4096) DEFAULT NULL COMMENT '模块白名单',
  `freezing_schedule_time` datetime DEFAULT NULL COMMENT '定时冻结时间',
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`) USING BTREE,
  KEY `idx_app_id` (`app_id`) USING BTREE,
  KEY `idx_meta_project_id` (`meta_project_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='集成区表';

