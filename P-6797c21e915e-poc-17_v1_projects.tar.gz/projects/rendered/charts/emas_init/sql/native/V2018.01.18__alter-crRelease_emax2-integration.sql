USE `emas`;
ALTER TABLE  `emas_native_project_cr_release`
  CHANGE  `scm_commit` `scm_commit` text,
  CHANGE  `error_msg` `error_msg` text;