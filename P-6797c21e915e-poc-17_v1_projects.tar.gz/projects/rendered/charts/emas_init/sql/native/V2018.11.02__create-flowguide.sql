USE `emas`;
CREATE TABLE `emas_native_intg_flow_guide` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `project_id` bigint(20) NOT NULL COMMENT '对应当前的项目ID',
  `flow` varchar(128) COLLATE utf8_unicode_ci NOT NULL COMMENT '流程',
  `creator` varchar(64) COLLATE utf8_unicode_ci NOT NULL COMMENT '创建者',
  `modifier` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '修改者',
  `is_deleted` tinyint(4) DEFAULT NULL COMMENT '是否删除',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `flow` (`flow`,`project_id`),
  KEY `index2` (`project_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=251 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;