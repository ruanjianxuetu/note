USE `emas`;
CREATE TABLE IF NOT EXISTS `emas_native_op_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `is_deleted` tinyint(4) DEFAULT 0 COMMENT '是否删除',
  `creator` varchar(255) DEFAULT '' COMMENT '创建人',
  `modifier` varchar(255) DEFAULT '' COMMENT '修改人',
  `area_type` varchar(64) NOT NULL COMMENT '区域类型: project_area/integrate_area/integrate_sheet/publish_area',
  `area_id` bigint(20) NOT NULL COMMENT 'area_type对应区域ID,如: 集成单id,项目ID,发布单ID',
  `operation` varchar(255) NOT NULL COMMENT '各业务方自己定义',
  `old_value` varchar(1024) DEFAULT NULL COMMENT '旧值',
  `new_value` varchar(1024) DEFAULT NULL COMMENT '新值',
  `remark` varchar(1024) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  KEY `idx_area_id` (`area_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='native操作日志表';