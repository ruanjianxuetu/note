USE `emas`;
CREATE TABLE `emas_native_intg_area_dep` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` tinyint(4) NOT NULL COMMENT '是否已经删除',
  `creator` varchar(255) NOT NULL COMMENT '创建人',
  `modifier` varchar(255) NOT NULL COMMENT '修改人',
  `intg_area_id` bigint(20) NOT NULL COMMENT '集成区ID',
  `module_id` bigint(20) NOT NULL COMMENT '模块ID',
  `intg_count` int(11) NOT NULL COMMENT '集成次数',
  `cr_id` bigint(20) NOT NULL COMMENT '变更ID',
  `doc_cr_id` bigint(20) NOT NULL COMMENT '集成单变更ID',
  `cr_type` varchar(255) NOT NULL COMMENT '变更类型',
  `doc_id` bigint(20) NOT NULL COMMENT '集成单ID',
  `project_id` bigint(20) NOT NULL COMMENT '最近集成的项目ID',
  `intg_dep_status` varchar(255) NOT NULL COMMENT '集成状态',
  `intg_dep_type` varchar(255) NOT NULL COMMENT '集成类型',
  `intg_dep_lock_status` varchar(255) NOT NULL COMMENT '锁定状态',
  `dep_key` varchar(255) NOT NULL COMMENT '依赖key',
  `version` varchar(255) NOT NULL COMMENT '版本',
  `compile_type` int(255) DEFAULT NULL COMMENT '编译类型',
  PRIMARY KEY (`id`),
  KEY `idx_intg_area_id` (`intg_area_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='集成区依赖模块表';

