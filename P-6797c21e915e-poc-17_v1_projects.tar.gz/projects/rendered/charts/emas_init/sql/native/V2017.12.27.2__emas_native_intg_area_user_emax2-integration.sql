USE `emas`;
CREATE TABLE `emas_native_intg_area_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` tinyint(4) NOT NULL COMMENT '是否已经删除',
  `creator` varchar(255) NOT NULL COMMENT '创建人',
  `modifier` varchar(255) NOT NULL COMMENT '修改人',
  `user_id` varchar(255) NOT NULL COMMENT '用户ID',
  `intg_area_id` bigint(20) NOT NULL COMMENT '集成区ID',
  `intg_area_user_type` varchar(255) NOT NULL COMMENT '关系来源',
  `is_active` tinyint(4) NOT NULL COMMENT '是否有效',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`) USING BTREE,
  KEY `idx_intg_area_id` (`intg_area_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='集成区用户表';

