CREATE DATABASE IF NOT EXISTS emas_man;

USE emas_man;

CREATE TABLE `emas_visit_statistics` (
  `md5` varchar(32) NOT NULL,
  `app_id` varchar(32) NOT NULL,
  `app_version` varchar(32) NOT NULL,
  `type` varchar(16) NOT NULL,
  `target` varchar(2048) NOT NULL,
  `ds` varchar(8) DEFAULT NULL,
  `pv` bigint(20) DEFAULT NULL,
  `uv` bigint(20) DEFAULT NULL,
  `stay_time` double DEFAULT NULL,
  `click_uv` bigint(20) DEFAULT NULL,
  UNIQUE KEY `emas_panorama_visit_statistics_identity_uindex` (`md5`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='访问指标';

CREATE TABLE `emas_page_go_visit_statistics` (
  `md5` varchar(32) NOT NULL,
  `app_id` varchar(32) NOT NULL,
  `app_version` varchar(32) NOT NULL,
  `from_page` varchar(2048) DEFAULT NULL,
  `page` varchar(2048) NOT NULL,
  `ds` varchar(8) NOT NULL,
  `pv` bigint(20) DEFAULT NULL,
  `uv` bigint(20) DEFAULT NULL,
  `stay_time` double DEFAULT NULL,
  `step` bigint(20) DEFAULT NULL,
  UNIQUE KEY `emas_panorama_go_visit_statistics_md5_uindex` (`md5`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='去向页面指标统计';

CREATE TABLE `emas_event_detail` (
  `id` bigint(20) auto_increment primary key,
  `target` varchar(2048) NOT NULL,
  `target_name` varchar(2048) NOT NULL,
  `gmt_create` datetime NULL,
  `gmt_modified` datetime NULL,
   UNIQUE KEY `emas_event_detail_id_uindex` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='页面事件明细';

CREATE TABLE `emas_event_funnel` (
  `id` bigint(20) auto_increment primary key,
  `app_id` varchar(32) NOT NULL,
  `funnel_name` varchar(1024) NOT NULL,
  `funnel_detail` varchar(2048) NOT NULL,
  `gmt_create` datetime NULL,
  `gmt_modified` datetime NULL,
   UNIQUE KEY `emas_event_funnel_id_uindex` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='事件漏斗';

CREATE TABLE `emas_man_app_version` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `unique_app_id` varchar(32) NOT NULL COMMENT '唯一app标志',
  `app_version` varchar(32) NOT NULL COMMENT 'app版本',
  `status` varchar(128) NOT NULL COMMENT '状态',
  `params` varchar(1024) DEFAULT NULL COMMENT '参数',
  `type` varchar(128) NOT NULL COMMENT '类型：正式、灰度等',
  `release_time` datetime DEFAULT NULL COMMENT '发布时间',
  `release_status` varchar(20) DEFAULT NULL COMMENT '发布状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_version` (`unique_app_id`,`app_version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='emas_man_app_version';

CREATE TABLE `emas_page_go_path` (
  `md5` varchar(32) NOT NULL,
  `app_id` varchar(32) NOT NULL,
  `app_version` varchar(32) NOT NULL,
  `ds` varchar(32) NOT NULL,
  `step`  varchar(256) NOT NULL,
  `page1` varchar(128) NOT NULL,
  `page2` varchar(128) DEFAULT NULL ,
  `page3` varchar(128) DEFAULT NULL ,
  `page4` varchar(128) DEFAULT null ,
  `page5` varchar(128) DEFAULT NULL ,
  `pv` bigint(20) NOT NULL,
  UNIQUE KEY `emas_page_go_path_md5_uindex` (`md5`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='去向页面指标统计';