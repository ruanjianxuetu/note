USE emas_man;

alter table emas_visit_statistics add index `app_id_app_version_ds` (`app_id`,`app_version`,`ds`);
alter table emas_page_go_path add index `app_id_version_ds` (`app_id`,`app_version`,`ds`);
