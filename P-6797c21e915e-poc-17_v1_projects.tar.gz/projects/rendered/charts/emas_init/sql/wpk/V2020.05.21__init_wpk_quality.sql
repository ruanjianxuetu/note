use log_analysis;
CREATE TABLE IF NOT EXISTS wpk_app_authorization (
  id bigint(20) NOT NULL AUTO_INCREMENT,
  apps varchar(127) DEFAULT NULL COMMENT '应用标识apps.app',
  scene varchar(63) NOT NULL COMMENT '授权场景',
  client_key varchar(63) NOT NULL COMMENT '授权key',
  client_secret varchar(63) NOT NULL COMMENT '授权secret',
  create_at datetime NOT NULL,
  update_at datetime NOT NULL,
  is_deleted tinyint(2) NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `wpk_quality_report_config` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `model_id` BIGINT NOT NULL COMMENT '关联对象主键',
  `model_type` VARCHAR(63) NOT NULL COMMENT '关联对象类型，可以是apps、product（暂无）',
  `formula_type` VARCHAR(63) NOT NULL COMMENT '公式类型，如dim_weigth_score',
  `formula_configs` VARCHAR(2047) NOT NULL COMMENT '公式配置，json配置信息',
  `is_deleted` TINYINT NOT NULL,
  `create_at` DATETIME NOT NULL,
  `create_by` BIGINT NOT NULL,
  `update_at` DATETIME NOT NULL,
  `update_by` BIGINT NOT NULL,
  PRIMARY KEY (`id`)
)
ENGINE = InnoDB
COMMENT = '质量报表配置表';

ALTER TABLE `wpk_quality_report_config` ADD INDEX `idx_model`(`model_id`,`model_type`);


CREATE TABLE IF NOT EXISTS `wpk_quality_report_result` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `apps_id` BIGINT NOT NULL COMMENT 'apps.id',
  `config_id` BIGINT NOT NULL COMMENT 'wpk_quality_report_config.id',
  `calculation_result` VARCHAR(2047) NOT NULL COMMENT '计算结果，jsno数据格式',
  `report_date` DATETIME NOT NULL COMMENT '报告日期',
  `is_deleted` TINYINT NOT NULL,
  `create_at` DATETIME NOT NULL,
  `update_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`)
)
ENGINE = InnoDB
COMMENT = '质量报告结果';

ALTER TABLE `wpk_quality_report_result` ADD INDEX `idx_ar`(`apps_id`,`report_date`);

 INSERT INTO `wpk_quality_report_config` (`model_id`, `model_type`, `formula_type`, `formula_configs`, `is_deleted`, `create_at`, `create_by`, `update_at`, `update_by`)
 VALUES (0, 'SYSTEM', 'DIM_WEIGTH_SCORE'
 , '{"formula_type":"DIM_WEIGTH_SCORE","formula_configs":{"dims":{"perf":{"weigth":0.5,"grade_configs":[{"grade":"A","scr_max":100,"scr_min":85,"idx_max":1000,"idx_min":0},{"grade":"B","scr_max":84.99,"scr_min":75,"idx_max":2000,"idx_min":1000.00001},{"grade":"C","scr_max":74.99,"scr_min":60,"idx_max":5000,"idx_min":2000.00001},{"grade":"D","scr_max":59.99,"scr_min":0,"idx_max":60000,"idx_min":5000.00001}]},"blank":{"weigth":0.15,"grade_configs":[{"grade":"A","scr_max":100,"scr_min":85,"idx_max":0,"idx_min":0.00019},{"grade":"B","scr_max":84.99,"scr_min":75,"idx_max":0.0002,"idx_min":0.00049},{"grade":"C","scr_max":74.99,"scr_min":60,"idx_max":0.0005,"idx_min":0.00099},{"grade":"D","scr_max":59.99,"scr_min":0,"idx_max":0.001,"idx_min":1}]},"api":{"weigth":0.15,"grade_configs":[{"grade":"A","scr_max":100,"scr_min":85,"idx_max":1,"idx_min":0.99949},{"grade":"B","scr_max":84.99,"scr_min":75,"idx_max":0.9995,"idx_min":0.99899},{"grade":"C","scr_max":74.99,"scr_min":60,"idx_max":0.999,"idx_min":0.98999},{"grade":"D","scr_max":59.99,"scr_min":0,"idx_max":0.99,"idx_min":0}]},"jserror":{"weigth":0.1,"grade_configs":[{"grade":"A","scr_max":100,"scr_min":85,"idx_max":0,"idx_min":0.00199},{"grade":"B","scr_max":84.99,"scr_min":75,"idx_max":0.002,"idx_min":0.00499},{"grade":"C","scr_max":74.99,"scr_min":60,"idx_max":0.005,"idx_min":0.00999},{"grade":"D","scr_max":59.99,"scr_min":0,"idx_max":0.01,"idx_min":1}]},"resloadfail":{"weigth":0.1,"grade_configs":[{"grade":"A","scr_max":100,"scr_min":85,"idx_max":0,"idx_min":0.00999},{"grade":"B","scr_max":84.99,"scr_min":75,"idx_max":0.01,"idx_min":0.01499},{"grade":"C","scr_max":74.99,"scr_min":60,"idx_max":0.015,"idx_min":0.02999},{"grade":"D","scr_max":59.99,"scr_min":0,"idx_max":0.03,"idx_min":1}]}},"grade_configs":[{"grade":"A","scr_max":100,"scr_min":85},{"grade":"B","scr_max":84.99,"scr_min":75},{"grade":"C","scr_max":74.99,"scr_min":60},{"grade":"D","scr_max":59.99,"scr_min":0}]}}'
 , 0, now(), 1, now(), 1);