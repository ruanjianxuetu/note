use log_analysis;

-- 添加质量大盘资源 （iframe这里会走应用自己的鉴权功能，所以需要单独添加资源项）
insert into wpk_resource(code, name, group_code, create_at, create_by, update_at, update_by, is_deleted) values ('h5:health', '质量大盘', 'h5', now(), 1, now(), 1, 0);
set @health_id=LAST_INSERT_ID();
insert into wpk_resource_template(app_type, resource_id, create_at, create_by, update_at, update_by, is_deleted) values ('html5', @health_id, now(), 1, now(), 1, 0);

-- 添加默认角色资源配置
insert into wpk_role_template_resource(role_template_id, resource_id, create_at, create_by, update_at, update_by, is_deleted) values (9, @health_id, now(), 1, now(), 1, 0);
insert into wpk_role_template_resource(role_template_id, resource_id, create_at, create_by, update_at, update_by, is_deleted) values (8, @health_id, now(), 1, now(), 1, 0);
insert into wpk_role_template_resource(role_template_id, resource_id, create_at, create_by, update_at, update_by, is_deleted) values (7, @health_id, now(), 1, now(), 1, 0);