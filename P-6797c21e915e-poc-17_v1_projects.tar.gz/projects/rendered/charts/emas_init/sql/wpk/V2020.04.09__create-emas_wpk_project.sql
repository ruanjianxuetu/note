use log_analysis;
-- 创建项目表
CREATE TABLE IF NOT EXISTS wpk_project (
  id bigint(20) NOT NULL AUTO_INCREMENT,
  name varchar(31) NOT NULL COMMENT '项目名称',
  pid varchar(63) NOT NULL COMMENT '项目标识',
  description varchar(255) DEFAULT NULL COMMENT '项目说明',
  type varchar(20) DEFAULT NULL COMMENT '应用组类型，android/ios/html5（应用组里只能添加指定类型的应用）',
  create_at datetime DEFAULT NULL,
  create_by bigint(11) DEFAULT NULL,
  update_at datetime DEFAULT NULL,
  update_by bigint(11) DEFAULT NULL,
  is_deleted bit(1) DEFAULT NULL COMMENT '是否被删除，1表示被删除，0表示没删除',
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 创建项目与应用关联表
CREATE TABLE IF NOT EXISTS wpk_project_apps (
  id bigint(20) NOT NULL AUTO_INCREMENT,
  project_id bigint(20) NOT NULL COMMENT '项目id',
  app_id bigint(20) DEFAULT NULL COMMENT '应用id',
  create_at datetime DEFAULT NULL,
  create_by bigint(11) DEFAULT NULL,
  update_at datetime DEFAULT NULL,
  update_by bigint(11) DEFAULT NULL,
  is_deleted bit(1) DEFAULT NULL COMMENT '是否被删除，1表示被删除，0表示没删除',
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 创建项目角色表
CREATE TABLE IF NOT EXISTS wpk_project_role (
  id bigint(20) NOT NULL AUTO_INCREMENT,
  project_id bigint(20) NOT NULL COMMENT '关联wpk_project表id',
  name varchar(31) DEFAULT NULL COMMENT '项目角色名',
  is_admin bit(1) DEFAULT NULL COMMENT '是否管理员，1表示是，0表示否',
  create_at datetime DEFAULT NULL,
  create_by bigint(11) DEFAULT NULL,
  update_at datetime DEFAULT NULL,
  update_by bigint(11) DEFAULT NULL,
  is_deleted bit(1) DEFAULT NULL COMMENT '是否被删除，1表示被删除，0表示没删除',
  PRIMARY KEY (id),
  KEY idx_projectid (project_id) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 项目角色与用户关联表
CREATE TABLE IF NOT EXISTS wpk_project_role_user (
  id bigint(11) NOT NULL AUTO_INCREMENT,
  project_role_id bigint(20) NOT NULL COMMENT '关联wpk_project_role表id',
  user_id bigint(20) NOT NULL COMMENT '用户id',
  create_at datetime DEFAULT NULL,
  create_by bigint(11) DEFAULT NULL,
  update_at datetime DEFAULT NULL,
  update_by bigint(11) DEFAULT NULL,
  is_deleted bit(1) DEFAULT NULL COMMENT '是否被删除，1表示被删除，0表示没删除',
  PRIMARY KEY (id),
  KEY idx_projectroleid (project_role_id) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
