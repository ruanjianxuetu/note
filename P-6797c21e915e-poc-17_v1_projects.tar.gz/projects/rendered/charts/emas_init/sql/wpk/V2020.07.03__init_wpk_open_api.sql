use ucmobile_crash_log;

alter table crash_aone_project add column cluster varchar(31) default 'alibaba';


use log_analysis;

-- 添加字段
ALTER TABLE wpk_role_template
    ADD COLUMN entity_type varchar(31) default 'app' AFTER is_admin,
    ADD COLUMN biz_type varchar(31) default 'default' AFTER entity_type;
ALTER TABLE wpk_role
    ADD COLUMN entity_id bigint(20) NULL AFTER is_admin,
    ADD COLUMN entity_type varchar(31) default 'app' AFTER entity_id;

-- 添加open-api 授权
INSERT INTO `wpk_openapi_user`(`client_id`, `client_key`, `name`, `allow_url`, `ip_white_list`, `description`, `is_deleted`, `create_by`, `create_at`, `update_by`, `update_at`) VALUES ('emas', 'RcfFoSC2Cwv2zWoDSACnhJTojLavYxeQ', 'EMAS-WPK', NULL, NULL, 'EMAS', 0, NULL, NOW(), NULL, NOW());

-- 添加虚拟用户
INSERT INTO `wp_user_profile`(`account`, `user_name`, `password`, `user_id`, `phone`, `email`, `type`, `company_name`, `active_code`, `is_active`, `is_disable`, `update_user`, `update_time`, `create_user`, `create_time`, `is_deleted`, `nickname`, `source_id`, `dingtalk_id`, `meg_id`) VALUES ('emas', 'EMAS授权用户', NULL, 'emas', NULL, '', 0, 'EMAS-开放授权', '', 0, 0, '', NULL, '', NULL, 0, 'EMAS', '', NULL, NULL);
