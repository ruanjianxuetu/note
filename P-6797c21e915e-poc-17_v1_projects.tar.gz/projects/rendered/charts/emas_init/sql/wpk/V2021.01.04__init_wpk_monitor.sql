use log_analysis;
 
DROP TABLE IF EXISTS `wpk_alarm`;
CREATE TABLE `wpk_alarm` (
	`id` BIGINT ( 20 ) NOT NULL AUTO_INCREMENT,
	`app` VARCHAR ( 255 ) NOT NULL COMMENT 'app的唯一标识',
	`name` VARCHAR ( 255 ) NOT NULL COMMENT '供给用户填写报警名称，方便识别',
	`app_id` BIGINT ( 20 ) NOT NULL COMMENT '对应所属应用的id',
	`category` TINYINT ( 4 ) NOT NULL COMMENT '分类，0: 系统、1、自定义',
	`code` INT ( 11 ) NOT NULL COMMENT '监控code， 对应现有系统监控项code',
	`silent_period` TINYINT ( 4 ) NOT NULL COMMENT '静默期，默认：0,考虑到有“1天” 这种近似动态值，因此用数字枚举标识对应静默期',
	`unique_id` VARCHAR ( 32 ) NOT NULL COMMENT '自动生成，用于保存一条完整信息的唯一值，让各系统不依赖数据库id',
	`level` TINYINT ( 4 ) NOT NULL COMMENT '等级，0:致命、1:告警',
	`is_active` bit ( 1 ) NOT NULL COMMENT '是否开启',
	`is_deleted` bit ( 1 ) NOT NULL COMMENT '是否删除，默认0',
	`rule` LONGTEXT NOT NULL COMMENT '报警规则协议',
	`create_at` datetime NOT NULL COMMENT '创建时间',
	`create_by` VARCHAR ( 63 ) DEFAULT NULL COMMENT '创建人',
	`update_at` datetime DEFAULT NULL COMMENT '更新时间',
	`update_by` VARCHAR ( 63 ) DEFAULT NULL COMMENT '更新人',
	`bizz_type` VARCHAR ( 7 ) DEFAULT 'web',
	`src` VARCHAR ( 63 ) DEFAULT NULL COMMENT '来源，比如用于区分uc.cn和yueying',
	`dep_src` TINYINT ( 4 ) DEFAULT '0' COMMENT '数据来源，0：来源于计算数据，1：来源于存储数据',
	`time_unit` CHAR ( 7 ) DEFAULT 'm' COMMENT '规则的最小时间单位，分钟（m）、小时（h）、天（d）',
	`begin_time` time DEFAULT NULL COMMENT '告警通知开始时间',
	`end_time` time DEFAULT NULL COMMENT '告警通知结束时间',
	PRIMARY KEY ( `id` ),
	KEY `alarm_app_idx` ( `app` ),
	KEY `alarm_app_id_idx` ( `app_id` ),
	KEY `alarm_unique_id_idx` ( `unique_id` ),
	KEY `idx_active_bizzType` ( `is_active`, `is_deleted`, `bizz_type` ),
KEY `alarm_name_idx` ( `name` ) 
) ENGINE = INNODB   DEFAULT CHARSET = utf8 COMMENT = '报警表';

DROP TABLE IF EXISTS `wpk_alarm_data`;
CREATE TABLE `wpk_alarm_data` (
	`id` BIGINT ( 20 ) NOT NULL AUTO_INCREMENT,
	`alarm_id` BIGINT ( 20 ) NOT NULL COMMENT ' alarm的id',
	`integrity` INT ( 11 ) DEFAULT NULL COMMENT '完整性，当完整性不为空且为100%时，才会发送',
	`batch_id` BIGINT ( 20 ) DEFAULT NULL COMMENT '批次Id, 用于获取完整性结果',
	`alarm_data` LONGTEXT COMMENT '取回的经过处理后的报警数据',
	`origin_data` LONGTEXT COMMENT '原始报警数据',
	`status` TINYINT ( 4 ) NOT NULL COMMENT '状态：0: 待通知，1: 已通知，2: silented，3: 失败',
	`phase` TINYINT ( 4 ) NOT NULL COMMENT '数据阶段：0：初始，99：最终',
	`create_at` datetime NOT NULL COMMENT '创建时间',
	`alarm_at` datetime DEFAULT NULL COMMENT '报警时间',
	`notice_at` datetime DEFAULT NULL COMMENT '通知时间',
	`notice_result` VARCHAR ( 127 ) DEFAULT NULL COMMENT '通知结果，按通知方式映射，通知成功为0，大于0为失败次数',
	PRIMARY KEY ( `id` ),
	KEY `alarm_data_alarm_id_idx` ( `alarm_id` ),
	KEY `alarm_data_status_idx` ( `status` ) USING BTREE,
    KEY `alarm_data_phase_idx` ( `phase` ) USING BTREE 
) ENGINE = INNODB   DEFAULT CHARSET = utf8 COMMENT = '通知表';

DROP TABLE IF EXISTS `wpk_alarm_rule_base`;
CREATE TABLE `wpk_alarm_rule_base` (
	`id` BIGINT ( 20 ) NOT NULL AUTO_INCREMENT,
	`name` VARCHAR ( 255 ) NOT NULL COMMENT '规则名称',
	`rule` LONGTEXT NOT NULL COMMENT '规则内容',
	`platform` VARCHAR ( 10 ) NOT NULL COMMENT '平台，android/ios',
	`type` TINYINT ( 4 ) NOT NULL COMMENT '类型（1-默认创建；0-下拉建议选择）',
	`dep_src` TINYINT ( 4 ) NOT NULL COMMENT '数据来源，0：来源于计算数据，1：来源于存储数据',
	`create_by` BIGINT ( 11 ) DEFAULT NULL,
	`create_at` datetime DEFAULT NULL,
	`update_by` BIGINT ( 11 ) DEFAULT NULL,
	`update_at` datetime DEFAULT NULL,
	`is_deleted` bit ( 1 ) DEFAULT NULL COMMENT '是否被删除，1表示被删除，0表示没删除',
	PRIMARY KEY ( `id` ),
KEY `idx_platform_type` ( `platform`, `type` ) USING BTREE 
) ENGINE = INNODB   DEFAULT CHARSET = utf8 ;

DROP TABLE IF EXISTS `wpk_alarm_subscriber`;
CREATE TABLE `wpk_alarm_subscriber` (
	`id` BIGINT ( 20 ) NOT NULL AUTO_INCREMENT,
	`alarm_id` BIGINT ( 20 ) NOT NULL COMMENT 'alarm的id',
	`subscriber` LONGTEXT COMMENT '用户id列表、钉钉组token、webhooks url等',
	`category` TINYINT ( 4 ) NOT NULL COMMENT '类型： 1：钉钉2：邮件，3：钉钉群，4: 短信，5：webhooks',
	`is_active` bit ( 1 ) NOT NULL COMMENT '是否开启',
	PRIMARY KEY ( `id` ),
KEY `subscriber_alarm_id_idx` ( `alarm_id` ) 
) ENGINE = INNODB   DEFAULT CHARSET = utf8 COMMENT = '订阅表' ;


INSERT INTO `wpk_openapi_user`(client_id,client_key,name,description,allow_url,ip_white_list,create_at,create_by,update_at,update_by,is_deleted) VALUES ('wpk-monitor', 'yfyor4xvb6cuwtrrdbj5y8cczzq4f9xz', 'wpk报警项目', 'monitor模块使用', NULL, NULL, '2021-01-06 16:21:10', NULL, NULL, NULL, 0);


$<<importSwitch>>INSERT INTO `wpk_resource`(code,name,group_code,create_at,create_by,update_at,update_by,is_deleted) VALUES ('h5:alarm', '监控报警', 'h5', '2021-01-06 16:21:10', 1, '2021-01-06 16:21:10', 1, 0);



-- insert into `apps` (app, name, type, region, create_at, parent_id, create_by, update_at, update_by, is_deleted, agg_type, is_active, src, es_index_suffix, open_state, belong_code, belong_type) 
-- VALUES ('wpk-base-alert', '告警基准', 'html5', 1, now(), 0, 10, now(), 10, 0, 'url', 1, 'h5', 'h5_0', 0, '50000351', 'EMAS');

-- insert into `emas.emas_app` (creator, modifier, is_deleted, name, app_type, product_id, platform, package_name, app_key, app_key_secret, identifier, current_app_key, gmt_create, gmt_modified, secret_type, app_category, is_hidden)
-- VALUES('10000', '10000', 0, '告警基准', 'SIMPLE', 50000001, 'ANDROID', 'wpk-base-alert', '20000351', '16e1d507a0a7ba89e523387a56a2bf37', '20000351@android', '20000351', now(), now(), 'PRIVATE', 'H5', 0)
