CREATE DATABASE IF NOT EXISTS log_analysis;
USE log_analysis;
SET NAMES utf8mb4;
set FOREIGN_KEY_CHECKS = 0;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `apps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT '' COMMENT '类型 android ,ios',
  `package_name` varchar(255) DEFAULT NULL COMMENT '包名',
  `region` int(11) DEFAULT NULL COMMENT '区域(1国内 2国际)',
  `create_at` datetime DEFAULT NULL COMMENT '创建时间',
  `category` varchar(31) DEFAULT NULL COMMENT '分类',
  `ext_info` varchar(255) DEFAULT NULL COMMENT '扩展信息如子应用需要的信息',
  `parent_id` bigint(20) DEFAULT NULL COMMENT '父应用ID',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `crash_size` varchar(63) DEFAULT NULL COMMENT '预计崩溃日志量',
  `create_by` bigint(20) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` bigint(20) DEFAULT NULL,
  `is_deleted` tinyint(2) DEFAULT NULL,
  `version_tags` varchar(2047) DEFAULT NULL,
  `agg_type` varchar(255) DEFAULT NULL COMMENT '聚合维度，url：URL聚合；host：域名聚合',
  `is_active` tinyint(2) DEFAULT '1',
  `src` varchar(55) DEFAULT '',
  `es_index_suffix` varchar(255) DEFAULT '' COMMENT 'esindexSuffix',
  `app_group_id` bigint(11) DEFAULT NULL,
  `es_index_suffix_alias` varchar(255) DEFAULT '' COMMENT 'esIndexSuffixAlias',
  `api_agg_type` varchar(255) DEFAULT NULL COMMENT 'API聚合维度，url：URL聚合；host：域名聚合',
  `res_agg_type` varchar(255) DEFAULT NULL COMMENT '资源加载异常聚合维度，url：URL聚合；host：域名聚合',
  `open_state` tinyint(2) DEFAULT NULL COMMENT '开放状态：1：公开，0：私有',
  `belong_code` varchar(63) DEFAULT NULL COMMENT '所属code，企业应用为orgCode，个人应用为创建人megId',
  `belong_type` varchar(6) DEFAULT NULL COMMENT '应用所属类型：person：个人，org：企业',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_app` (`app`),
  KEY `idx_belongcode` (`belong_code`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `apps_ext_config` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `app_id` bigint(11) NOT NULL COMMENT '关联apps表id',
  `config_key` varchar(255) DEFAULT NULL COMMENT '扩展信息key',
  `value` varchar(255) DEFAULT NULL COMMENT '扩展信息value',
  `type` varchar(100) DEFAULT NULL COMMENT '类型',
  `create_at` datetime DEFAULT NULL,
  `create_by` bigint(11) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` bigint(11) DEFAULT NULL,
  `is_deleted` bit(1) DEFAULT NULL COMMENT '是否被删除，1表示被删除，0表示没删除',
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`app_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;



/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wp_properties_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `platform` varchar(255) NOT NULL DEFAULT '',
  `sub_platform` varchar(255) NOT NULL DEFAULT '',
  `type` int(4) NOT NULL DEFAULT '0',
  `config_key` varchar(255) NOT NULL DEFAULT '',
  `config_value` varchar(255) NOT NULL DEFAULT '',
  `version` int(11) NOT NULL DEFAULT '0',
  `update_user` varchar(255) NOT NULL DEFAULT '',
  `update_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `create_user` varchar(255) NOT NULL DEFAULT '',
  `create_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `is_deleted` int(4) NOT NULL DEFAULT '0',
  `platform_type` varchar(31) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_key` (`platform`,`sub_platform`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wp_user_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(255) NOT NULL DEFAULT '',
  `user_name` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL COMMENT '电话号码',
  `email` varchar(255) DEFAULT NULL,
  `type` int(4) DEFAULT '0',
  `company_name` varchar(225) DEFAULT NULL COMMENT '公司/部门名称',
  `active_code` varchar(255) DEFAULT NULL,
  `is_active` int(4) DEFAULT '0',
  `is_disable` int(4) DEFAULT '0',
  `update_user` varchar(255) NOT NULL DEFAULT '' COMMENT '�޸���',
  `update_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP COMMENT '�޸�ʱ��',
  `create_user` varchar(255) NOT NULL DEFAULT '' COMMENT '������',
  `create_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '����ʱ��',
  `is_deleted` int(4) NOT NULL DEFAULT '0' COMMENT '�Ƿ�ɾ��',
  `user_id` varchar(50) DEFAULT NULL COMMENT '第三方系统的用户id',
  `nickname` varchar(127) DEFAULT NULL COMMENT '用户昵称',
  `source_id` varchar(50) DEFAULT 'wpk' COMMENT '用户来源',
  `dingtalk_id` varchar(127) DEFAULT NULL COMMENT '钉钉id',
  `meg_id` varchar(63) DEFAULT NULL COMMENT 'MEG账号中心账号唯一标识',
  PRIMARY KEY (`id`),
  KEY `cache_key` (`user_name`(191)),
  KEY `IDX_USER_ID` (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='�û���';

/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_alarm` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL COMMENT 'app的唯一标识',
  `name` varchar(255) NOT NULL COMMENT '供给用户填写报警名称，方便识别',
  `app_id` bigint(20) NOT NULL COMMENT '对应所属应用的id',
  `category` tinyint(4) NOT NULL COMMENT '分类，0: 系统、1、自定义',
  `code` int(11) NOT NULL COMMENT '监控code， 对应现有系统监控项code',
  `silent_period` tinyint(4) NOT NULL COMMENT '静默期，默认：0,考虑到有“1天” 这种近似动态值，因此用数字枚举标识对应静默期',
  `unique_id` varchar(32) NOT NULL COMMENT '自动生成，用于保存一条完整信息的唯一值，让各系统不依赖数据库id',
  `level` tinyint(4) NOT NULL COMMENT '等级，0:致命、1:告警',
  `is_active` bit(1) NOT NULL COMMENT '是否开启',
  `is_deleted` bit(1) NOT NULL COMMENT '是否删除，默认0',
  `rule` longtext NOT NULL COMMENT '报警规则协议',
  `create_at` datetime NOT NULL COMMENT '创建时间',
  `create_by` varchar(63) DEFAULT NULL COMMENT '创建人',
  `update_at` datetime DEFAULT NULL COMMENT '更新时间',
  `update_by` varchar(63) DEFAULT NULL COMMENT '更新人',
  `bizz_type` varchar(7) DEFAULT 'web',
  `src` varchar(63) DEFAULT NULL COMMENT '来源，比如用于区分uc.cn和yueying',
  PRIMARY KEY (`id`),
  KEY `alarm_app_idx` (`app`),
  KEY `alarm_app_id_idx` (`app_id`),
  KEY `alarm_unique_id_idx` (`unique_id`),
  KEY `idx_active_bizzType` (`is_active`,`is_deleted`,`bizz_type`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='报警表';

/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_alarm_data` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `alarm_id` bigint(20) NOT NULL COMMENT ' alarm的id',
  `integrity` int(11) DEFAULT NULL COMMENT '完整性，当完整性不为空且为100%时，才会发送',
  `batch_id` bigint(20) DEFAULT NULL COMMENT '批次Id, 用于获取完整性结果',
  `alarm_data` longtext COMMENT '取回的经过处理后的报警数据',
  `origin_data` longtext COMMENT '原始报警数据',
  `status` tinyint(4) NOT NULL COMMENT '状态：0: 待通知，1: 已通知，2: silented，3: 失败',
  `phase` tinyint(4) NOT NULL COMMENT '数据阶段：0：初始，99：最终',
  `create_at` datetime NOT NULL COMMENT '创建时间',
  `alarm_at` datetime DEFAULT NULL COMMENT '报警时间',
  `notice_at` datetime DEFAULT NULL COMMENT '通知时间',
  `notice_result` varchar(127) DEFAULT NULL COMMENT '通知结果，按通知方式映射，通知成功为0，大于0为失败次数',
  PRIMARY KEY (`id`),
  KEY `alarm_data_alarm_id_idx` (`alarm_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39386 DEFAULT CHARSET=utf8 COMMENT='通知表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_alarm_subscriber` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `alarm_id` bigint(20) NOT NULL COMMENT 'alarm的id',
  `subscriber` longtext COMMENT '用户id列表、钉钉组token、webhooks url等',
  `category` tinyint(4) NOT NULL COMMENT '类型： 1：钉钉2：邮件，3：钉钉群，4: 短信，5：webhooks',
  `is_active` bit(1) NOT NULL COMMENT '是否开启',
  PRIMARY KEY (`id`),
  KEY `subscriber_alarm_id_idx` (`alarm_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='订阅表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_app_collect` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `app_id` bigint(11) NOT NULL COMMENT '应用id',
  `user_id` bigint(11) NOT NULL COMMENT '用户id',
  `create_at` datetime DEFAULT NULL,
  `create_by` bigint(11) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` bigint(11) DEFAULT NULL,
  `is_deleted` bit(1) DEFAULT NULL COMMENT '是否被删除，1表示被删除，0表示没删除',
  PRIMARY KEY (`id`),
  KEY `idx_appid_userid` (`app_id`,`user_id`) USING BTREE,
  KEY `idx_userid` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_app_group` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL COMMENT '应用组名称',
  `create_at` datetime DEFAULT NULL,
  `create_by` bigint(11) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` bigint(11) DEFAULT NULL,
  `is_deleted` bit(1) DEFAULT NULL COMMENT '是否被删除，1表示被删除，0表示没删除',
  `type` varchar(20) DEFAULT NULL COMMENT '应用组类型，android/ios/html5（应用组里只能添加指定类型的应用）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_app_group_role` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `app_group_id` bigint(11) NOT NULL COMMENT '关联wpk_app_group表id',
  `name` varchar(255) DEFAULT NULL COMMENT '应用组角色名',
  `is_admin` bit(1) DEFAULT NULL COMMENT '是否管理员，1表示是，0表示否',
  `create_at` datetime DEFAULT NULL,
  `create_by` bigint(11) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` bigint(11) DEFAULT NULL,
  `is_deleted` bit(1) DEFAULT NULL COMMENT '是否被删除，1表示被删除，0表示没删除',
  PRIMARY KEY (`id`),
  KEY `idx_appgroupid` (`app_group_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_app_group_role_resource` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `app_group_role_id` bigint(11) NOT NULL COMMENT '关联wpk_app_group_role表id',
  `resource_id` bigint(11) NOT NULL COMMENT '关联wpk_resource表id',
  `create_at` datetime DEFAULT NULL,
  `create_by` bigint(11) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` bigint(11) DEFAULT NULL,
  `is_deleted` bit(1) DEFAULT NULL COMMENT '是否被删除，1表示被删除，0表示没删除',
  PRIMARY KEY (`id`),
  KEY `idx_resourceid` (`resource_id`) USING BTREE,
  KEY `idx_appgrouproleid` (`app_group_role_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_app_group_role_user` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `app_group_role_id` bigint(11) NOT NULL COMMENT '关联wpk_app_group_role表id',
  `user_id` bigint(11) NOT NULL COMMENT '用户id',
  `create_at` datetime DEFAULT NULL,
  `create_by` bigint(11) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` bigint(11) DEFAULT NULL,
  `is_deleted` bit(1) DEFAULT NULL COMMENT '是否被删除，1表示被删除，0表示没删除',
  PRIMARY KEY (`id`),
  KEY `idx_appgrouproleid` (`app_group_role_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_app_module` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app_id` bigint(20) NOT NULL COMMENT '应用的id',
  `version_id` bigint(20) NOT NULL COMMENT '版本的id',
  `module_id` varchar(64) NOT NULL COMMENT '模块的id前缀',
  `file_md5` varchar(64) NOT NULL COMMENT '模块文件md5',
  `uuid` varchar(64) DEFAULT NULL COMMENT '符号唯一标识',
  `name` varchar(64) DEFAULT NULL COMMENT '模块名',
  `size` bigint(20) DEFAULT NULL COMMENT '符号总行数',
  `type` tinyint(4) NOT NULL COMMENT '类型  1-oc应用，2-oc系统，3-oc测',
  `comment` varchar(255) DEFAULT NULL COMMENT '模块说明',
  `status` tinyint(4) NOT NULL COMMENT '模块状态 1-成功，2-文件上传中，3-待处理，4-处理中，5-处理失败，6-已过期',
  `hbase_time` bigint(20) NOT NULL DEFAULT '0' COMMENT 'HBase记录创建时间,用于判断是否有效',
  `create_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  `create_at` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) DEFAULT NULL COMMENT '修改人',
  `update_at` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `APPID_IDX` (`app_id`),
  KEY `VERSIONID_IDX` (`version_id`),
  KEY `UUID_IDX` (`uuid`),
  KEY `NAME_IDX` (`name`),
  KEY `MODULEID_IDX` (`module_id`),
  KEY `FILEMD5_IDX` (`file_md5`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='符号表模块表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_app_resource` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app_id` bigint(20) DEFAULT NULL COMMENT '应用ID',
  `resource_id` bigint(20) DEFAULT NULL COMMENT '资源ID',
  `create_at` datetime DEFAULT NULL,
  `create_by` bigint(20) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` bigint(20) DEFAULT NULL,
  `is_deleted` tinyint(2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`app_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=35135 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_app_version` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app_id` bigint(20) NOT NULL COMMENT '应用标识',
  `version` varchar(255) NOT NULL COMMENT '版本号',
  `version_suffix` varchar(255) DEFAULT NULL COMMENT '版本后缀',
  `create_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  `create_at` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) DEFAULT NULL COMMENT '修改人',
  `update_at` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `APPID_VERSION` (`app_id`,`version`,`version_suffix`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='版本表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_condition_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `template_id` bigint(20) NOT NULL COMMENT '关联的模板ID',
  `label` varchar(32) DEFAULT NULL COMMENT '用于显示条件项名称',
  `default_selected` varchar(32) DEFAULT NULL COMMENT '用逗号相隔的默认选中的下标，如 单选''0''，多选''0,1''',
  `is_multiple` bit(1) DEFAULT b'0' COMMENT '指定options为单选或多选',
  `condition_key` varchar(32) DEFAULT NULL COMMENT '条件的key，多选时不能为空',
  `options` text COMMENT '条件选项，包含label、value的对象数组，label用于显示，value是具体条件',
  `sort` int(11) DEFAULT '0' COMMENT '排序字段',
  `is_deleted` bit(1) DEFAULT b'0' COMMENT '删除标记',
  `create_at` datetime DEFAULT NULL,
  `create_by` bigint(20) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_templateid` (`template_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_condition_template` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL COMMENT '用户ID，如果为0表示系统或应用级别的模板，大于0表示用户个人模板',
  `parent_id` bigint(20) DEFAULT NULL COMMENT '自关联的父模板ID，个人创建模板时会基于应用级别的模板创建，此ID就是应用级别的模板ID',
  `app_id` bigint(20) NOT NULL COMMENT '应用ID，大于0时属于对应的应用级别的模板',
  `title` varchar(32) DEFAULT NULL COMMENT '用于显示的模板标题',
  `default_conditions` varchar(1024) DEFAULT '[]' COMMENT '默认条件，key-op-value的对象数组',
  `custom_conditions` text COMMENT '自定义条件，key-op-value的对象数组',
  `sort` int(11) DEFAULT '0' COMMENT '排序字段',
  `is_default` bit(1) DEFAULT b'0' COMMENT '标记为默认显示的模板',
  `is_deleted` bit(1) DEFAULT b'0' COMMENT '删除标记',
  `create_at` datetime DEFAULT NULL,
  `create_by` bigint(20) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`app_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_elastic_search_region` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(15) NOT NULL,
  `alias_name` varchar(31) DEFAULT NULL,
  `type` varchar(15) DEFAULT NULL,
  `count` int(9) DEFAULT '0',
  `is_public` tinyint(1) DEFAULT NULL,
  `create_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_elastic_search_region_registry` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `region_id` bigint(10) NOT NULL,
  `app` varchar(31) DEFAULT NULL,
  `create_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_identify` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app_id` bigint(20) DEFAULT NULL COMMENT '关联apps表id',
  `name` varchar(255) DEFAULT NULL COMMENT '业务名称',
  `value` varchar(255) DEFAULT NULL COMMENT '业务标识',
  `create_at` datetime DEFAULT NULL,
  `create_by` bigint(20) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` bigint(20) DEFAULT NULL,
  `is_deleted` bit(1) DEFAULT NULL COMMENT '是否被删除，1表示被删除，0表示没删除',
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`app_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_identify_url` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app_id` bigint(20) NOT NULL,
  `url` varchar(255) DEFAULT NULL COMMENT '匹配的URL',
  `way` varchar(10) DEFAULT NULL COMMENT '匹配方式：前缀匹配：prefix；',
  `url_key` varchar(255) DEFAULT NULL COMMENT '新增url后生成的key值内容',
  `is_deleted` bit(1) DEFAULT NULL COMMENT '是否被删除，1表示被删除，0表示没删除',
  `create_at` datetime DEFAULT NULL,
  `create_by` bigint(20) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`app_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_join_request_config` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(127) NOT NULL COMMENT '生成的token',
  `entity_id` varchar(63) NOT NULL COMMENT '对应的实体的id',
  `entity_type` varchar(31) NOT NULL COMMENT '对应的对象类型： app、corporation、appGroup等',
  `expire_date` datetime NOT NULL COMMENT '过期时间（48小时）',
  `create_by` bigint(11) DEFAULT NULL,
  `create_at` datetime DEFAULT NULL,
  `update_by` bigint(11) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `is_deleted` bit(1) DEFAULT NULL COMMENT '是否被删除，1表示被删除，0表示没删除',
  PRIMARY KEY (`id`),
  KEY `idx_token` (`token`) USING BTREE,
  KEY `idx_entityid_entitytype` (`entity_id`,`entity_type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_join_request_record` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `entity_id` varchar(63) NOT NULL COMMENT '对应的实体的id',
  `entity_type` varchar(31) NOT NULL COMMENT '对应的对象类型： app、corporation、appGroup等',
  `approve_status` tinyint(2) NOT NULL COMMENT '审批状态：0： init，1：通过；2：拒绝',
  `req_user_id` bigint(20) NOT NULL COMMENT '申请人的ID',
  `approve_user_id` bigint(20) DEFAULT NULL COMMENT '审批人的ID',
  `approve_at` datetime DEFAULT NULL COMMENT '审批时间',
  `approve_remark` varchar(255) DEFAULT NULL COMMENT '审批备注',
  `request_remark` varchar(255) DEFAULT NULL COMMENT '申请备注',
  `create_by` bigint(11) DEFAULT NULL,
  `create_at` datetime DEFAULT NULL,
  `update_by` bigint(11) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `is_deleted` bit(1) DEFAULT NULL COMMENT '是否被删除，1表示被删除，0表示没删除',
  PRIMARY KEY (`id`),
  KEY `idx_entityid_entitytype_requserid` (`entity_id`,`entity_type`,`req_user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_meter_account` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `account_id` varchar(255) DEFAULT NULL,
  `account_status` int(11) DEFAULT NULL,
  `entity_type` varchar(8) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_accountId` (`account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_meter_data` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `entity_id` varchar(255) DEFAULT NULL,
  `entity_type` varchar(255) DEFAULT NULL,
  `account_id` varchar(255) DEFAULT NULL,
  `data_amount` bigint(20) DEFAULT NULL,
  `data_category` varchar(255) DEFAULT NULL,
  `data_date` datetime DEFAULT NULL,
  `data_id` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `create_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_dataDate` (`data_date`),
  KEY `idx_dataDate_status` (`data_date`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_meter_entity_account` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `account_id` varchar(255) DEFAULT NULL,
  `account_type` int(11) DEFAULT NULL,
  `account_status` tinyint(2) DEFAULT NULL,
  `entity_id` varchar(255) DEFAULT NULL,
  `entity_type` varchar(255) DEFAULT NULL,
  `entity_table_id` bigint(20) DEFAULT NULL,
  `status_update_date` datetime DEFAULT NULL,
  `last_summary_job_date` datetime DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entityType` (`entity_type`),
  KEY `idx_entityType_jobDate` (`entity_type`,`last_summary_job_date`),
  KEY `idx_accountStatus` (`account_status`),
  KEY `idx_entityType_accountStatus` (`entity_type`,`account_status`),
  KEY `idx_entityType_accountStatus_statusUpdateDate` (`entity_type`,`account_status`,`status_update_date`),
  KEY `idx_entityType_jobDate_accountStatus_statusUpdateDate` (`entity_type`,`last_summary_job_date`,`account_status`,`status_update_date`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_meter_invalid_resource` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `account_id` varchar(255) DEFAULT NULL,
  `entity_type` varchar(255) DEFAULT NULL,
  `invalid_date` datetime DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `status` tinyint(2) DEFAULT NULL,
  `create_at` datetime DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_accountId_entityType` (`account_id`,`entity_type`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_meter_message` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `msg_id` varchar(255) DEFAULT NULL,
  `msg_type` varchar(255) DEFAULT NULL,
  `msg_data` text,
  `status` int(11) DEFAULT NULL,
  `create_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_meter_processed_note` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `data_id` varchar(255) DEFAULT NULL,
  `data_date` datetime DEFAULT NULL,
  `retry_count` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `create_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_meter_uv_source` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `entity_id` varchar(255) DEFAULT NULL,
  `source_type` int(11) DEFAULT NULL,
  `source_date` datetime DEFAULT NULL,
  `hyper_log_log` text,
  `create_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_sourceDate` (`source_date`),
  KEY `idx_sourceDate_sourceType` (`source_date`,`source_type`),
  KEY `idx_sourceDate_sourceType_entityId` (`source_date`,`source_type`,`entity_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_method_time_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `action_id` varchar(63) NOT NULL,
  `begin_millis` bigint(20) DEFAULT NULL,
  `end_millis` bigint(20) DEFAULT NULL,
  `method_name` varchar(127) NOT NULL,
  `time_spend` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_monitor_conf` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `code` int(11) NOT NULL COMMENT '对应的监控项代码',
  `name` varchar(55) NOT NULL COMMENT '监控项名称',
  `app_id` bigint(11) NOT NULL COMMENT '关联apps表id',
  `custom_field` varchar(1000) DEFAULT NULL COMMENT '用来存储c1~c5的字段格式为[{"key":"c1","label":""}...]',
  `is_active` bit(1) DEFAULT NULL COMMENT '是否激活，0：否，1：是',
  `create_by` bigint(11) DEFAULT NULL,
  `create_at` datetime DEFAULT NULL,
  `update_by` bigint(11) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `is_deleted` bit(1) DEFAULT NULL COMMENT '是否被删除，1表示被删除，0表示没删除',
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`app_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_notice` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_at` datetime DEFAULT NULL,
  `create_by` varchar(31) DEFAULT NULL,
  `display` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `type` int(11) NOT NULL,
  `begin_time` datetime DEFAULT NULL COMMENT '生效时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `allow_sources` varchar(127) DEFAULT '' COMMENT '可访问公告的用户来源',
  PRIMARY KEY (`id`),
  KEY `idx_type_status` (`type`,`status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_notice_content` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content` longtext,
  `notice_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_notice_content_id` (`notice_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_notice_user_association` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_at` datetime DEFAULT NULL,
  `notice_id` bigint(20) DEFAULT NULL,
  `user_id` varchar(64) NOT NULL,
  `user_name` varchar(55) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_notice_user` (`notice_id`,`user_id`) USING BTREE COMMENT '公告id与用户id的组合索引',
  KEY `idx_user_notice` (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_openapi_account` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` varchar(64) NOT NULL DEFAULT '',
  `client_key` varchar(64) NOT NULL DEFAULT '',
  `is_deleted` bit(1) NOT NULL DEFAULT b'0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `client_type` tinyint(4) DEFAULT '0' COMMENT '0: app级别：1:平台级别',
  `create_by` bigint(20) unsigned NOT NULL,
  `create_at` datetime NOT NULL,
  `update_by` bigint(20) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `openapi_cliid_idx` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='2.0版本openapi账号主表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_openapi_auth_config` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `account_id` bigint(20) unsigned NOT NULL,
  `entity` varchar(64) NOT NULL DEFAULT '' COMMENT '对应App表的app字段',
  `entity_type` varchar(15) NOT NULL DEFAULT '',
  `entity_op` varchar(15) NOT NULL DEFAULT 'eq' COMMENT '资源操作，可以是op,prefix',
  `res` varchar(128) NOT NULL DEFAULT '' COMMENT '资源值',
  `is_deleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否已删除',
  `create_at` datetime NOT NULL,
  `create_by` bigint(20) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态: 0: 申请中、1: 申请通过、2: 申请不通过，需要审批的资源',
  `approve_by` bigint(20) unsigned DEFAULT NULL COMMENT '审批人',
  `approve_at` datetime DEFAULT NULL COMMENT '审批时间',
  PRIMARY KEY (`id`),
  KEY `openapi_auth_accid_idx` (`account_id`),
  KEY `openapi_auth_entity_idx` (`entity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='OpenAPI验证配置表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_openapi_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `client_id` varchar(255) NOT NULL COMMENT '接入openApi的应用标识',
  `client_key` varchar(255) NOT NULL COMMENT '接入openApi的应用密钥',
  `name` varchar(255) DEFAULT NULL COMMENT '应用名',
  `description` varchar(500) DEFAULT NULL COMMENT '说明',
  `allow_url` varchar(500) DEFAULT NULL COMMENT '允许url',
  `ip_white_list` varchar(500) DEFAULT NULL COMMENT 'ip白名单',
  `create_at` datetime DEFAULT NULL,
  `create_by` bigint(20) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` bigint(20) DEFAULT NULL,
  `is_deleted` tinyint(2) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `IDX_CLIENT_ID` (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='开放平台用户表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_resource` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(63) DEFAULT NULL COMMENT '资源编码',
  `name` varchar(63) DEFAULT NULL COMMENT '资源名称',
  `group_code` varchar(31) DEFAULT NULL COMMENT '资源组code',
  `create_at` datetime DEFAULT NULL,
  `create_by` bigint(20) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` bigint(20) DEFAULT NULL,
  `is_deleted` tinyint(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_resource_template` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app_type` varchar(31) DEFAULT NULL COMMENT 'app类型',
  `resource_id` bigint(20) DEFAULT NULL COMMENT '资源ID',
  `create_at` datetime DEFAULT NULL,
  `create_by` bigint(20) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` bigint(20) DEFAULT NULL,
  `is_deleted` tinyint(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app_id` bigint(20) DEFAULT NULL COMMENT '应用ID',
  `name` varchar(63) DEFAULT NULL COMMENT '角色名',
  `is_admin` tinyint(2) DEFAULT NULL COMMENT '是否管理员',
  `create_at` datetime DEFAULT NULL,
  `create_by` bigint(20) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` bigint(20) DEFAULT NULL,
  `is_deleted` tinyint(2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`app_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_role_resource` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) DEFAULT NULL COMMENT '角色ID',
  `resource_id` bigint(20) DEFAULT NULL COMMENT '资源ID',
  `create_at` datetime DEFAULT NULL,
  `create_by` bigint(20) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` bigint(20) DEFAULT NULL,
  `is_deleted` tinyint(2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_roleid_resourceid` (`role_id`,`resource_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_role_template` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app_type` varchar(31) DEFAULT NULL COMMENT 'app类型',
  `name` varchar(63) DEFAULT NULL COMMENT '角色名称',
  `is_admin` tinyint(2) DEFAULT NULL COMMENT '是否管理员',
  `create_at` datetime DEFAULT NULL,
  `create_by` bigint(20) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` bigint(20) DEFAULT NULL,
  `is_deleted` tinyint(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_role_template_resource` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_template_id` bigint(20) DEFAULT NULL COMMENT '角色模板ID',
  `resource_id` bigint(20) DEFAULT NULL COMMENT '资源ID',
  `create_at` datetime DEFAULT NULL,
  `create_by` bigint(20) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` bigint(20) DEFAULT NULL,
  `is_deleted` tinyint(2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_resourceid` (`resource_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_role_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) DEFAULT NULL COMMENT '角色ID',
  `user_id` bigint(20) DEFAULT NULL COMMENT '用户ID',
  `create_at` datetime DEFAULT NULL,
  `create_by` bigint(20) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` bigint(20) DEFAULT NULL,
  `is_deleted` tinyint(2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_roleid_userid` (`role_id`,`user_id`) USING BTREE,
  KEY `idx_userid` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_schedule_job_index` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL COMMENT '应用标识',
  `job_host` varchar(63) NOT NULL COMMENT '任务所在服务器ip',
  `status` int(11) DEFAULT NULL COMMENT '状态，1：新建运行中，0：已完成，-1：失败',
  `create_by` bigint(11) DEFAULT NULL,
  `create_at` datetime DEFAULT NULL,
  `update_by` bigint(11) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `is_deleted` bit(1) DEFAULT NULL COMMENT '是否被删除，1表示被删除，0表示没删除',
  `index_name` varchar(255) DEFAULT NULL COMMENT 'es上创建的index名称',
  PRIMARY KEY (`id`),
  KEY `idx_jobhost_status` (`job_host`,`status`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_schedule_job_register` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_at` datetime DEFAULT NULL,
  `create_by` bigint(20) DEFAULT NULL,
  `is_deleted` bit(1) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` bigint(20) DEFAULT NULL,
  `job_date` varchar(15) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `job_host` varchar(63) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `job_name` varchar(31) NOT NULL,
  `status` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_job_date` (`job_date`) USING BTREE,
  KEY `idx_job_name_date_status` (`job_name`,`job_date`,`status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_search_custom_key` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app_id` bigint(20) NOT NULL COMMENT '应用id',
  `user_id` bigint(20) NOT NULL COMMENT '用户id',
  `es_key` varchar(127) DEFAULT NULL COMMENT '检索Key',
  `title` varchar(255) DEFAULT NULL COMMENT 'key对应的标题',
  `type` varchar(127) DEFAULT NULL COMMENT '类型，如analysis-group：聚合分析',
  `create_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_appid_userid_type` (`app_id`,`user_id`,`type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_search_key` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app_id` bigint(20) DEFAULT NULL COMMENT 'app_id为0表示默认key',
  `type` varchar(127) DEFAULT NULL COMMENT '类型，ios/android',
  `es_key` varchar(127) DEFAULT NULL COMMENT '检索Key（与es中数据相对应）',
  `title` varchar(255) DEFAULT NULL COMMENT 'key对应的标题',
  `description` varchar(255) DEFAULT NULL COMMENT 'key的相关描述',
  `is_deleted` bit(1) DEFAULT NULL COMMENT '是否被删除，1表示被删除，0表示没删除',
  `create_at` datetime DEFAULT NULL,
  `create_by` bigint(20) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `update_by` bigint(20) DEFAULT NULL,
  `purpose` varchar(31) DEFAULT NULL COMMENT '标识key的用途，termAgg、rangeAgg、transfer',
  `sort` int(10) DEFAULT NULL COMMENT '用于前端排序使用，数值越小越靠前',
  `use_places` varchar(127) DEFAULT NULL COMMENT '使用地方，table:崩溃列表、top:top排行，多个以‘,’相隔',
  PRIMARY KEY (`id`),
  KEY `idx_appid` (`app_id`) USING BTREE,
  KEY `idx_type` (`type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_sub_search_key` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `sub_key` varchar(127) NOT NULL COMMENT 'key',
  `title` varchar(255) DEFAULT NULL COMMENT 'key对应的标题',
  `parent_id` bigint(11) DEFAULT NULL COMMENT '关联wpk_search_key表的id',
  `create_by` bigint(11) DEFAULT NULL,
  `create_at` datetime DEFAULT NULL,
  `update_by` bigint(11) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `is_deleted` bit(1) DEFAULT NULL COMMENT '是否被删除，1表示被删除，0表示没删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_symbol_file` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app_id` bigint(20) NOT NULL COMMENT '应用id',
  `version_id` bigint(20) NOT NULL COMMENT '版本id',
  `path` varchar(512) NOT NULL DEFAULT '' COMMENT '文件路径',
  `size` bigint(20) NOT NULL DEFAULT '0' COMMENT '文件大小',
  `file_md5` varchar(64) DEFAULT NULL COMMENT '文件md5',
  `cluster` varchar(32) DEFAULT NULL COMMENT '集群标识，中转代理中使用',
  `type` tinyint(4) NOT NULL COMMENT '符号类型  1-oc应用，2-oc系统，3-oc测试应用，',
  `format` tinyint(4) NOT NULL COMMENT '格式 1-machO，2-ocLine，3，wsgOcLine',
  `status` tinyint(4) NOT NULL COMMENT '状态 1-成功，2-文件上传中，3-待处理，4-处理中，5-处理失败',
  `create_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  `create_at` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) DEFAULT NULL COMMENT '修改人',
  `update_at` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `APPID_MD5` (`app_id`,`file_md5`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='原始符号文件表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_user_log_level_control` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app_id` bigint(20) DEFAULT NULL,
  `user_key` varchar(31) DEFAULT NULL,
  `user_value` varchar(127) DEFAULT NULL,
  `level` varchar(63) DEFAULT NULL,
  `valid_days` int(11) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `create_at` datetime DEFAULT NULL,
  `create_by` bigint(20) DEFAULT NULL,
  `status` tinyint(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_user_log_pull` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app_id` bigint(20) DEFAULT NULL,
  `user_key` varchar(31) DEFAULT NULL,
  `user_value` varchar(127) DEFAULT NULL,
  `process_name` varchar(255) DEFAULT NULL,
  `begin_time` varchar(31) DEFAULT NULL,
  `to_time` varchar(31) DEFAULT NULL,
  `net_type` varchar(31) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `create_at` datetime DEFAULT NULL,
  `create_by` bigint(20) DEFAULT NULL,
  `status` tinyint(2) DEFAULT NULL,
  `pull_type` varchar(31) DEFAULT NULL COMMENT '类型，如rmb、upmc',
  `expired_time` datetime DEFAULT NULL COMMENT '有效时间',
  `push_result` varchar(255) DEFAULT NULL COMMENT '通知结果',
  `pull_status` varchar(127) DEFAULT NULL COMMENT '推送结果，如：{"rmb":true,"upmc":false}',
  `analyze_status` tinyint(2) DEFAULT NULL COMMENT '解析状态，0：待解析；1：解析成功；-1：超时',
  `w_task_id` varchar(127) DEFAULT NULL COMMENT '任务id',
  `user_log_task_id` bigint(20) DEFAULT NULL COMMENT '所属ulog任务id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `wpk_user_log_task` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app_id` bigint(20) NOT NULL,
  `task_name` varchar(255) DEFAULT NULL COMMENT '任务名称',
  `begin_time` varchar(31) DEFAULT NULL COMMENT '开始时间',
  `to_time` varchar(31) DEFAULT NULL COMMENT '结束时间',
  `process_name` varchar(255) DEFAULT NULL COMMENT '选择捞取的进程名称',
  `net_type` varchar(63) DEFAULT NULL COMMENT '网络属性',
  `reason` varchar(255) DEFAULT NULL COMMENT '捞取日志原因描述',
  `custom_content` varchar(255) DEFAULT NULL COMMENT '自定义内容',
  `create_by` bigint(11) DEFAULT NULL,
  `create_at` datetime DEFAULT NULL,
  `update_by` bigint(11) DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  `is_deleted` bit(1) DEFAULT NULL COMMENT '是否被删除，1表示被删除，0表示没删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
set FOREIGN_KEY_CHECKS = 1;
