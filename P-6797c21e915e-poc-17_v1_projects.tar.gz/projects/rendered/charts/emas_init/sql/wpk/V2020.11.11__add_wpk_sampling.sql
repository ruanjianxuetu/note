use log_analysis;

-- 20200731-emas2master.sql
alter table wpk_project add column env varchar(15) default 'emas' after type;

-- 20200907_sampling.sql
CREATE TABLE `wpk_sampling_config` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `status` VARCHAR(31) NOT NULL COMMENT '配置状态',
  `sampling_target_id` VARCHAR(63) NOT NULL COMMENT '采样对象唯一标识',
  `sampling_target_type` VARCHAR(63) NOT NULL COMMENT '采样对象类型',
  `sampling_mode` VARCHAR(63) NOT NULL COMMENT '采样方式（客户端、网关...）',
  `sampling_log_type` VARCHAR(63) NOT NULL COMMENT '采样日志类型',
  `sampling_rate` VARCHAR(63) NOT NULL COMMENT '采样率',
  `is_synced` BIT NOT NULL COMMENT '是否已同步',
  `ext_client_core_container` VARCHAR(63) COMMENT '扩展-客户端内核容器',
  `ext_client_core_container_tag` VARCHAR(63) COMMENT '扩展-客户端内核容器app的默认采样tag信息',
  `create_at` DATETIME NOT NULL,
  `create_by` BIGINT NOT NULL,
  `update_at` DATETIME NOT NULL,
  `update_by` BIGINT NOT NULL,
  `is_deleted` BIT NOT NULL,
  `version` BIGINT NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
COMMENT = '采样配置';

CREATE TABLE `wpk_gateway_app_conf` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `apps` VARCHAR(127) NOT NULL COMMENT 'app标识',
  `config_content` TEXT NOT NULL COMMENT '配置内容',
  `create_at` DATETIME NOT NULL,
  `create_by` BIGINT NOT NULL,
  `update_at` DATETIME NOT NULL,
  `update_by` BIGINT NOT NULL,
  `is_deleted` BIT NOT NULL,
  `version` BIGINT NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
COMMENT = '网关应用配置';

CREATE TABLE `wpk_gateway_gateway_limit` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `apps` VARCHAR(127) NOT NULL COMMENT 'app标识',
  `config_content` TEXT NOT NULL COMMENT '配置内容',
  `create_at` DATETIME NOT NULL,
  `create_by` BIGINT NOT NULL,
  `update_at` DATETIME NOT NULL,
  `update_by` BIGINT NOT NULL,
  `is_deleted` BIT NOT NULL,
  `version` BIGINT NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
COMMENT = '网关服务端采样配置';

-- 20200924_monitor.sql
alter table wpk_monitor_conf add column dims_config varchar (2047) comment '维度配置';

-- 20200927_monitor.sql
alter table wpk_monitor_conf modify column custom_field varchar (2047);

-- 20201110-quality-report.sql
ALTER TABLE `wpk_quality_report_result` ADD COLUMN assess_score decimal(5,2)
,ADD COLUMN assess_grade VARCHAR(31);

-- 插入openApi账号
INSERT INTO wpk_openapi_account(`client_id`, `client_key`, `is_deleted`, `name`, `description`, `client_type`, `create_by`, `create_at`, `update_by`, `update_at`) VALUES ('emas', 'RcfFoSC2Cwv2zWoDSACnhJTojLavYxeQ', b'0', 'EMAS-WPK', '', 3, 8, NOW(), 8, NOW());