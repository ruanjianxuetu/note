USE `emas_mqc`;
set names utf8;

-- DROP TABLE `mts_free_res_record`;
-- DROP TABLE `mts_chromedriver_version_mapping`;
-- DROP TABLE `mts_order`;

ALTER TABLE `mts_app_device_perf` MODIFY COLUMN `avg_sys_score` decimal(10, 2) NULL DEFAULT NULL COMMENT '系统运行平均分' AFTER `num`;

ALTER TABLE `mts_app_device_perf` MODIFY COLUMN `avg_pid_score` decimal(10, 2) NULL DEFAULT NULL COMMENT '进程运行平均分' AFTER `avg_sys_score`;

ALTER TABLE `mts_device_type` MODIFY COLUMN `device_type` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'PHONE' COMMENT '手机-PHONE，平板-TABLET，电视盒子-TV，模拟器-EMULATOR' AFTER `gmt_modified`;

ALTER TABLE `mts_device_type` MODIFY COLUMN `cpu` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'cpu频率，例如：4GHz' AFTER `price`;

ALTER TABLE `mts_device_type` MODIFY COLUMN `device_name` varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '设备名' AFTER `is_hot`;

ALTER TABLE `mts_device_type` MODIFY COLUMN `gpu` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'GPU型号，如Adreno (TM) 305' AFTER `newmodel`;

ALTER TABLE `mts_execution` MODIFY COLUMN `login_param` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '登陆参数，json格式的用户名密码' AFTER `h5_test_urls`;

-- ALTER TABLE `mts_execution` DROP COLUMN `base_check_result`;

ALTER TABLE `mts_execution` ADD COLUMN `order_id` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '订单表id';

ALTER TABLE `mts_execution_task` MODIFY COLUMN `result_json` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '结果全集，json串' AFTER `msg`;

ALTER TABLE `mts_package` ADD INDEX `IDX_PLATFORMTYPE`(`platform_type`(5)) USING BTREE;

ALTER TABLE `mts_perf_data` ADD INDEX `idx_execution_id`(`execution_id`) USING BTREE;

-- ALTER TABLE `mts_remote_case` DROP COLUMN `lock_user_id`;

-- ALTER TABLE `mts_remote_case` DROP COLUMN `lock_begin_date`;

ALTER TABLE `mts_remote_order_debug` ADD COLUMN `aliyun_subuser_id` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '阿里云子账号id' AFTER `charge_time`;

ALTER TABLE `mts_service` MODIFY COLUMN `spec_json` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商品规格信息' AFTER `price`;

ALTER TABLE `mts_execution` MODIFY COLUMN `test_mode` varchar(64) NULL COMMENT '测试策略，如用例优先(CASE_FIRST)、设备优先(DEVICE_FIRST)';
  
ALTER TABLE `mts_package`
  ADD KEY `idx_project_id` (`project_id`);

ALTER TABLE `mts_remote_case`
  ADD KEY `idx_case_version_id` (`case_version_id`);

ALTER TABLE `mts_remote_case_suite`
  ADD KEY `idx_case_version_id` (`case_version_id`),
  ADD KEY `idx_case_module_id` (`case_module_id`);

ALTER TABLE `mts_case_version`
  ADD KEY `idx_project_id` (`project_id`);

ALTER TABLE `mts_case_param_space`
  ADD KEY `idx_project_id` (`project_id`);

ALTER TABLE `mts_case_module`
  ADD KEY `idx_case_version_id` (`case_version_id`);

ALTER TABLE `mts_case_dir`
  ADD KEY `idx_case_version_id` (`case_version_id`);

ALTER TABLE `mts_remote_case_func`
  ADD KEY `idx_project_id` (`project_id`);

ALTER TABLE `mts_automation_test_script`
  ADD KEY `idx_project_id` (`project_id`);

--
-- mts_service.spec_json含义增强
-- duration=-1 代表用户指定d时长
-- deviceNum=0 代表不需要提供机型id
-- deviceNum=-1 代表自选机型
-- deviceNum>0 代表系统生成的机型数量
--
UPDATE `mts_service` SET `spec_json` = '{\"executionType\":\"COMPATIBILITY\", \"duration\":-1}' WHERE (`service_name`='ANDROID_COM_CHARGE') LIMIT 1;
UPDATE `mts_service` SET `spec_json` = '{\"executionType\":\"NEW_AUTOMATION\", \"duration\":600}' WHERE (`service_name`='ANDROID_AUTO_CHARGE') LIMIT 1;
UPDATE `mts_service` SET `spec_json` = '{\"executionType\":\"NEW_IOS_FUNC\", \"duration\" : 600}' WHERE (`service_name`='IOS_AUTO_CHARGE') LIMIT 1;
UPDATE `mts_service` SET `spec_json` = '{\"executionType\":\"IOSMONKEY\", \"duration\" : -1}' WHERE (`service_name`='IOS_COM_CHARGE') LIMIT 1;
UPDATE `mts_service` SET `spec_json` = '{\"executionType\":\"PERFORMANCE\", \"duration\":10, \"deviceNum\":0}' WHERE (`service_name`='ANDROID_PERF_CHARGE') LIMIT 1;

UPDATE mts_ability_cfg set status="OFFLINE" where id in(1,2);

ALTER TABLE `mts_execution` MODIFY COLUMN `replay_script_ids` text NULL COMMENT '录制回放脚本id，JSON list';
