USE `emas_mqc`;
set names utf8;

INSERT INTO `mts_role_permission` (`gmt_create`, `gmt_modified`, `role_id`, `permission_id`) VALUES(NOW(), NOW(), 6, 12);
