USE `emas_mqc`;
set names utf8;

CREATE TABLE `mts_permission` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `permission_name` varchar(64) NOT NULL COMMENT '权限名称',
  `permission_label` varchar(64) NOT NULL COMMENT '权限标志',
  `permission_type` varchar(8) NOT NULL COMMENT '权限类型: SYSTEM-系统 PROJECT-项目组',
  `description` varchar(256) DEFAULT NULL COMMENT '权限描述信息',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '记录是否被删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_permission_label` (`permission_label`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='权限表';

ALTER TABLE `mts_role`
ADD COLUMN `role_type` VARCHAR(8) NULL DEFAULT 'SYSTEM' COMMENT '角色类型: SYSTEM-系统 PROJECT-项目组' AFTER `role_name_ch`;

CREATE TABLE `mts_role_permission` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `role_id` bigint(20) unsigned NOT NULL COMMENT '角色id',
  `permission_id` bigint(20) unsigned NOT NULL COMMENT '权限id',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_role_id_permission_id` (`role_id`,`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色-权限关联表';

CREATE TABLE `mts_project` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `project_name` varchar(64) NOT NULL COMMENT '权限名称',
  `description` varchar(256) DEFAULT NULL COMMENT '项目描述信息',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '记录是否被删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='项目表';

CREATE TABLE `mts_user_role_project` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `user_id` bigint(20) unsigned NOT NULL COMMENT '用户id',
  `role_id` bigint(20) unsigned NOT NULL COMMENT '角色id',
  `project_id` bigint(20) unsigned NULL COMMENT '项目id',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_id_role_id_project_id` (`user_id`,`role_id`,`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户-角色-项目关联表';


CREATE TABLE `mts_device_project` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `device_id` bigint(20) unsigned NOT NULL COMMENT '设备id',
  `project_id` bigint(20) unsigned NULL COMMENT '项目id',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_device_id_project_id` (`device_id`,`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='设备-项目关联表';

ALTER TABLE `mts_remote_case_func`
ADD COLUMN `project_id` bigint(20) unsigned NULL COMMENT '项目id';

ALTER TABLE `mts_package`
ADD COLUMN `project_id` bigint(20) unsigned NULL COMMENT '项目id';

ALTER TABLE `mts_case_param_space`
ADD COLUMN `project_id` bigint(20) unsigned NULL COMMENT '项目id';

ALTER TABLE `mts_case_version`
ADD COLUMN `project_id` bigint(20) unsigned NULL COMMENT '项目id';

ALTER TABLE `mts_automation_test_script`
ADD COLUMN `project_id` bigint(20) unsigned NULL COMMENT '项目id';

INSERT INTO `mts_project` (`id`, `gmt_create`, `gmt_modified`, `project_name`, `description`, `is_deleted`) VALUES (1, NOW(), NOW(), '默认项目', '这是一个默认项目，您可以建立自己的项目', 0);

INSERT INTO `mts_role` (`id`, `gmt_create`, `gmt_modified`, `priority`, `role_name`, `description`, `is_deleted`, `role_name_ch`, `role_type`, `config_json`) VALUES (4, NOW(), NOW(), 3, 'PROJECT_ADMIN', '项目组管理员', 0, '项目组管理员', 'PROJECT', '{}');
INSERT INTO `mts_role` (`id`, `gmt_create`, `gmt_modified`, `priority`, `role_name`, `description`, `is_deleted`, `role_name_ch`, `role_type`, `config_json`) VALUES (5, NOW(), NOW(), 4, 'PROJECT_TESTER', '测试', 0, '测试', 'PROJECT', '{}');
INSERT INTO `mts_role` (`id`, `gmt_create`, `gmt_modified`, `priority`, `role_name`, `description`, `is_deleted`, `role_name_ch`, `role_type`, `config_json`) VALUES (6, NOW(), NOW(), 5, 'PROJECT_DEVELOPER', '开发', 0, '开发', 'PROJECT', '{}');


INSERT INTO `mts_permission` (`id`, `gmt_create`, `gmt_modified`, `permission_name`, `permission_label`, `permission_type`, `description`, `is_deleted`) VALUES (1, NOW(), NOW(), '用户管理', 'USER_MANAGE', 'SYSTEM', '用户管理', 0);
INSERT INTO `mts_permission` (`id`, `gmt_create`, `gmt_modified`, `permission_name`, `permission_label`, `permission_type`, `description`, `is_deleted`) VALUES (2, NOW(), NOW(), '设备管理', 'DEVICE_MANAGE', 'SYSTEM', '设备管理', 0);
INSERT INTO `mts_permission` (`id`, `gmt_create`, `gmt_modified`, `permission_name`, `permission_label`, `permission_type`, `description`, `is_deleted`) VALUES (3, NOW(), NOW(), '系统设置', 'SYSTEM_SETTING', 'SYSTEM', '系统设置', 0);
INSERT INTO `mts_permission` (`id`, `gmt_create`, `gmt_modified`, `permission_name`, `permission_label`, `permission_type`, `description`, `is_deleted`) VALUES (4, NOW(), NOW(), '自定义测试流程', 'TEST_ABILITY', 'SYSTEM', '自定义测试流程', 0);
INSERT INTO `mts_permission` (`id`, `gmt_create`, `gmt_modified`, `permission_name`, `permission_label`, `permission_type`, `description`, `is_deleted`) VALUES (5, NOW(), NOW(), '项目管理', 'PROJECT_MANAGE', 'SYSTEM', '项目管理', 0);
INSERT INTO `mts_permission` (`id`, `gmt_create`, `gmt_modified`, `permission_name`, `permission_label`, `permission_type`, `description`, `is_deleted`) VALUES (6, NOW(), NOW(), '脚本管理', 'GROOVY_MANAGE', 'SYSTEM', '脚本管理', 0);
INSERT INTO `mts_permission` (`id`, `gmt_create`, `gmt_modified`, `permission_name`, `permission_label`, `permission_type`, `description`, `is_deleted`) VALUES (7, NOW(), NOW(), '项目设置', 'PROJECT_SETTING', 'PROJECT', '项目设置', 0);
INSERT INTO `mts_permission` (`id`, `gmt_create`, `gmt_modified`, `permission_name`, `permission_label`, `permission_type`, `description`, `is_deleted`) VALUES (8, NOW(), NOW(), '测试工具', 'TEST_TOOL', 'PROJECT', '测试工具', 0);
INSERT INTO `mts_permission` (`id`, `gmt_create`, `gmt_modified`, `permission_name`, `permission_label`, `permission_type`, `description`, `is_deleted`) VALUES (9, NOW(), NOW(), '控制台', 'CONSOLE', 'PROJECT', '控制台', 0);
INSERT INTO `mts_permission` (`id`, `gmt_create`, `gmt_modified`, `permission_name`, `permission_label`, `permission_type`, `description`, `is_deleted`) VALUES (10, NOW(), NOW(), '安装包管理', 'PACKAGE_MANAGE', 'PROJECT', '安装包管理', 0);
INSERT INTO `mts_permission` (`id`, `gmt_create`, `gmt_modified`, `permission_name`, `permission_label`, `permission_type`, `description`, `is_deleted`) VALUES (11, NOW(), NOW(), '自动化测试', 'AUTOMATION_TEST', 'PROJECT', '自动化测试', 0);
INSERT INTO `mts_permission` (`id`, `gmt_create`, `gmt_modified`, `permission_name`, `permission_label`, `permission_type`, `description`, `is_deleted`) VALUES (12, NOW(), NOW(), '用例库管理', 'TEST_CASE_MANAGE', 'PROJECT', '用例库管理', 0);

INSERT INTO `mts_role_permission` (`gmt_create`, `gmt_modified`, `role_id`, `permission_id`) VALUES (NOW(), NOW(), 4, 7);
INSERT INTO `mts_role_permission` (`gmt_create`, `gmt_modified`, `role_id`, `permission_id`) VALUES (NOW(), NOW(), 4, 8);
INSERT INTO `mts_role_permission` (`gmt_create`, `gmt_modified`, `role_id`, `permission_id`) VALUES (NOW(), NOW(), 4, 9);
INSERT INTO `mts_role_permission` (`gmt_create`, `gmt_modified`, `role_id`, `permission_id`) VALUES (NOW(), NOW(), 4, 10);
INSERT INTO `mts_role_permission` (`gmt_create`, `gmt_modified`, `role_id`, `permission_id`) VALUES (NOW(), NOW(), 4, 11);
INSERT INTO `mts_role_permission` (`gmt_create`, `gmt_modified`, `role_id`, `permission_id`) VALUES (NOW(), NOW(), 4, 12);
INSERT INTO `mts_role_permission` (`gmt_create`, `gmt_modified`, `role_id`, `permission_id`) VALUES (NOW(), NOW(), 5, 8);
INSERT INTO `mts_role_permission` (`gmt_create`, `gmt_modified`, `role_id`, `permission_id`) VALUES (NOW(), NOW(), 5, 9);
INSERT INTO `mts_role_permission` (`gmt_create`, `gmt_modified`, `role_id`, `permission_id`) VALUES (NOW(), NOW(), 5, 10);
INSERT INTO `mts_role_permission` (`gmt_create`, `gmt_modified`, `role_id`, `permission_id`) VALUES (NOW(), NOW(), 5, 11);
INSERT INTO `mts_role_permission` (`gmt_create`, `gmt_modified`, `role_id`, `permission_id`) VALUES (NOW(), NOW(), 5, 12);
INSERT INTO `mts_role_permission` (`gmt_create`, `gmt_modified`, `role_id`, `permission_id`) VALUES (NOW(), NOW(), 6, 8);
INSERT INTO `mts_role_permission` (`gmt_create`, `gmt_modified`, `role_id`, `permission_id`) VALUES (NOW(), NOW(), 6, 9);
INSERT INTO `mts_role_permission` (`gmt_create`, `gmt_modified`, `role_id`, `permission_id`) VALUES (NOW(), NOW(), 6, 10);
INSERT INTO `mts_role_permission` (`gmt_create`, `gmt_modified`, `role_id`, `permission_id`) VALUES (NOW(), NOW(), 6, 11);

UPDATE `mts_remote_case_func` SET `project_id` = 1;
UPDATE `mts_package` SET `project_id` = 1;
UPDATE `mts_case_param_space` SET `project_id` = 1;
UPDATE `mts_case_version` SET `project_id` = 1;
UPDATE `mts_automation_test_script` SET `project_id` = 1;


ALTER TABLE `mts_package` 
CHANGE COLUMN `project_id` `project_id` BIGINT(20) UNSIGNED NULL DEFAULT 1 COMMENT '项目id' ;

ALTER TABLE `mts_remote_case_func` 
CHANGE COLUMN `project_id` `project_id` BIGINT(20) UNSIGNED NULL DEFAULT 1 COMMENT '项目id' ;

ALTER TABLE `mts_case_param_space` 
CHANGE COLUMN `project_id` `project_id` BIGINT(20) UNSIGNED NULL DEFAULT 1 COMMENT '项目id' ;

ALTER TABLE `mts_case_version` 
CHANGE COLUMN `project_id` `project_id` BIGINT(20) UNSIGNED NULL DEFAULT 1 COMMENT '项目id' ;

ALTER TABLE `mts_automation_test_script` 
CHANGE COLUMN `project_id` `project_id` BIGINT(20) UNSIGNED NULL DEFAULT 1 COMMENT '项目id' ;

ALTER TABLE mts_remote_case CHANGE step_detail step_detail text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

CREATE TABLE `mts_task_model` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `model_name` varchar(200) NOT NULL COMMENT '模板名称',
  `creator` varchar(100) NOT NULL COMMENT '模板创建者',
  `mts_uid` bigint(20) unsigned NOT NULL COMMENT '创建者id, 对应mts_user.id',
  `project_id` bigint(20) unsigned NOT NULL COMMENT '所属项目组',
  `app_url` varchar(1024) NOT NULL COMMENT '安装包地址',
  `test_type` varchar(64) NOT NULL COMMENT '测试服务',
  `test_type_params` varchar(4096) NOT NULL COMMENT '测试服务提测时所需的具体信息',
  `timer_rule` varchar(50) DEFAULT NULL COMMENT '定时器规则',
  `timer_show_rule` varchar(1024) DEFAULT NULL COMMENT '定时器展示规则字段，主要为了方便前端界面解析，与timer_rule匹配',
  `task_model_hash` varchar(50) NOT NULL COMMENT '任务模板hash码',
  `status` varchar(32) NOT NULL COMMENT '模板状态，分为ONLINE、OFFLINE',
  `is_deleted` tinyint(4) unsigned zerofill NOT NULL DEFAULT '0000' COMMENT '记录是否被删除，有效值为0和1',
  `package_id` bigint(20) DEFAULT NULL COMMENT 'app包id',
  `package_name` varchar(128) NOT NULL COMMENT 'app包名',
  `platform_type` varchar(32) NOT NULL COMMENT 'app平台类型，如ANDROID、IOS',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8  COMMENT='任务模板表';

CREATE TABLE `mts_task_model_execution` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `task_model_id` bigint(20) unsigned NOT NULL COMMENT '任务模板id',
  `app_url` varchar(1024) NOT NULL COMMENT '执行时的安装包地址',
  `timer_rule` varchar(50) DEFAULT NULL COMMENT '执行时的定时器规则',
  `timer_show_rule` varchar(1024) DEFAULT NULL COMMENT '定时器展示规则字段，主要为了方便前端界面解析，与timer_rule匹配',
  `execution_id` bigint(20) unsigned DEFAULT NULL COMMENT '任务执行id，即mts_execution.id',
  `exec_error_msg` varchar(500) DEFAULT NULL COMMENT '执行错误的信息',
  `executor` varchar(100) NOT NULL COMMENT '执行者',
  `mts_uid` bigint(20) unsigned DEFAULT NULL COMMENT '执行者id，对应mts_user.id',
  `is_deleted` tinyint(4) unsigned zerofill NOT NULL DEFAULT '0000' COMMENT '记录是否被删除，有效值为0和1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='任务模板调用情况表';

ALTER TABLE mts_execution add `remark` varchar(1024) DEFAULT NULL COMMENT '备注';

INSERT INTO `mts_permission` (`id`, `gmt_create`, `gmt_modified`, `permission_name`, `permission_label`, `permission_type`, `description`, `is_deleted`) VALUES (13, NOW(), NOW(), '任务模板管理', 'TASK_MODEL_MANAGE', 'PROJECT', '任务模板管理', 0);

INSERT INTO `mts_role_permission` (`gmt_create`, `gmt_modified`, `role_id`, `permission_id`) VALUES (NOW(), NOW(), 4, 13);
INSERT INTO `mts_role_permission` (`gmt_create`, `gmt_modified`, `role_id`, `permission_id`) VALUES (NOW(), NOW(), 5, 13);
INSERT INTO `mts_role_permission` (`gmt_create`, `gmt_modified`, `role_id`, `permission_id`) VALUES (NOW(), NOW(), 6, 13);

INSERT INTO `mts_document` VALUES ('130', '2018-11-19 11:01:43', '2018-11-21 17:45:37', '&lt;br/&gt;\n&lt;h2&gt;功能介绍&lt;/h2&gt;\n&lt;hr/&gt;&lt;br/&gt;\n&lt;span style=&quot;margin:20px&quot;&gt;测试任务模板，固化创建提测任务流程，提供可复用的提测模板，减少重复操作。在任务模板的基础上，提供相应的API接口供持续集成使用。相较于老版本的持续集成接口而言，其解决了接口入参复杂不够灵活、代码和参数配置不能分离等问题，提高了使用效率。UI界面交互式的参数配置，大大优化了用户体验，降低了配置出错的概率。&lt;/span&gt;\n&lt;br/&gt;&lt;br/&gt;&lt;br/&gt;\n&lt;h2&gt;快速接入&lt;/h2&gt;\n&lt;hr/&gt;&lt;br/&gt;\n&lt;p&gt;&lt;strong&gt;&amp;nbsp; &amp;nbsp; 第一步：创建测试任务模板&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 要在持续集成中使用任务模板相关接口，首先得登陆移动测试平台，在自动化测试-&amp;gt;测试任务模板中按需创建任务模板，创建成功后会为该模板产生一个唯一的调用执行接口地址。&lt;/p&gt;\n&lt;p&gt;&lt;strong&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 注意：&lt;/strong&gt;&lt;br/&gt;\n&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 1、测试任务模板与APP相关联，并且同属于一个项目组下，项目组管理员拥有创建、修改等权利，测试和开发人员仅有执行和查看执行结果的权利。&lt;br/&gt;\n&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 2、受限于接入手机总数等的限制，请控制好模板数量，尤其控制好定时规则的设置，合理安排触发时间。&lt;br/&gt;\n&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 3、模板列表页可进行周期执行规则的设置，其修改将在1分钟后生效，请合理设置执行规则，避免错过执行时间点。&lt;br/&gt;\n&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 4、安装包下载地址需是可直接下载apk／ipa文件的有效地址，且下载的APP包名要与模板关联的APP相同，否则触发执行时将无法通过前置条件的检查。&lt;br/&gt;\n&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 5、目前仅支持对系统自带测试服务创建测试任务模板。&lt;/p&gt;\n&lt;p&gt;&lt;strong&gt;&amp;nbsp; &amp;nbsp; 第二步：查看模板调用接口&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &lt;span style=&quot;color:orange&quot;&gt;每个任务模板都拥有一个唯一的触发执行接口地址&lt;/span&gt;，可在测试任务模板管理页查看具体的接口地址。&lt;br/&gt;\n&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 查询执行状态和详细信息的接口，可直接查看下方的API列表。&lt;/p&gt;\n&lt;p&gt;&lt;strong&gt;&amp;nbsp; &amp;nbsp; 第三步：接口调用&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 具体的接口使用说明详见下方的API列表。&lt;/p&gt;\n&lt;br/&gt;&lt;br/&gt;\n&lt;h2&gt;API列表&lt;/h2&gt;\n&lt;hr/&gt;\n&lt;table style=&quot;width:800px;margin:15px;\nborder-collapse: separate;\nborder-spacing: 0;\ntext-align: left;\nborder-radius: 4px 4px 0 0;&quot;&gt;\n    &lt;thead&gt;\n        &lt;tr style=&quot;background: #fafafa&quot;&gt;\n                &lt;th style=&quot;width:15%;padding:8px;border-bottom:1px solid #e8e8e8&quot;&gt;请求类型&lt;/th&gt;\n                &lt;th style=&quot;width:50%;padding:8px;border-bottom:1px solid #e8e8e8&quot;&gt;&lt;strong&gt;接口地址&lt;/strong&gt;&lt;/th&gt;\n                &lt;th style=&quot;width:35%;padding:8px;border-bottom:1px solid #e8e8e8&quot;&gt;&lt;strong&gt;接口说明&lt;/strong&gt;&lt;/th&gt;\n        &lt;/tr&gt;\n    &lt;/thead&gt;\n	&lt;tbody &gt;\n		&lt;tr&gt;\n			&lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;POST&lt;/td&gt;\n			&lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;taskserver.mqc.com/openapi/v2/taskmodels/:ID&lt;/td&gt;\n			&lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;触发执行任务接口，可在测试任务模板管理列表页查看每个模板的具体接口地址&lt;/td&gt;\n		&lt;/tr&gt;\n		&lt;tr&gt;\n			&lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;GET&lt;/td&gt;\n			&lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;taskserver.mqc.com/openapi/v2/taskmodels/:ID&lt;/td&gt;\n			&lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;查询任务执行状态接口&lt;/td&gt;\n		&lt;/tr&gt;\n		&lt;tr&gt;\n			&lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;GET&lt;/td&gt;\n			&lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;taskserver.mqc.com/openapi/v2/executions/:ID&lt;/td&gt;\n			&lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;查询任务执行的详细信息&lt;/td&gt;\n		&lt;/tr&gt;\n	&lt;/tbody&gt;\n&lt;/table&gt;\n&lt;br/&gt;\n&lt;h4&gt;触发执行任务接口&lt;/h4&gt;\n&lt;p&gt;\n&lt;strong&gt;&amp;nbsp; &amp;nbsp; 接口说明：&lt;/strong&gt;&lt;br/&gt;\n&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 调用指定任务模板执行测试任务。支持修改安装包地址。采用异步执行方式。&lt;br/&gt;\n&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 每个任务模板的调用地址是唯一的，此处的ID指任务模板唯一标志码，&lt;br/&gt;\n&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 可在测试任务模板管理页直接查看／复制模板对应的接口调用链接。&lt;br/&gt;\n&lt;/p&gt;\n&lt;p&gt;&lt;strong&gt;&amp;nbsp; &amp;nbsp; 请求url：&lt;/strong&gt;&lt;br/&gt;\n&lt;pre style=&quot;margin:15px;padding:8px&quot;&gt;\n&lt;code&gt;POST     taskserver.mqc.com/openapi/v2/taskmodels/:ID&lt;/code&gt;\n&lt;/pre&gt;\n&lt;/p&gt;\n&lt;p&gt;&lt;strong&gt;&amp;nbsp; &amp;nbsp; 入参：&lt;/strong&gt;\n\n&lt;table style=&quot;width:850px;margin:15px;\nborder-collapse: separate;\nborder-spacing: 0;\ntext-align: left;\nborder-radius: 4px 4px 0 0;&quot;&gt;\n    &lt;thead&gt;\n        &lt;tr style=&quot;background: #fafafa&quot;&gt;\n                &lt;th style=&quot;width:12%;padding:8px;border-bottom:1px solid #e8e8e8&quot;&gt;参数&lt;/th&gt;\n                &lt;th style=&quot;width:12%;padding:8px;border-bottom:1px solid #e8e8e8&quot;&gt;类型&lt;/th&gt;\n                &lt;th style=&quot;width:52%;padding:8px;border-bottom:1px solid #e8e8e8&quot;&gt;描述&lt;/th&gt;\n                &lt;th style=&quot;width:12%;padding:8px;border-bottom:1px solid #e8e8e8&quot;&gt;约束&lt;/th&gt;\n                &lt;th style=&quot;width:12%;padding:8px;border-bottom:1px solid #e8e8e8&quot;&gt;默认值&lt;/th&gt;\n        &lt;/tr&gt;\n    &lt;/thead&gt;\n	&lt;tbody&gt;\n		&lt;tr&gt;\n                &lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;uid&lt;/td&gt;\n                &lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;Long&lt;/td&gt;\n                &lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;用户id(外部用户系统关联id, 若未传此参数，默认使用超级管理员uid)&lt;/td&gt;\n                &lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;非必需&lt;/td&gt;\n                &lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;-&lt;/td&gt;\n		&lt;/tr&gt;\n		&lt;tr&gt;\n\n                &lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;appUrl&lt;/td&gt;\n                &lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;String&lt;/td&gt;\n                &lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;安装包下载地址。此入参只会临时替换模板中的安装包地址。&lt;/td&gt;\n                &lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;非必需&lt;/td&gt;\n                &lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;-&lt;/td&gt;\n		&lt;/tr&gt;\n	&lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/p&gt;\n&lt;p&gt;&lt;strong&gt;&amp;nbsp; &amp;nbsp; 调用示例：&lt;/strong&gt;&lt;/p&gt;\n&lt;pre style=&quot;margin:15px;padding:8px&quot;&gt;\n&lt;code&gt;curl -H &#39;X-User-Agent: mqc&#39; -H &#39;X-HTTP-Method-Override: POST&#39; -H &#39;content-type: application/json&#39; -H &#39;X-API-Signature: xxxx&#39; -d &#39;{&amp;quot;appUrl&amp;quot;:&amp;quot;http://fsadfaag/sdf.apk&amp;quot;}&#39; taskserver.mqc.com/openapi/v2/taskmodels/6000000545045972&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;&lt;strong&gt;&amp;nbsp; &amp;nbsp; 请求成功返回的结果数据示例：&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 调用成功，会返回任务模板执行记录id，根据该id可查询任务执行状态。&lt;/p&gt;\n&lt;pre style=&quot;margin:15px;padding:8px&quot;&gt;\n&lt;code&gt;{\n    &amp;quot;taskModelExecutionId&amp;quot;:&amp;quot;42&amp;quot;\n}&lt;/code&gt;&lt;/pre&gt;\n&lt;br/&gt;\n&lt;h4&gt;查询任务执行状态接口&lt;/h4&gt;\n\n&lt;p&gt;&lt;strong&gt;&amp;nbsp; &amp;nbsp; 接口说明：&lt;/strong&gt;&lt;/p&gt;\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 查询持续集成调用执行状态，此处的ID指任务模板执行记录id，即上方触发执行任务接口返回的数据。&lt;/p&gt;\n\n&lt;p&gt;&lt;strong&gt;&amp;nbsp; &amp;nbsp; 请求url：&lt;/strong&gt;&lt;/p&gt;\n&lt;pre style=&quot;margin:15px;padding:8px&quot;&gt;&lt;code&gt;GET     taskserver.mqc.com/openapi/v2/taskmodels/:ID&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;&lt;strong&gt;&amp;nbsp; &amp;nbsp; 调用示例：&lt;/strong&gt;&lt;/p&gt;\n&lt;pre  style=&quot;margin:15px;padding:8px&quot;&gt;\n&lt;code&gt;curl -H &#39;X-User-Agent: mqc&#39; -H &#39;X-HTTP-Method-Override: GET&#39; -H &#39;X-API-Signature: xxxx&#39; taskserver.mqc.com/openapi/v2/taskmodels/42&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;&lt;strong&gt;&amp;nbsp; &amp;nbsp; 请求成功返回的结果数据示例：&lt;/strong&gt;&lt;/p&gt;\n&lt;pre style=&quot;margin:15px;padding:8px&quot;&gt;\n&lt;code&gt;{\n    &amp;quot;id&amp;quot;:42,\n    &amp;quot;appUrl&amp;quot;:&amp;quot;http://fsadfaag/sdf.apk&amp;quot;,\n    &amp;quot;executionId&amp;quot;:21,\n    &amp;quot;executor&amp;quot;:&amp;quot;CI_API&amp;quot;,\n    &amp;quot;isDeleted&amp;quot;:0,\n    &amp;quot;status&amp;quot;:&amp;quot;FINISHED&amp;quot;,\n    &amp;quot;taskModelId&amp;quot;:6\n}&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;&lt;strong&gt;&amp;nbsp; &amp;nbsp; 状态码说明：&lt;/strong&gt;&lt;/p&gt;\n&lt;table style=&quot;width:500px;margin:15px;\nborder-collapse: separate;\nborder-spacing: 0;\ntext-align: left;\nborder-radius: 4px 4px 0 0;&quot;&gt;\n    &lt;thead&gt;\n        &lt;tr style=&quot;background: #fafafa&quot;&gt;\n                &lt;th style=&quot;width:35%;padding:8px;border-bottom:1px solid #e8e8e8&quot;&gt;状态码&lt;/th&gt;\n                &lt;th style=&quot;width:65%;padding:8px;border-bottom:1px solid #e8e8e8&quot;&gt;描述&lt;/th&gt;\n        &lt;/tr&gt;\n    &lt;/thead&gt;\n	&lt;tbody&gt;\n		&lt;tr&gt;\n                &lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;PRECHECK&lt;/td&gt;\n                &lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;正式测试前的检查工作，如检查安装包地址、被测机型状态等&lt;/td&gt;\n		&lt;/tr&gt;\n		&lt;tr&gt;\n                &lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;EXEC_ERROR&lt;/td&gt;\n                &lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;执行错误。如安装包地址异常、所有被测机型状态异常等&lt;/td&gt;\n		&lt;/tr&gt;\n		&lt;tr&gt;\n                &lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;WAITING&lt;/td&gt;\n                &lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;表示已通过测试前的检查工作，正在排队等待正式被执行中&lt;/td&gt;\n		&lt;/tr&gt;\n		&lt;tr&gt;\n                &lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;RUNNING&lt;/td&gt;\n                &lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;正在执行测试任务中&lt;/td&gt;\n		&lt;/tr&gt;\n		&lt;tr&gt;\n                &lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;FINISHED&lt;/td&gt;\n                &lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;测试任务执行结束&lt;/td&gt;\n		&lt;/tr&gt;\n		&lt;tr&gt;\n                &lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;USER_CANCELED&lt;/td&gt;\n                &lt;td style=&quot;padding:5px;border-bottom:1px solid #e8e8e8&quot;&gt;用户取消了该次执行&lt;/td&gt;\n		&lt;/tr&gt;\n	&lt;/tbody&gt;\n&lt;/table&gt;\n&lt;br/&gt;\n&lt;h4&gt;查询任务执行详细信息&lt;/h4&gt;\n\n&lt;p&gt;&lt;strong&gt;&amp;nbsp; &amp;nbsp; 接口说明：&lt;/strong&gt;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 查询任务正式执行后的详细信息，此处的ID指任务模板执行记录id，即上方查询任务执行状态接口中返回的executionId。&lt;/p&gt;\n\n&lt;p&gt;&lt;strong&gt;&amp;nbsp; &amp;nbsp; 请求url：&lt;/strong&gt;&lt;/p&gt;\n&lt;pre style=&quot;margin:15px;padding:8px&quot;&gt;&lt;code&gt;GET    taskserver.mqc.com/openapi/v2/executions/:ID&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;&lt;strong&gt;&amp;nbsp; &amp;nbsp; 调用示例：&lt;/strong&gt;&lt;/p&gt;\n&lt;pre style=&quot;margin:15px;padding:8px&quot;&gt;\n&lt;code&gt;curl -H &#39;X-User-Agent: mqc&#39; -H &#39;X-HTTP-Method-Override: GET&#39; -H &#39;X-API-Signature: xxxx&#39; -H &#39;X-Timestamp: xxxx&#39; taskserver.mqc.com/openapi/v2/executions/21&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;&lt;strong&gt;&amp;nbsp; &amp;nbsp; 请求成功返回的结果数据示例：&lt;/strong&gt;&lt;/p&gt;\n&lt;pre style=&quot;margin:15px;padding:8px&quot;&gt;\n&lt;code&gt;{\n	&amp;quot;id&amp;quot;: 1, // 测试任务id\n	&amp;quot;test_type&amp;quot; : &amp;quot;COMPATIBILITY&amp;quot;, // 测试类型\n	&amp;quot;package_id&amp;quot; : 1, // 安装包id\n	&amp;quot;h5_test_url&amp;quot; : null, // h5测试url\n	&amp;quot;platform_type&amp;quot; : &amp;quot;ANDROID&amp;quot;, // APP类型\n	&amp;quot;status&amp;quot; : &amp;quot;WAITING&amp;quot;, // 当前状态，可选枚举值为：WAITING|RUNING|FINISHED|USER_CANCELED分别代表：等待中|执行中|执行结束|用户取消\n	&amp;quot;user_id&amp;quot; : 1, // 用户id\n	&amp;quot;login_param&amp;quot; : null // 自动登录参数\n	&amp;quot;callback_url&amp;quot; : null, // 测试完成回调URL\n	&amp;quot;emails&amp;quot; : null, // 接收测试完成通知的email，如有多个以逗号分隔\n	&amp;quot;test_mode&amp;quot; : null, // 测试策略\n	&amp;quot;description&amp;quot; : null, // 任务备注\n	&amp;quot;begin_time&amp;quot; : null, // 测试开始时间\n	&amp;quot;end_time&amp;quot; : null, // 测试结束时间\n	&amp;quot;gmt_create&amp;quot; : &amp;quot;2017-11-16 15:10:53&amp;quot;, // 创建时间\n	&amp;quot;share_code&amp;quot; : null, // 报告分享码\n	&amp;quot;gmt_share_validate&amp;quot; : null, // 报告分享码的失效时间\n	&amp;quot;total&amp;quot; : 3, // 总测试终端数量\n	&amp;quot;success&amp;quot; : 0, // 测试通过终端数量\n	&amp;quot;fail&amp;quot; : 0, // 测试未通过终端数量，包括安装失败、启动失败、Monkey失败、卸载失败等\n	&amp;quot;waiting&amp;quot; : 3, // 等待执行测试的终端数量\n	&amp;quot;running&amp;quot; : 0, // 正在执行测试的终端数量\n	&amp;quot;abnormal&amp;quot; : 0 // 异常的终端数量\n}&lt;/code&gt;\n&lt;/pre&gt;', '持续集成接口使用指南', '皓青', '\n功能介绍\n\n测试任务模板，固化创建提测任务流程，提供可复用的提测模板，减少重复操作。在任务模板的基础上，提供相应的API接口供持续集成使用。相较于老版本的持续集成接口而言，其解决了接口入参复杂不够灵活、代码和参数配置不能分离等问题，提高了使用效率。UI界面交互式的参数配置，大大优化了用户体验，降低了配置出错的概率。\n\n快速接入\n\n    第一步：创建测试任务模板\n          要在持续集成中使用任务模板相关接口，首先得登陆移动测试平台，在自动化测试->测试任务模板中按需创建任务模板，创建成功后会为该模板产生一个唯一的调用执行接口地址。\n          注意：\n                1、测试任务模板与APP相关联，并且同属于一个项目组下，项目组管理员拥有创建、修改等权利，测试和开发人员仅有执行和查看执行结果的权利。\n                2、受限于接入手机总数等的限制，请控制好模板数量，尤其控制好定时规则的设置，合理安排触发时间。\n                3、模板列表页可进行周期执行规则的设置，其修改将在1分钟后生效，请合理设置执行规则，避免错过执行时间点。\n                4、安装包下载地址需是可直接下载apk／ipa文件的有效地址，且下载的APP包名要与模板关联的APP相同，否则触发执行时将无法通过前置条件的检查。\n                5、目前仅支持对系统自带测试服务创建测试任务模板。\n    第二步：查看模板调用接口\n          每个任务模板都拥有一个唯一的触发执行接口地址，可在测试任务模板管理页查看具体的接口地址。\n          查询执行状态和详细信息的接口，可直接查看下方的API列表。\n    第三步：接口调用\n          具体的接口使用说明详见下方的API列表。\n\nAPI列表\n\n\n    \n        \n                请求类型\n                接口地址\n                接口说明\n        \n    \n	\n		\n			POST\n			taskserver.mqc.com/openapi/v2/taskmodels/:ID\n			触发执行任务接口，可在测试任务模板管理列表页查看每个模板的具体接口地址\n		\n		\n			GET\n			taskserver.mqc.com/openapi/v2/taskmodels/:ID\n			查询任务执行状态接口\n		\n		\n			GET\n			taskserver.mqc.com/openapi/v2/executions/:ID\n			查询任务执行的详细信息\n		\n	\n\n\n触发执行任务接口\n\n    接口说明：\n            调用指定任务模板执行测试任务。支持修改安装包地址。采用异步执行方式。\n            每个任务模板的调用地址是唯一的，此处的ID指任务模板唯一标志码，\n            可在测试任务模板管理页直接查看／复制模板对应的接口调用链接。\n\n    请求url：\n\nPOST     taskserver.mqc.com/openapi/v2/taskmodels/:ID\n\n\n    入参：\n\n\n    \n        \n                参数\n                类型\n                描述\n                约束\n                默认值\n        \n    \n	\n		\n                uid\n                Long\n                用户id(外部用户系统关联id, 若未传此参数，默认使用超级管理员uid)\n                非必需\n                -\n		\n		\n\n                appUrl\n                String\n                安装包下载地址。此入参只会临时替换模板中的安装包地址。\n                非必需\n                -\n		\n	\n\n\n    调用示例：\n\ncurl -H \'X-User-Agent: mqc\' -H \'X-HTTP-Method-Override: POST\' -H \'content-type: application/json\' -H \'X-API-Signature: xxxx\' -d \'{&quot;appUrl&quot;:&quot;http://fsadfaag/sdf.apk&quot;}\' taskserver.mqc.com/openapi/v2/taskmodels/6000000545045972\n\n    请求成功返回的结果数据示例：\n            调用成功，会返回任务模板执行记录id，根据该id可查询任务执行状态。\n\n{\n    &quot;taskModelExecutionId&quot;:&quot;42&quot;\n}\n\n查询任务执行状态接口\n\n    接口说明：\n            查询持续集成调用执行状态，此处的ID指任务模板执行记录id，即上方触发执行任务接口返回的数据。\n\n    请求url：\nGET     taskserver.mqc.com/openapi/v2/taskmodels/:ID\n\n    调用示例：\n\ncurl -H \'X-User-Agent: mqc\' -H \'X-HTTP-Method-Override: GET\' -H \'X-API-Signature: xxxx\' taskserver.mqc.com/openapi/v2/taskmodels/42\n\n    请求成功返回的结果数据示例：\n\n{\n    &quot;id&quot;:42,\n    &quot;appUrl&quot;:&quot;http://fsadfaag/sdf.apk&quot;,\n    &quot;executionId&quot;:21,\n    &quot;executor&quot;:&quot;CI_API&quot;,\n    &quot;isDeleted&quot;:0,\n    &quot;status&quot;:&quot;FINISHED&quot;,\n    &quot;taskModelId&quot;:6\n}\n\n    状态码说明：\n\n    \n        \n                状态码\n                描述\n        \n    \n	\n		\n                PRECHECK\n                正式测试前的检查工作，如检查安装包地址、被测机型状态等\n		\n		\n                EXEC_ERROR\n                执行错误。如安装包地址异常、所有被测机型状态异常等\n		\n		\n                WAITING\n                表示已通过测试前的检查工作，正在排队等待正式被执行中\n		\n		\n                RUNNING\n                正在执行测试任务中\n		\n		\n                FINISHED\n                测试任务执行结束\n		\n		\n                USER_CANCELED\n                用户取消了该次执行\n		\n	\n\n\n查询任务执行详细信息\n\n    接口说明：\n\n            查询任务正式执行后的详细信息，此处的ID指任务模板执行记录id，即上方查询任务执行状态接口中返回的executionId。\n\n    请求url：\nGET    taskserver.mqc.com/openapi/v2/executions/:ID\n\n    调用示例：\n\ncurl -H \'X-User-Agent: mqc\' -H \'X-HTTP-Method-Override: GET\' -H \'X-API-Signature: xxxx\' -H \'X-Timestamp: xxxx\' taskserver.mqc.com/openapi/v2/executions/21\n\n    请求成功返回的结果数据示例：\n\n{\n	&quot;id&quot;: 21, // 测试任务id\n	&quot;test_type&quot; : &quot;COMPATIBILITY&quot;, // 测试类型\n	&quot;package_id&quot; : 1, // 安装包id\n	&quot;h5_test_url&quot; : null, // h5测试url\n	&quot;platform_type&quot; : &quot;ANDROID&quot;, // APP类型\n	&quot;status&quot; : &quot;WAITING&quot;, // 当前状态，可选枚举值为：WAITING|RUNING|FINISHED|USER_CANCELED分别代表：等待中|执行中|执行结束|用户取消\n	&quot;user_id&quot; : 1, // 用户id\n	&quot;login_param&quot; : null // 自动登录参数\n	&quot;callback_url&quot; : null, // 测试完成回调URL\n	&quot;emails&quot; : null, // 接收测试完成通知的email，如有多个以逗号分隔\n	&quot;test_mode&quot; : null, // 测试策略\n	&quot;description&quot; : null, // 任务备注\n	&quot;begin_time&quot; : null, // 测试开始时间\n	&quot;end_time&quot; : null, // 测试结束时间\n	&quot;gmt_create&quot; : &quot;2017-11-16 15:10:53&quot;, // 创建时间\n	&quot;share_code&quot; : null, // 报告分享码\n	&quot;gmt_share_validate&quot; : null, // 报告分享码的失效时间\n	&quot;total&quot; : 3, // 总测试终端数量\n	&quot;success&quot; : 0, // 测试通过终端数量\n	&quot;fail&quot; : 0, // 测试未通过终端数量，包括安装失败、启动失败、Monkey失败、卸载失败等\n	&quot;waiting&quot; : 3, // 等待执行测试的终端数量\n	&quot;running&quot; : 0, // 正在执行测试的终端数量\n	&quot;abnormal&quot; : 0 // 异常的终端数量\n}\n', '0', '3', '1');