USE `emas_mqc`;
set names utf8;

ALTER TABLE `mts_execution`
    ADD COLUMN `project_id` bigint unsigned NULL COMMENT 'project id';