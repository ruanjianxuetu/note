USE `emas_mqc`;
set names utf8;

ALTER TABLE `mts_device_type`
	ADD COLUMN `level` varchar(64) NULL COMMENT '设备分级';
