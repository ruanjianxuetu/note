USE `emas_mqc`;
set names utf8;

INSERT INTO `emas_mqc`.`mts_permission` (`id`, `gmt_create`, `gmt_modified`, `permission_name`, `permission_label`, `permission_type`, `description`, `is_deleted`) VALUES (14, NOW(), NOW(), '在线录制', 'REMOTE_RECORD', 'PROJECT', '在线录制', 0);
INSERT INTO `emas_mqc`.`mts_permission` (`id`, `gmt_create`, `gmt_modified`, `permission_name`, `permission_label`, `permission_type`, `description`, `is_deleted`) VALUES (15, NOW(), NOW(), '远程调试', 'REMOTE_DEBUG', 'PROJECT', '远程调试', 0);

INSERT INTO `emas_mqc`.`mts_role_permission` (`gmt_create`, `gmt_modified`, `role_id`, `permission_id`) VALUES (NOW(), NOW(), 4, 14);
INSERT INTO `emas_mqc`.`mts_role_permission` (`gmt_create`, `gmt_modified`, `role_id`, `permission_id`) VALUES (NOW(), NOW(), 4, 15);
INSERT INTO `emas_mqc`.`mts_role_permission` (`gmt_create`, `gmt_modified`, `role_id`, `permission_id`) VALUES (NOW(), NOW(), 5, 14);
INSERT INTO `emas_mqc`.`mts_role_permission` (`gmt_create`, `gmt_modified`, `role_id`, `permission_id`) VALUES (NOW(), NOW(), 5, 15);
INSERT INTO `emas_mqc`.`mts_role_permission` (`gmt_create`, `gmt_modified`, `role_id`, `permission_id`) VALUES (NOW(), NOW(), 6, 15);