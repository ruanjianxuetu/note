USE `emas_mqc`;
set names utf8;

ALTER TABLE `mts_remote_order_debug`
    ADD COLUMN `exit_reason` varchar(4096) NULL COMMENT '远程调试异常退出原因';