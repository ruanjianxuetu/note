USE `emas_mqc`;
set names utf8;

ALTER TABLE `mts_execution_task`
    ADD COLUMN `normal_images` mediumtext NULL COMMENT '任务检测普通图片',
    ADD COLUMN `exception_images` mediumtext NULL COMMENT '任务检测异常图片';