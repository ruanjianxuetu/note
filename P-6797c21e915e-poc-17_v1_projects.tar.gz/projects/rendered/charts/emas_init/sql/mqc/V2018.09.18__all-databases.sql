-- MySQL dump 10.13  Distrib 5.7.19, for Linux (x86_64)
--
-- Host: localhost    Database: 
-- ------------------------------------------------------
-- Server version	5.7.19-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `emas_mqc_mdp`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `emas_mqc_mdp` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `emas_mqc_mdp`;

--
-- Table structure for table `accessory`
--

DROP TABLE IF EXISTS `accessory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accessory` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'primary key',
  `type` varchar(32) NOT NULL COMMENT 'HUB/MONITOR/PC',
  `asset_num` varchar(128) NOT NULL COMMENT '资产编号或者用户编写的编号，用于标识附件',
  `idc` varchar(32) DEFAULT NULL COMMENT '所在位置',
  `it_holder` varchar(64) DEFAULT NULL COMMENT '资产持有人',
  `brand` varchar(128) NOT NULL COMMENT '品牌',
  `model` varchar(128) NOT NULL COMMENT '型号',
  `property` text COMMENT '其他属性，json格式',
  `agent_id` bigint(20) DEFAULT NULL COMMENT '一个HUB对应1/0个agent；一个PC对应1/0个agent；一个HUB对应0/多个device；',
  `description` text COMMENT '描述信息，用于存储额外信息',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `idx_accessory_agent_id` (`agent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='其他设备';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accessory`
--

LOCK TABLES `accessory` WRITE;
/*!40000 ALTER TABLE `accessory` DISABLE KEYS */;
/*!40000 ALTER TABLE `accessory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent`
--

DROP TABLE IF EXISTS `agent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agent` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `ip` varchar(32) NOT NULL COMMENT 'IP',
  `hostname` varchar(128) DEFAULT NULL COMMENT 'HOSTNAME',
  `agent_version` varchar(32) DEFAULT NULL COMMENT '版本信息',
  `idc` varchar(32) DEFAULT NULL COMMENT 'IDC',
  `os_type` varchar(32) DEFAULT NULL COMMENT '系统类型',
  `os_version` varchar(128) DEFAULT NULL COMMENT '系统版本',
  `status` tinyint(4) DEFAULT '0' COMMENT 'Agent在线状态\n0-未上线\n1-在线\n2-掉线\n3-下线',
  `env_id` tinyint(4) DEFAULT '0' COMMENT 'Agent所属环境 1-mts 2-mtl',
  `description` text COMMENT '描述信息，用于存储额外信息',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `alert_receiver` text COMMENT '报警接收者，内容为用户的6位工号或者其他唯一标示，多个用户之间用“,”隔开',
  `alert_info` text COMMENT '报警信息，格式为json，例如{"agent_offline":"","device_offline":"50%","device_not_in_mdp":["TD112800061337"]} 表示已发送agent掉线报警，一半以上设备掉线报警，有设备未上线到mdp的报警',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip_unique` (`ip`)
) ENGINE=InnoDB AUTO_INCREMENT=2752 DEFAULT CHARSET=utf8 COMMENT='Agent';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent`
--

LOCK TABLES `agent` WRITE;
/*!40000 ALTER TABLE `agent` DISABLE KEYS */;
/*!40000 ALTER TABLE `agent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alarm_follow`
--

DROP TABLE IF EXISTS `alarm_follow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alarm_follow` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `user_id` bigint(20) unsigned NOT NULL COMMENT 'user.id外键',
  `monitor_type` varchar(100) NOT NULL COMMENT '监控项目',
  `monitor_index` varchar(100) NOT NULL COMMENT '监控指标',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='监控指标关注表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alarm_follow`
--

LOCK TABLES `alarm_follow` WRITE;
/*!40000 ALTER TABLE `alarm_follow` DISABLE KEYS */;
/*!40000 ALTER TABLE `alarm_follow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alarm_record`
--

DROP TABLE IF EXISTS `alarm_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alarm_record` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `ip` varchar(100) NOT NULL COMMENT 'ip',
  `monitor_type` varchar(100) NOT NULL COMMENT '监控类型',
  `monitor_index` varchar(100) NOT NULL COMMENT '监控指标',
  `level` varchar(100) NOT NULL COMMENT '报警级别: WARNING | ERROR',
  `content` varchar(1024) NOT NULL COMMENT '报警内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25488 DEFAULT CHARSET=utf8 COMMENT='报警记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alarm_record`
--

LOCK TABLES `alarm_record` WRITE;
/*!40000 ALTER TABLE `alarm_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `alarm_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_assignment`
--

DROP TABLE IF EXISTS `auth_assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_assignment` (
  `auth_item_name` varchar(32) NOT NULL COMMENT 'auth_item 外键',
  `user_emp_id` varchar(32) NOT NULL COMMENT '用户id 外键',
  `bizrule` text COMMENT '逻辑',
  `data` text COMMENT '数据',
  PRIMARY KEY (`auth_item_name`,`user_emp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='权限授予';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_assignment`
--

LOCK TABLES `auth_assignment` WRITE;
/*!40000 ALTER TABLE `auth_assignment` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_assignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_item`
--

DROP TABLE IF EXISTS `auth_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_item` (
  `name` varchar(32) NOT NULL COMMENT '名称',
  `type` int(11) DEFAULT NULL COMMENT '类型',
  `description` text COMMENT '描述',
  `bizrule` text COMMENT '逻辑',
  `data` text COMMENT '数据',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='权限管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_item`
--

LOCK TABLES `auth_item` WRITE;
/*!40000 ALTER TABLE `auth_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device`
--

DROP TABLE IF EXISTS `device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `asset_num` varchar(128) DEFAULT NULL COMMENT '资产编号',
  `device_type_id` bigint(20) NOT NULL COMMENT '设备类型外键',
  `agent_id` bigint(20) DEFAULT NULL COMMENT 'Agent外键',
  `serial_num` varchar(128) DEFAULT NULL COMMENT '设备序列号',
  `os_type` varchar(32) DEFAULT NULL COMMENT '设备系统类型，Android或iOS',
  `os_version` varchar(32) DEFAULT NULL COMMENT '设备系统版本',
  `imei` varchar(32) DEFAULT NULL COMMENT 'IMEI',
  `wifi_mac` varchar(32) DEFAULT NULL COMMENT 'Wifi MAC地址',
  `bluetooth_mac` varchar(32) DEFAULT NULL COMMENT '蓝牙MAC地址',
  `sdcard` varchar(32) DEFAULT NULL COMMENT 'SDCARD大小',
  `location` varchar(128) DEFAULT NULL COMMENT '设备在机房中的位置',
  `group_id` bigint(20) DEFAULT NULL COMMENT '分组外键',
  `status` tinyint(4) DEFAULT '0' COMMENT '设备在线状态\n0-未上线\n1-在线\n2-掉线\n3-下线',
  `env_id` tinyint(4) DEFAULT '0' COMMENT '设备所属环境\n0-未上线\n1-mts\n2-mtl',
  `description` text COMMENT '描述信息，用于存储额外信息',
  `is_root` tinyint(4) DEFAULT '0' COMMENT '是否有root权限',
  `has_vnc` tinyint(4) DEFAULT '0' COMMENT '是否装有vncserver',
  `has_asset_file` tinyint(4) DEFAULT '1' COMMENT '是否存在asset.json文件',
  `is_third_rom` tinyint(4) DEFAULT '0' COMMENT '是否刷了第三方ROM',
  `is_stay_awake` tinyint(4) DEFAULT '1' COMMENT '是否设置了保持唤醒',
  `has_screen_lock` tinyint(4) DEFAULT '0' COMMENT '是否有自动锁屏',
  `is_reset_after_reboot` tinyint(4) DEFAULT '0' COMMENT '重启后是否会丢失设置',
  `has_maintenance_apk` tinyint(4) DEFAULT '0' COMMENT '是否装有运维APK',
  `is_hardware_modified` tinyint(4) DEFAULT '0' COMMENT '是否已经过硬件改造',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `it_holder` varchar(64) DEFAULT NULL COMMENT '设备负责人',
  `borrower` varchar(64) DEFAULT NULL COMMENT '借用者',
  `borrow_time` datetime DEFAULT NULL COMMENT '借用时间',
  `borrow_memo` text COMMENT '借用备注',
  `network` varchar(32) DEFAULT 'WIFI' COMMENT '设备网络环境',
  PRIMARY KEY (`id`),
  KEY `idx_device_device_type_id` (`device_type_id`),
  KEY `idx_device_agent_id` (`agent_id`),
  KEY `idx_device_group_id` (`group_id`),
  KEY `asset_num_index` (`asset_num`)
) ENGINE=InnoDB AUTO_INCREMENT=2114 DEFAULT CHARSET=utf8 COMMENT='设备';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device`
--

LOCK TABLES `device` WRITE;
/*!40000 ALTER TABLE `device` DISABLE KEYS */;
/*!40000 ALTER TABLE `device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_group`
--

DROP TABLE IF EXISTS `device_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_group` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(64) NOT NULL COMMENT '名称',
  `description` text COMMENT '描述信息',
  `env_id` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Group所属环境 1-mts 2-mtl',
  PRIMARY KEY (`id`),
  KEY `name_index` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='设备分组';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_group`
--

LOCK TABLES `device_group` WRITE;
/*!40000 ALTER TABLE `device_group` DISABLE KEYS */;
INSERT INTO `device_group` VALUES (1,'public','public',0),(2,'remote_debug','remote_debug',0),(3,'H5','H5',0),(4,'DeepPerformance','',0),(5,'ios remote debug','ios remote debug',0),(6,'public','public',0),(7,'remote_debug','remote_debug',0),(8,'H5','H5',0),(9,'DeepPerformance','',0),(10,'ios remote debug','ios remote debug',0);
/*!40000 ALTER TABLE `device_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_statistic_daily`
--

DROP TABLE IF EXISTS `device_statistic_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_statistic_daily` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `offline_count` int(11) DEFAULT '0' COMMENT '掉线次数',
  `offline_duration` int(11) DEFAULT '0' COMMENT '掉线时长',
  `busy_count` int(11) DEFAULT '0' COMMENT '使用次数',
  `busy_duration` int(11) DEFAULT '0' COMMENT '使用时长',
  `date` date DEFAULT NULL COMMENT '日期,例如2015-06-04',
  `device_id` bigint(20) NOT NULL COMMENT '对应device表的id',
  PRIMARY KEY (`id`),
  KEY `idx_device_statistic_daily_device_id` (`device_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9476 DEFAULT CHARSET=utf8 COMMENT='设备统计信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_statistic_daily`
--

LOCK TABLES `device_statistic_daily` WRITE;
/*!40000 ALTER TABLE `device_statistic_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `device_statistic_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_type`
--

DROP TABLE IF EXISTS `device_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `brand` varchar(128) NOT NULL COMMENT '品牌',
  `model` varchar(128) NOT NULL COMMENT '型号',
  `type` varchar(64) DEFAULT 'PHONE' COMMENT '手机-PHONE\n平板-TABLET\n电视盒子-TV\n模拟器-EMULATOR',
  `dimension` varchar(64) DEFAULT NULL COMMENT '屏幕尺寸',
  `resolution` varchar(64) DEFAULT NULL COMMENT '屏幕分辨率',
  `cpu` varchar(128) DEFAULT NULL COMMENT 'CPU信息',
  `gpu` varchar(128) DEFAULT NULL COMMENT 'GPU信息',
  `ram` varchar(128) DEFAULT NULL COMMENT '内存',
  `rom` varchar(128) DEFAULT NULL COMMENT '内置存储',
  `camera` varchar(32) DEFAULT NULL COMMENT '后置相机',
  `front_camera` varchar(32) DEFAULT NULL COMMENT '前置相机',
  `battery` varchar(32) DEFAULT NULL COMMENT '电池信息',
  `thumbnail` varchar(256) DEFAULT NULL COMMENT '手机样图地址',
  `nickname` varchar(256) DEFAULT NULL COMMENT '设备名称',
  `extension` text COMMENT '扩展字段，记录其他信息',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `nickname_index` (`nickname`(255))
) ENGINE=InnoDB AUTO_INCREMENT=879 DEFAULT CHARSET=utf8 COMMENT='设备类型';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_type`
--

LOCK TABLES `device_type` WRITE;
/*!40000 ALTER TABLE `device_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `device_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `machine`
--

DROP TABLE IF EXISTS `machine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `machine` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `name` varchar(100) DEFAULT NULL COMMENT '机器名称',
  `ip` varchar(100) NOT NULL COMMENT '机器ip地址',
  `monitor_items` varchar(50) DEFAULT NULL COMMENT '监控项配置（预留）',
  `is_deleted` tinyint(4) NOT NULL COMMENT '是否被弃用，0-未弃用，1-已弃用',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  KEY `ins_ip_type` (`ip`)
) ENGINE=InnoDB AUTO_INCREMENT=174 DEFAULT CHARSET=utf8 COMMENT='机器列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `machine`
--

LOCK TABLES `machine` WRITE;
/*!40000 ALTER TABLE `machine` DISABLE KEYS */;
/*!40000 ALTER TABLE `machine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maintenance_order`
--

DROP TABLE IF EXISTS `maintenance_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maintenance_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `exception_id` tinyint(4) DEFAULT NULL COMMENT '0.其它 \n1.设备关机\n2.设备死机\n3.设备设置问题\n4.设备硬件配件问题\n5.monkey导致的问题\n6.异常',
  `exception_des` varchar(256) DEFAULT NULL COMMENT 'Exception描述信息',
  `solution_id` tinyint(4) DEFAULT NULL COMMENT '0.其它 \n1.下线充电 \n2.重新开机(可插拔电池)，检查各项设置 \n3.usb连接模式设置\n4.开发者选项设置 \n5.开启未知来源，关闭验证应用 \n6.下线测试 \n7.下线维修 \n8.更换hub端口，更换usb线 \n9.插拔usb线\n10.重启hub \n11.恢复出厂设置（推资产编号），检查各项设置',
  `solution_des` varchar(256) DEFAULT NULL COMMENT 'Solution描述信息',
  `state` tinyint(4) DEFAULT NULL COMMENT '工单状态\n0 结单\n1 运维中\n2 下线测试\n3 下线维修',
  `device_id` bigint(20) NOT NULL COMMENT '设备信息外键',
  `problem_info` text COMMENT 'JSON格式，用于保存mts发送的问题信息',
  `created_by` bigint(20) DEFAULT NULL COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` bigint(20) DEFAULT NULL COMMENT '修改者',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `idx_maintenance_order_device_id` (`device_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='工单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maintenance_order`
--

LOCK TABLES `maintenance_order` WRITE;
/*!40000 ALTER TABLE `maintenance_order` DISABLE KEYS */;
INSERT INTO `maintenance_order` VALUES (1,NULL,NULL,NULL,NULL,1,1979,'[{\"detail\":\"\\\"INSTALL_CANCELED_BY_USER,\\\"\",\"execution\":\"20\",\"summary\":\"DEVICE_ERROR\",\"taskSuite\":\"20\",\"taskType\":\"MONKEY\",\"timestamp\":1511940584375},{\"detail\":\"\\\"START_ERROR: com.android.ddmlib.ShellCommandUnresponsiveException\\\"\\\"\\\"\",\"execution\":\"131\",\"summary\":\"DEVICE_ERROR\",\"taskSuite\":\"107\",\"taskType\":\"MONKEY\",\"timestamp\":1513821043710},{\"detail\":\"\\\"START_ERROR: com.android.ddmlib.ShellCommandUnresponsiveException\\\"\\\"\\\"\",\"execution\":\"131\",\"summary\":\"DEVICE_ERROR\",\"taskSuite\":\"107\",\"taskType\":\"MONKEY\",\"timestamp\":1513821043854},{\"detail\":\"\\\"START_ERROR: com.android.ddmlib.ShellCommandUnresponsiveException\\\"\\\"\\\"\",\"execution\":\"131\",\"summary\":\"DEVICE_ERROR\",\"taskSuite\":\"107\",\"taskType\":\"MONKEY\",\"timestamp\":1513821043854},{\"detail\":\"\\\"START_ERROR: com.android.ddmlib.ShellCommandUnresponsiveException\\\"\\\"\\\"\",\"execution\":\"156\",\"summary\":\"DEVICE_ERROR\",\"taskSuite\":\"132\",\"taskType\":\"MONKEY\",\"timestamp\":1514278434611}]',NULL,'2017-12-26 16:54:17',NULL,NULL);
/*!40000 ALTER TABLE `maintenance_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mdop_sonar_basic_indicator`
--

DROP TABLE IF EXISTS `mdop_sonar_basic_indicator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mdop_sonar_basic_indicator` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `create_time` varchar(32) DEFAULT NULL COMMENT 'create_time',
  `target_time` varchar(255) DEFAULT NULL COMMENT 'target_time',
  `indicator_name` varchar(255) DEFAULT NULL COMMENT 'indicator_name',
  `indicator_target` varchar(255) DEFAULT NULL COMMENT 'indicator_target',
  `value` varchar(255) DEFAULT NULL COMMENT 'value',
  `granularity` varchar(255) DEFAULT NULL COMMENT 'granularity',
  PRIMARY KEY (`id`),
  KEY `idx_mdop_sonar_basic_indicator` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='mdop_sonar_basic_indicator';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdop_sonar_basic_indicator`
--

LOCK TABLES `mdop_sonar_basic_indicator` WRITE;
/*!40000 ALTER TABLE `mdop_sonar_basic_indicator` DISABLE KEYS */;
/*!40000 ALTER TABLE `mdop_sonar_basic_indicator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `monitor_data`
--

DROP TABLE IF EXISTS `monitor_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `monitor_data` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `monitor_type` varchar(100) NOT NULL COMMENT '监控项类型，如cpu、swift',
  `ip` varchar(100) NOT NULL COMMENT 'PC机ip',
  `status` varchar(50) DEFAULT NULL COMMENT '服务状态',
  `is_restarted` tinyint(4) DEFAULT NULL COMMENT '是否被重启，0-未重启，1-已重启过',
  `data_json` longtext COMMENT '结果全集，json串',
  PRIMARY KEY (`id`),
  KEY `ins_ip_type` (`ip`,`monitor_type`,`gmt_create`)
) ENGINE=InnoDB AUTO_INCREMENT=711027 DEFAULT CHARSET=utf8 COMMENT='监控数据';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `monitor_data`
--

LOCK TABLES `monitor_data` WRITE;
/*!40000 ALTER TABLE `monitor_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `monitor_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `monitor_index`
--

DROP TABLE IF EXISTS `monitor_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `monitor_index` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `monitor_type` varchar(100) NOT NULL COMMENT '监控类型',
  `monitor_index` varchar(100) NOT NULL COMMENT '监控指标',
  `monitor_index_name` varchar(100) NOT NULL COMMENT '监控指标名称',
  `monitor_index_unit` varchar(50) NOT NULL COMMENT '监控指标单位',
  `alarm_status` varchar(50) NOT NULL DEFAULT 'ON' COMMENT '是否开启报警 ON|OFF',
  `alarm_level` varchar(50) NOT NULL DEFAULT 'ERROR' COMMENT '报警等级',
  `alarm_rule_config` text NOT NULL COMMENT '报警规则配置',
  `is_deleted` tinyint(4) NOT NULL COMMENT '是否删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=375 DEFAULT CHARSET=utf8 COMMENT='监控项';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `monitor_index`
--

LOCK TABLES `monitor_index` WRITE;
/*!40000 ALTER TABLE `monitor_index` DISABLE KEYS */;
INSERT INTO `monitor_index` VALUES (344,'2017-09-06 14:50:29','2017-11-03 16:48:59','BASIC','cpu','CPU使用率','%','ON','WARNING','{\"continuedTimes\":1,\"relationOpt\":\"EGT\",\"value\":\"90\",\"valueEditable\":true}',0),(345,'2017-09-06 14:50:29','2017-12-27 14:19:14','BASIC','mem','内存使用率','%','ON','WARNING','{\"continuedTimes\":3,\"relationOpt\":\"EGT\",\"value\":\"90\",\"valueEditable\":true}',0),(346,'2017-09-06 14:50:29','2017-09-06 14:50:29','BASIC','load1','1分钟平均负载','','OFF','WARNING','{\"relationOpt\":\"EGT\", \"value\":\"2\", \"valueEditable\":true, \"continuedTimes\":3}',0),(347,'2017-09-06 14:50:29','2017-09-06 14:50:29','BASIC','load1','5分钟平均负载','','OFF','WARNING','{\"relationOpt\":\"EGT\", \"value\":\"2\", \"valueEditable\":true, \"continuedTimes\":3}',0),(348,'2017-09-06 14:50:29','2017-09-06 14:50:29','BASIC','load1','15分钟平均负载','','OFF','WARNING','{\"relationOpt\":\"EGT\", \"value\":\"2\", \"valueEditable\":true, \"continuedTimes\":3}',0),(349,'2017-09-06 14:50:30','2017-09-11 14:41:25','BASIC','traffic_in','网络流入流量','KByte/s','OFF','WARNING','{\"continuedTimes\":3,\"relationOpt\":\"EGT\",\"value\":\"2000\",\"valueEditable\":true}',0),(350,'2017-09-06 14:50:30','2017-09-11 14:41:26','BASIC','traffic_out','网络流出流量','KByte/s','OFF','WARNING','{\"continuedTimes\":3,\"relationOpt\":\"EGT\",\"value\":\"2000\",\"valueEditable\":true}',0),(351,'2017-09-06 14:50:30','2017-09-06 14:50:30','BASIC','disk','磁盘使用率','%','ON','WARNING','{\"relationOpt\":\"EGT\", \"value\":\"80\", \"valueEditable\":true, \"continuedTimes\":-1}',0),(352,'2017-09-06 14:50:30','2017-09-06 14:50:30','BASIC','io_rrqms','每秒读磁盘次数','次/s','ON','WARNING','{\"relationOpt\":\"EGT\", \"value\":\"80\", \"valueEditable\":true, \"continuedTimes\":3}',0),(353,'2017-09-06 14:50:30','2017-09-06 14:50:30','BASIC','io_wrqms','每秒写磁盘次数','次/s','ON','WARNING','{\"relationOpt\":\"EGT\", \"value\":\"80\", \"valueEditable\":true, \"continuedTimes\":3}',0),(354,'2017-09-06 14:50:31','2017-09-06 14:50:31','BASIC','io_util','磁盘IO的CPU占比','%','ON','WARNING','{\"relationOpt\":\"EGT\", \"value\":\"80\", \"valueEditable\":true, \"continuedTimes\":3}',0),(355,'2017-09-06 14:50:31','2017-12-27 14:19:14','BASIC','heartbeat','心跳超时时间','秒','ON','ERROR','{\"continuedTimes\":-1,\"relationOpt\":\"EGT\",\"value\":\"900\",\"valueEditable\":true}',0),(356,'2017-09-06 14:50:31','2017-12-27 14:19:16','MYSQL','status','Mysql状态','','ON','ERROR','{\"continuedTimes\":-1,\"relationOpt\":\"NEQ\",\"value\":\"online\",\"valueEditable\":false}',0),(357,'2017-09-06 14:50:32','2017-09-06 14:50:32','MYSQL','qps','Mysql QPS','','ON','WARNING','{\"relationOpt\":\"EGT\", \"value\":\"100\", \"valueEditable\":true, \"continuedTimes\":3}',0),(358,'2017-09-06 14:50:32','2017-09-06 14:50:32','MYSQL','tps','Mysql TPS','','ON','WARNING','{\"relationOpt\":\"EGT\", \"value\":\"100\", \"valueEditable\":true, \"continuedTimes\":3}',0),(359,'2017-09-06 14:50:32','2017-09-06 14:50:32','MYSQL','threads_con','Mysql连接线程数','','ON','WARNING','{\"relationOpt\":\"EGT\", \"value\":\"100\", \"valueEditable\":true, \"continuedTimes\":3}',0),(360,'2017-09-06 14:50:32','2017-09-06 14:50:32','MYSQL','threads_run','Mysql活跃线程数','','ON','WARNING','{\"relationOpt\":\"EGT\", \"value\":\"100\", \"valueEditable\":true, \"continuedTimes\":3}',0),(361,'2017-09-06 14:50:32','2017-12-27 14:19:17','REDIS','status','Mysql状态','','ON','ERROR','{\"continuedTimes\":-1,\"relationOpt\":\"NEQ\",\"value\":\"online\",\"valueEditable\":false}',0),(362,'2017-09-06 14:50:33','2017-09-06 14:50:33','REDIS','instantaneous_ops_per_sec','每秒处理指令数','','ON','WARNING','{\"relationOpt\":\"EGT\", \"value\":\"100\", \"valueEditable\":true, \"continuedTimes\":3}',0),(363,'2017-09-06 14:50:33','2017-09-06 14:50:33','REDIS','used_memory_peak_perc','内存使用率','%','ON','WARNING','{\"relationOpt\":\"EGT\", \"value\":\"80\", \"valueEditable\":true, \"continuedTimes\":3}',0),(364,'2017-09-06 14:50:33','2017-12-27 14:19:18','SWIFT','status','Swfit状态','','ON','ERROR','{\"continuedTimes\":-1,\"relationOpt\":\"NEQ\",\"value\":\"online\",\"valueEditable\":false}',0),(365,'2017-09-06 14:50:33','2017-09-06 14:50:33','SWIFT','qps','Swfit QPS','','ON','WARNING','{\"relationOpt\":\"EGT\", \"value\":\"100\", \"valueEditable\":true, \"continuedTimes\":3}',0),(366,'2017-09-06 14:50:34','2017-09-06 14:50:34','REDIS','highestDiskUsage','最大磁盘使用率','%','ON','WARNING','{\"relationOpt\":\"EGT\", \"value\":\"80\", \"valueEditable\":true, \"continuedTimes\":3}',0),(367,'2017-09-06 14:50:34','2017-09-06 14:50:34','REDIS','avgDiskUsage','最大磁盘使用率','%','ON','WARNING','{\"relationOpt\":\"EGT\", \"value\":\"80\", \"valueEditable\":true, \"continuedTimes\":3}',0),(368,'2017-09-06 14:50:34','2017-12-27 14:19:19','NGINX','status','Nginx状态','','ON','ERROR','{\"continuedTimes\":-1,\"relationOpt\":\"NEQ\",\"value\":\"online\",\"valueEditable\":false}',0),(369,'2017-09-06 14:50:34','2017-09-06 14:50:34','NGINX','Err4xxNum','4XX数量','','ON','ERROR','{\"relationOpt\":\"EGT\", \"value\":\"100\", \"valueEditable\":true, \"continuedTimes\":-1}',0),(370,'2017-09-06 14:50:34','2017-09-06 14:50:34','NGINX','Err5xxNum','5XX数量','','ON','ERROR','{\"relationOpt\":\"EGT\", \"value\":\"100\", \"valueEditable\":true, \"continuedTimes\":-1}',0),(371,'2017-09-06 14:50:34','2017-12-27 14:19:20','TOMCAT','status','Tomcat状态','','ON','ERROR','{\"continuedTimes\":-1,\"relationOpt\":\"NEQ\",\"value\":\"online\",\"valueEditable\":false}',0),(372,'2017-09-06 14:50:35','2017-09-06 14:50:35','TOMCAT','qps','Tomcat QPS','','ON','WARNING','{\"relationOpt\":\"EGT\", \"value\":\"100\", \"valueEditable\":true, \"continuedTimes\":3}',0),(373,'2017-09-06 14:50:35','2017-09-06 14:50:35','REMOTEDEBUG','server_status','远程调试server状态','','ON','ERROR','{\"relationOpt\":\"NEQ\", \"value\":\"online\", \"valueEditable\":false, \"continuedTimes\":-1}',0),(374,'2017-09-06 14:50:35','2017-09-06 14:50:35','REMOTEDEBUG','client_status','远程调试client状态','','ON','ERROR','{\"relationOpt\":\"NEQ\", \"value\":\"online\", \"valueEditable\":false, \"continuedTimes\":-1}',0);
/*!40000 ALTER TABLE `monitor_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operation`
--

DROP TABLE IF EXISTS `operation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `operation` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `device_id` bigint(20) NOT NULL COMMENT '设备信息外键',
  `type` tinyint(4) DEFAULT NULL COMMENT '操作类型',
  `result` tinyint(4) DEFAULT NULL COMMENT '操作结果',
  `message` text COMMENT '其他信息',
  `operated_by` bigint(20) DEFAULT NULL COMMENT '操作人',
  `operate_time` datetime DEFAULT NULL COMMENT '操作时间',
  PRIMARY KEY (`id`),
  KEY `idx_operation_device_id` (`device_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='设备操作记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operation`
--

LOCK TABLES `operation` WRITE;
/*!40000 ALTER TABLE `operation` DISABLE KEYS */;
/*!40000 ALTER TABLE `operation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recover_data`
--

DROP TABLE IF EXISTS `recover_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recover_data` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `op_type` varchar(100) NOT NULL COMMENT '操作类型',
  `op_result` varchar(200) DEFAULT NULL COMMENT '操作结果',
  `ip` varchar(100) NOT NULL COMMENT 'PC机ip',
  PRIMARY KEY (`id`),
  KEY `ins_ip_type` (`ip`,`op_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='恢复记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recover_data`
--

LOCK TABLES `recover_data` WRITE;
/*!40000 ALTER TABLE `recover_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `recover_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `serial_board`
--

DROP TABLE IF EXISTS `serial_board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `serial_board` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `ip` varchar(128) NOT NULL COMMENT '控制板ip',
  `device_locations` varchar(1024) NOT NULL COMMENT '控制板相关设备位置',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='串口控制板';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `serial_board`
--

LOCK TABLES `serial_board` WRITE;
/*!40000 ALTER TABLE `serial_board` DISABLE KEYS */;
/*!40000 ALTER TABLE `serial_board` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `temp_device_statistic_being_handled`
--

DROP TABLE IF EXISTS `temp_device_statistic_being_handled`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `temp_device_statistic_being_handled` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `event` varchar(64) DEFAULT NULL COMMENT '时间',
  `event_message` varchar(4096) DEFAULT NULL COMMENT '事件信息',
  `execution_task_id` bigint(20) DEFAULT NULL COMMENT '执行任务Id',
  `operation` varchar(64) DEFAULT NULL COMMENT 'device error后的操作，例如restore',
  `device_id` bigint(20) NOT NULL COMMENT '对应device表的id',
  PRIMARY KEY (`id`),
  KEY `idx_temp_device_statistic_being_handled_device_id` (`device_id`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8 COMMENT='设备统计信息临时处理表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temp_device_statistic_being_handled`
--

LOCK TABLES `temp_device_statistic_being_handled` WRITE;
/*!40000 ALTER TABLE `temp_device_statistic_being_handled` DISABLE KEYS */;
/*!40000 ALTER TABLE `temp_device_statistic_being_handled` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'BUC User ID,帐号系统，权限系统等BUC相关服务会用到',
  `mts_id` varchar(32) DEFAULT NULL COMMENT '工号',
  `user_name` varchar(64) NOT NULL COMMENT '真实姓名',
  `password` varchar(64) DEFAULT NULL,
  `role_name` varchar(64) DEFAULT NULL COMMENT '花名',
  `email` varchar(64) DEFAULT NULL COMMENT '邮箱地址',
  `user_type` varchar(32) DEFAULT NULL COMMENT '用户类型',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=111158031 DEFAULT CHARSET=utf8 COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (111158029,NULL,'admin','21232f297a57a5a743894a0e4a801fc3',NULL,'peimin.ypm@alibaba-inc.com',NULL,NULL,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `emas_mqc`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `emas_mqc` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `emas_mqc`;

--
-- Table structure for table `mts_ability_cfg`
--

DROP TABLE IF EXISTS `mts_ability_cfg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_ability_cfg` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `mts_uid` bigint(20) unsigned NOT NULL COMMENT '创建者的id',
  `type_flag` varchar(64) NOT NULL COMMENT '测试流程唯一标志，二次开发的流程表示以"EXT_"开头，后跟终端类型+新建时的时间戳',
  `name` varchar(64) NOT NULL COMMENT '测试能力名字',
  `group_id` bigint(20) unsigned NOT NULL COMMENT '功能分组id',
  `platform_type` varchar(64) NOT NULL COMMENT '终端类型,如ANDROID、IOS',
  `param_cfg_json` longtext COMMENT '参数配置，以json串方式存储',
  `ability_type` varchar(32) NOT NULL DEFAULT 'GROOVY' COMMENT '测试能力类型：GROOVY，PYTHON',
  `ability_urls` varchar(2048) NOT NULL COMMENT '测试能力脚本下载地址，多个以英文逗号分隔，第一个为启动脚本',
  `status` varchar(20) NOT NULL DEFAULT 'OFFLINE' COMMENT '测试能力状态，如ONLIE、OFFLINE',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0-未删除，1-已删除',
  `remark` varchar(1024) DEFAULT NULL COMMENT '备注',
  `extension` varchar(1024) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='二次开发测试能力流程配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_ability_cfg`
--

LOCK TABLES `mts_ability_cfg` WRITE;
/*!40000 ALTER TABLE `mts_ability_cfg` DISABLE KEYS */;
INSERT INTO `mts_ability_cfg` VALUES (1,'2017-11-15 19:51:35','2017-11-15 20:05:34',1,'EXT_ANDROID_20171115195135833','RF功能测试',1,'ANDROID','[{\"required\":true,\"type\":\"FILE\",\"key\":\"script\",\"name\":\"测试脚本\",\"help\":\"测试脚本(zip压缩包)\",\"maxNum\":1,\"options\":[]},{\"required\":false,\"type\":\"TEXT\",\"key\":\"otherCmd\",\"name\":\"其它参数\",\"help\":\"附加在robot命令后面的其它参数\",\"maxNum\":1,\"options\":[]}]','GROOVY','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/RobotFrameworkTest.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/TestRunnerAgent.py.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/RobotFramework.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/lib.groovy','OFFLINE',0,'Robot Framework功能测试',NULL),(2,'2017-11-15 21:06:19','2017-11-17 09:59:12',1,'EXT_IOS_20171115210619610','RF功能测试',1,'IOS','[{\"required\":true,\"type\":\"FILE\",\"key\":\"script\",\"name\":\"测试脚本\",\"help\":\"测试脚本(zip压缩包)\",\"maxNum\":1,\"options\":[]},{\"required\":false,\"type\":\"TEXT\",\"key\":\"otherCmd\",\"name\":\"其它参数\",\"help\":\"附加在robot命令后面的其它参数\",\"maxNum\":1,\"options\":[]}]','GROOVY','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/IOSRobotFrameworkTest.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/iOSLib.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/IOSRobotFramework.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/iOSCommon.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/SaveOutputToFileReceiver.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/TestRunnerAgent.py.groovy','OFFLINE',0,'Robot Framework功能测试 for iOS',NULL);
/*!40000 ALTER TABLE `mts_ability_cfg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_access_pair`
--

DROP TABLE IF EXISTS `mts_access_pair`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_access_pair` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `ak` varchar(32) NOT NULL COMMENT '公钥，md5',
  `sk` varchar(32) NOT NULL COMMENT '私钥，md5',
  `vip` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'api等级，0-最高，都可以调',
  `user` varchar(128) NOT NULL COMMENT '用户名',
  `user_company` varchar(256) DEFAULT NULL COMMENT '公司',
  `description` varchar(1024) DEFAULT NULL COMMENT '描述',
  `user_group_id` bigint(20) unsigned DEFAULT NULL COMMENT '对应的用户组表',
  `device_group_id` bigint(20) unsigned DEFAULT NULL COMMENT '对应的设备权限表',
  `extension` varchar(1024) DEFAULT NULL COMMENT '扩展字段',
  `allow_service` varchar(1024) DEFAULT NULL COMMENT '允许使用的服务，若有多个，逗号连接',
  `ci_status` tinyint(4) DEFAULT '0' COMMENT '持续集成状态\nnull或0: 非持续集成生成的ak\n1: 待审核（未曾获得过有效ak）\n2: 审核通过\n3: 已失效\n4: 待审核（至少已获得过一次有效ak）',
  `start_time` datetime DEFAULT NULL COMMENT '生效日期',
  `end_time` datetime DEFAULT NULL COMMENT '失效日期',
  `share_users` varchar(512) DEFAULT NULL COMMENT '共享用户名单',
  `res_pkg_id` bigint(20) unsigned DEFAULT NULL COMMENT '资源包id',
  `mts_uid` bigint(20) unsigned DEFAULT NULL COMMENT '用户id，用于查询外部持续集成用户所拥有的ak',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ak_unique` (`ak`),
  KEY `idx_mts_uid` (`mts_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COMMENT='公钥私钥表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_access_pair`
--

LOCK TABLES `mts_access_pair` WRITE;
/*!40000 ALTER TABLE `mts_access_pair` DISABLE KEYS */;
INSERT INTO `mts_access_pair` VALUES (1,'2017-11-16 14:33:40','2017-11-16 14:33:45','5d769f0d57629c30429fac14e201a9fc','b93955a73ecdc8b2f17c50766534be8f',0,'admin','admin','agent',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `mts_access_pair` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_agent`
--

DROP TABLE IF EXISTS `mts_agent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_agent` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `agent_ip` varchar(64) NOT NULL COMMENT 'agent的ip',
  `agent_version` varchar(32) NOT NULL DEFAULT '1.0.1' COMMENT 'agent版本号，例如：1.0.1',
  `machine_name` varchar(128) DEFAULT NULL COMMENT 'agent名字',
  `platform_type` varchar(32) DEFAULT 'LINUX' COMMENT 'agent平台：WINDOWS、LINUX、MAC',
  `platform_version` varchar(32) DEFAULT NULL COMMENT '平台版本',
  `status` varchar(32) NOT NULL DEFAULT 'OFFLINE' COMMENT '状态：OFFLINE、ONLINE',
  `location` varchar(128) DEFAULT NULL COMMENT '地址，例如：IDC',
  `extension` varchar(1024) DEFAULT NULL COMMENT '扩展字段',
  `emulator_capacity` smallint(6) DEFAULT '0' COMMENT '如果大于0，此Agent为运行模拟器的Agent；如果等于0，此Agent为挂载真实设备的Agent。',
  `user_group_id` int(11) DEFAULT '1' COMMENT 'Agent所属的用户分组id，id为1是公共分组。为模拟器任务调度设置此字段。',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_agent_ip` (`agent_ip`),
  KEY `idx_gmt_modified_status` (`gmt_modified`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=179 DEFAULT CHARSET=utf8 COMMENT='agent表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_agent`
--

LOCK TABLES `mts_agent` WRITE;
/*!40000 ALTER TABLE `mts_agent` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_agent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_agent_log`
--

DROP TABLE IF EXISTS `mts_agent_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_agent_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `agent_id` bigint(20) unsigned NOT NULL COMMENT '对应agent的id',
  `event` varchar(64) NOT NULL COMMENT 'agent状态事件，例如offline',
  `event_message` varchar(128) DEFAULT NULL COMMENT 'agent状态事件说明',
  `extension` varchar(1024) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`id`),
  KEY `idx_agentid_event` (`agent_id`,`event`),
  KEY `idx_gmt_create` (`gmt_create`),
  KEY `idx_event` (`event`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='agent日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_agent_log`
--

LOCK TABLES `mts_agent_log` WRITE;
/*!40000 ALTER TABLE `mts_agent_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_agent_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_app_device_perf`
--

DROP TABLE IF EXISTS `mts_app_device_perf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_app_device_perf` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `launch_time` double(10,3) DEFAULT NULL COMMENT '平均启动时间',
  `avg_cpu` double(10,6) DEFAULT NULL COMMENT '平均CPU占用率(%)',
  `max_cpu` double(10,6) DEFAULT NULL COMMENT '峰值CPU占用率(%)',
  `avg_mem` double(13,3) DEFAULT NULL COMMENT '平均内存占用(byte)',
  `max_mem` double(13,3) DEFAULT NULL COMMENT '最大内存占用(byte)',
  `avg_web_traffic` double(13,3) DEFAULT NULL COMMENT '平均流量耗用',
  `avg_battery` double(10,3) DEFAULT NULL COMMENT '平均电量耗用',
  `avg_fps` double(10,6) DEFAULT NULL COMMENT '平均FPS',
  `avg_pid_score` double(10,3) DEFAULT NULL COMMENT 'app运行平均分',
  `avg_sys_score` double(10,3) DEFAULT NULL COMMENT '系统运行平均分',
  `device_type_id` bigint(20) unsigned NOT NULL COMMENT '设备类型id',
  `package_name` varchar(128) NOT NULL COMMENT 'APP包名',
  `task_type` varchar(128) NOT NULL COMMENT '测试能力名字，@see mts_execution_task.task_type',
  `num` bigint(20) unsigned NOT NULL COMMENT '已经计算的性能数据数量',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_device_type_id_package_name_task_type` (`device_type_id`,`package_name`,`task_type`),
  KEY `idx_device_type_id` (`device_type_id`),
  KEY `idx_launch_time` (`launch_time`),
  KEY `idx_avg_cpu` (`avg_cpu`),
  KEY `idx_avg_mem` (`avg_mem`),
  KEY `idx_avg_web_traffic` (`avg_web_traffic`),
  KEY `idx_avg_fps` (`avg_fps`),
  KEY `idx_avg_battery` (`avg_battery`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COMMENT='每个APP在每款设备上每个测试能力类型的性能平均值';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_app_device_perf`
--

LOCK TABLES `mts_app_device_perf` WRITE;
/*!40000 ALTER TABLE `mts_app_device_perf` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_app_device_perf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_ar_package`
--

DROP TABLE IF EXISTS `mts_ar_package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_ar_package` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `signature_hashcode` int(11) DEFAULT NULL COMMENT '签名hash',
  `package_name` varchar(128) DEFAULT NULL COMMENT '包名',
  `ar_path` varchar(512) DEFAULT NULL COMMENT '文件地址',
  `package_id` bigint(20) unsigned NOT NULL COMMENT '应用id，对应mts_package表',
  `extension` varchar(1024) DEFAULT NULL COMMENT '扩展字段',
  `two_dimensional_code` varchar(1024) DEFAULT NULL COMMENT 'ar包地址对应的二维码存储在oss的地址',
  `md5` varchar(256) DEFAULT NULL COMMENT '文件的md5',
  PRIMARY KEY (`id`),
  KEY `ins_pn_sh` (`package_name`,`signature_hashcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='testapk和被测apk之间对应关系表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_ar_package`
--

LOCK TABLES `mts_ar_package` WRITE;
/*!40000 ALTER TABLE `mts_ar_package` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_ar_package` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_automation_test_script`
--

DROP TABLE IF EXISTS `mts_automation_test_script`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_automation_test_script` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `target_package_id` bigint(20) unsigned DEFAULT NULL COMMENT '关联的被测APP 的id， mts_package表里的id',
  `target_package_name` varchar(300) DEFAULT NULL COMMENT '管理的被测APP的包名。1.为了管理页展示，2. 有些测试脚本对被测app的版本不敏感，可以用这个关联',
  `package_name` varchar(300) DEFAULT NULL COMMENT '如果测试脚本是基于instrumentation的，则记录脚本APK的包名',
  `runner_class` varchar(300) DEFAULT NULL COMMENT '如果测试脚本是基于instrumentation的，则记录脚本APK的测试入口class',
  `framework` varchar(50) NOT NULL DEFAULT 'robotium' COMMENT '几类测试框架：robotium、appium',
  `script_file_type` varchar(50) NOT NULL DEFAULT 'apk' COMMENT '支持的几类测试脚本格式：python, apk。分别对应appium和robotium',
  `script_path` varchar(500) DEFAULT NULL COMMENT '脚本的OSS地址',
  `script_name` varchar(100) NOT NULL COMMENT '脚本上传时的名称',
  `mts_uid` bigint(20) unsigned DEFAULT NULL COMMENT '上传脚本的用户的id。mts_user表里的id',
  `target_platform` varchar(50) NOT NULL DEFAULT 'Android' COMMENT 'Android 还是IOS',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '脚本是否被删除',
  `script_params` varchar(1000) DEFAULT NULL COMMENT 'JSON格式。脚本如果需要参数，可以通过此字段写入。',
  `script_md5` varchar(32) DEFAULT NULL COMMENT '脚本文件的MD5值。',
  `is_virus` tinyint(4) DEFAULT '0' COMMENT '是否是病毒',
  `upload_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0-上传完成，1-病毒检测完成，2-数据校验完成，3-检测合法性完成，4-检测结果为病毒，5-合法性检测失败',
  `target_package_name_from_script` varchar(300) DEFAULT NULL COMMENT '从脚本解析出来的被测包名',
  `description` varchar(8192) DEFAULT NULL COMMENT '脚本描述',
  `finger_md5` varchar(256) DEFAULT NULL COMMENT 'Instrumentation脚本的签名MD5值',
  `case_ids` varchar(1024) DEFAULT NULL COMMENT '脚本对应的相关用例信息，不存在则不是录制生成的用例脚本',
  PRIMARY KEY (`id`),
  KEY `idx_target_package_id` (`target_package_id`),
  KEY `idx_target_package_name` (`target_package_name`(255)),
  KEY `idx_mts_uid` (`mts_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='自动化测试的脚本表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_automation_test_script`
--

LOCK TABLES `mts_automation_test_script` WRITE;
/*!40000 ALTER TABLE `mts_automation_test_script` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_automation_test_script` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_case_dir`
--

DROP TABLE IF EXISTS `mts_case_dir`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_case_dir` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `dir_name` varchar(64) NOT NULL COMMENT '目录名字',
  `pid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '父节点id',
  `case_version_id` bigint(20) unsigned NOT NULL COMMENT '用例版本id',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0-未删除，1-已删除',
  PRIMARY KEY (`id`),
  KEY `idx_name` (`dir_name`)
) ENGINE=InnoDB AUTO_INCREMENT=709 DEFAULT CHARSET=utf8 COMMENT='用例目录表';
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `mts_case_dir` WRITE;
/*!40000 ALTER TABLE `mts_case_dir` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_case_dir` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_case_history`
--

DROP TABLE IF EXISTS `mts_case_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_case_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `case_id` bigint(20) unsigned NOT NULL COMMENT 'mts_remote_case.id外键',
  `execution_task_id` bigint(20) unsigned NOT NULL COMMENT 'mts_execution_task.id外键',
  `status` varchar(24) NOT NULL COMMENT 'mts_execution_task.status',
  `is_deleted` tinyint(4) NOT NULL COMMENT '是否删除',
  `execution_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'execution_id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用例执行历史';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_case_history`
--

LOCK TABLES `mts_case_history` WRITE;
/*!40000 ALTER TABLE `mts_case_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_case_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_case_module`
--

DROP TABLE IF EXISTS `mts_case_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_case_module` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `module_name` varchar(64) NOT NULL COMMENT '模块名字',
  `case_version_id` bigint(20) unsigned NOT NULL COMMENT '用例版本id',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0-未删除，1-已删除',
  PRIMARY KEY (`id`),
  KEY `idx_name` (`module_name`)
) ENGINE=InnoDB AUTO_INCREMENT=660 DEFAULT CHARSET=utf8 COMMENT='用例模块表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_case_module`
--

LOCK TABLES `mts_case_module` WRITE;
/*!40000 ALTER TABLE `mts_case_module` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_case_module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_case_param_space`
--

DROP TABLE IF EXISTS `mts_case_param_space`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_case_param_space` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `package_name` varchar(64) NOT NULL COMMENT '应用包名',
  `platform_type` varchar(64) NOT NULL COMMENT '平台类型，如ANDROID,IOS',
  `space_name` varchar(64) NOT NULL COMMENT '参数空间名字',
  `user_id` bigint(20) unsigned NULL DEFAULT 0 COMMENT '用户id',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0-未删除，1-已删除',
  PRIMARY KEY (`id`),
  KEY `idx_package_name` (`package_name`),
  KEY `idx_package` (`package_name`,`platform_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='参数空间表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_case_param_space`
--

LOCK TABLES `mts_case_param_space` WRITE;
/*!40000 ALTER TABLE `mts_case_param_space` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_case_param_space` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_case_suite_param`
--

DROP TABLE IF EXISTS `mts_case_suite_param`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_case_suite_param` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `case_suite_id` bigint(20) unsigned NOT NULL COMMENT '用例集id',
  `case_version_id` bigint(20) unsigned NOT NULL COMMENT '用例版本id',
  `param_key` text COMMENT '参数key列表，以list形式存储',
  `param` text COMMENT '参数，以json形式存储',
  `space_id` bigint(20) unsigned NOT NULL COMMENT '参数空间id',
  PRIMARY KEY (`id`),
  KEY `idx_1` (`case_suite_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1764 DEFAULT CHARSET=utf8 COMMENT='用例库参数表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_case_suite_param`
--

LOCK TABLES `mts_case_suite_param` WRITE;
/*!40000 ALTER TABLE `mts_case_suite_param` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_case_suite_param` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_case_version`
--

DROP TABLE IF EXISTS `mts_case_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_case_version` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `package_name` varchar(64) NOT NULL COMMENT '应用包名',
  `platform_type` varchar(64) NOT NULL COMMENT '平台类型，如ANDROID,IOS',
  `version_name` varchar(64) NOT NULL COMMENT '版本名字',
  `description` varchar(1024) DEFAULT NULL COMMENT '备注',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0-未删除，1-已删除',
  `user_id` bigint(20) unsigned NULL DEFAULT 0 COMMENT '用户id',
  PRIMARY KEY (`id`),
  KEY `idx_package_name` (`package_name`),
  KEY `idx_package` (`package_name`,`platform_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用例版本表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_case_version`
--

LOCK TABLES `mts_case_version` WRITE;
/*!40000 ALTER TABLE `mts_case_version` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_case_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_crash_solution`
--

DROP TABLE IF EXISTS `mts_crash_solution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_crash_solution` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `type` varchar(64) DEFAULT NULL COMMENT 'INSTALL、LAUNCH、UNINSTALL、CRASH、ANR、EXCEPTION、NATIVECRASH',
  `keyword` varchar(512) DEFAULT NULL COMMENT '关键词，crash的keyline搜索标准',
  `key_solution` text COMMENT '简单快速解决方案，用于hover显示',
  `detail_solution` text COMMENT 'markdown的详细解决方案，可以沉淀案例',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0--未删除，1--已删除',
  `title` varchar(256) DEFAULT NULL COMMENT '显示在帮助文档中的title',
  PRIMARY KEY (`id`),
  KEY `idx_keyword` (`keyword`(40))
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COMMENT='crash解决方案汇总';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_crash_solution`
--

LOCK TABLES `mts_crash_solution` WRITE;
/*!40000 ALTER TABLE `mts_crash_solution` DISABLE KEYS */;
INSERT INTO `mts_crash_solution` VALUES (1,'2016-10-20 19:59:45','2016-10-20 20:02:20','INSTALL','INSTALL_FAILED_OLDER_SDK','AndroidManifest.xml中android:minSdkVersion的值大于当前手机的版本，当前手机版本过低。','因为APK编译是在高版本SDK下编译生成的，但是手机设备是低版本。\n\n具体可以查看AndroidManifest.xml中android:minSdkVersion的值。\n\n而且，随着安卓版本的不断更新，新的API不断提供，有时候高版本的API会在低版本发生crash。\n\n如果minSdkVersion设置过低，在build的时候，会报错（Call requires API level * (current min is *)）。\n\n为了编译可以通过，可以添加@SuppressLint(\"NewApi\")或者@TargeApi($API_LEVEL)注解，但这样只是编译通过，运行时依然会crash。\n\n若要兼容低版本，需要判断运行时的版本，在低版本系统中不调用此方法，同时为了保证功能的完整性，提供低版本功能实现。SDK版本（一个自然数字）可以通过下面的代码确定：\n```\nint currentapiVersion = android.os.Build.VERSION.SDK_INT; \nif (currentapiVersion >= android.os.Build.VERSION_CODES.FROYO) {\n     // 使用高版本的API \n} else {\n     // 使用低版本的API \n} \n```',0,'FAILED_OLDER_SDK'),(2,'2016-11-29 10:57:36','2016-11-29 11:01:15','INSTALL','INSTALL_FAILED_CONTAINER_ERROR','需要安装SD卡在手机上，这样MountService就可以成功创建ASEC文件在sd卡上，所以应用安装成功。遇到此类问题请联系MQC工作人员，旺旺群：335334143；QQ群：492028798。','日志示例：\n\nD/VoldConnector(  553): RMV <- {200 6 asec operation succeeded}\n\nE/MountService(  553): External SD not exist, and PMS want to create ASEC in SD (APP2SD). For SWAP feature, make createSecureContainer() fail!\n\nE/DefContainer( 7417): Failed to create container smdl2tmp1\nI/ProviderMap(  553): getProviderByName:  , callingUid = 1000\n\nW/ActivityManager(  553): No content provider found for permission revoke: file:///data/local/tmp/a.apk\n\nI/PackageManager(  553): Apk copy done\n\n\n问题分析：\nMountService要求读写外部存储器权限，但是存储器不存在，因此安装失败返回。\n\n解决方案：\nKeySolution：需要安装SD卡在手机上，这样MountService就可以成功创建ASEC文件在sd卡上，所以应用安装成功。遇到此类问题请联系MQC工作人员，旺旺群：335334143；QQ群：492028798。\n参考文献：\n1. http://blog.csdn.net/lilian0118/article/details/24455019',0,'INSTALL_FAILED_CONTAINER_ERROR'),(3,'2016-11-29 11:05:47','2016-11-29 11:05:47','INSTALL','INSTALL_FAILED_CANCELLED_BY_USER','部分机型在使用adb命令安装应用时，设备会弹窗询问用户是否允许安装，假如一段时间内（一般是30s），如果没有点击确认弹窗此类设备会阻止安装，并提示用户：INSTALL_FAILED_CANCELLED_BY_USER。此时需要点击确认安装的按钮。如果报这种异常，请联系MQC工作人员，旺旺群：335334143；QQ群：492028798','问题分析：部分机型在使用adb命令安装应用时，设备会弹窗询问用户是否允许安装，假如一段时间内（一般是30s），如果没有点击确认弹窗此类设备会阻止安装，并提示用户：INSTALL_FAILED_CANCELLED_BY_USER。\n\n解决方案：\n部分机型在使用adb命令安装应用时，设备会弹窗询问用户是否允许安装，假如一段时间内（一般是30s），如果没有点击确认弹窗此类设备会阻止安装，并提示用户：INSTALL_FAILED_CANCELLED_BY_USER。此时需要点击确认安装的按钮。如果报这种异常，请联系MQC工作人员，旺旺群：335334143；QQ群：492028798',0,'INSTALL_FAILED_CANCELLED_BY_USER'),(4,'2016-11-29 11:12:32','2016-11-29 11:12:32','INSTALL','INSTALL_FAILED_VERIFICATION_TIMEOUT','部分机型在使用adb命令安装应用时，设备会弹窗询问用户是否允许安装，假如一段时间内（一般是30s），如果没有点击确认弹窗此类设备会阻止安装，并提示用户：INSTALL_FAILED_VERIFICATION_TIMEOUT。此时需要点击确认安装的按钮。如果报这种异常，请联系MQC工作人员，旺旺群：335334143；QQ群：492028798','问题分析：部分机型在使用adb命令安装应用时，设备会弹窗询问用户是否允许安装，假如一段时间内（一般是30s），如果没有点击确认弹窗此类设备会阻止安装，并提示用户：INSTALL_FAILED_VERIFICATION_TIMEOUT。\n\n\n解决方案：\n部分机型在使用adb命令安装应用时，设备会弹窗询问用户是否允许安装，假如一段时间内（一般是30s），如果没有点击确认弹窗此类设备会阻止安装，并提示用户：INSTALL_FAILED_VERIFICATION_TIMEOUT。此时需要点击确认安装的按钮。如果报这种异常，请联系MQC工作人员，旺旺群：335334143；QQ群：492028798',0,'INSTALL_FAILED_VERIFICATION_TIMEOUT'),(5,'2016-11-29 11:15:53','2016-11-29 11:15:53','INSTALL','INSTALL_PARSE_FAILED_NO_CERTIFICATES','因为没有签名信息导致安装失败，建议使用Eclipse或者Android Studio对项目重新编译打包。','问题分析：应用中没有签名信息时安装失败。\n\n解决方案：\n因为没有签名信息导致安装失败，建议使用Eclipse或者Android Studio对项目重新编译打包。因为应用有可能类名，包名相同，所以签名作为区分作用，保证安装时签名不同的包不被替换。APK如果使用一个key签名，发布时另一个key签名的文件将无法安装或覆盖老的版本，这样可以防止你已安装的应用被恶意的第三方覆盖或替换掉。签名其实也是开发者的身份标识，是开发者自己产生的数字证书，即所谓的自签名。具体的签名过程请参考文献。\n\n参考文献：\n\n1.https://developer.android.com/studio/publish/app-signing.html （官方签名文档）\n\n2.http://blog.csdn.net/fengye810130/article/details/9159419 （签名文档）',0,'INSTALL_PARSE_FAILED_NO_CERTIFICATES'),(6,'2016-11-29 11:18:25','2016-11-29 11:18:25','INSTALL','INSTALL_FAILED_MEDIA_UNAVAILABLE','严格指定安装位置到sdcard时，如果设备没有sdcard会报此类错误，建议在AndroidManifest.xml中配置android:installLocation。其中的auto参数可以指定程序可以被安装在外部存储介质上(例如:SD Card),但是默认会被安装到手机内存中.当手机内存为空时,程序将被安装到外部存储介质上.当程序安装到手机上后,用户可以决定把程序放在外部储介质还是内存中。','问题分析：\nAndroid应用安装位置不可用。应用安装位置有两个：ROM、sdcard。如果严格指定安装到sdcard，但是设备没有sdcard时，就会报此类错误。\n\n解决方案：\n严格指定安装位置到sdcard时，如果设备没有sdcard会报此类错误，建议在AndroidManifest.xml中配置android:installLocation。其中的auto参数可以指定程序可以被安装在外部存储介质上(例如:SD Card),但是默认会被安装到手机内存中.当手机内存为空时,程序将被安装到外部存储介质上.当程序安装到手机上后,用户可以决定把程序放在外部储介质还是内存中。\n\n代码示例：\n<manifest xmlns:android=\"http://schemas.android.com/apk/res/android\" android:installLocation=\"auto\" ></mainfest>',0,'INSTALL_FAILED_MEDIA_UNAVAILABLE'),(7,'2016-11-29 11:20:23','2016-11-29 11:20:23','INSTALL','INSTALL_FAILED_VERSION_DOWNGRADE','因为设备中已经安装了APP更高版本，无法降级安装。因此建议先卸载之前的版本，再安装此版本。','问题分析：\n设备中已经安装了此APP的更高版本，无法降级安装。\n\n解决方案：\n建议先卸载之前的版本，再安装此版本。',0,'INSTALL_FAILED_VERSION_DOWNGRADE'),(8,'2016-11-29 11:23:17','2016-11-29 11:23:17','INSTALL','INSTALL_FAILED_UID_CHANGED','应用在上次卸载时，由于应用中的native程序未被杀死而占用/data/data/{packageName}目录，导致/data/data/目录下的APP相关内容未被删除，再次安装无法覆盖报出此类问题。此时如果设备已经Root，则直接删除/data/data/目录下的应用包名文件夹；如果没有root，需要将手机恢复出厂设置。','问题分析：\n应用在上次卸载时，由于应用中的native程序未被杀死而占用/data/data/{packageName}目录，导致/data/data/目录下的APP相关内容未被删除，多数情况下能在logcat中找到报错：Installer: rm -rf failed， directory is not empty。再次安装时无法覆盖，导致报出此类问题。\n\n解决方案：\n此时如果设备已经Root，则直接删除/data/data/目录下的应用包名文件夹；如果没有root，需要将手机恢复出厂设置。此外，开发者要额外注意容易出现此类问题的手机，对此类设备的用户给出提示。用户无需操心，阿里移动测试平台会帮助解决。',0,'INSTALL_FAILED_UID_CHANGED'),(9,'2016-11-29 11:27:05','2016-11-29 11:28:05','INSTALL','INSTALL_FAILED_NO_MATCHING_ABIS','安装的APP包含native libraries（一般是so文件）的时候，因为没有对应机器CPU架构的库文件，就会报出此类问题。建议在编译APP时，先用NDK编译出相应的CPU架构的库文件。','问题分析：当安装的APP包含native libraries（一般是so文件）的时候，如果没有对应机器CPU架构的库文件，就会出现这种问题。比如，开发者编译了一个armv7平台的APP，但是想要装在intel 架构的设备上，就会出现这个错误。\n\n\n解决方案：\n安装的APP包含native libraries（一般是so文件）的时候，因为没有对应机器CPU架构的库文件，就会报出此类问题。建议在编译APP时，先用NDK编译出相应的CPU架构的库文件。\n\n步骤一：\n编写 Application.mk 文件\n在 jni 目录下（例如，即hello-jni.c同级目录下）新建一个Application.mk文件，在文件中添加如下代码：\n\nAPP_ABI := armeabi armeabi-v7a x86\n\n这段话表示你可以同时生成三个处理器的so库。如果没有或不想使用Application.mk文件,则在ndk-build参数中添加\n\nAPP_ABI=\"armeabi armeabi-v7a x86 mips\"\n\n即运行：\n\nndk-build APP_ABI=\"armeabi armeabi-v7a x86 mips\"\n\n\n步骤二： 生成.so共享库文件\nAndroid.mk文件已经编写好了，现在可以用 android NDK 开发包中的 ndk-build 脚本生成对应的.so共享库了，方法如下：\n\nmqc@ubuntu:~/workspace/android/NDK/hello-jni$ ls \n\nAndroidManifest.xml  assets  bin  default.properties  gen  jni  libs  obj  res  src \n\nmqc@ubuntu:~/workspace/android/NDK/hello-jni$ ndk-build \n\nGdbserver      : [arm-linux-androideabi-4.4.3] libs/armeabi/gdbserver \nGdbsetup       : libs/armeabi/gdb.setup \nInstall        : libhello-jni.so => libs/armeabi/libhello-jni.so \n\n这样，在文件夹hello-jni/libs下生成了三个文件夹armeabi armeabi-v7a 以及x86，里面已经正确的生成了libhello-jni.so共享库了。\n\n步骤三：在 eclipse 重新编译 HelloJni 工程，生成 apk\neclipse 中刷新下 HelloJni 工程，重新编译生成 apk，libhello-jni.so 共享库会一起打包在 apk 文件内。',0,'INSTALL_FAILED_NO_MATCHING_ABIS'),(10,'2016-11-29 11:29:10','2016-11-29 11:29:10','INSTALL','INSTALL_PARSE_FAILED_INCONSISTENT_CERTIFICATES','如果设备上已经安装了其他签名的相同包名APP，再安装其他签名的就会报出此类错误，建议解决方案：\n1. 更换签名文件，重新签名；\n2. 更改应用的包名，避免冲突。','问题分析：由于APP签名冲突造成。如果设备上已经安装了其他签名的相同包名APP，再安装其他签名的就会报出此类错误。\n\n解决方案：\n\n1. 更换签名文件，重新签名；\n\n2. 更改应用的包名，避免冲突。',0,'INSTALL_PARSE_FAILED_INCONSISTENT_CERTIFICATES'),(11,'2016-11-29 11:31:22','2016-11-29 11:31:22','INSTALL','INSTALL_FAILED_DEXOPT','ADT和SDK Tool在将source转化成apk的时候因为dex优化失败，导致方法数超标进而抛出异常（类中的每一个方法都分配有一个id，字节码中以id标识和调用方法）。因为方法数超标，建议解决方案：\na.检查代码，删出无用jar包和代码，尤其是自动生成的get/set，没用的类。\nb.将部分java代码封装到JNI中。','问题分析：\nADT和SDK Tool在将source转化成apk的时候因为dex优化失败，导致方法数超标进而抛出异常（类中的每一个方法都分配有一个id，字节码中以id标识和调用方法）。\n\n解决方案：\n\n因为方法数超标，建议采用下述方式：\n\na.检查代码，删出无用jar包和代码，尤其是自动生成的get/set，没用的类。\n\nb.将部分java代码封装到JNI中。',0,'INSTALL_FAILED_DEXOPT'),(12,'2016-11-29 11:36:51','2016-11-29 11:39:51','CRASH','java.lang.ArrayIndexOutOfBoundsException','数组索引越界，引用的对象超出了数组的大小。因此在操作数组之前查看数组大小，判断对象是否存在，如果存在则返回，否则返回null。','问题分析：\n\n数组索引越界，引用的对象超出了数组的大小。\n\n解决方案：\n\n数组索引越界，引用的对象超出了数组的大小。因此在操作数组之前查看数组大小，判断对象是否存在，如果存在则返回，否则返回null。\n\n	public String arrayOutOfBounds(String[] array, int index){\n    	if(array!=null && array.length>index && index>=0){\n    		System.out.println(\"content is: \"+array[index]);\n    		return array[index];\n    	}\n    	return null;\n    }\n\n详细例子：\n\n	Exception in thread \"main\" java.lang.ArrayIndexOutOfBoundsException: 3\n	at com.alibaba.mqc.test.Test.arrayOutOfBounds(Test.java:52)\n	at com.alibaba.mqc.test.Test.main(Test.java:31)\n\n这种Crash是数组本身大小为0而代码中获取了数组的对象而导致的。在SourceFile文件第86行对数组进行get操作时index越界导致的。\n\n参考文献：\n1.https://developer.android.com/reference/java/lang/IndexOutOfBoundsException.html',0,'java.lang.ArrayIndexOutOfBoundsException'),(13,'2016-11-29 11:42:37','2016-11-29 11:54:39','CRASH','java.lang.reflect.InvocationTargetException','在反射调用方法时，被调用的方法内部抛出了异常没有被捕获会抛出此类异常，建议使用try Catch块进行捕获并处理。','问题分析：\n\nInvocationTargetException异常由Method.invoke(obj, args...)方法抛出。当被调用的方法的内部抛出了异常而没有被捕获时，由此异常接收。\n\n解决方案：\n\n在反射调用方法时，被调用的方法内部抛出了异常没有被捕获会抛出此类异常，建议使用try Catch块进行捕获并处理。\n\n代码示例：\n\n	public static void main(String[] args) {\n		try {\n			Class<?> clazz = Class.forName(\"com.alibaba.test\");\n			Method method = clazz.getMethod(\"run\", int.class);\n			method.invoke(clazz.newInstance(), -1);\n		} catch (InvocationTargetException e) {\n			System.out.println(\"此处接收被调用方法内部未被捕获的异常\");\n			e.printStackTrace();\n		} \n	}\n\n详细的例子：\n\n	java.lang.reflect.InvocationTargetException\n		at java.lang.reflect.Method.invokeNative(Native Method)\n		at java.lang.reflect.Method.invoke(Method.java:515)\n		at android.app.ActivityThread.pauseGC(ActivityThread.java:5525)\n		at android.app.ActivityThread.performLaunchActivity(ActivityThread.java:2324)\n		at android.app.ActivityThread.handleLaunchActivity(ActivityThread.java:2471)\n		at android.app.ActivityThread.access$900(ActivityThread.java:175)\n		at android.app.ActivityThread$H.handleMessage(ActivityThread.java:1308)\n		at android.os.Handler.dispatchMessage(Handler.java:102)\n		at android.os.Looper.loop(Looper.java:146)\n		at android.app.ActivityThread.main(ActivityThread.java:5602)\n		at java.lang.reflect.Method.invokeNative(Native Method)\n		at java.lang.reflect.Method.invoke(Method.java:515)\n		at com.android.internal.os.ZygoteInit$MethodAndArgsCaller.run(ZygoteInit.java:1283)\n		at com.android.internal.os.ZygoteInit.main(ZygoteInit.java:1099)\n		at dalvik.system.NativeStart.main(Native Method)\n	Caused by: java.lang.UnsatisfiedLinkError: Native method not found: dalvik.system.VMRuntime.pauseGc:(Ljava/lang/String;)I\n		at dalvik.system.VMRuntime.pauseGc(Native Method)\n		... 15 more\n\n针对这个异常的堆栈信息来看，暂时没有好的解决方案，这个问题是三星Android4.4.2、4.4.4版本引入的bug，原因是：\n在ActivityThread文件的第5525行调用反射调用native方法pauseGc()而未找到此函数。每当视频重绘调用GLSurfaceView时，会起一个新的Activity会产生2MB的垃圾，但GC机制没有对此进行垃圾回收。因此如果播放一个视频30min左右内存就满了，应用Crash产生。\n\n参考文献：\n\n1.http://developer.samsung.com/forum/thread/pause-gc-error-post-android-442-upgrade-on-samsung-galaxy-note-ii/201/266242?boardName=SDK&startId=zzzzz~&searchSubId=0000000029\n\n2.https://docs.oracle.com/javase/7/docs/api/java/lang/reflect/InvocationTargetException.html',0,'java.lang.reflect.InvocationTargetException'),(14,'2016-11-29 11:53:22','2016-11-29 11:55:29','CRASH','java.io.FileNotFoundException','文件未找到或无权限时，请确认文件路径文件存在，添加所需访问权限，确保文件存在的情况下进行读写，并增加try catch块做异常处理。','问题分析：\n\n文件未找到或无权限时抛出此类异常。\n\n\n解决方案\n文件未找到或无权限时，请确认文件路径文件存在，添加所需访问权限，确保文件存在的情况下进行读写，并增加try catch块做异常处理。\n\n代码示例：\n\n增加读写外部存储上的文件权限：\n\n	<uses-permission android:name=\"android.permission.READ_EXTERNAL_STORAGE\"></uses-permission>\n	<uses-permission android:name=\"android.permission.WRITE_EXTERNAL_STORAGE\"></uses-permission>\n\n创建文件，增加读写权限并catch exception。\n\n	File extDir = Environment.getExternalStorageDirectory();\n	String filename = \"file.txt\";\n	File fullFilename = new File(extDir, filename);\n	try {\n	if(!fullFilename.exists()){\n			fullFilename.createNewFile();\n			fullFilename.setWritable(Boolean.TRUE);\n	                // 写文件操作\n		}\n		else{\n			// 读文件操作\n		}\n	} catch (IOException e) {\n	    e.printStackTrace();\n	}\n\n示例：\n\n	java.io.FileNotFoundException: /proc/mtprof/status: open failed: ENOENT (No such file or directory)\n		at libcore.io.IoBridge.open(IoBridge.java:496)\n		at java.io.FileInputStream.<init>(FileInputStream.java:76)\n		at java.io.FileInputStream.<init>(FileInputStream.java:103)\n		at android.app.ActivityThread$H.handleMessage(ActivityThread.java:1494)\n		at android.os.Handler.dispatchMessage(Handler.java:111)\n		at android.os.Looper.loop(Looper.java:194)\n		at android.app.ActivityThread.main(ActivityThread.java:5692)\n		at java.lang.reflect.Method.invoke(Native Method)\n		at java.lang.reflect.Method.invoke(Method.java:372)\n		at com.android.internal.os.ZygoteInit$MethodAndArgsCaller.run(ZygoteInit.java:959)\n		at com.android.internal.os.ZygoteInit.main(ZygoteInit.java:754)\n	Caused by: android.system.ErrnoException: open failed: ENOENT (No such file or directory)\n		at libcore.io.Posix.open(Native Method)\n		at libcore.io.BlockGuardOs.open(BlockGuardOs.java:186)\n		at libcore.io.IoBridge.open(IoBridge.java:482)\n		... 10 more\n\n异常导致应用无法启动。日志如下：\n\n	10-20 09:43:08.073   820   820 E WifiTrafficPoller: TRAFFIC_STATS_POLL true Token 1138 num clients 12\n	10-20 09:43:08.074   820   820 E WifiTrafficPoller:  packet count Tx=237196 Rx=493756\n	10-20 09:43:08.365   820   842 W BroadcastQueue: Skipping deliver [background] BroadcastRecord{9a089ad u-1 android.net.conn.CONNECTIVITY_CHANGE} to ReceiverList{2c1b84e2 23189 (unknown name)/2000/u-1 remote:2663fdd7}: process crashing\n	10-20 09:43:08.401 23079 23079 E ActivityThread: mtprof entry can not be found\n	10-20 09:43:08.401 23079 23079 E ActivityThread: java.io.FileNotFoundException: /proc/mtprof/status: open failed: ENOENT (No such file or directory)\n	10-20 09:43:08.401 23079 23079 E ActivityThread: 	at libcore.io.IoBridge.open(IoBridge.java:496)\n	10-20 09:43:08.401 23079 23079 E ActivityThread: 	at java.io.FileInputStream.<init>(FileInputStream.java:76)\n	10-20 09:43:08.401 23079 23079 E ActivityThread: 	at java.io.FileInputStream.<init>(FileInputStream.java:103)\n	10-20 09:43:08.401 23079 23079 E ActivityThread: 	at android.app.ActivityThread$H.handleMessage(ActivityThread.java:1494)\n	10-20 09:43:08.401 23079 23079 E ActivityThread: 	at android.os.Handler.dispatchMessage(Handler.java:111)\n	10-20 09:43:08.401 23079 23079 E ActivityThread: 	at android.os.Looper.loop(Looper.java:194)\n	10-20 09:43:08.401 23079 23079 E ActivityThread: 	at android.app.ActivityThread.main(ActivityThread.java:5692)\n	10-20 09:43:08.401 23079 23079 E ActivityThread: 	at java.lang.reflect.Method.invoke(Native Method)\n	10-20 09:43:08.401 23079 23079 E ActivityThread: 	at java.lang.reflect.Method.invoke(Method.java:372)\n	10-20 09:43:08.401 23079 23079 E ActivityThread: 	at com.android.internal.os.ZygoteInit$MethodAndArgsCaller.run(ZygoteInit.java:959)\n	10-20 09:43:08.401 23079 23079 E ActivityThread: 	at com.android.internal.os.ZygoteInit.main(ZygoteInit.java:754)\n	10-20 09:43:08.401 23079 23079 E ActivityThread: Caused by: android.system.ErrnoException: open failed: ENOENT (No such file or directory)\n	10-20 09:43:08.401 23079 23079 E ActivityThread: 	at libcore.io.Posix.open(Native Method)\n	10-20 09:43:08.401 23079 23079 E ActivityThread: 	at libcore.io.BlockGuardOs.open(BlockGuardOs.java:186)\n	10-20 09:43:08.401 23079 23079 E ActivityThread: 	at libcore.io.IoBridge.open(IoBridge.java:482)\n	10-20 09:43:08.401 23079 23079 E ActivityThread: 	... 10 more\n	10-20 09:43:08.415 23079 23079 W Launcher: setApplicationContext called twice! \n	10-20 09:43:08.422 23079 23079 E Fatal exception: :java.lang.RuntimeException: Unable to start activity ComponentInfo{}: java.io.IOException: broken file descriptor\n	10-20 09:43:08.422 23079 23079 W System.err: java.lang.RuntimeException: Unable to start activity ComponentInfo{}: java.io.IOException: broken file descriptor\n	10-20 09:43:08.422 23079 23079 W System.err: 	at android.app.ActivityThread.performLaunchActivity(ActivityThread.java:2581)\n	10-20 09:43:08.422 23079 23079 W System.err: 	at android.app.ActivityThread.handleLaunchActivity(ActivityThread.java:2656)\n	10-20 09:43:08.422 23079 23079 W System.err: 	at android.app.ActivityThread.access$800(ActivityThread.java:178)\n	10-20 09:43:08.423 23079 23079 W System.err: 	at android.app.ActivityThread$H.handleMessage(ActivityThread.java:1512)\n	10-20 09:43:08.423 23079 23079 W System.err: 	at android.os.Handler.dispatchMessage(Handler.java:111)\n	10-20 09:43:08.423 23079 23079 W System.err: 	at android.os.Looper.loop(Looper.java:194)\n	10-20 09:43:08.423 23079 23079 W System.err: 	at android.app.ActivityThread.main(ActivityThread.java:5692)\n	10-20 09:43:08.423 23079 23079 W System.err: 	at java.lang.reflect.Method.invoke(Native Method)\n	10-20 09:43:08.423 23079 23079 W System.err: 	at java.lang.reflect.Method.invoke(Method.java:372)\n	10-20 09:43:08.423 23079 23079 W System.err: 	at com.android.internal.os.ZygoteInit$MethodAndArgsCaller.run(ZygoteInit.java:959)\n	10-20 09:43:08.423 23079 23079 W System.err: 	at com.android.internal.os.ZygoteInit.main(ZygoteInit.java:754)\n	10-20 09:43:08.423 23079 23079 W System.err: Caused by: java.io.IOException: broken file descriptor\n	10-20 09:43:08.423 23079 23079 W System.err: 	at android.graphics.BitmapFactory.nativeDecodeFileDescriptor(Native Method)\n	10-20 09:43:08.423 23079 23079 W System.err: 	at android.graphics.BitmapFactory.decodeFileDescriptor(BitmapFactory.java:714)\n	10-20 09:43:08.423 23079 23079 W System.err: 	at android.app.WallpaperManager$Globals.getCurrentWallpaperLocked(WallpaperManager.java:308)\n	10-20 09:43:08.423 23079 23079 W System.err: 	at android.app.WallpaperManager$Globals.peekWallpaperBitmap(WallpaperManager.java:270)\n	10-20 09:43:08.423 23079 23079 W System.err: 	at android.app.WallpaperManager.getDrawable(WallpaperManager.java:413)\n\n更换手机桌面应用布局界面时调用native方法decodeFileDescriptor读取文件/proc/stprof/status抛出了异常未捕获导致进程崩溃，建议按照示例一判断文件是否存在并对异常进行捕获处理。\n\n参考文献：\n\n1. https://developer.android.com/guide/topics/data/data-storage.html#filesExternal \n\n2. http://www.cnblogs.com/feisky/archive/2011/01/05/1926177.html',0,'java.io.FileNotFoundException'),(15,'2016-11-29 11:57:42','2016-11-29 11:57:42','CRASH','java.net.SocketTimeoutException','SocketTimeoutException发生在socket连接过程中的accept()和read()中，服务端或客户端设置超时连接后，当到达超时时间均会抛出此类异常。建议设置可接受的socket超时时间并捕获处理SocketTimeoutException。','问题分析：\n\n这类异常发生在建立socket连接或读取数据时发生超时时抛出。\n\n解决方案：\nSocketTimeoutException发生在socket连接过程中的accept()和read()中，服务端或客户端设置超时连接后，当到达超时时间均会抛出此类异常。建议设置可接受的socket超时时间并捕获处理SocketTimeoutException。\n\n代码示例：\n\n服务器端：\n\n        ServerSocket serverSocket = null;\n			try {\n				serverSocket = new ServerSocket(8111);\n				serverSocket.setSoTimeout(10000);\n				while (true) {\n					try {\n						Socket clientSocket = serverSocket.accept();\n						BufferedReader inputReader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));\n						System.out.println(\"Client said :\"+ inputReader.readLine());\n					} catch (SocketTimeoutException e) {\n						e.printStackTrace();\n					}\n				}\n			} catch (IOException e1) {\n				e1.printStackTrace();\n			} finally {\n				try {\n					if (serverSocket != null) {\n						serverSocket.close();\n					}\n				} catch (IOException e) {\n					e.printStackTrace();\n				}\n			}\n\n客户端：\n\n	@Override\n    public void run() {\n        try {\n            HttpURLConnection.setFollowRedirects(false);\n            HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();\n            con.setRequestMethod(\"HEAD\");\n            con.setConnectTimeout(5000);\n            log.info(\"Response Code: \" + con.getResponseCode());\n        } catch (SocketTimeoutException e) {\n            System.out.println(“SocketTimeoutException”+e.getMessage());\n        } catch (IOException e) {\n            System.out.println(“IOException”+e.getMessage());\n        } catch (Exception e) {\n            System.out.println(“Exception”+e.getMessage());\n        }\n    }\n\n参考文献：\n\n1.https://developer.android.com/reference/java/net/SocketTimeoutException.html\n\n2.https://examples.javacodegeeks.com/core-java/net/sockettimeoutexception/java-net-sockettimeoutexception-how-to-solve-sockettimeoutexception/',0,'java.net.SocketTimeoutException'),(16,'2016-11-29 14:33:45','2016-11-29 14:33:45','CRASH','java.net.SocketException','当服务端创建SocketServer时、客户端向服务端创建socket时、连接过程中发生错误时会抛出此类异常，建议使用try catch finally块捕获异常并做好业务处理。','问题分析：\n\n当服务端创建SocketServer时、客户端向服务端创建socket时、连接过程中发生错误时会抛出此类异常。此类异常主要有四种子类BindException、 ConnectException、NoRouteToHostException、PortUnreachableException，均可以被SocketException捕获。这四种子类的问题分析如下：\n\n1. BindException试图将套接字绑定到本地地址和端口时发生错误的情况下，抛出此异常。\n\n2. ConnectException试图将套接字连接到远程地址和端口时发生错误的情况下，抛出此异常，典型的方式是因为远程主机拒绝，例如远程主机不存在或并未监听此端口。\n\n3. NoRouteToHostException试图将套接字连接到远程地址和端口时发生错误的情况下，抛出此异常，一般原因是因为防火墙拦截或必经路由器中断引起的。\n4. PortUnreachableException在连接的数据报上已接收到 ICMP Port Unreachable 消息时，抛出该异常。\n\n解决方案：\n当服务端创建SocketServer时、客户端向服务端创建socket时、连接过程中发生错误时会抛出此类异常，建议使用try catch finally块捕获异常并做好业务处理。\n\n1. 示例一\n\n	   java.net.SocketException: Connection reset\n		at java.net.SocketInputStream.read(SocketInputStream.java:196)\n		at java.net.SocketInputStream.read(SocketInputStream.java:122)\n		at sun.nio.cs.StreamDecoder.readBytes(StreamDecoder.java:283)\n		at sun.nio.cs.StreamDecoder.implRead(StreamDecoder.java:325)\n		at sun.nio.cs.StreamDecoder.read(StreamDecoder.java:177)\n		at java.io.InputStreamReader.read(InputStreamReader.java:184)\n		at java.io.BufferedReader.fill(BufferedReader.java:154)\n		at java.io.BufferedReader.readLine(BufferedReader.java:317)\n		at java.io.BufferedReader.readLine(BufferedReader.java:382)\n\n问题分析：\n\n该异常在客户端和服务器端均有可能发生，引起该异常的原因有两个，第一个就是如果一端的Socket被关闭（或主动关闭或者因为异常退出而引起的关闭），另一端仍发送数据，发送的第一个数据包引发该异常(Connect reset by peer)。另一个是一端退出，但退出时并未关闭该连接，另一端如果在从连接中读数据则抛出该异常（Connection reset）。主要原因是在连接断开后的读和写操作引起的异常。\n\n解决方案：\n\n建议不要频繁建立过多socket请求导致服务器压力增大抛出SocketException，并使用try catch块捕获异常做后续处理。如果服务是幂等的，则客户端可以重试连接。如果不是幂等的，重试可能造成重复提单。\n\n代码示例：\n\n服务端代码：\n\n	class SimpleServer implements Runnable {\n		@Override\n		public void run() {\n			ServerSocket serverSocket = null;\n			try {\n				serverSocket = new ServerSocket(8111);\n				serverSocket.setSoTimeout(3000);\n				while (true) {\n					try {\n						Socket clientSocket = serverSocket.accept();\n						BufferedReader inputReader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));\n						System.out.println(\"Client said :\"+ inputReader.readLine());\n					} catch (SocketTimeoutException e) {\n						e.printStackTrace();\n					}\n				}\n			}catch (SocketException e) {\n				e.printStackTrace();\n			}catch (IOException e1) {\n				e1.printStackTrace();\n			} finally {\n				try {\n					if (serverSocket != null) {\n						serverSocket.close();\n					}\n				} catch (IOException e) {\n					e.printStackTrace();\n				}\n			}\n		}\n	}\n\n客户端代码：\n\n 	class SimpleClient implements Runnable {\n		@Override\n		public void run() {\n			Socket socket = null;\n			try {\n				socket = new Socket(\"localhost\", 8111);\n				PrintWriter outWriter = new PrintWriter(socket.getOutputStream(), true);\n				System.out.println(\"Wait\");\n				Thread.sleep(15000);\n				//throw new Exception(\"Random exception\");\n				outWriter.println(\"Hello Mr. Server!\");\n			}catch (SocketException e) {\n				e.printStackTrace();\n			}catch (InterruptedException e) {\n				e.printStackTrace();\n			} catch (UnknownHostException e) {\n				e.printStackTrace();\n			} catch (IOException e) {\n				e.printStackTrace();\n			} catch (Exception e) {\n				e.printStackTrace();\n			} finally {\n				try {\n					if (socket != null)\n						socket.close();\n				} catch (IOException e) {\n					e.printStackTrace();\n				}\n			}\n		}\n\n\n2. 示例二\n\n		java.net.ConnectException: Connection refused: connect\n		at java.net.DualStackPlainSocketImpl.connect0(Native Method)\n		at java.net.DualStackPlainSocketImpl.socketConnect(DualStackPlainSocketImpl.java:79)\n		at java.net.AbstractPlainSocketImpl.doConnect(AbstractPlainSocketImpl.java:339)\n		at java.net.AbstractPlainSocketImpl.connectToAddress(AbstractPlainSocketImpl.java:200)\n		at java.net.AbstractPlainSocketImpl.connect(AbstractPlainSocketImpl.java:182)\n		at java.net.PlainSocketImpl.connect(PlainSocketImpl.java:172)\n		at java.net.SocksSocketImpl.connect(SocksSocketImpl.java:392)\n		at java.net.Socket.connect(Socket.java:579)\n		at java.net.Socket.connect(Socket.java:528)\n		at java.net.Socket.(Socket.java:425)\n		at java.net.Socket.(Socket.java:208)\n		\n\n问题分析：\n服务端不能响应客户端的连接请求抛出异常。可能原因：ip或者端口写错、服务器宕机、防火墙等原因。\n\n解决方案：\n\n服务端不能响应客户端的连接请求抛出异常。建议检查ip或者端口正确、服务器可以访问、防火墙未限制。\n代码示例与示例一相同。\n\n参考文献：\n\n1. https://docs.oracle.com/javase/7/docs/api/java/net/SocketException.html\n2. https://docs.oracle.com/javase/7/docs/api/java/net/BindException.html\n3. https://docs.oracle.com/javase/7/docs/api/java/net/ConnectException.html\n4. https://docs.oracle.com/javase/7/docs/api/java/net/NoRouteToHostException.html \n5. https://examples.javacodegeeks.com/core-java/net/connectexception/java-net-connectexception-how-to-solve-connect-exception/ \n6. http://www.seotcs.com/blog/796.html \n7. https://my.oschina.net/xionghui/blog/508758',0,'java.net.SocketException'),(17,'2016-11-29 14:36:39','2016-11-29 14:36:39','CRASH','org.json.JSONException','Json解析时或查找方式不正确导致抛出此类异常，建议捕获此类异常并做处理。','问题分析：\n\n抛出此类异常主要有以下情况：\n\n1.试图解析或生成格式不正确的文档；\n\n2.Key的值为null；\n\n3.使用NaNs或infinites等Json不容许的数字类型；\n\n4.查找的索引超出边界或不存在的key；\n\n5.查找时的方式与查找内容类型不匹配。\n\n\n解决方案：\n\nJson解析时或查找方式不正确导致抛出此类异常，建议捕获此类异常并做处理。\n\n代码示例：\n\n	public void parseJson(String jsonStr){\n	    	try {\n	    		JSONObject json=JSON.parseObject(jsonStr);\n	        	if(json.containsKey(\"name\")){\n	        		System.out.println(json.get(\"name\"));\n	        	}\n			} catch (JSONException e) {\n				e.printStackTrace();\n			}\n	}\n\n参考文献：\n\n1. https://developer.android.com/reference/org/json/JSONException.html',0,'org.json.JSONException'),(18,'2016-11-29 14:40:11','2016-11-29 14:40:11','CRASH','java.lang.InterruptedException','线程在sleep、wait、join时如果对线程调用interrupt方法，会抛出InterruptedException，对该类异常进行捕获，可以获得线程控制权，继续执行任务。','问题分析：\n\n通过调用interrupt()方法，线程在sleep, wait, join时，会抛出InterruptedException，可以在适当地方配合isInterrupted()方法检查中断状态，并对异常进行捕获并处理，这样线程不用继续等待，线程控制权直接会转给catch住异常块的代码。\n\n解决方案：\n线程在sleep、wait、join时如果对线程调用interrupt方法，会抛出InterruptedException，对该类异常进行捕获，可以获得线程控制权，继续执行任务。\n\n代码示例：\n\n    public class PlayerMatcher {\n        private PlayerSource players;\n        public PlayerMatcher(PlayerSource players) { \n            this.players = players; \n        }\n        public void matchPlayers() throws InterruptedException { \n            try {\n                 Player playerOne, playerTwo;\n                 while (true) {\n                     playerOne = playerTwo = null;\n                     // Wait for two players to arrive and start a new game\n                     playerOne = players.waitForPlayer(); // could throw IE\n                     playerTwo = players.waitForPlayer(); // could throw IE\n                     startNewGame(playerOne, playerTwo);\n                 }\n             }\n             catch (InterruptedException e) {  \n                 // If we got one player and were interrupted, put that player back\n                 if (playerOne != null)\n                     players.addFirst(playerOne);\n                 // Then propagate the exception\n                 throw e;\n             }\n        }\n    }\n\n参考文献：\n\n1. https://docs.oracle.com/javase/7/docs/api/java/lang/InterruptedException.html\n2. http://www.ibm.com/developerworks/cn/java/j-jtp05236.html\n3. http://blog.csdn.net/derekjiang/article/details/4845757',0,'java.lang.InterruptedException'),(19,'2016-11-29 14:43:17','2016-11-29 14:43:17','CRASH','android.database.sqlite.SQLiteCantOpenDatabaseException','SQLite无法打开数据库抛出此类异常是因为读写的数据库文件不存在或者没有申请到正确的读写权限或者这个文件的权限比较特别，建议检查是否申请到了正确的权限、并且文件路径正确。','问题分析：\n\nSQLite无法打开数据库时抛出此类异常。\n\n\n解决方案：\n\nSQLite无法打开数据库抛出此类异常是因为读写的数据库文件不存在或者没有申请到正确的读写权限或者这个文件的权限比较特别，建议检查是否申请到了正确的权限、并且文件路径正确。\n\n\n代码示例：\n\n如果需要读取外部存储器上的文件需要在Manifest添加权限\n\n    <uses-permission android:name=\"android.permission.READ_EXTERNAL_STORAGE\"></uses-permission>\n    <uses-permission android:name=\"android.permission.WRITE_EXTERNAL_STORAGE\"></uses-permission>\n\n在Android6.0以前申请权限时，用户在安装和更新时会进行授权。Android6.0以后会在运行期用户进行授权。为了在运行期获取权限，首先需要向用户请求权限：\n\n    // Here, thisActivity is the current activity\n    if (ContextCompat.checkSelfPermission(thisActivity,\n                    Manifest.permission.READ_CONTACTS)\n            != PackageManager.PERMISSION_GRANTED) {\n        // Should we show an explanation?\n        if (ActivityCompat.shouldShowRequestPermissionRationale(thisActivity,\n                Manifest.permission.READ_CONTACTS)) {\n            // Show an expanation to the user *asynchronously* -- don\'t block\n            // this thread waiting for the user\'s response! After the user\n            // sees the explanation, try again to request the permission.\n        } else {\n            // No explanation needed, we can request the permission.\n            ActivityCompat.requestPermissions(thisActivity,\n                    new String[]{Manifest.permission.READ_CONTACTS},\n                    MY_PERMISSIONS_REQUEST_READ_CONTACTS);\n\n            // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an\n            // app-defined int constant. The callback method gets the\n            // result of the request.\n        }\n    }\n\n然后确认是否权限通过，做业务处理。\n\n      @Override\n      public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {\n          switch (requestCode) {\n             case WRITE_REQUEST_CODE:\n               if(grantResults[0] == PackageManager.PERMISSION_GRANTED){\n                 //Permission granted.\n                 //Continue with writing files...\n               }\n             else{\n                 //Permission denied.\n               }\n              break;\n          }\n      }\n\n参考文献：\n\n1. https://developer.android.com/reference/android/database/sqlite/SQLiteCantOpenDatabaseException.html\n2. http://stackoverflow.com/questions/17034511/android-database-sqlite-sqlitecantopendatabaseexception-unknown-error-code-14\n3. https://developer.android.com/training/permissions/requesting.html#perm-check （安卓6.0授权检查方式）\n4.https://developer.android.com/guide/topics/security/permissions.html#normal-dangerous （普通权限及危险权限说明）',0,'android.database.sqlite.SQLiteCantOpenDatabaseException'),(20,'2016-11-29 14:46:16','2016-11-29 14:46:16','CRASH','android.database.sqlite.DatabaseObjectNotClosedException','应用程序没有关闭游标或数据库对象导致抛出此类异常。通过对游标及数据库对之前打开的数据库对象调用close方法进行关闭操作即可。','问题分析：\n\n在打开数据库操作之前，应用程序没有关闭游标或数据库对象。\n\n解决方案：\n\n应用程序没有关闭游标或数据库对象导致抛出此类异常。通过对游标及数据库对之前打开的数据库对象调用close方法进行关闭操作即可。\n\n示例：\n\n\n      android.database.sqlite.DatabaseObjectNotClosedException: Application did not close the cursor or database object that was opened here\n      android.database.sqlite.DatabaseObjectNotClosedException: Application did not close the cursor or database object that was opened here\n        at android.content.ContentResolver.query(ContentResolver.java:399)\n        at android.content.ContentResolver.query(ContentResolver.java:316)\n\n\n步骤1：\n\n使用try catch块捕获异常，并在finally部分关闭数据库。\n\n      OpenHelper dh = new DatabaseHelper(this);\n      SQLiteDatabase db = null;\n      try {\n          db =  dh.getWritableDatabase();\n      } catch(SQLiteException e){\n          e.printStackTrace();\n      } finally {\n          if(db != null && db.isOpen())\n              db.close();\n      }\n\n步骤2：\n\n在Activity生命周期中，onResume()打开数据库，onPause()关闭数据库。\n\n      OpenHelper dh = null;\n      @Override\n      protected void onCreate(Bundle savedInstanceState) {\n          dh = new DatabaseHelper(this);\n      }\n      @Override\n      protected void onResume() {\n          this.db =  dh.getWritableDatabase();\n      }\n      @Override\n      protected void onPause( {\n          if(db != null && db.isOpen()){\n              db.close();\n          }\n      }\n\n参考文献：\n\n1. http://stackoverflow.com/questions/7492006/databaseobjectnotclosedexception \n2. http://stackoverflow.com/questions/4734886/how-can-one-avoid-databaseobjectnotclosedexception \n3. http://debuglog.iteye.com/blog/1404338',0,'android.database.sqlite.DatabaseObjectNotClosedException'),(21,'2016-11-29 14:55:56','2016-11-29 14:55:56','CRASH','java.lang.IllegalArgumentException','因为参数不合法导致抛出IllegalArgumentException，请根据堆栈信息描述的出错的函数参数，按照要求传入正确的参数。','问题分析：\n\n根据Android官方文档，当方法接收到了一个不合法或不正确的参数时会抛出此类异常。\n\n\n解决方案：\n\n因为参数不合法导致抛出IllegalArgumentException，请根据堆栈信息描述的出错的函数参数，按照要求传入正确的参数。\n\n\n代码示例：\n\n      public static void getUserAgent(Context context) {\n        WebView webview = new WebView(context);\n        WebSettings settings = webview.getSettings();\n        userAgent = settings.getUserAgentString();\n        Log.i(\"UserAgent：\" + userAgent);\n      }\n\n示例一：\n\n      java.lang.IllegalArgumentException: HTTP parameters may not be null\n        at org.apache.http.params.HttpProtocolParams.getUserAgent(HttpProtocolParams.java:150)\n        at org.apache.http.impl.client.AbstractHttpClient.isMoMMS(AbstractHttpClient.java:790)\n        at org.apache.http.impl.client.AbstractHttpClient.execute(AbstractHttpClient.java:563)\n        at org.apache.http.impl.client.AbstractHttpClient.execute(AbstractHttpClient.java:520)\n        at org.apache.http.impl.client.AbstractHttpClient.execute(AbstractHttpClient.java:498)\n        at com.g.utils.HttpClientUtil.post(HttpClientUtil.java:99)\n        at com.g.utils.LoadDataFromServer$2.run(LoadDataFromServer.java:195)\n\n\n因为参数为空导致获取字符集失败抛出的异常。\n\n在这个例子里，getUserAgent因为userAgent变量为空所以报错。User Agent中文名为用户代理，简称 UA，它是一个特殊字符串头，使得服务器能够识别客户使用的操作系统及版本、CPU 类型、浏览器及版本、浏览器渲染引擎、浏览器语言、浏览器插件等。\n\n示例二：\n\n      java.lang.IllegalArgumentException\n        at android.view.Surface.nativeLockCanvas(Native Method)\n        at android.view.Surface.lockCanvas(Surface.java:243)\n        at android.view.ViewRootImpl.drawSoftware(ViewRootImpl.java:2435)\n        at android.view.ViewRootImpl.draw(ViewRootImpl.java:2409)\n        at android.view.ViewRootImpl.performDraw(ViewRootImpl.java:2253)\n        at android.view.ViewRootImpl.performTraversals(ViewRootImpl.java:1883)\n        at android.view.ViewRootImpl.doTraversal(ViewRootImpl.java:1000)\n        at android.view.ViewRootImpl$TraversalRunnable.run(ViewRootImpl.java:5670)\n        at android.view.Choreographer$CallbackRecord.run(Choreographer.java:761)\n        at android.view.Choreographer.doCallbacks(Choreographer.java:574)\n        at android.view.Choreographer.doFrame(Choreographer.java:544)\n        at android.view.Choreographer$FrameDisplayEventReceiver.run(Choreographer.java:747)\n        at android.os.Handler.handleCallback(Handler.java:733)\n        at android.os.Handler.dispatchMessage(Handler.java:95)\n        at android.os.Looper.loop(Looper.java:136)\n        at android.app.ActivityThread.main(ActivityThread.java:5017)\n        at java.lang.reflect.Method.invokeNative(Native Method)\n        at java.lang.reflect.Method.invoke(Method.java:515)\n        at com.android.internal.os.ZygoteInit$MethodAndArgsCaller.run(ZygoteInit.java:779)\n        at com.android.internal.os.ZygoteInit.main(ZygoteInit.java:595)\n        at dalvik.system.NativeStart.main(Native Method)\n\n问题分析：\n\n该问题在Android诸多系统版本均有出现。这个问题是由于Android系统的bug导致Webview内存无法被正确管理，从而导致内存泄漏。当内存太低时，绘图时无法申请到内存资源，导致此异常抛出，应用崩溃。\n\n\n解决方案：\n\nA.强制管理Webview的生命周期。\n在Webview对应的Activity的声明周期管理中，对webview进行强制的管理。当Activity在onPause()时，强制destory掉webview，并清空webview的container。\n这样，webview占用的内存会在下一次GC时，被系统回收。\n\n        @Override\n        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saved) {\n            View v = super.onCreateView(inflater, container, saved);\n            mActivity = (BaseActivity) getSupportActivity();\n            // this is the framelayout which will contain our WebView\n            mWebContainer = (FrameLayout) v.findViewById(R.id.web_container);\n            return v;\n        }\n\n        public void onResume() {\n            super.onResume();\n            // create new WebView and set all its options.\n            mWebView = new WebView(mActivity);\n            mWebView....\n            // add it to the container\n            mWebContainer.addView(mWebView);\n            // if data is available, display it immediately\n            if(mTopic != null) {\n                mWebView.loadDataWithBaseURL(\"file:///android_asset/\", mTopic.getHtmlCache(),\n                        \"text/html\", \"UTF-8\", null);\n            }\n        }\n\n        @Override\n        public void onPause() {\n            super.onPause();\n            // destroy the webview\n            mWebView.destroy();\n            mWebView = null;\n            // remove the view from the container.\n            mWebContainer.removeAllViews();\n        }\n\n\nB.取消应用的硬件加速\n\n在AndroidManifest.xml里增加android:hardwareAccelerated=\"false\"，用来禁止硬件加速，此方法可以避免该系统bug。不过，不推荐游戏或者对流畅性要求很高的应用采用此方法，可能会导致应用变得有一些卡顿。\n\n\n示例三：\n\n      01-17 00:19:44.703: E/Surface(9731): Surface::lock failed, already locked\n      01-17 00:19:44.796: E/SurfaceHolder(9731): Exception locking surface\n      01-17 00:19:44.796: E/SurfaceHolder(9731): java.lang.IllegalArgumentException\n      01-17 00:19:44.796: E/SurfaceHolder(9731):  at android.view.Surface.lockCanvasNative(Native Method)\n      01-17 00:19:44.796: E/SurfaceHolder(9731):  at android.view.Surface.lockCanvas(Surface.java:314)\n      01-17 00:19:44.796: E/SurfaceHolder(9731):  at android.view.SurfaceView$3.internalLockCanvas(SurfaceView.java:762)\n      01-17 00:19:44.796: E/SurfaceHolder(9731):  at android.view.SurfaceView$3.lockCanvas(SurfaceView.java:741)\n      01-17 00:19:44.796: E/SurfaceHolder(9731):  at com.frequency.FreqTapArea$2.onTouch(FreqTapArea.java:54)\n      01-17 00:19:44.796: E/SurfaceHolder(9731):  at android.view.View.dispatchTouchEvent(View.java:3897)\n      01-17 00:19:44.796: E/SurfaceHolder(9731):  at android.view.ViewGroup.dispatchTouchEvent(ViewGroup.java:869)\n      01-17 00:19:44.796: E/SurfaceHolder(9731):  at android.view.ViewGroup.dispatchTouchEvent(ViewGroup.java:869)\n      01-17 00:19:44.796: E/SurfaceHolder(9731):  at android.view.ViewGroup.dispatchTouchEvent(ViewGroup.java:869)\n      01-17 00:19:44.796: E/SurfaceHolder(9731):  at com.android.internal.policy.impl.PhoneWindow$DecorView.superDispatchTouchEvent(PhoneWindow.java:1737)\n      01-17 00:19:44.796: E/SurfaceHolder(9731):  at com.android.internal.policy.impl.PhoneWindow.superDispatchTouchEvent(PhoneWindow.java:1153)\n      01-17 00:19:44.796: E/SurfaceHolder(9731):  at android.app.Activity.dispatchTouchEvent(Activity.java:2096)\n      01-17 00:19:44.796: E/SurfaceHolder(9731):  at com.android.internal.policy.impl.PhoneWindow$DecorView.dispatchTouchEvent(PhoneWindow.java:1721)\n      01-17 00:19:44.796: E/SurfaceHolder(9731):  at android.view.ViewRoot.deliverPointerEvent(ViewRoot.java:2200)\n      01-17 00:19:44.796: E/SurfaceHolder(9731):  at android.view.ViewRoot.handleMessage(ViewRoot.java:1884)\n      01-17 00:19:44.796: E/SurfaceHolder(9731):  at android.os.Handler.dispatchMessage(Handler.java:99)\n      01-17 00:19:44.796: E/SurfaceHolder(9731):  at android.os.Looper.loop(Looper.java:130)\n      01-17 00:19:44.796: E/SurfaceHolder(9731):  at android.app.ActivityThread.main(ActivityThread.java:3835)\n      01-17 00:19:44.796: E/SurfaceHolder(9731):  at java.lang.reflect.Method.invokeNative(Native Method)\n      01-17 00:19:44.796: E/SurfaceHolder(9731):  at java.lang.reflect.Method.invoke(Method.java:507)\n      01-17 00:19:44.796: E/SurfaceHolder(9731):  at com.android.internal.os.ZygoteInit$MethodAndArgsCaller.run(ZygoteInit.java:847)\n      01-17 00:19:44.796: E/SurfaceHolder(9731):  at com.android.internal.os.ZygoteInit.main(ZygoteInit.java:605)\n      01-17 00:19:44.796: E/SurfaceHolder(9731):  at dalvik.system.NativeStart.main(Native Method))\n\n问题分析：\n\nCanvas在操作之前需要加锁（lockCanvas函数），操作结束后，应该立即释放锁资源（unlockCanvasAndPost函数），这个问题的出现就是因为lockCanvas()之后没有释放锁资源，正确的流程是：\n\nA.调用 mSurfaceHolder.lockCanvas(); 获取Canvas对象。\n\nB.调用Canvas方法进行绘图：canvas.drawXXX(arg, arg, arg, arg);\n\nC.绘图完成之后，调用 mSurfaceHolder.unlockCanvasAndPost(c); 释放锁资源。\n\n\n代码示例：\n\n      public boolean draw(View arg0, MotionEvent arg1) {\n              Canvas c = mSurfaceHolder.lockCanvas();\n              // Draw something\n          c.drawCircle(args,…,arg);\n              mSurfaceHolder.unlockCanvasAndPost(c);\n              return true;\n      }\n\n参考文章：\n\n1.https://developer.android.com/reference/java/lang/IllegalArgumentException.html \n\n2.http://stackoverflow.com/questions/20554621/after-a-while-of-usage-my-app-freezes-during-scrolling-a-webview-saying-could\n\n3.http://stackoverflow.com/questions/8875702/android-canvas-locking-throws-illegalargumentexception\nhttp://androidxref.com/4.4_r1/xref/external/apache-http/src/org/apache/http/params/HttpProtocolParams.java#148',0,'java.lang.IllegalArgumentException'),(22,'2016-11-29 15:00:08','2016-11-29 15:00:08','CRASH','java.lang.IllegalStateException','当一个方法在不合法或不恰当的时间被调用时抛出。建议根据状态图检查对象当前状态，更改错误的调用方法时机。','问题分析：\n\n当一个方法在不合法或不恰当的时间被调用时抛出。\n\n解决方案：\n\n当一个方法在不合法或不恰当的时间被调用时抛出。建议根据状态图检查对象当前状态，更改错误的调用方法时机。\n\n\n示例一：\n\n        java.lang.IllegalStateException\n          at io.er.yune.MediaPlayer._reset(Native Method)\n          at io.er.yune.MediaPlayer.reset(MediaPlayer.java:734)\n          at io.er.yune.widget.VideoView.release(VideoView.java:502)\n          at io.er.yune.widget.VideoView.access$1500(VideoView.java:69)\n          at io.er.yune.widget.VideoView$3.surfaceDestroyed(VideoView.java:164)\n          at android.view.SurfaceView.updateWindow(SurfaceView.java:594)\n          at android.view.SurfaceView.onWindowVisibilityChanged(SurfaceView.java:239)\n          at android.view.View.dispatchWindowVisibilityChanged(View.java:8170)\n          at android.view.ViewGroup.dispatchWindowVisibilityChanged(ViewGroup.java:1113)\n          at android.view.ViewGroup.dispatchWindowVisibilityChanged(ViewGroup.java:1113)\n          at android.view.ViewGroup.dispatchWindowVisibilityChanged(ViewGroup.java:1113)\n          at android.view.ViewGroup.dispatchWindowVisibilityChanged(ViewGroup.java:1113)\n\n问题分析：\n\n这种异常是由于MediaPlayer的生命周期使用不正确，比如没有调用prepare等方法就先调用isPlaying等方法时，或非合法状态调用prepareAsyn，setDataSource方法时会抛出这种异常。\n\n解决方案：\n由于MediaPlayer的生命周期使用不正确导致抛出的异常，建议阅读MediaPlayer的状态图，确认不同状态调用正确的函数。\n\n\n代码示例：\n\n步骤一：初始化操作\n\n// 方案一：通过将音频文件添加到资源结构中的res/raw文件夹中。\n\n      MediaPlayer player = MediaPlayer.create(getApplicationContext(), R.raw.music);\n\n// 方案二：以file://开头的本地文件URI\n\n      MediaPlayer player = MediaPlayer.create(getApplicationContext(), Uri.parse(“file:///sdcard/music/1.mp3”));\n\n// 方案三：setDataSource方法\n\n      MediaPlayer player = new MediaPlayer();\n      player.setDataSource(“/sdcard/test.3gp”);\n      player.prepare();\n\n步骤二：播放控制\n\n关键状态及函数说明：\n\n准备好MediaPlayer后，想要开始播放，必须调用start()方法。当此方法成功返回时，MediaPlayer的对象处于Started状态。\n\n  isPlaying()方法可以被调用来测试某个MediaPlayer对象是否在Started状态。而对一个已经处于Started 状态的MediaPlayer对象调用start()方法没有影响。\n\n  start()方法调用之后调用pause()方法并返回时, 播放可以被暂停会使MediaPlayer对象进入Paused状态。调用start()方法会让一个处于Paused状态的MediaPlayer对象从之前暂停的地方恢复播放。当调用start()方法返回的时候，MediaPlayer对象的状态会又变成Started状态。在Started与Paused状态的相互转换在内部的播放引擎中是异步的。所以可能需要一点时间在isPlaying()方法中更新状态，若在播放流内容，这段时间可能会有几秒钟。\n\n  调用stop()方法会停止播放，并且还会让一个处于Started，Paused，Prepared或PlaybackCompleted状态的MediaPlayer进入Stopped状态。\n\n  调用seekTo()方法可以调整播放的位置。seekTo(int)方法是异步执行的，所以它可以马上返回，但是实际的定位播放操作可能需要一段时间才能完成，尤其是播放流形式的音频/视频。当实际的定位播放操作完成之后，内部的播放引擎会调用客户端程序员提供的OnSeekComplete.onSeekComplete()回调方法。可以通过setOnSeekCompleteListener(OnSeekCompleteListener)方法注册。seekTo(int)方法也可以在其它状态下调用，比如Prepared，Paused和PlaybackCompleted状态。\n\n播放位置可以调用getCurrentPosition()方法得到，它可以帮助如音乐播放器的应用程序不断更新播放进度。\n\n        private void startPlay() {\n            player.start();\n        }\n        private void stopPlay() {\n            payer.stop();\n        }\n        private void pausePlay() {\n            player.pause();\n        }\n        private void goTo(int pos) {\n           player.seekTo(pos);\n        }\n\n步骤三：释放播放资源\n\n当播放到流的末尾，播放就完成了。如果调用了setLooping(boolean)方法开启了循环模式，那么这个MediaPlayer对象会重新进入Started状态。\n \n  在播放结束时，应调用MediaPlayer的release()方法，释放播放程序所占用的资源。\n\n        private void release() {\n          if(player != null) {\n             player.stop();\n             player.release();\n             player = null;\n          }\n        }\n\n参考文献：\n\n1.https://developer.android.com/reference/android/media/MediaPlayer.html#StateDiagram （MediaPlayer状态图）\n\n2.https://developer.android.com/reference/android/media/MediaPlayer.html （MediaPlayer官方文档）\n\n3.http://www.devdiv.com/Android-MediaPlayer%E7%9A%84%E4%BD%BF%E7%94%A8-thread-130166-1-1.html\n\n4.http://blog.csdn.net/yearafteryear/article/details/8966221',0,'java.lang.IllegalStateException'),(23,'2016-11-29 15:03:05','2016-11-29 15:03:05','CRASH','java.io.EOFException','因为不知道流的末尾，当到达末尾的时候，抛出了此异常。这种异常主要被数据输入流用来表明到达流的末尾，建议捕获异常并退出读取输入流。','问题分析：\n\n当输入过程中意外到达文件或流的末尾时，抛出此异常。此异常主要被数据输入流用来表明到达流的末尾。\n\n解决方案：\n\n因为不知道流的末尾，当到达末尾的时候，抛出了此异常。这种异常主要被数据输入流用来表明到达流的末尾，建议捕获异常并退出读取输入流。\n\n\n示例：\n\n      java.io.EOFException\n        at libcore.io.Streams.readAsciiLine(Streams.java:203)\n        at libcore.net.http.HttpEngine.readResponseHeaders(HttpEngine.java:579)\n        at libcore.net.http.HttpEngine.readResponse(HttpEngine.java:827)\n        at libcore.net.http.HttpURLConnectionImpl.getResponse(HttpURLConnectionImpl.java:283)\n        at libcore.net.http.HttpURLConnectionImpl.getInputStream(HttpURLConnectionImpl.java:177)\n\n\n代码示例：\n\n      public static void main(String[] args) {\n          DataInputStream input = null;\n          try {\n            //do something\n            \n            // Read all characters, until an EOFException is thrown.\n            input = new DataInputStream(new FileInputStream(FILENAME));\n            while(true) {\n              char num;\n              try {\n                num = input.readChar();\n                System.out.println(\"Reading from file: \" + num);\n              }\n              catch (EOFException ex1) {\n                break; //EOF reached.\n              }\n              catch (IOException ex2) {\n                System.err.println(\"An IOException was caught: \" + ex2.getMessage());\n                ex2.printStackTrace();\n              }\n            }\n          }\n          catch (IOException ex) {\n            System.err.println(\"An IOException was caught: \" + ex.getMessage());\n            ex.printStackTrace();\n          }\n          finally {\n            try {\n              // Close the input stream.\n              input.close();\n            }\n            catch(IOException ex) {\n              System.err.println(\"An IOException was caught: \" + ex.getMessage());\n              ex.printStackTrace();\n            }\n          }\n        }\n\n参考文献：\n\n1. https://docs.oracle.com/javase/7/docs/api/java/io/EOFException.html \n\n2. https://examples.javacodegeeks.com/java-basics/exceptions/java-io-eofexception-how-to-solve-eofexception/',0,'java.io.EOFException'),(24,'2016-11-29 15:04:47','2016-11-29 15:04:47','CRASH','android.content.res.Resources.NotFoundException','在编译器编译程序时可以找到的资源，但在运行时却找不到时会抛出此类异常。建议clean project， 删除R文件重新build，并检查引用的资源是否正确。','问题分析：\n\n当请求资源却无法找到资源时会抛出此类问题。一般是因为编译器编译程序时可以找到的资源，但在运行时却找不到时会抛出此类异常。\n\n解决方案：\n\n在编译器编译程序时可以找到的资源，但在运行时却找不到时会抛出此类异常。建议clean project， 删除R文件重新build，并检查引用的资源是否正确。\n\n参考文献：\n\n1.https://developer.android.com/reference/android/content/res/Resources.NotFoundException.html \n\n2.http://stackoverflow.com/questions/9161435/getting-android-content-res-resourcesnotfoundexception-exception-even-when-the',0,'android.content.res.Resources.NotFoundException'),(25,'2016-11-29 15:05:59','2016-11-29 15:05:59','CRASH','android.content.res.Resources$NotFoundException','在编译器编译程序时可以找到的资源，但在运行时却找不到时会抛出此类异常。建议clean project， 删除R文件重新build，并检查引用的资源是否正确。','问题分析：\n\n当请求资源却无法找到资源时会抛出此类问题。一般是因为编译器编译程序时可以找到的资源，但在运行时却找不到时会抛出此类异常。\n\n解决方案：\n\n在编译器编译程序时可以找到的资源，但在运行时却找不到时会抛出此类异常。建议clean project， 删除R文件重新build，并检查引用的资源是否正确。\n\n参考文献：\n\n1.https://developer.android.com/reference/android/content/res/Resources.NotFoundException.html \n\n2.http://stackoverflow.com/questions/9161435/getting-android-content-res-resourcesnotfoundexception-exception-even-when-the',0,'android.content.res.Resources.NotFoundException'),(26,'2016-11-29 15:08:45','2016-11-29 15:08:45','CRASH','android.content.ActivityNotFoundException','无法找到对应的Activity时抛出此类异常，一般发生在AndroidManifest.xml文件没有配置需要的Activity路径所导致的或手机中确实无此应用，建议检查AndroidManifest文件Activity路径并在启动Activity处捕获异常。','问题分析：\n\n无法找到对应的Activity时抛出此类异常。\n\n解决方案：\n\n无法找到对应的Activity时抛出此类异常，一般发生在AndroidManifest.xml文件没有配置需要的Activity路径所导致的或手机中确实无此应用，建议检查AndroidManifest文件Activity路径并在启动Activity处捕获异常。\n\n\n代码示例：\n\nandroid.content.ActivityNotFoundException: Unable to find explicit activity class {*}; have you declared this activity in your AndroidManifest.xml?\n\n方案1. 确认AndroidManifest.xml中所需Activity路径正确\n\n        <activity\n            android:name=\"com.your.package.name.YourActivity\"\n            android:label=\"@string/app_name\">\n            <intent-filter>\n                <action android:name=\"android.intent.action.MAIN\" />\n                <category android:name=\"android.intent.category.LAUNCHER\" />\n            </intent-filter>\n        </activity>\n\n方案2. 针对可能不存在的Activity抛出的异常进行捕获\n\n    public static void startDialer(Context context, String phoneNumber) {\n        try {\n            Intent dial = new Intent();\n            dial.setAction(Intent.ACTION_DIAL);\n            dial.setData(Uri.parse(\"tel:\" + phoneNumber));\n            context.startActivity(dial);\n        } catch (ActivityNotFoundException ex) {\n            Log.e(TAG, \"Error starting phone dialer intent.\", ex);\n            Toast.makeText(context, \"Sorry, we couldn\'t find any app to place a phone call!\",\n                    Toast.LENGTH_SHORT).show();\n        }\n    }\n\n\n参考文献：\n\n1.https://developer.android.com/reference/android/content/ActivityNotFoundException.html \n\n2.http://stackoverflow.com/questions/15825081/error-default-activity-not-found \n\n3.http://www.cnblogs.com/Cjch/archive/2013/05/28/3104561.html \n\n4.https://developer.android.com/guide/topics/manifest/manifest-intro.html （应用清单文件）\n\n5.https://developer.android.com/guide/topics/manifest/activity-element.html （activity语法）',0,'android.content.ActivityNotFoundException'),(27,'2016-11-29 15:10:44','2016-11-29 16:06:38','CRASH','android.content.pm.PackageManager$NameNotFoundException','找不定给定的包名、应用或者组件名时抛出此类异常。需要检查依赖的包名、应用或者组件。','问题分析：\n\n找不定给定的包名、应用或者组件名时抛出此类异常。\n\n解决方案：\n\n找不定给定的包名、应用或者组件名时抛出此类异常。需要检查依赖的包名、应用或者组件。\n\n代码示例：\n\n        public static void startEmailIntent(Context context, String emailAddress) {\n           try {\n                Resources res = context.getPackageManager().\n                getResourcesForApplication(\"com.android.launcher\");\n                res.getDisplayMetrics();\n           } catch (NameNotFoundException e) {\n                    e.printStackTrace();\n           }\n        }\n\n参考文献：\n\n1.https://developer.android.com/reference/android/content/pm/PackageManager.NameNotFoundException.html \n\n2.http://androidxref.com/4.4_r1/xref/frameworks/base/core/java/android/app/ContextImpl.java#1879',0,'android.content.pm.PackageManager.NameNotFoundException'),(28,'2016-11-29 15:12:17','2016-11-29 15:12:17','CRASH','java.io.IOException','引起IO异常的原因很多，如相关文件不存在、无权限读写、编码错误、文件读到末尾、io中断、JSON、URL等格式不正确等。建议捕获IO异常并做相应的业务处理。','问题分析：\n\nIO发生异常时抛出，引起的原因很多，如相关文件不存在、无权限读写、编码错误、文件读到末尾、io中断、JSON、URL等格式不正确等。\n\n解决方案：\n\n引起IO异常的原因很多，如相关文件不存在、无权限读写、编码错误、文件读到末尾、io中断、JSON、URL等格式不正确等。建议捕获IO异常并做相应的业务处理。\n\n代码示例：\n\n1. 示例一：\n\njava.io.IOException: open failed: EACCES (Permission denied)\n\n确认文件路径，增加读写外部存储上的文件权限：\n\n    <uses-permission android:name=\"android.permission.READ_EXTERNAL_STORAGE\"></uses-permission>\n    <uses-permission android:name=\"android.permission.WRITE_EXTERNAL_STORAGE\"></uses-permission>\n\n2. 示例二：\n\njava.io.IOException: open failed: ENOENT (No such file or directory)\n\n增加try catch块做异常处理。\n\n    public void readFile(String filePath) {\n        BufferedReader br = null;\n        try {\n            String sCurrentLine;\n            br = new BufferedReader(new FileReader(filePath));\n            while ((sCurrentLine = br.readLine()) != null) {\n                System.out.println(sCurrentLine);\n            }\n        } catch (IOException e) {\n            e.printStackTrace();\n        } finally {\n            try {\n                if (br != null)\n                    br.close();\n            } catch (IOException ex) {\n                ex.printStackTrace();\n            }\n        }\n    }\n\n参考文献：\n\n1.https://developer.android.com/training/permissions/index.html （权限使用文档）\n\n2.https://developer.android.com/reference/android/Manifest.permission.html （权限分类文档）\n\n3.https://www.mkyong.com/java/how-to-read-file-from-java-bufferedreader-example/ \n\n4.https://developer.android.com/reference/java/io/IOException.html \n\n5.https://developer.android.com/guide/topics/security/permissions.html#normal-dangerous （普通权限及危险权限）\n\n6.https://developer.android.com/training/permissions/requesting.html#perm-check （权限授权方式）',0,'java.io.IOException'),(29,'2016-11-29 15:14:11','2016-11-29 15:14:11','CRASH','android.os.TransactionTooLargeException','Binder的参数或返回值太大导致调用失败，并抛出TransactionTooLargeException，建议不要将大量数据传入Binder，避免传入大数组、大量字符串或位图。','问题分析：\n\nBinder传输的数据存在Parcel类中，如果Binder的参数或返回值太大（超过1MB），不适合的事务缓冲区，调用会失败，并抛出TransactionTooLargeException。\n\n解决方案：\n\nBinder的参数或返回值太大导致调用失败，并抛出TransactionTooLargeException，建议不要将大量数据传入Binder，避免传入大数组、大量字符串或位图。\n\n代码示例：\n\n    android.os.TransactionTooLargeException\n        at android.os.BinderProxy.transact(Native Method)\n        at com.android.internal.view.IInputMethodManager$Stub$Proxy.startInput(IInputMethodManager.java:604)\n        at android.view.inputmethod.InputMethodManager.startInputInner(InputMethodManager.java:1173)\n        at android.view.inputmethod.InputMethodManager.checkFocus(InputMethodManager.java:1282)\n        at android.view.ViewRootImpl$ViewRootHandler.handleMessage(ViewRootImpl.java:3201)\n        at android.os.Handler.dispatchMessage(Handler.java:102)\n        at android.os.Looper.loop(Looper.java:136)\n        at android.app.ActivityThread.main(ActivityThread.java:5017)\n        at java.lang.reflect.Method.invokeNative(Native Method)\n        at java.lang.reflect.Method.invoke(Method.java:515)\n        at com.android.internal.os.ZygoteInit$MethodAndArgsCaller.run(ZygoteInit.java:779)\n        at com.android.internal.os.ZygoteInit.main(ZygoteInit.java:595)\n        at dalvik.system.NativeStart.main(Native Method)\n\n\n    public class MainActivity extends Activity {\n        private IDictionaryManager mDictionaryManager;\n        @Override\n        protected void onCreate(Bundle savedInstanceState) {\n            super.onCreate(savedInstanceState);\n            setContentView(R.layout.activity_main);\n            Intent intent = new Intent();\n            intent.setAction(\"android.intent.action.DictionaryManagerService\");\n            intent.setPackage(\"com.wanginbeijing.dictionaryserver\");\n            bindService(intent, mConnection, Context.BIND_AUTO_CREATE);\n            //添加一个新单词\n            findViewById(R.id.btn_add).setOnClickListener(new View.OnClickListener() {\n                @Override\n                public void onClick(View view) {\n                    try {\n                        mDictionaryManager.add(\"你好\", \"Hello\");\n                    } catch (RemoteException e) {\n                        e.printStackTrace();\n                    }\n                }\n            });\n            //查询单词\n            findViewById(R.id.btn_query).setOnClickListener(new View.OnClickListener() {\n                @Override\n                public void onClick(View view) {\n                    try {\n                        String english = mDictionaryManager.query(\"你好\");\n                        Toast.makeText(MainActivity.this,english, Toast.LENGTH_SHORT).show();\n                    } catch (RemoteException e) {\n                        e.printStackTrace();\n                    }\n                }\n            });\n        }\n        private ServiceConnection mConnection = new ServiceConnection() {\n            @Override\n            public void onServiceConnected(ComponentName componentName, IBinder iBinder) {\n                IDictionaryManager dictionaryManager = IDictionaryManager.Stub.asInterface(iBinder);\n                try {\n                    mDictionaryManager = dictionaryManager;\n                    Toast.makeText(MainActivity.this, \"connect success\", Toast.LENGTH_SHORT).show();\n                } catch (Exception e) {\n                    Toast.makeText(MainActivity.this, \"connect failed\", Toast.LENGTH_SHORT).show();\n                    e.printStackTrace();\n                }\n            }\n            @Override\n            public void onServiceDisconnected(ComponentName name) {\n            }\n        };\n    }\n\n参考文献：\n\n1.https://developer.android.com/reference/android/os/TransactionTooLargeException.html \n\n2.http://stackoverflow.com/questions/11451393/what-to-do-on-transactiontoolargeexception \n\n3.https://halfstackdeveloper.github.io/2016/09/10/Android-Binder%E8%A7%A3%E5%AF%86/',0,'android.os.TransactionTooLargeException'),(30,'2016-11-29 15:16:26','2016-11-29 15:16:26','CRASH','java.lang.NullPointerException','对可以预见为空的对象进行处理，对不可预知的对象判断是否是null，然后再访问内部成员变量或执行成员函数。','问题分析：\n\n试图对一个为null的对象执行成员函数、试图获取null对象的成员变量、试图获取null数组的长度、试图访问数组中某个空对象、抛出一个对象而实际未初始化为null时，此时会抛出NullPointerException异常。\n\n解决方案：\n对可以预见为空的对象进行处理，对不可预知的对象判断是否是null，然后再访问内部成员变量或执行成员函数。\n\n代码示例：\n\n1. 示例1：\n\n        Exception in thread \"main\" java.lang.NullPointerException\n\n解决方案：判断对象是否为null，不是null再执行对象成员函数。\n\n    public String[] split(String content){\n        if(content!=null){\n            String[] result=content.split(\"\\\\s+\");\n            return result;\n        }\n        return null;\n    }\n\n2. 示例2：\n\n       java.lang.NullPointerException\n        at android.webkit.WebViewClassic$WebViewInputConnection.setNewText(WebViewClassic.java:587)\n        at android.webkit.WebViewClassic$WebViewInputConnection.setComposingText(WebViewClassic.java:327)\n        at android.webkit.WebViewClassic$WebViewInputConnection.commitText(WebViewClassic.java:343)\n        at com.android.internal.view.IInputConnectionWrapper.executeMessage(IInputConnectionWrapper.java:279)\n        at com.android.internal.view.IInputConnectionWrapper$MyHandler.handleMessage(IInputConnectionWrapper.java:77)\n        at android.os.Handler.dispatchMessage(Handler.java:107)\n        at android.os.Looper.loop(Looper.java:194)\n        at android.app.ActivityThread.main(ActivityThread.java:5391)\n        at java.lang.reflect.Method.invokeNative(Native Method)\n        at java.lang.reflect.Method.invoke(Method.java:525)\n        at com.android.internal.os.ZygoteInit$MethodAndArgsCaller.run(ZygoteInit.java:833)\n        at com.android.internal.os.ZygoteInit.main(ZygoteInit.java:600)\n        at dalvik.system.NativeStart.main(Native Method)\n\n在使用Google Play Services的google-play-services.jar时报错，建议设置全局Exception Handler。\n\n    public class MyApplication extends Application {\n        @Override\n        public void onCreate() {\n            super.onCreate();\n            Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {\n                @Override\n                public void uncaughtException(Thread thread, final Throwable ex) {\n                    // Custom code here to handle the error.\n                }\n            });\n        }\n    }\n\n\n参考文献：\n\n1. https://docs.oracle.com/javase/7/docs/api/java/lang/NullPointerException.html \n\n2. http://stackoverflow.com/questions/21866459/android-nullpointerexception-on-webview \n\n3. https://groups.google.com/forum/#!topic/google-admob-ads-sdk/QvUhH5ZGIHQ \n\n4. http://stackoverflow.com/questions/18824076/how-to-catch-this-exception-in-android-webview',0,'java.lang.NullPointerException'),(31,'2016-11-29 15:17:47','2016-11-29 15:17:47','CRASH','java.lang.NoSuchMethodException','找不到特定的函数时抛出此类异常，请注意打包的类库版本信息，一般发生在反射调用时被抛出。请查看日志中此crash附近日志信息，并检查日志报错对应的代码是否写错函数名。','问题分析：\n\n找不到特定的函数时抛出此类异常，因为编译时依赖的库版本有这个函数的，但是运行时却没有找到，这个异常通常发生在反射调用时被抛出。\n\n解决方案：\n\n找不到特定的函数时抛出此类异常，请注意打包的类库版本信息，一般发生在反射调用时被抛出。请查看日志中此crash附近日志信息，并检查日志报错对应的代码是否写错函数名。\n\n代码示例：\n\n        package com.alibaba.mqc.test;\n\n        import java.lang.reflect.InvocationTargetException;\n        import java.lang.reflect.Method;\n         \n        //简单的反射demo\n        public class V {\n            public void printf(){\n                System.out.println(\"printf\");\n            }\n            public static void main(String[] args) throws ClassNotFoundException, SecurityException, NoSuchMethodException, IllegalArgumentException, IllegalAccessException, InvocationTargetException, InstantiationException {\n                Class c = Class.forName(\"com.alibaba.mqc.test.V\");\n                Method m = c.getDeclaredMethod(\"printf\",null);\n                m.invoke(c.newInstance(),null);\n            }\n        }\n\n参考文献：\n\n1.https://docs.oracle.com/javase/7/docs/api/java/lang/NoSuchMethodException.html \n\n2.http://stackoverflow.com/questions/19913970/java-java-lang-nosuchmethodexception',0,'java.lang.NoSuchMethodException'),(32,'2016-11-29 15:19:31','2016-11-29 15:19:31','CRASH','java.lang.ClassNotFoundException','通过Class.forName(java.lang.String)等方式试图通过String找到类而未找到的报错，这种错误只能在运行期抛出，请确认类路径正确并已正确引用。','问题分析：\n\nClassNotFoundException是通过Class.forName(java.lang.String)等方式试图通过String找到类而未找到的报错，这种错误只能在运行期抛出。\n\n解决方案：\n\n通过Class.forName(java.lang.String)等方式试图通过String找到类而未找到的报错，这种错误只能在运行期抛出，请确认类路径正确并已正确引用。\n\n\n代码示例：\n\n        package com.alibaba.mqc.test;\n\n        import java.lang.reflect.InvocationTargetException;\n        import java.lang.reflect.Method;\n         \n        //简单的反射demo\n        public class V {\n            public void printf(){\n                System.out.println(\"printf\");\n            }\n            public static void main(String[] args) throws ClassNotFoundException, SecurityException, NoSuchMethodException, IllegalArgumentException, IllegalAccessException, InvocationTargetException, InstantiationException {\n                Class c = Class.forName(\"com.alibaba.mqc.test.V\");\n                Method m = c.getDeclaredMethod(\"printf\",null);\n                m.invoke(c.newInstance(),null);\n            }\n        }\n\n参考文献：\n\n1. https://docs.oracle.com/javase/7/docs/api/java/lang/ClassNotFoundException.html \n\n2. http://www.cnblogs.com/xing901022/p/4185514.html',0,'java.lang.ClassNotFoundException'),(33,'2016-11-29 15:22:12','2016-11-29 15:22:12','CRASH','java.lang.NoClassDefFoundError','NoClassDefFoundError是编译通过，运行时本来预期是找得到类文件的但是因为打包等问题虚拟机无法定位需要加载的类因此在运行期报错。类依赖的class或者jar不存在请确认打包方式正确。若类文件存在，但是存在不同的域中，此时含有包名的类在编译时需要指定classpath的路径，并且使用的时候指定包名全路径即可。','问题分析： \n\n应用编译通过但是在运行时本来预期是找得到类文件的但是因为打包等问题无法定位需要加载的类因此在运行期报错。\n\n解决方案：\n\nNoClassDefFoundError是编译通过，运行时本来预期是找得到类文件的但是因为打包等问题虚拟机无法定位需要加载的类因此在运行期报错。类依赖的class或者jar不存在请确认打包方式正确。若类文件存在，但是存在不同的域中，此时含有包名的类在编译时需要指定classpath的路径，并且使用的时候指定包名全路径即可。\n\n参考文献：\n\n1.https://docs.oracle.com/javase/7/docs/api/java/lang/NoClassDefFoundError.html \n\n2.http://blog.csdn.net/jamesjxin/article/details/46606307',0,'java.lang.NoClassDefFoundError'),(34,'2016-11-29 15:32:47','2016-11-29 15:32:47','LAUNCH','NoClassDefFoundError','应用编译通过但是在运行时本来预期是找得到类文件的但是因为打包等问题无法定位需要加载的类因此在运行期报错。如果使用的是Eclipse ADT 17，在Java Build Path里删除除了Android X.X.X及Android Dependency以为所有的依赖，重命名lib文件夹为libs文件夹，然后clean安卓项目。','问题分析：\n\n应用编译通过但是在运行时本来预期是找得到类文件的但是因为打包等问题无法定位需要加载的类因此在运行期报错。\n\n解决方案：\n\n如果使用的是Eclipse ADT 17，在Java Build Path里删除除了Android X.X.X及Android Dependency以为所有的依赖，重命名lib文件夹为libs文件夹，然后clean安卓项目。\n\n参考文献：\n\n1. http://android.foxykeep.com/dev/how-to-fix-the-classdefnotfounderror-with-adt-17 \n\n2. http://stackoverflow.com/questions/9870995/android-java-lang-noclassdeffounderror',0,'NoClassDefFoundError'),(35,'2016-11-29 15:42:32','2016-11-29 15:42:32','CRASH','java.lang.UnsatisfiedLinkError','JVM找不到对应的native方法抛出此类异常，请检查.so文件是否存在、位置是否正确以及是否加载成功。通常是因为应用运行于不同的手机之上，cpu架构不同，因此需要编译生成支持不同cpu架构的静态库so文件。','问题分析：\n\nJVM找不到对应的native方法抛出此类异常。\n\n解决方案：\n\nJVM找不到对应的native方法抛出此类异常，请检查.so文件是否存在、位置是否正确以及是否加载成功。通常是因为应用运行于不同的手机之上，cpu架构不同，因此需要编译生成支持不同cpu架构的静态库so文件。\n\n      java.lang.UnsatisfiedLinkError: Native method not found: com.baidu.android.moplus.systemmonitor.security.md5.MD5.Transform_native:([I[BII)V\n        at com.c.h.systemmonitor.security.md5.MD5.Transform_native(Native Method)\n        at com.c.h.systemmonitor.security.md5.MD5.update(Unknown Source)\n        at com.c.h.systemmonitor.security.md5.MD5.update(Unknown Source)\n        at com.c.h.systemmonitor.security.md5.MD5InputStream.read(Unknown Source)\n        at java.io.InputStream.read(InputStream.java:163)\n\n代码示例：\n\n步骤一：编写 Application.mk 文件\n\n在 jni 目录下（即hello-jni.c同级目录下）新建一个Application.mk文件，在文件中添加如下代码：\n\n      APP_ABI := armeabi armeabi-v7a x86\n\n这段话表示你可以同时生成三个处理器的so库。如果没有或不想使用Application.mk文件,则在ndk-build参数中添加\n\n      APP_ABI=\"armeabi armeabi-v7a x86 mips\"\n\n即运行：\n\n      ndk-build APP_ABI=\"armeabi armeabi-v7a x86 mips\"\n\n步骤二： 生成.so共享库文件\n\nAndroid.mk文件已经编写好了，现在可以用 android NDK 开发包中的 ndk-build 脚本生成对应的.so共享库了，方法如下：\n\n      mqc@ubuntu:~/workspace/android/NDK/hello-jni$ ls \n      AndroidManifest.xml  assets  bin  default.properties  gen  jni  libs  obj  res  src \n      mqc@ubuntu:~/workspace/android/NDK/hello-jni$ ndk-build \n      Gdbserver      : [arm-linux-androideabi-4.4.3] libs/armeabi/gdbserver \n      Gdbsetup       : libs/armeabi/gdb.setup \n      Install        : libhello-jni.so => libs/armeabi/libhello-jni.so \n\n这样，在文件夹hello-jni/libs下生成了三个文件夹armeabi armeabi-v7a 以及x86，里面已经正确的生成了libhello-jni.so共享库了。\n\n步骤三：在 eclipse 重新编译 HelloJni 工程，生成 apk\n\neclipse 中刷新下 HelloJni 工程，重新编译生成 apk，libhello-jni.so 共享库会一起打包在 apk 文件内。\n\n\n\n\n附录\n\nNDK程序开发详解：\n\n步骤一：\n\n搭建开发环境：\n\n1.android 的 NDK 开发需要在 linux 下进行： 因为需要把 C/C++ 编写的代码生成能在 arm 上运行的.so文件，这就需要用到交叉编译环境，而交叉编译需要在 linux 系统下才能完成。\n\n2.安装 android-ndk 开发包，这个开发包可以在 google android 官网下载： 通过这个开发包的工具才能将android jni 的 C/C++ 的代码编译成库\n\n3.android 应用程序开发环境： 包括 eclipse、java、android sdk、adt 等。\n\n4.安装完成android-ndk之后，将 android-ndk 的路劲加到环境变量 PATH 中：\n\n      sudo gedit /etc/environment\n\n5.在 environment 的 PATH 环境变量中添加 android-ndk 的安装路径，然后再让这个更改的环境变量立即生效：\n      source  /etc/environment\n\n经过了上述步骤，在命令行下敲：\n\n      ndk-bulid\n\n弹出如下的错误，而不是说 ndk-build not found，就说明 ndk 环境已经安装成功了。\n\n    　Android NDK: Could not find application project directory !    \n    　Android NDK: Please define the NDK_PROJECT_PATH variable to point to it.    \n    　/home/mqc/workspace/android/android-ndk-r5/build/core/build-local.mk:85: *** Android NDK: Aborting    .  Stop.\n\n步骤二：\n\n编写 Java 代码\n\n建立一个 Android 应用工程 HelloJni，创建 HelloJni.java 文件。\n\n\n      import android.app.Activity;\n      import android.widget.TextView;\n      import android.os.Bundle;\n\n      public class HelloJni extends Activity\n      {\n          /** Called when the activity is first created. */\n          @Override\n          public void onCreate(Bundle savedInstanceState)\n          {\n              super.onCreate(savedInstanceState);\n              TextView  tv = new TextView(this);\n              tv.setText( stringFromJNI() );\n              setContentView(tv);\n          }\n          /* A native method that is implemented by the \'hello-jni\' native library, which is packaged with this application. */\n          public native String  stringFromJNI();\n          public native String  unimplementedStringFromJNI();\n          /* this is used to load the \'hello-jni\' library on application startup. The library has already been unpacked into\n            /data/data/com.example.HelloJni/lib/libhello-jni.so at installation time by the package manager. */\n          static {\n              System.loadLibrary(\"hello-jni\");\n          }\n      }\n\n上面展示的代码中的static代码块表明程序开始运行的时候会加载 hello-jni, static 区声明的代码会先于 onCreate 方法执行。如果你的程序中有多个类，而且如果 HelloJni 这个类不是你应用程序的入口，那么 hello-jni（完整的名字是 libhello-jni.so）这个库会在第一次使用 HelloJni 这个类的时候加载。\n\n      public native String stringFromJNI(); \n      public native String unimplementedStringFromJNI();\n\n上面展示的代码中可以看到这两个方法的声明中有 native 关键字， 这个关键字表示这两个方法是本地方法，也就是说这两个方法是通过本地代码（C/C++）实现的，在java代码中仅仅是声明。\n使用eclipse 编译该工程，生成相应的.class文件，因为生成.h文件需要用到相应的.class文件。\n\n\n步骤三：编写相应的 C/C++ 代码\n\n利用javah生成相应的.h文件，然后根据这个.h文件编写相应的 C/C++ 代码。\n\n1.生成相应.h文件：\n\n首先在终端下进入刚刚建立的 HelloJni 工程的目录：\n\n      mqc@ubuntu:~$ cd workspace/android/NDK/hello-jni/\n\nls 查看工程文件\n\n      mqc@ubuntu:~/workspace/android/NDK/hello-jni$ ls \n      AndroidManifest.xml  assets  bin  default.properties  gen  res  src\n\n可以看到目前仅仅有几个标准的 android 应用程序的文件（夹）。\n首先我们在工程目录下建立一个 jni 文件夹：\n\n      mqc@ubuntu:~/workspace/android/NDK/hello-jni$ mkdir jni\n      mqc@ubuntu:~/workspace/android/NDK/hello-jni$ ls\n      AndroidManifest.xml  assets  bin  default.properties  gen  jni  res  src\n\n\n下面就可以生成相应的.h文件了：\n\n      mqc@ubuntu:~/workspace/android/NDK/hello-jni$ javah -classpath bin -d jni com.example.hellojni.HelloJni \n\n-classpath bin：表示类的路劲\n\n-d jni: 表示生成的头文件存放的目录\n\ncom.example.hellojni.HelloJni 则是完整类名\n\n\n这一步的成功要建立在已经在 bin/com/example/hellojni/ 目录下生成了 HelloJni.class 的基础之上。现在可以看到 jni 目录下多了个.h文件：\n\n      mqc@ubuntu:~/workspace/android/NDK/hello-jni$ cd jni/ \n      mqc@ubuntu:~/workspace/android/NDK/hello-jni/jni$ ls \n      com_example_hellojni_HelloJni.h\n\n下面展示出 com_example_hellojni_HelloJni.h 的内容：\n\ncom_example_hellojni_HelloJni.h :\n\n      /* DO NOT EDIT THIS FILE - it is machine generated */\n      #include <jni.h>\n      /* Header for class com_example_hellojni_HelloJni */\n      #ifndef _Included_com_example_hellojni_HelloJni\n      #define _Included_com_example_hellojni_HelloJni\n      #ifdef __cplusplus\n\n      extern \"C\" {\n      #endif\n      /*\n\n       * Class:     com_example_hellojni_HelloJni\n\n       * Method:    stringFromJNI\n\n       * Signature: ()Ljava/lang/String;\n\n       */\n\n      JNIEXPORT jstring JNICALL Java_com_example_hellojni_HelloJni_stringFromJNI\n        (JNIEnv *, jobject);\n\n      /*\n\n       * Class:     com_example_hellojni_HelloJni\n\n       * Method:    unimplementedStringFromJNI\n\n       * Signature: ()Ljava/lang/String;\n\n       */\n\n      JNIEXPORT jstring JNICALL Java_com_example_hellojni_HelloJni_unimplementedStringFromJNI\n        (JNIEnv *, jobject);\n      #ifdef __cplusplus\n      }\n      #endif\n      #endif\n\n上面的源码中函数名是很有规律的，完全按照：java_pacakege_class_mathod 形式来命名，即：\n\nHello.java 中 stringFromJNI() 方法对应于 C/C++中的 Java_com_example_hellojni_HelloJni_stringFromJNI() 方法\n\nHelloJni.java 中的 unimplementedStringFromJNI() 方法对应于 C/C++中的 Java_com_example_hellojni_HelloJni_unimplementedStringFromJNI() 方法\n\n步骤四：编写相应的.c文件\n\nhello-jni.c :\n\n      #include <string.h>\n      #include <jni.h>\n\n      /* This is a trivial JNI example where we use a native method\n\n       * to return a new VM String. See the corresponding Java source\n\n       * file located at:\n\n       *   apps/samples/hello-jni/project/src/com/example/HelloJni/HelloJni.java\n\n       */\n\n      jstring Java_com_example_hellojni_HelloJni_stringFromJNI( JNIEnv* env, jobject thiz )\n      {\n          return (*env)->NewStringUTF(env, \"Hello from JNI !\");\n      }\n\nJava_com_example_hellojni_HelloJni_stringFromJNI() 函数只是简单的返回了一个内容为 \"Hello from JNI !\" 的 jstring 对象（对应于 Java 中的 String 对象）。\n\n步骤五：编译 hello-jni.c 生成相应的库\n\n1. 编写 Android.mk 文件\n\n在 jni 目录下（即hello-jni.c同级目录下）新建一个Android.mk文件，Android.mk文件是 Android 的 makefile 文件，内容如下：\n\n      # Copyright (C) 2009 The Android Open Source Project\n\n      #\n\n      # Licensed under the Apache License, Version 2.0 (the \"License\");\n\n      # you may not use this file except in compliance with the License.\n\n      # You may obtain a copy of the License at\n\n      #\n\n      #      http://www.apache.org/licenses/LICENSE-2.0\n\n      #\n\n      # Unless required by applicable law or agreed to in writing, software\n\n      # distributed under the License is distributed on an \"AS IS\" BASIS,\n\n      # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.\n\n      # See the License for the specific language governing permissions and\n\n      # limitations under the License.\n\n      #\n\n      LOCAL_PATH := $(call my-dir)\n\n      include $(CLEAR_VARS)\n\n      LOCAL_MODULE    := hello-jni\n\n      LOCAL_SRC_FILES := hello-jni.c\n\n      include $(BUILD_SHARED_LIBRARY)\n\n这个 Androd.mk 文件很短，下面我们来逐行解释下：\n\n      LOCAL_PATH := $(call my-dir)\n\n一个 Android.mk 文件首先必须定义好 LOCAL_PATH 变量。它用于在开发树中查找源文件。在这个例子中，宏函数’my-dir’, 由编译系统提供，用于返回当前路径（即包含 Android.mk file 文件的目录）。\n\n      include $( CLEAR_VARS)\n\nCLEAR_VARS 由编译系统提供，指定让 GNU MAKEFILE 为你清除许多 LOCAL_XXX 变量（例如 LOCAL_MODULE, LOCAL_SRC_FILES, LOCAL_STATIC_LIBRARIES, 等等...), 除 LOCAL_PATH 。这是必要的，因为所有的编译控制文件都在同一个 GNU MAKE 执行环境中，所有的变量都是全局的。\n\n      LOCAL_MODULE := hello-jni\n\n编译的目标对象，LOCAL_MODULE 变量必须定义，以标识你在Android.mk文件中描述的每个模块。名称必须是唯一的，而且不包含任何空格。\n\n注意：编译系统会自动产生合适的前缀和后缀，换句话说，一个被命名为hello-jni的共享库模块，将会生成libhello-jni.so文件。\n\n重要注意事项：如果你把库命名为libhello-jni，编译系统将不会添加任何的 lib 前缀，也会生成 libhello-jni.so，这是为了支持来源于 Android 平台的源代码的Android.mk文件。\n\n      LOCAL_SRC_FILES := hello-jni.c\n\nLOCAL_SRC_FILES 变量必须包含将要编译打包进模块中的 C 或 C++ 源代码文件。注意，你不用在这里列出头文件和包含文件，因为编译系统将会自动为你找出依赖型的文件；仅仅列出直接传递给编译器的源代码文件就好。\n\n      include $(BUILD_SHARED_LIBRARY)\n\nBUILD_SHARED_LIBRARY 表示编译生成共享库，是编译系统提供的变量，指向一个 GNU Makefile 脚本，负责收集自从上次调用include $(CLEAR_VARS)以来，定义在 LOCAL_XXX 变量中的所有信息，并且决定编译什么，如何正确地去做。还有 BUILD_STATIC_LIBRARY 变量表示生成静态库：lib$(LOCAL_MODULE).a， BUILD_EXECUTABLE 表示生成可执行文件。\n\n2. 编写 Application.mk 文件\n\n在 jni 目录下（即hello-jni.c同级目录下）新建一个Application.mk文件，在文件中添加如下代码：\n      \n      APP_ABI := armeabi armeabi-v7a x86\n\n这段话表示你可以同时生成三个处理器的so库。如果没有或不想使用Application.mk文件,则在ndk-build参数中添加\n      \n      APP_ABI=\"armeabi armeabi-v7a x86 mips\"\n\n即运行：\n\n      ndk-build APP_ABI=\"armeabi armeabi-v7a x86 mips\"\n\n3. 生成.so共享库文件\n\nAndroid.mk文件已经编写好了，现在可以用 android NDK 开发包中的 ndk-build 脚本生成对应的.so共享库了，方法如下：\n\n      mqc@ubuntu:~/workspace/android/NDK/hello-jni$ ls \n      AndroidManifest.xml  assets  bin  default.properties  gen  jni  libs  obj  res  src \n      mqc@ubuntu:~/workspace/android/NDK/hello-jni$ ndk-build \n      Gdbserver      : [arm-linux-androideabi-4.4.3] libs/armeabi/gdbserver \n      Gdbsetup       : libs/armeabi/gdb.setup \n      Install        : libhello-jni.so => libs/armeabi/libhello-jni.so \n\n可以看到已经正确的生成了libhello-jni.so共享库了。\n\n4. 在 eclipse 重新编译 HelloJni 工程，生成 apk\n\neclipse 中刷新下 HelloJni 工程，重新编译生成 apk，libhello-jni.so 共享库会一起打包在 apk 文件内。\n\n参考文献：\n\n1.https://developer.android.com/training/articles/perf-jni.html?hl=ja#faq_ULE\n\n2.https://www.ibm.com/developerworks/community/blogs/738b7897-cd38-4f24-9f05-48dd69116837/entry/debugging_java_lang_unsatisfiedlinkerror9?lang=en \n\n3.http://wiki.jikexueyuan.com/project/jni-ndk-developer-guide/ndk.html （NDK开发教程）\n\n4.http://www.cnblogs.com/mengshu-lbq/archive/2013/03/29/2988657.html \n\n5.https://my.oschina.net/lhjtianji/blog/188074',0,'java.lang.UnsatisfiedLinkError'),(36,'2016-11-29 15:44:13','2016-11-29 15:44:13','CRASH','java.lang.ClassCastException','在进行强制类型转换时，转换的对象不是转换的类型的实例而抛出此类异常。可以通过if(object instanceof 类型)的语句来判断object的类型是否可强制类型转换来进行。','问题分析：\n\n在进行强制类型转换时，转换的对象不是转换的类型的实例而抛出此类异常。\n\n解决方案：\n\n在进行强制类型转换时，转换的对象不是转换的类型的实例而抛出此类异常。可以通过if(object instanceof 类型)的语句来判断object的类型是否可强制类型转换来进行。\n\n代码示例\n\n       public Son getSon(Father reference){\n          if(reference instanceof Son){\n            Son son=(Son)reference;\n            return son;\n          }\n          return null;\n        }\n\n\n参考文献：\n\n1. https://docs.oracle.com/javase/7/docs/api/java/lang/ClassCastException.html',0,'java.lang.ClassCastException'),(37,'2016-11-29 15:47:52','2016-11-29 15:47:52','CRASH','java.net.MalformedURLException','在URL格式不正确时抛出此类异常，一般是协议不合法或者字符串无法被解析，建议捕获此类异常并做业务处理。','问题分析：\n\n在URL格式不正确时抛出此类异常，一般是协议不合法或者字符串无法被解析。\n\n解决方案：\n\n在URL格式不正确时抛出此类异常，一般是协议不合法或者字符串无法被解析，建议捕获此类异常并做业务处理。\n\n\n代码示例：\n\n      public void parse(String location){\n          try\n          {\n            projectUrl = new URL(location);\n          }\n          catch (MalformedURLException e)\n          {\n            e.printStackTrace();\n          } \n        }\n\n参考文献：\n\n1. https://docs.oracle.com/javase/7/docs/api/java/net/MalformedURLException.html',0,'java.net.MalformedURLException'),(38,'2016-11-29 15:50:26','2016-11-29 15:50:26','CRASH','java.lang.NumberFormatException','通过字符串转数值类型时因为字符串格式不正确无法转换抛出此类异常。建议检查转换的字符串并对代码进行捕获。','问题分析：\n\n通过字符串转数值类型时因为字符串格式不正确无法转换抛出此类异常。\n\n\n解决方案：\n\n\n通过字符串转数值类型时因为字符串格式不正确无法转换抛出此类异常。建议检查转换的字符串并对代码进行捕获。\n\n\n代码示例：\n\n        public static int parseInt(String s){\n          try {\n            return Integer.parseInt(s);\n          }\n          catch(NumberFormatException e){\n            e.printStackTrace();\n          }\n        }\n\n参考文献：\n\n1. http://docs.oracle.com/javase/7/docs/api/java/lang/NumberFormatException.html',0,'java.lang.NumberFormatException'),(39,'2016-11-29 15:52:30','2016-11-29 15:52:30','CRASH','java.lang.ArrayStoreException','当试图将类型不兼容类型的对象存入一个Object[]数组时将引发异常，建议根据堆栈信息修改存储对象类型。','问题分析：\n\n这是数组存储异常，当试图将类型不兼容类型的对象存入一个Object[]数组时将引发异常。\n\n解决方案：\n\n当试图将类型不兼容类型的对象存入一个Object[]数组时将引发异常，建议根据堆栈信息修改存储对象类型。\n\n代码示例：\n\n    class Father{}\n\n    class Son extends Father{}\n\n    ... ...\n\n    public void handleArrayStoreException(){\n          Father[] fathers=new Son[3];\n          // 此处会抛异常\n          try {\n            // 无法存父类对象，只能存子类对象\n          fathers[0]=new Father();\n        } catch (ArrayStoreException e) {\n          e.printStackTrace();\n        }\n          \n          // 正确的代码\n          Father father=new Father();\n          Son son=new Son();\n          if(son instanceof Son){\n              // 可以存进数组\n            fathers[1]=son;\n          }\n          if(father instanceof Son){\n                // 无法存进数组\n            fathers[2]=father;\n          }\n        }\n\n\n参考文献：\n\n1. https://docs.oracle.com/javase/7/docs/api/java/lang/ArrayStoreException.html',0,'java.lang.ArrayStoreException'),(40,'2016-11-29 15:58:17','2016-11-29 15:58:17','CRASH','java.lang.SecurityException','当违背安全原则，检测到安全错误时会抛出此类异常。具体原因需要看给出的相应的其他信息并获取相应权限。','问题分析：\n\n当违背安全原则，检测到安全错误时会抛出此类异常。\n\n解决方案：\n\n当违背安全原则，检测到安全错误时会抛出此类异常。具体原因需要看给出的相应的其他信息并获取相应权限。\n\n示例一：\n\n      Caused by: java.lang.SecurityException: Permission denied (missing INTERNET permission?)\n            at java.net.InetAddress.lookupHostByName(InetAddress.java:430)\n            at java.net.InetAddress.getAllByNameImpl(InetAddress.java:236)\n            at java.net.InetAddress.getAllByName(InetAddress.java:214)\n            at libcore.net.http.HttpConnection.<init>(HttpConnection.java:70)\n            at libcore.net.http.HttpConnection.<init>(HttpConnection.java:50)\n            at libcore.net.http.HttpConnection$Address.connect(HttpConnection.java:340)\n            at libcore.net.http.HttpConnectionPool.get(HttpConnectionPool.java:87)\n            at libcore.net.http.HttpConnection.connect(HttpConnection.java:128)\n            at libcore.net.http.HttpEngine.openSocketConnection(HttpEngine.java:316)\n\n问题分析：\n\n因为没有获取到访问网络权限，因此抛出此类异常。\n\n解决方案：\n\n因为没有获取到访问网络权限而抛出此类异常。需要检查AndroidManifest.xml文件是否获取权限，检查手机是否有限制权限的软件如管家等并打开权限。\n\n代码示例：\n\n在AndroidManifest.xml中使用网络权限\n\n      <uses-permission android:name=\"android.permission.INTERNET\" />\n\n因为在这个例子中使用HTTPUrlConnection类，根据官方文档还需要申请检测网络状态的权限。\n\n      <uses-permission android:name=\"android.permission.ACCESS_NETWORK_STATE\" />\n\n如果还是报这个异常，请确认手机中没有其他软件管家控制网络权限没有授权。\n\n参考文献：\n\n1.https://developer.android.com/reference/java/lang/SecurityException.html \n\n2.https://developer.android.com/training/basics/network-ops/connecting.html',0,'java.lang.SecurityException'),(41,'2016-11-29 16:00:22','2016-11-29 16:00:22','CRASH','java.lang.UnsupportedOperationException','当请求了不支持的操作时抛出此类异常，请根据堆栈信息检查相关代码，根据官方文档及状态图检查是否进行了不支持的操作。','问题分析：\n\n当请求了不支持的操作时抛出此类异常。这个异常有三个子类：\n\n1. HeadlessException, 在不支持键盘、显示器或鼠标的环境中调用与键盘、显示器或鼠标有关的代码时，被抛出的异常。\n\n2. ReadOnlyBufferException, 当在只读缓冲区上调用内容可变（content-mutation）的方法（例如 put 或 compact 方法）时，抛出此未经检查的异常。\n\n3. ReadOnlyFileSystemException，当试图更新一个关联了只读权限的文件的对象时抛出此类异常。\n\n解决方案：\n\n当请求了不支持的操作时抛出此类异常，请根据堆栈信息检查相关代码，根据官方文档及状态图检查是否进行了不支持的操作。\n\n示例一：\n\n      java.lang.UnsupportedOperationException\n          java.util.AbstractList.add(Unknown Source)\n          java.util.AbstractList.add(Unknown Source)\n          javax.servlet.http.HttpServlet.service(HttpServlet.java:641)\n          javax.servlet.http.HttpServlet.service(HttpServlet.java:722)\n\n\n问题分析：\n\n根据官方文档，asList()函数返回的List不支持结构调整，即不支持remove和add操作。\n\n解决方案\n\n可以创建一个新的List，将符合要求的List加入新的List对象中。\n\n代码示例：\n\n      public void chooseObject(String[] array, String key){\n            List<String> list=Arrays.asList(array);\n            /* 错误的代码\n            list.remove(0); */\n            List<String> newList=new ArrayList<String>();\n            for(String tmp:list){\n              if(tmp.contains(key)){\n                newList.add(tmp);\n              }\n            }\n            System.out.println(newList.toString());\n      }\n\n参考文献：\n\n1.https://docs.oracle.com/javase/7/docs/api/java/lang/UnsupportedOperationException.html \n\n2.http://stackoverflow.com/questions/5755477/java-list-add-unsupportedoperationexception \nhttp://docs.oracle.com/javase/6/docs/api/java/util/Arrays.html#asList%28T...%29 （asList函数说明）',0,'java.lang.UnsupportedOperationException'),(42,'2016-11-29 16:02:58','2016-11-29 16:02:58','CRASH','android.os.DeadObjectException','调用的对象不存在，因为它所在app进程不存在或进程崩溃，此时在底层回调时报错抛出此类异常。因此在调用对象之前，建议检查是否存在此进程。','问题分析：\n\n调用的对象不存在，因为它所在app进程不存在或进程崩溃，此时在底层回调时报错。\n\n解决方案：\n\n在调用对象之前，建议检查是否存在此进程。DeadObjectException 异常出现是因为app进程不存在或进程崩溃因此在底层回调时报错。进程不存在或者进程崩溃需要查看其他日志来定位。对于进程崩溃的情况，也有可能部分原因是由于操作系统考虑到内存、cpu、优先级等指标，选择杀死一个进程得到资源。这种情况下，可以使用MQC平台的深度性能测试产品来帮助分析内存泄漏等问题。\n\n\n代码示例：\n\n        ActivityManager activityManager = (ActivityManager) this.getSystemService(Context.ACTIVITY_SERVICE);List<ActivityManager.RunningAppProcessInfo> pidsTask = activityManager.getRunningAppProcesses();\n        for(int i = 0; i < pidsTask.size(); i++) {\n            nameList.add(pidsTask.get(i).processName);\n        idList.add(pidsTask.get(i).uid);\n        }\n        If(nameList.contains(“processName”)){\n           // 进程存在\n        }\n        else{\n           // 进程不存在\n        }\n\n参考文献：\n\n1. https://developer.android.com/reference/android/os/DeadObjectException.html\n\n2. http://stackoverflow.com/questions/6039398/android-get-pid-of-other-applications',0,'android.os.DeadObjectException'),(43,'2016-11-29 16:04:33','2016-11-29 16:06:12','CRASH','java.lang.OutOfMemoryError','OutOfMemoryError是在当程序需要请求一块内存，而java虚拟机进行垃圾回收机制GC后无法再提供要求的内存时抛出此类异常，程序已经占用的内存到达系统限制的应用内存上线无法再申请到所需的内存空间。需要重点检查代码中是否有死循环或递归调用。检查是否在循环重复产生占用大内存的新对象。是否有一次获得大量数据的查询存到内存中，应当尽量用分页的方式查询。是否List、Map等集合对象使用后未清除，而集合对象有对对象的引用导致对象不能被GC回收，是否有内存泄露等。建议使用深度性能测试检测内存泄漏等问题。','问题分析：\n\nOutOfMemoryError是在当程序需要请求一块内存，而java虚拟机进行垃圾回收机制GC后无法再提供要求的内存时抛出此异常。\n\n解决方案：\n\nOutOfMemoryError是在当程序需要请求一块内存，而java虚拟机进行垃圾回收机制GC后无法再提供要求的内存时抛出此类异常，程序已经占用的内存到达系统限制的应用内存上线无法再申请到所需的内存空间。需要重点检查代码中是否有死循环或递归调用。检查是否在循环重复产生占用大内存的新对象。是否有一次获得大量数据的查询存到内存中，应当尽量用分页的方式查询。是否List、Map等集合对象使用后未清除，而集合对象有对对象的引用导致对象不能被GC回收，是否有内存泄露等。建议使用深度性能测试检测内存泄漏等问题。\n\n代码示例：\n\n        // 在循环外初始化大对象list并在循环内重复使用，并清空集合类、置null\n        List list=new ArrayList<Object>();\n        for(Object tmp:otherList){\n          // to do something\n        } \n        list.clear();\n        list=null;\n\n\n参考文献：\n\n1.https://developer.android.com/reference/java/lang/OutOfMemoryError.html\n\n2.https://source.android.com/compatibility/android-cdd.html#7_6_memory_and_storage （安卓系统对程序所使用内存的最大值限制，参见3.7节的表格，或直接参考文献3)\n\n3.https://drive.google.com/file/d/0B7Vx1OvzrLa3Y0R0X1BZbUpicGc/view?usp=sharing（安卓系统对内存最大值限制）',0,'java.lang.OutOfMemoryError'),(44,'2016-11-29 16:09:08','2016-11-29 16:40:10','CRASH','UncaughtHandler.uncaughtException','因为应用开启的线程抛出了异常未被捕获而导致抛出uncaughtException，建议在线程内捕获异常并做处理，如果无法在线程内捕获异常，设置线程默认的UncaughtException Handler来处理。','问题分析：\n\n此类异常发生在应用创建了线程，如果线程因为异常未捕获而退出，在RuntimeInit中会捕获此类异常并杀死进程。具体异常的原因需要看日志附近其他log确定触发异常信息。\n\n解决方案：\n\n因为应用开启的线程抛出了异常未被捕获而导致抛出uncaughtException，建议在线程内捕获异常并做处理，如果无法在线程内捕获异常，设置线程默认的UncaughtException Handler来处理。\n\n代码示例：\n\n        public static void main(String[] args) {\n          UncaughtExceptionHandler eh=new UncaughtExceptionHandler() {\n            @Override\n            public void uncaughtException(Thread t, Throwable e) {\n                  System.out.println(\"uncaught Caught \" + e);\n            }\n          };\n          \n          Thread thread=new Thread(){\n            @Override\n            public void run(){\n              try {\n                // do something and happen a exception\n                throw new IOException(\"e\");\n              } catch (IOException e) {\n                System.out.println(\"catching IOException:\");\n                e.printStackTrace();\n              }\n              // code may cause some other exception, we could catch these, or use setDefaultUncaughtExceptionHandler\n              System.out.println(1/0);\n            }\n          };\n          thread.setDefaultUncaughtExceptionHandler(eh);\n          thread.start();\n        }\n\n参考文献：\n\n1.http://androidxref.com/4.3_r2.1/xref/frameworks/base/core/java/com/android/internal/os/RuntimeInit.java\n\n2.http://docs.oracle.com/javase/8/docs/api/java/lang/Thread.UncaughtExceptionHandler.html\n\n3.http://stackoverflow.com/questions/6546193/how-to-catch-an-exception-from-a-thread\n\n4.http://www.cnblogs.com/freeliver54/archive/2011/10/17/2215423.html',0,'com.android.internal.os.RuntimeInit.UncaughtHandler.uncaughtException'),(45,'2016-11-29 16:15:46','2017-03-10 21:34:50','CRASH','java.lang.RuntimeException','RuntimeException是发生在程序运行期，预先不可预见的发生。编译器未要求一定要进行捕获，如果运行期没有处理，则RuntimeException会一直往上层抛。最后由JVM来处理，JVM会打印堆栈信息然后结束应用。对于可能发生的RuntimeException，建议根据堆栈信息，检查代码是否有误并进行更改，如果情况复杂无法全部解决，可以对RuntimeException进行捕获并进行业务恢复处理。','问题分析：\n\nRuntimeException是运行时异常，是java编译器事先不可预见的异常。RuntimeException的子类众多，这里列举一些比较常见的子类：\n\n1. BufferOverflowException当相关 put 操作达到目标缓冲区限制时，抛出此未经检查的异常。\n\n2. ArrayStoreException试图将错误类型的对象存储到一个对象数组时抛出的异常。\n3. ArithmeticException当出现异常的运算条件时，抛出此异常。例如，一个整数“除以零”时，抛出此类的一个实例。\n4. BufferUnderflowException当相关 get 操作达到源缓冲区限制时，抛出此未经检查的异常。\n5. IndexOutOfBoundsException 指示某排序索引（例如对数组、字符串或向量的排序）引用时超出范围时抛出。\n6. NoSuchElementException 由 Enumeration 的 nextElement 方法抛出，表明枚举中没有更多的元素。\n\n解决方案：\n\nKeySolution：RuntimeException是发生在程序运行期，预先不可预见的发生。编译器未要求一定要进行捕获，如果运行期没有处理，则RuntimeException会一直往上层抛。最后由JVM来处理，JVM会打印堆栈信息然后结束应用。对于可能发生的RuntimeException，建议根据堆栈信息，检查代码是否有误并进行更改，如果情况复杂无法全部解决，可以对RuntimeException进行捕获并进行业务恢复处理。\n代码示例：\n\n	try {\n	   somethingThrowingARuntimeException();\n	   }catch (RuntimeException e) {\n	     // Do something with it. At least log it\n	     e.printStackTrace();\n	   }\n\n1. 示例一：\n\n	java.lang.RuntimeException: Unable to start activity ComponentInfo {com.demo.demo/com.demo.demo.api.MainActivity}: java.lang.RuntimeException: Parcelable encountered ClassNotFoundException reading a Serializable object (name = com.alibaba.mqc.intentfuzzer.util.SerializableTest)  \n\n	Caused by: java.lang.ClassNotFoundException: Didn\'t find class \"com.alibaba.mqc.intentfuzzer.util.SerializableTest\" on path: DexPathList[[zip file \"/data/app/com.demo.demo-1/base.apk\"],nativeLibraryDirectories=[/data/app/com.demo.demo-1/lib/arm, /data/app/com.demo.demo-1/base.apk!/lib/armeabi-v7a, /vendor/lib, /system/lib]] \n\n这个异常是因为Activity\\Service\\Broadcast没有验证Intent传入的参数类型导致应用崩溃，建议getSerializableExtra获取序列化对象时验证参数类型。\n\n代码示例：\n\n	public void onCreate(Bundle savedInstanceState) {\n	  super.onCreate(savedInstanceState);\n	  Intent intent = getIntent();\n	  Object object = intent.getSerializableExtra(\"data\");\n	  if (object.getClass() == \"xxxx\") {\n	  	// do something\n	  }\n	}\n\n2. 示例二：\n\n	java.lang.RuntimeException: Unable to start activity ComponentInfo{*}: android.support.v4.app.Fragment$InstantiationException: *: make sure class name exists, is public, and has an empty constructor that is public\n\n当系统因为内存不足杀死非前台进程，用户又将被系统杀掉的非前台应用带回前台，如果这个时候有UI是呈现在Fragment中，那么会因为restore造成fragment需要通过反射实例对象，从而将之前save的状态还原。因此不应该改写构造函数，而应该使用静态方法比如newInstance来构造有参Fragment对象并返回。\n\n代码示例：\n\n步骤一：编写有参静态创建对象函数\n\n	public static final AlertFragment newInstance(int title, String message)\n	{\n	    AlertFragment f = new AlertFragment();\n	    Bundle bdl = new Bundle(2);\n	    bdl.putInt(EXTRA_TITLE, title);\n	    bdl.putString(EXTRA_MESSAGE, message);\n	    f.setArguments(bdl);\n	    return f;\n	}\n\n步骤二：通过Bundle获取参数\n\n	@Override\n	public void onCreate(Bundle savedInstanceState)\n	{\n	    title = getArguments().getInt(EXTRA_TITLE);\n	    message = getArguments().getString(EXTRA_MESSAGE);\n	    //...\n	    //etc\n	    //...\n	}\n\n步骤三：通过FragmentManager对Fragment进行管理。\n\n	public onCreate(Bundle savedInstanceState) {\n	    if(savedInstanceState == null){\n	        getSupportFragmentManager()\n	            .beginTransaction()\n	            .replace(R.id.content,AlertFragment.newInstance(\n	                R.string.alert_title,\n	                \"Oh noes an error occured!\")\n	            )\n	            .commit();\n	    }\n	}\n\n3. 示例三：\n\n	Exception in thread \"main\" java.lang.IndexOutOfBoundsException: Index: 80, Size: 3\n		at java.util.ArrayList.rangeCheck(ArrayList.java:635)\n		at java.util.ArrayList.remove(ArrayList.java:474)\n		at com.alibaba.mqc.test.Test.indexOutOfBounds(Test.java:66)\n		at com.alibaba.mqc.test.Test.main(Test.java:32)\n\n问题分析：\nIndexOutOfBoundsException 指示某排序索引（例如对数组、字符串或向量的排序）引用时超出范围时抛出。请检查是否有对List有越界索引，判断访问数组的索引是否合法。\n有误的代码：\n\n    public void indexOutOfBounds(){\n		ArrayList<Character> a = new ArrayList<Character>();\n		 a.add(\'A\');\n		 a.add(\'B\');\n		 a.add(\'C\');\n		 System.out.println(a);\n		 //a.remove(\'A\');\n		 a.remove(80);	// 抛出此类异常\n		 System.out.println(a);\n    }\n\n建议的代码：\n\n	public void indexOutOfBounds(){\n		ArrayList<Character> a = new ArrayList<Character>();\n		 a.add(\'A\');\n		 a.add(\'B\');\n		 a.add(\'C\');\n		 System.out.println(a);\n		 if(a.size()>80){\n			 a.remove(80);\n		 }\n		 System.out.println(a);\n    }\n\n参考文献：\n1. https://developer.android.com/reference/java/lang/RuntimeException.html \n2. http://stackoverflow.com/questions/10450348/do-fragments-really-need-an-empty-constructor\n3. http://blog.csdn.net/xplee0576/article/details/43057633\n4. http://stackoverflow.com/questions/2028719/handling-runtimeexceptions-in-java \n5. http://tool.oschina.net/uploads/apidocs/jdk-zh/java/lang/RuntimeException.html',0,'java.lang.RuntimeException'),(46,'2016-11-29 16:35:33','2016-11-29 16:35:33','NATIVECRASH','Native crash','应用在C/C++运行时出错，系统产生了Linux错误信号，导致的进程出错退出。建议开发者使用NDK工具ndk-stack进行分析定位。','问题分析：\n\nNative的Crash是指在C/C++运行时出错，系统产生了Linux错误信号，导致的进程出错退出。可以通过系统的logcat来分析crash日志。\n\n解决方案：\n\n应用在C/C++运行时出错，系统产生了Linux错误信号，导致的进程出错退出。建议开发者使用NDK工具ndk-stack进行分析定位。\n\nAndroid开发中，在Java层可以方便的捕获crashlog，但对于Native层的crashlog通常无法直接获取，只能通过系统的logcat来分析crash日志。这里我们建议开发者使用NDK工具ndk-stack进行分析定位。\n\n1.下载最新版NDK：NDK下载地址。ndk-stack工具就在NDK主目录下。\n\n2.在mqc管理中心找到出现Native Crash的测试，并下载日志。 \n\n3.根据失败机型查找该机型的CPU信息ro.product.cpu.abi，如图三星N7100的cpu类型为armeabi-v7a。(目前mqc上的模拟器cpu类型均为x86_64。)\n\n4. 使用ndk-stack分析出错位置，命令格式如下：\n\n        $NDK/ndk-stack -sym $PROJECT_PATH/obj/local/$cpu.abi -dump $LOGCAT_PATH\n\n本示例使用的命令如下：\n\n            ndk-stack -sym ./workspace2/testNdkStack/obj/local/armeabi-v7a/ -dump ./logcat.log > result.log\n\n在result.log中可以分析定位到出现该crash的对应代码文件和具体行数。',0,'Native crash');
/*!40000 ALTER TABLE `mts_crash_solution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_device`
--

DROP TABLE IF EXISTS `mts_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_device` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `device_type_id` bigint(20) unsigned NOT NULL COMMENT '设备类型id',
  `device_group_id` bigint(20) unsigned NOT NULL COMMENT '设备组id',
  `agent_id` bigint(20) unsigned NOT NULL COMMENT '对应agent的id',
  `asset_num` varchar(128) NOT NULL COMMENT '资产编号',
  `serial_num` varchar(128) NOT NULL COMMENT 'adb device看到的',
  `status` varchar(64) NOT NULL DEFAULT 'OFFLINE' COMMENT '掉线-OFFLINE，正常-ONLINE',
  `network` varchar(32) NOT NULL DEFAULT 'WIFI' COMMENT '2G、3G、4G、WIFI',
  `borrow_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0-没有被借出，1-被借出',
  `borrowable` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0-不可借，1-可借',
  `it_holder` varchar(64) DEFAULT NULL COMMENT '在谁的名下',
  `borrower` varchar(64) DEFAULT NULL COMMENT '借用者',
  `memo` varchar(1024) DEFAULT NULL COMMENT '说明',
  `battery_level` varchar(64) NOT NULL COMMENT '用电量，例如：100%',
  `available_ram` varchar(64) NOT NULL COMMENT '可用内存',
  `agent_ip` varchar(64) NOT NULL COMMENT '对应agent的ip',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否被删除',
  `location` varchar(128) DEFAULT NULL COMMENT '设备地点，例如：IDC',
  `is_root` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否root',
  `extension` varchar(1024) DEFAULT NULL COMMENT '扩展字段',
  `is_busy` tinyint(4) DEFAULT '0' COMMENT '0为空闲，1为忙碌',
  `wifi_ip` varchar(64) DEFAULT NULL COMMENT 'wifi ip',
  `system_time` datetime DEFAULT NULL COMMENT '设备系统时间',
  `air_mode` varchar(64) DEFAULT 'OFF' COMMENT '是否开启飞行模式',
  `bluetooth` varchar(64) DEFAULT 'OFF' COMMENT '是否开启蓝牙',
  `gps` varchar(64) DEFAULT 'OFF' COMMENT '是否开启gps',
  `wifi_mac` varchar(128) DEFAULT NULL COMMENT '设备的wifi MAC地址',
  `imei` varchar(128) DEFAULT NULL COMMENT '设备的IMEI号',
  `bluetooth_mac` varchar(128) DEFAULT NULL COMMENT '设备的bluetooth MAC地址',
  `has_vnc` tinyint(4) DEFAULT '0' COMMENT '是否安装androidvncserver,1=安装，0=未安装',
  `need_restore` tinyint(4) DEFAULT '0' COMMENT '是否需要恢复出厂设置，1=需要，0=不需要',
  `need_repaire` tinyint(4) DEFAULT '0' COMMENT '是否需要维修，1=需要，0=不需要',
  `need_replacebattery` tinyint(4) DEFAULT '0' COMMENT '是否需要更换电池，1=需要，0=不需要',
  `mtsguard_version` varchar(64) DEFAULT NULL COMMENT '手机上的MtsGuard的版本信息',
  `remote_status` tinyint(4) DEFAULT '0' COMMENT '0--空闲，1--使用中',
  `remote_available` tinyint(4) DEFAULT '1' COMMENT '0--不可用，1--可用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_asset_num` (`asset_num`),
  KEY `ins_dtid` (`device_type_id`),
  KEY `ins_st` (`status`),
  KEY `ins_dgid` (`device_group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='设备表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_device`
--

LOCK TABLES `mts_device` WRITE;
/*!40000 ALTER TABLE `mts_device` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_device_group`
--

DROP TABLE IF EXISTS `mts_device_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_device_group` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `group_name` varchar(64) NOT NULL COMMENT '组名',
  `group_password` varchar(32) DEFAULT NULL COMMENT '密码，md5加密',
  `description` varchar(512) DEFAULT NULL COMMENT '描述',
  `group_email` varchar(512) DEFAULT NULL COMMENT '组邮件',
  `is_public` tinyint(4) NOT NULL COMMENT '是否公开',
  `is_deleted` tinyint(4) NOT NULL COMMENT '是否被删除',
  `extension` varchar(1024) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='设备组表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_device_group`
--

LOCK TABLES `mts_device_group` WRITE;
/*!40000 ALTER TABLE `mts_device_group` DISABLE KEYS */;
INSERT INTO `mts_device_group` VALUES (1,'2017-04-11 15:05:23','2017-10-19 10:14:43','test','******',NULL,'******',1,0,NULL),(2,'2015-09-27 20:06:42','2015-09-27 20:06:42','remote_debug','******',NULL,'******',1,0,NULL),(9,'2016-07-22 15:16:07','2017-10-17 16:31:49','H5','******',NULL,'******',0,0,NULL),(14,'2017-03-30 19:23:47','2017-03-30 19:23:47','DeepPerformance','******','','******',1,0,NULL),(15,'2017-04-25 17:05:51','2017-04-25 17:05:51','ios remote debug','******',NULL,'******',1,0,NULL);
/*!40000 ALTER TABLE `mts_device_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_device_log`
--

DROP TABLE IF EXISTS `mts_device_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_device_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `device_id` bigint(20) unsigned DEFAULT NULL COMMENT '设备ID',
  `asset_num` varchar(128) DEFAULT NULL COMMENT '资产编号',
  `offline_time` int(10) unsigned DEFAULT '0' COMMENT '掉线时间',
  `online_time` int(10) unsigned DEFAULT '0' COMMENT '在线时间',
  `inuse_time` int(10) unsigned DEFAULT '0' COMMENT '正在执行任务的时间',
  `device_error_count` int(10) unsigned DEFAULT '0' COMMENT '设备出错次数',
  `task_success_count` int(10) unsigned DEFAULT '0' COMMENT '执行任务成功次数',
  `task_fail_count` int(10) unsigned DEFAULT '0' COMMENT '执行任务失败次数',
  `extension` varchar(1024) DEFAULT NULL COMMENT '扩展字段',
  `event` varchar(64) NOT NULL DEFAULT 'IDLE' COMMENT 'device状态事件',
  `event_message` varchar(4096) DEFAULT NULL COMMENT 'device状态事件说明',
  `execution_task_id` bigint(20) unsigned DEFAULT NULL COMMENT 'device执行任务的id',
  `borrower_id` bigint(20) unsigned DEFAULT NULL COMMENT 'device借用者的id',
  `operation` varchar(64) DEFAULT NULL COMMENT 'device error后的操作，例如restore',
  PRIMARY KEY (`id`),
  KEY `idx_device_id` (`device_id`),
  KEY `idx_gmt_create` (`gmt_create`),
  KEY `idx_asset_num` (`asset_num`),
  KEY `idx_assetnum_event` (`asset_num`,`event`)
) ENGINE=InnoDB AUTO_INCREMENT=846 DEFAULT CHARSET=utf8 COMMENT='设备日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_device_log`
--

LOCK TABLES `mts_device_log` WRITE;
/*!40000 ALTER TABLE `mts_device_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_device_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_device_perf`
--

DROP TABLE IF EXISTS `mts_device_perf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_device_perf` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `device_type_id` bigint(20) unsigned NOT NULL COMMENT '设备类型ID',
  `launch_time_count` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '参与计算的启动时间数',
  `avg_launch_time` decimal(10,3) NOT NULL DEFAULT '0.000' COMMENT '历史平均启动时间',
  `cpu_usage_count` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '参与计算的CPU占用率数',
  `avg_cpu_usage` decimal(10,3) NOT NULL DEFAULT '0.000' COMMENT '历史平均CPU占用率',
  `mem_usage_count` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '参与计算的内存占用率数',
  `avg_mem_usage` decimal(10,3) NOT NULL DEFAULT '0.000' COMMENT '历史平均内存占用',
  `network_usage_count` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '参与计算的流量使用数',
  `avg_network_usage` decimal(10,3) NOT NULL DEFAULT '0.000' COMMENT '历史平均流量耗用',
  `is_deleted` tinyint(4) DEFAULT '0' COMMENT '是否被删除',
  `last_perf_data_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '最新加入运算的perf_data_id',
  PRIMARY KEY (`id`),
  KEY `idx_test_type_id` (`device_type_id`),
  KEY `idx_is_deleted` (`is_deleted`),
  KEY `idx_perf_date_id` (`last_perf_data_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='设备的历史测试性能表现平均水平记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_device_perf`
--

LOCK TABLES `mts_device_perf` WRITE;
/*!40000 ALTER TABLE `mts_device_perf` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_device_perf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_device_performance_log`
--

DROP TABLE IF EXISTS `mts_device_performance_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_device_performance_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `available_ram` varchar(64) NOT NULL COMMENT '可用ram大小',
  `cpu` varchar(64) NOT NULL COMMENT 'cpu使用率',
  `extension` varchar(128) DEFAULT NULL COMMENT '扩展字段',
  `device_id` bigint(20) unsigned DEFAULT NULL COMMENT '对应mts_device表的id',
  `asset_num` varchar(128) NOT NULL COMMENT '设备的资产编号',
  `available_sdcard` varchar(128) DEFAULT NULL COMMENT '设备剩余的sd卡空间',
  PRIMARY KEY (`id`),
  KEY `idx_device_id` (`device_id`)
) ENGINE=InnoDB AUTO_INCREMENT=873 DEFAULT CHARSET=utf8 COMMENT='设备性能日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_device_performance_log`
--

LOCK TABLES `mts_device_performance_log` WRITE;
/*!40000 ALTER TABLE `mts_device_performance_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_device_performance_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_device_queue_config`
--

DROP TABLE IF EXISTS `mts_device_queue_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_device_queue_config` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `use_config` tinyint(4) NOT NULL DEFAULT '0' COMMENT '配置总开关\n0-表示不使用\n1-表示使用此配置的系数',
  `android_queue` int(11) DEFAULT '55' COMMENT 'android任务，设备队列饱和度。默认55次/台',
  `ios_queue` int(11) DEFAULT '35' COMMENT 'ios任务，任务队列饱和度。\n默认值35次/台',
  `max_hide` int(11) DEFAULT '50' COMMENT '最大机型隐藏数',
  `hide_rate` int(11) DEFAULT '50' COMMENT '设备隐藏率百分比，默认最大隐藏 50%',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='设备任务队列限制、隐藏数等配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_device_queue_config`
--

LOCK TABLES `mts_device_queue_config` WRITE;
/*!40000 ALTER TABLE `mts_device_queue_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_device_queue_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_device_type`
--

DROP TABLE IF EXISTS `mts_device_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_device_type` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `device_type` varchar(64) DEFAULT 'PHONE' COMMENT '?只?-PHONE??平??-TABLET?????雍???-TV??模????-EMULATOR',
  `brand` varchar(128) NOT NULL COMMENT '厂商',
  `model` varchar(128) NOT NULL COMMENT '型号',
  `dimension` varchar(64) NOT NULL COMMENT '屏幕尺寸',
  `resolution` varchar(64) NOT NULL COMMENT '分辨率',
  `platform_type` varchar(64) NOT NULL COMMENT 'ANDROID，IOS',
  `platform` varchar(64) NOT NULL COMMENT 'ANDROID 4.4.2，ANDROID 2.3.5',
  `sdcard` varchar(32) DEFAULT NULL COMMENT 'SD卡大小，例如：16G',
  `price` varchar(32) DEFAULT NULL COMMENT '价格',
  `cpu` varchar(32) DEFAULT NULL COMMENT 'cpu频率，例如：4GHz',
  `ram` varchar(32) DEFAULT NULL COMMENT '内存总大小',
  `rom` varchar(32) DEFAULT NULL COMMENT 'rom大小，例如：16M',
  `camera` varchar(32) DEFAULT NULL COMMENT '相机像素，例如：160W（160万）',
  `battery` varchar(32) DEFAULT NULL COMMENT '电池总电量，例如：1800mAh',
  `thumbnail` varchar(512) NOT NULL COMMENT '图片地址',
  `is_hot` tinyint(4) DEFAULT '0' COMMENT '0-非热门，1-热门',
  `device_name` varchar(512) DEFAULT NULL COMMENT '?璞??',
  `extension` varchar(1024) DEFAULT NULL COMMENT '扩展字段',
  `percentage` float DEFAULT '0' COMMENT '该机型使用量在所有机型中的占比',
  `user_affected` bigint(20) unsigned DEFAULT '0' COMMENT '该机型影响用户数(W)',
  `is_delete` tinyint(4) DEFAULT '0' COMMENT '是否被删除，0-未删除，1-删除',
  `newbrand` varchar(128) DEFAULT NULL COMMENT '修改后显示在前端的brand',
  `newplatform` varchar(64) DEFAULT NULL COMMENT '修改后显示在前端的platform',
  `newmodel` varchar(128) DEFAULT NULL COMMENT '修改后显示在前端的model',
  `gpu` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ins_dt` (`device_type`),
  KEY `ins_plf` (`platform`),
  KEY `ins_resolution` (`resolution`),
  KEY `ins_brand` (`brand`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='设备类型表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_device_type`
--

LOCK TABLES `mts_device_type` WRITE;
/*!40000 ALTER TABLE `mts_device_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_device_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_document`
--

DROP TABLE IF EXISTS `mts_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_document` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `content` text COMMENT '富文本，存储内容，相关附件地址',
  `title` varchar(512) NOT NULL COMMENT '标题',
  `author` varchar(128) NOT NULL DEFAULT 'mts' COMMENT '作者',
  `other` text COMMENT '其他信息',
  `is_deleted` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '判断是否删除，删除为1',
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '指示父结点id，根节点为0',
  `sequence` bigint(20) unsigned NOT NULL DEFAULT '1' COMMENT '指示同级文章顺序',
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8 COMMENT='存储帮助文档';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_document`
--

LOCK TABLES `mts_document` WRITE;
/*!40000 ALTER TABLE `mts_document` DISABLE KEYS */;
INSERT INTO `mts_document` VALUES (1,'2015-04-21 20:20:27','2017-03-01 00:57:21','&lt;p&gt;MQC是为广大企业客户和移动开发者提供真机测试服务的云平台，拥有大量热门机型，提供7x24全天候服务。&lt;/p&gt;\n\n&lt;p&gt;我们致力于提供专业、稳定、全面、高价值的自动化测试能力，以及简单易用的使用流程、贴心的技术服务，并且帮助客户以最低的成本、最高的效率发现APP中的各类隐患（APP崩溃、各类兼容性问题、功能性问题、性能问题等），减少用户流失，提高APP质量和市场竞争力。&lt;/p&gt;\n\n&lt;p&gt;依托于阿里深厚的移动测试技术积累，MQC针对不同的测试场景和需求，研发了一套独特的测试方法和体系，可以涵盖Android、iOS、YunOS、H5等不同的平台体系，我们在内部服务了手淘、天猫、聚划算、支付宝等一系列超级App，积累了丰富的移动测试经验。&lt;/p&gt;\n\n&lt;p&gt;同时，在&amp;ldquo;发现问题&amp;rdquo; -&amp;gt; &amp;ldquo;定位问题&amp;rdquo; -&amp;gt; &amp;ldquo;解决问题&amp;rdquo; 整个链路上做了非常多的优化和提升，可以帮助客户快速的发现问题，并且辅助迅速定位问题，最后通过各类修复建议促进问题快速解决。通过一整套测试能力网络，使得MQC的测试效果非常出众，远远高于业界水平。&lt;/p&gt;','关于我们','MTS','MQC是为广大企业客户和移动开发者提供真机测试服务的云平台，拥有大量热门机型，提供7x24全天候服务。\n\n我们致力于提供专业、稳定、全面、高价值的自动化测试能力，以及简单易用的使用流程、贴心的技术服务，并且帮助客户以最低的成本、最高的效率发现APP中的各类隐患（APP崩溃、各类兼容性问题、功能性问题、性能问题等），减少用户流失，提高APP质量和市场竞争力。\n\n依托于阿里深厚的移动测试技术积累，MQC针对不同的测试场景和需求，研发了一套独特的测试方法和体系，可以涵盖Android、iOS、YunOS、H5等不同的平台体系，我们在内部服务了手淘、天猫、聚划算、支付宝等一系列超级App，积累了丰富的移动测试经验。\n\n同时，在“发现问题” -> “定位问题” -> “解决问题” 整个链路上做了非常多的优化和提升，可以帮助客户快速的发现问题，并且辅助迅速定位问题，最后通过各类修复建议促进问题快速解决。通过一整套测试能力网络，使得MQC的测试效果非常出众，远远高于业界水平。',0,0,2),(3,'2015-04-21 20:29:19','2016-06-08 00:25:56',NULL,'帮助文档','MTS',NULL,0,0,5),(4,'2015-04-21 20:30:19','2016-06-29 16:36:52',NULL,'FAQ','MTS',NULL,0,0,12),(5,'2015-04-21 20:31:56','2015-08-11 15:36:59',NULL,'Robotium使用文档','MTS','undefined',0,3,2),(7,'2015-04-21 20:34:15','2017-03-03 20:38:22','&lt;p&gt;Robotium是一个能够全面支持原生App和混合App（Native和H5页面混合）Android测试框架。Robotium让测试人员更容易的写出强大、稳定的Android的黑盒UI测试。在Robotium的支持下，测试脚本开发人员可以完成自己的跨多个Activity的测试用例。&lt;/p&gt;\n\n&lt;p&gt;在介绍如何开发测试用例之前，先介绍一下UI 测试以及Android 提供的ADT（Android developer tools）里的UI Automator Viewer。&lt;/p&gt;\n\n&lt;h2&gt;1. UI 测试&lt;/h2&gt;\n\n&lt;p&gt;Android APP测试除了需要测试不同的activity、不同的service，还需要对UI 的行为进行测试。 UI 测试能够保证你的APP能够正确响应用户的一系列输入（点击、拖拽、双击等等）。UI测试不需要测试人员了解一个APP的具体实现机制，只需要关心APP对用户输入是否能够产生正确的响应。这能够帮助开发人员和测试人员更好的协同工作。我们最常见的就是人工的进行UI测试。但是这种测试会占用大量时间，并且经常需要重复。所以，需要一种新的测试框架能够帮助测试自动进行，比如Robotium。我们需要做的就是写程序去完成一个个特定的测试用例。&lt;/p&gt;\n\n&lt;h2&gt;2. UI查看工具：UI Automator Viewer&lt;/h2&gt;\n\n&lt;p&gt;UI Automator Viewer是Android开发工具包里的一个工具。它有图形界面可以用来帮我们分析一个APP的各种UI控件。通过它，我们能找到UI控件的很多属性（包括ID）。在编写自动化程序时，这些属性就可以帮助我们定位到一个特定的UI控件了。然后，我们可以对这个UI控件对象进行各种操作，点击，拖拽等等。&lt;/p&gt;\n\n&lt;h3&gt;注：uiautomatorviewer只支持Android 4.1(含)以上的真机或模拟器。Robotium没有这个限制。&lt;/h3&gt;\n\n&lt;p&gt;&lt;img alt=&quot;Ui Automator Viewer查看UI控件截图&quot; src=&quot;/static/res/d7a29e0227c85e6461673c15bab864c6.png&quot; style=&quot;height:291px; width:461px&quot; /&gt;&lt;/p&gt;\n\n&lt;h2&gt;3. UI&amp;nbsp;Automator Viewer的基本使用&lt;/h2&gt;\n\n&lt;p&gt;首先请检查是否安装了Android 开发工具（adt），如果没有请先到&lt;a href=&quot;https://dl.google.com/android/ADT-23.0.6.zip&quot;&gt;这里&lt;/a&gt;进行下载（下载速度可能稍慢，请耐心等待），下载完成后直接解压到任意目录即可。ADT也可以在eclipse下安装，help-&amp;gt;install new software，打开后&amp;nbsp;location输入https://dl-ssl.google.com/android/eclipse/ 然后点击确定 ，如果https://dl-ssl.google.com/android/eclipse/慢的话可以换成http://dl-ssl.google.com/android/eclipse/ ，这里可能需要VPN来访问Google的服务，确定以后把所有选上，一路点next。完成后去安装目录查看。&lt;/p&gt;\n\n&lt;p&gt;Windows下打开：&amp;ldquo;adt目录/tools/uiautomatorviewer.bat&amp;rdquo;这个文件。&lt;/p&gt;\n\n&lt;p&gt;Linux 和Mac下打开：&amp;ldquo;adt目录/tools/uiautomatorviewer&amp;rdquo;这个文件，即可看到如下界面：&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;初始界面&quot; src=&quot;/static/res/917b92ea01b7143f5b6d98b7ea4b40b2.png&quot; style=&quot;height:362px; width:481px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;UI&amp;nbsp;Automator Viewer界面分为3部分：左侧的&amp;ldquo;APP Activity界面&amp;rdquo;，右侧上方的&amp;ldquo;控件树结构&amp;rdquo;，右侧下方的&amp;ldquo;控件信息&amp;rdquo;。&lt;/p&gt;\n\n&lt;h3&gt;查看APP的UI树：&lt;/h3&gt;\n\n&lt;p&gt;a. 首先，PC上连接一个Android 4.1(含)以上的真机或者模拟器。在命令行中：执行adb devices ，保证能够看到你连接的设备。&lt;/p&gt;\n\n&lt;p&gt;b. 在连接的设备上安装想要测试的APP, 然后打开APP（例图打开的是&amp;ldquo;手机淘宝&amp;rdquo;）。&lt;/p&gt;\n\n&lt;p&gt;c. 点击上图中的红色区域圈出的按钮, &amp;ldquo;Device Screenshot&amp;nbsp;(uiautomator dump)&amp;rdquo;，出现下图：&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;截图中&quot; src=&quot;/static/res/b5c458cd4d7d1812b18ac8015d2f4bb5.png&quot; style=&quot;height:323px; width:430px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;d. 完成之后，可以看到如下截图：&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;结果展示&quot; src=&quot;/static/res/d7a29e0227c85e6461673c15bab864c6.png&quot; style=&quot;height:291px; width:461px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;我们可以在APP界面截图区域，点击选中任意的UI控件，右侧上方&amp;ldquo;控件树&amp;rdquo;会定位到相应的控件。同时，右侧下方也同时出现选中控件的详细信息，如上图。&lt;/p&gt;','UI测试','MTS','Robotium是一个能够全面支持原生App和混合App（Native和H5页面混合）Android测试框架。Robotium让测试人员更容易的写出强大、稳定的Android的黑盒UI测试。在Robotium的支持下，测试脚本开发人员可以完成自己的跨多个Activity的测试用例。\n\n在介绍如何开发测试用例之前，先介绍一下UI 测试以及Android 提供的ADT（Android developer tools）里的UI Automator Viewer。\n\n1. UI 测试\n\nAndroid APP测试除了需要测试不同的activity、不同的service，还需要对UI 的行为进行测试。 UI 测试能够保证你的APP能够正确响应用户的一系列输入（点击、拖拽、双击等等）。UI测试不需要测试人员了解一个APP的具体实现机制，只需要关心APP对用户输入是否能够产生正确的响应。这能够帮助开发人员和测试人员更好的协同工作。我们最常见的就是人工的进行UI测试。但是这种测试会占用大量时间，并且经常需要重复。所以，需要一种新的测试框架能够帮助测试自动进行，比如Robotium。我们需要做的就是写程序去完成一个个特定的测试用例。\n\n2. UI查看工具：UI Automator Viewer\n\nUI Automator Viewer是Android开发工具包里的一个工具。它有图形界面可以用来帮我们分析一个APP的各种UI控件。通过它，我们能找到UI控件的很多属性（包括ID）。在编写自动化程序时，这些属性就可以帮助我们定位到一个特定的UI控件了。然后，我们可以对这个UI控件对象进行各种操作，点击，拖拽等等。\n\n注：uiautomatorviewer只支持Android 4.1(含)以上的真机或模拟器。Robotium没有这个限制。\n\n\n\n3. UI Automator Viewer的基本使用\n\n首先请检查是否安装了Android 开发工具（adt），如果没有请先到这里进行下载（下载速度可能稍慢，请耐心等待），下载完成后直接解压到任意目录即可。ADT也可以在eclipse下安装，help->install new software，打开后 location输入https://dl-ssl.google.com/android/eclipse/ 然后点击确定 ，如果https://dl-ssl.google.com/android/eclipse/慢的话可以换成http://dl-ssl.google.com/android/eclipse/ ，这里可能需要VPN来访问Google的服务，确定以后把所有选上，一路点next。完成后去安装目录查看。\n\nWindows下打开：“adt目录/tools/uiautomatorviewer.bat”这个文件。\n\nLinux 和Mac下打开：“adt目录/tools/uiautomatorviewer”这个文件，即可看到如下界面：\n\n\n\nUI Automator Viewer界面分为3部分：左侧的“APP Activity界面”，右侧上方的“控件树结构”，右侧下方的“控件信息”。\n\n查看APP的UI树：\n\na. 首先，PC上连接一个Android 4.1(含)以上的真机或者模拟器。在命令行中：执行adb devices ，保证能够看到你连接的设备。\n\nb. 在连接的设备上安装想要测试的APP, 然后打开APP（例图打开的是“手机淘宝”）。\n\nc. 点击上图中的红色区域圈出的按钮, “Device Screenshot (uiautomator dump)”，出现下图：\n\n\n\nd. 完成之后，可以看到如下截图：\n\n\n\n我们可以在APP界面截图区域，点击选中任意的UI控件，右侧上方“控件树”会定位到相应的控件。同时，右侧下方也同时出现选中控件的详细信息，如上图。',0,5,2),(8,'2015-04-21 20:35:15','2016-11-25 15:11:13','&lt;p&gt;刚刚我们学习了，如何使用UI Automator Viewer进行APP UI控件的查看。用Robotium框架编写测试用例，本质上就是使用Robotium的API，对找到的一个个控件进行有序的操作（点击、拖拽、滑动）。&lt;/p&gt;\n\n&lt;p&gt;下面我们通过一个例子(&lt;a href=&quot;/static/res/MtsDemoApp.apk&quot;&gt;示例APP&lt;/a&gt;)，来学习如何用Robotium编写登录APP的自动化脚本。通过这个例子也能了解到Robotium的自动化测试是如何工作的。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;1. 准备Android 开发环境&lt;/h2&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;如果已经有了Android开发环境就可以略过这一步，直接查看第二步。&lt;/p&gt;\n\n&lt;p&gt;配置Android 需要安装&lt;a href=&quot;http://wiki.eclipse.org/Eclipse/Installation&quot;&gt;Eclipse&lt;/a&gt; (最新版即可,目前是luna) 和&lt;a href=&quot;http://www.oracle.com/technetwork/java/javase/downloads/index.html&quot;&gt;JDK 6&lt;/a&gt;，然后参考&lt;a href=&quot;http://developer.android.com/sdk/installing/installing-adt.html&quot;&gt;Android官方说明&lt;/a&gt;安装Eclipse 的adt插件。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;2. 在Eclipse中创建测试用例&lt;/h2&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h3&gt;a. 创建一个空白的Android测试工程。&lt;/h3&gt;\n\n&lt;p&gt;点击File -&amp;gt; New -&amp;gt; Project，然后再弹出框内选择Android-&amp;gt;Android Test Project。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;创建一个空白的Android测试工程&quot; src=&quot;/static/res/359ebae99700986b687af689b3b61e74.png&quot; style=&quot;height:352px; width:428px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;点击Next到下一步，输入工程名称，比如MtsAutomationTest, 然后下一步，可以选择被测的APP工程，如果没有不选，如图所示：&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/1bb4ffc9d37125120182d21ab5ed929b.png&quot; style=&quot;height:460px; width:414px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;然后进入下一步选择Android版本，这里建议与被测APP保持一致，然后确认完成即可。然后在Eclipse的工程目录里就能看到刚刚创建的工程。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;3. 一步步编写登录脚本&lt;/h2&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h3&gt;a. 修改AndroidManifest.xml&lt;/h3&gt;\n\n&lt;p&gt;打开刚刚创建的工程，我们能够看到AndroidManifest.xml 文件。我们需要对其进行一些修改。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/1b35928f828ecde104df9f391c795668.png&quot; style=&quot;height:293px; width:462px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;区域1是测试脚本的包名（后续测试脚本要像APP一样安装到手机上），区域2是刚刚选择的Android sdk 的版本，&amp;rdquo;14&amp;rdquo;代表Android 4.0。区域3是测试脚本的Instrumentation的名字，启动测试时要指定它。区域4是被测APP的包名，如果创建时没有选择目标APP，那么要修改区域4，把&amp;ldquo;com.jayway.test&amp;rdquo;修改为被测APP的包名。比如我们本次被测的APP的包名：&amp;ldquo;com.alibaba.mts.mtsdemoapp&amp;rdquo;&lt;/p&gt;\n\n&lt;h3&gt;b. 加入Robotium.jar（&lt;a href=&quot;/static/res/robotium-solo-5.0.1.jar&quot;&gt;下载地址&lt;/a&gt;）&lt;/h3&gt;\n\n&lt;p&gt;下载Robotium.jar，然后在测试工程目录创建一个Robotium的文件夹（其他名字也可以，但是不要使用lib这个名字，它是特殊文件夹），并将Robotium.jar拷贝过去。然后把这个jar包，加入到工程的build path中。具体方法：右键点击测试工程，选择properties，在Libraries选项中，点击Add JARs添加，如下图：&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/b92e648bd3aebfafd9d88c4e65a88735.png&quot; style=&quot;height:332px; width:473px&quot; /&gt;&lt;br /&gt;\n&amp;nbsp;&lt;br /&gt;\n添加完毕后，如下图：&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/1c10c9c6eaff724d56ff7901afc56661.png&quot; style=&quot;height:319px; width:455px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;选择Order And Export，将robotium的jar包勾选上&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/f0782c67e73d74396d1f110799916b00.JPG&quot; /&gt;&lt;/p&gt;\n\n&lt;h3&gt;c. 开始编写测试脚本&lt;/h3&gt;\n\n&lt;p&gt;在空的测试包，创建一个MtsAutomationTest.java 的文件，如下所示：&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/0b6ae333c00dbfba5067d41097b15bf7.png&quot; style=&quot;height:291px; width:297px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;然后打开MtsAutomationTest.java 并拷贝以下代码：&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;\npackage com.jayway.test.test;\n\nimport com.robotium.solo.Solo;\nimport android.test.ActivityInstrumentationTestCase2;\n\npublic class MtsAutomationTest&amp;nbsp; extends ActivityInstrumentationTestCase2 {\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; private Solo solo;\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; private final static String lanchActivity = &amp;quot;com.alibaba.mts.mtsdemoapp.MainActivity&amp;quot;;\n\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; // 通过反射的方式，找到可以启动的Activity的Class.\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; private static Class&amp;lt;?&amp;gt; launcherActivityClass;\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp; static{\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; try {\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; launcherActivityClass = Class.forName(lanchActivity);\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; } catch (ClassNotFoundException e) {\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; throw new RuntimeException(e);\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; }\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp; }\n\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; @SuppressWarnings(&amp;quot;unchecked&amp;quot;)\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; public MtsAutomationTest() throws ClassNotFoundException {\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; super(launcherActivityClass);\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; }\n\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; @Override\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; public void setUp() throws Exception {\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; //setUp() 先于测试用例的执行， 用于初始化环境\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; //solo对象在这里被创建出来\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; solo = new Solo(getInstrumentation(), getActivity());\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; }\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; @Override\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; public void tearDown() throws Exception {\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; //tearDown() 是执行完所有的测试用例之后被执行。\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; //finishOpenedActivities() 会终止在测试期间打开的所有的activities.\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; solo.finishOpenedActivities();\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; }&amp;nbsp;\n\n}&amp;nbsp;\n&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;把launchActivity字符串替换为，被测APP的launchable-activity，比如本次使用的APP的启动Activity：&amp;ldquo;com.alibaba.mts.mtsdemoapp.MainActivity&amp;rdquo;。&lt;/p&gt;\n\n&lt;p&gt;然后，我们在MtsAutomationTest.java文件中添加一条测试用例: 添加一个函数testLogin（所有的测试case的函数名都要以test开始，testXXX的格式）:&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;\npublic void testLogin() throws Exception {\n&amp;nbsp;&amp;nbsp; &amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;nbsp;// 启动之后，等待5s，UI界面稳定下来\n&amp;nbsp;&amp;nbsp; &amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;nbsp;solo.sleep(5000);\n&amp;nbsp;&amp;nbsp; &amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;nbsp;// 图例3.3.1：在文字&amp;ldquo;Tab4&amp;rdquo;上点击，进入登录页\n&amp;nbsp;&amp;nbsp; &amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;nbsp;solo.clickOnText(&amp;quot;Tab4&amp;quot;);\n&amp;nbsp;&amp;nbsp; &amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;nbsp;// Activity切换时，最好等待一会儿。否则，某些异步元素可能还没加载\n&amp;nbsp;&amp;nbsp; &amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;nbsp;solo.sleep(5000);\n&amp;nbsp;&amp;nbsp; &amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;nbsp;// 图例3.3.2：此Activity中只有两个EditText控件，索引0是用户名控件。\n&amp;nbsp;&amp;nbsp; &amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;nbsp;EditText user = solo.getEditText(0);\n&amp;nbsp;&amp;nbsp; &amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;nbsp;// enterText用于向EditText控件中输入内容，用户名为：admin\n&amp;nbsp;&amp;nbsp; &amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;nbsp;solo.enterText(user, &amp;quot;admin&amp;quot;);\n&amp;nbsp;&amp;nbsp; &amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;nbsp;//图例3.3.2：索引1是密码控件\n&amp;nbsp;&amp;nbsp; &amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;nbsp;EditText pwd &amp;nbsp;= solo.getEditText(1);\n&amp;nbsp;&amp;nbsp; &amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;nbsp;\n&amp;nbsp;&amp;nbsp; &amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;nbsp;// 密码也是：admin\n&amp;nbsp;&amp;nbsp; &amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;nbsp;solo.enterText(pwd, &amp;quot;admin&amp;quot;);\n&amp;nbsp;&amp;nbsp; &amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;nbsp;\n&amp;nbsp;&amp;nbsp; &amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;nbsp;// 点击包含&amp;ldquo;登录&amp;rdquo;文字的控件。如果Activity中包含多个&amp;ldquo;登录&amp;rdquo;，我们需要指定控件索引，像下面数字2。这个索引可能需要尝试几次获取。\n&amp;nbsp;&amp;nbsp; &amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;nbsp;solo.clickOnText(&amp;quot;登陆&amp;quot;, 2);\n&amp;nbsp;&amp;nbsp; &amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;nbsp;\n&amp;nbsp;&amp;nbsp; &amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;nbsp;// 图例3.3.3: 测试完成之后，等待5s结束。一般登录需要跟后台交互，这里的等待是这个目的。\n&amp;nbsp;&amp;nbsp; &amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;nbsp;solo.sleep(5000);\n&amp;nbsp;&amp;nbsp; &amp;nbsp;}\n\n&lt;/code&gt;\n&lt;/pre&gt;\n\n&lt;p&gt;除了，上面几种获取控件的方法，还有一种常用的，通过resource-id获取控件的方法：&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;\nActivity act=solo.getCurrentActivity();\nTextView loginView = (TextView) solo.getView(act.getResources().getIdentifier(&amp;quot;login&amp;quot;, &amp;quot;id&amp;quot;, act.getPackageName()))\n&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;&amp;ldquo;login&amp;rdquo;是一个密码框的resource-id, 我们通过上面这种方式就能获取到这个控件对象。&lt;/p&gt;\n\n&lt;p&gt;然后，可以用solo.enterText(loginView, &amp;ldquo;密码xxx&amp;rdquo;); 进行密码输入。&lt;/p&gt;\n\n&lt;h3&gt;注：其他更多的Robotium API，请参见&lt;a href=&quot;http://robotium.googlecode.com/svn/doc/index.html&quot;&gt; Robotium官方文档&lt;/a&gt;。（如果访问不了，请加 &amp;rdquo; 74.125.71.94 &amp;nbsp;code.google.com&amp;rdquo;到host文件中）&lt;/h3&gt;\n\n&lt;h3&gt;项目编译完之后是一个APK包。&lt;/h3&gt;\n\n&lt;p&gt;图3.3.1 点击&amp;ldquo;Tab 4&amp;rdquo;：&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/5d38124b1ef17610f2c273bf149c0303.png&quot; style=&quot;height:309px; width:410px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;图3.3.2 进入登录页：&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/fab2404579b1ffc79bd9ee4e60725ebf.png&quot; style=&quot;height:298px; width:397px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;图3.3.3 登录完成页：&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/e9a466c9caa11d3979c7c2c403fea222.png&quot; style=&quot;height:298px; width:395px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;4.&amp;nbsp;签名&lt;/h2&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;签名就是为了标志自己，为自己的程序打上标记，让别人看到签名的时候知道这个是跟你有关的（不管是程序，还是其他的签名都是如此的作用）。&lt;/p&gt;\n\n&lt;p&gt;Android App签名是Android系统要求，Android系统要求每一个应用程序必须要经过数字签名才能安装到应用系统中，如果不进行数字签名，是没有办法安装到应用系统中的！Android通过数字签名来标识应用程序的作者和在应用程序之间建立信任关系，Android由应用程序的作者完成，并不需要权威认证，只是用来让应用程序包自我认证的。&lt;/p&gt;\n\n&lt;p&gt;为了保持被测APP和脚本APP签名一致，我们需要对被测APP进行重签或者脚本APP进行重签：&lt;/p&gt;\n\n&lt;h3&gt;a.&amp;nbsp;我是被测APP的开发者，有被测APP的签名文件&lt;/h3&gt;\n\n&lt;p&gt;这种情况可以对刚刚开发的脚本APP进行重签：&lt;/p&gt;\n\n&lt;p&gt;方法：Eclipse内右键测试工程 -&amp;gt; 选择&amp;ldquo;Android 工具&amp;rdquo;（Android Tools）-&amp;gt; 导出签名的应用包（Export Signed Application Package）&lt;/p&gt;\n\n&lt;p&gt;重签脚本App如图：&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/121664f82d082c128968a5a4eb915c3e.png&quot; style=&quot;height:349px; width:404px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;然后，选择自己的签名文件地址，并输入签名的密码进行导出即可。&lt;/p&gt;\n\n&lt;h3&gt;b. 我不知道被测APP的签名信息&lt;/h3&gt;\n\n&lt;p&gt;如果没有被测APP的签名文件信息，我们需要对被测APP进行重签名操作。具体步骤：&lt;/p&gt;\n\n&lt;p&gt;(1). 找到被测APP，修改文件后缀，&amp;ldquo;apk&amp;rdquo; =&amp;gt; &amp;ldquo;zip&amp;rdquo;&lt;/p&gt;\n\n&lt;p&gt;(2). 打开zip文件，不需要解压，直接删除&amp;ldquo;META-INF&amp;rdquo;目录，并恢复文件后缀为&amp;rdquo;apk&amp;rdquo;&lt;/p&gt;\n\n&lt;p&gt;(3). 执行重签命令：&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;Jarsigner -verbose -digestalg SHA1 &amp;ndash;sigalg MD5withRSA -keystore 用户目录/.android/debug.keystore &amp;nbsp;被测APP.apk &amp;nbsp;androiddebugkey\n&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;在弹出框内输入密码：android，然后回车。&lt;/p&gt;\n\n&lt;h3&gt;注意：&amp;ldquo;用户目录&amp;rdquo;指的是：win下，&amp;rdquo;C:\\Users\\xxxx\\&amp;rdquo;, 类unix下：/home/xxx/。&lt;/h3&gt;\n\n&lt;p&gt;上面我们用的是Eclipse默认的debug签名文件进行的签名，它的aliasName是androiddebugkey，密码是：android。&lt;/p&gt;\n\n&lt;p&gt;(4). 执行命令：jarsigner -verify 被测APP.apk&lt;/p&gt;\n\n&lt;p&gt;(5). 执行命令：zipalign -v 4 被测APP.apk &amp;nbsp;重签好的APP.apk。如果找不到zipalign, 可以把&amp;ldquo;adt目录/build-tools/android-xxxx&amp;rdquo;加入到环境变量中。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;5. 在Android设备上启动测试&lt;/h2&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;在重签名之后，我们把重签后的被测APP和脚本APP分别安装到手机或者模拟器上（可以使用adb install xxx.apk）。然后再命令行中执行命令：&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;adb shell am instrument -w com.jayway.test.test/android.test.InstrumentationTestRunner\n&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;测试完成后，可以看到有相应的测试结果生成。如果有错误，可以根据error trace进行测试代码修改。这里的&amp;rdquo;com.jayway.test.test&amp;ldquo;是测试APP的包名；&amp;rdquo;android.test.InstrumentationTestRunner&amp;rdquo; 是TestRunner的名字，用来启动测试。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;6. 上传到MQC云端进行测试，并查看测试结果&lt;/h2&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;确认在本地测试通过后，在MQC移动云测试服务的网站上，打开兼容性或者稳定性测试，先上传被测APP，然后在高级设置里上传登录脚本。并填写通知的旺旺和邮箱。&lt;/p&gt;\n\n&lt;p&gt;完毕后，下一步选择想要进行测试的机型，之后提交测试就可以了。&lt;/p&gt;\n\n&lt;p&gt;测试完成后，会用旺旺和邮箱通知您。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;7. 常见问题&lt;/h2&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;1）java.lang.NoClassDefFoundError: com.robotium.solo.Solo，找不到Solo类&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/85420ef42a9bbace289a1805938fb726.jpg&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;此问题是因为robotium的jar包未被打入apk内，解决方法是在Java Build Path的Order and Export内，将robotium的jar包选中。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/f0782c67e73d74396d1f110799916b00.JPG&quot; style=&quot;height:561px; width:746px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;（感谢网友cokeliang提供该问题的解决方案）&lt;/p&gt;\n\n&lt;p&gt;2），&lt;strong&gt;Errors running builder \'Android Resource Manager\' on project XXX&lt;/strong&gt;&lt;/p&gt;\n\n&lt;p&gt;解决方案：&lt;/p&gt;\n\n&lt;p&gt;（1）在项目文件夹中建立一个project.properties文件。&lt;/p&gt;\n\n&lt;p&gt;（2）&amp;nbsp;输入内容&amp;ldquo;target=android-XXX&amp;rdquo;，这个android-XXX&amp;nbsp;要查看一下你的Android SDK Manager里面显示的是多少。比如，我的是22&lt;/p&gt;\n\n&lt;p&gt;（3）保存文件后，重启Eclipse。此时Android默认的库就能显示到项目中了。&lt;/p&gt;\n\n&lt;p&gt;（4）此时便可以进行下面的操作了，而且也不会再报&amp;ldquo;&lt;strong&gt;Errors running builder \'Android Resource Manager\' on project XXX&lt;/strong&gt;&amp;rdquo;错误了！&lt;/p&gt;','脚本编写','MTS','刚刚我们学习了，如何使用UI Automator Viewer进行APP UI控件的查看。用Robotium框架编写测试用例，本质上就是使用Robotium的API，对找到的一个个控件进行有序的操作（点击、拖拽、滑动）。\n\n下面我们通过一个例子(示例APP)，来学习如何用Robotium编写登录APP的自动化脚本。通过这个例子也能了解到Robotium的自动化测试是如何工作的。\n\n \n\n1. 准备Android 开发环境\n\n \n\n如果已经有了Android开发环境就可以略过这一步，直接查看第二步。\n\n配置Android 需要安装Eclipse (最新版即可,目前是luna) 和JDK 6，然后参考Android官方说明安装Eclipse 的adt插件。\n\n \n\n2. 在Eclipse中创建测试用例\n\n \n\na. 创建一个空白的Android测试工程。\n\n点击File -> New -> Project，然后再弹出框内选择Android->Android Test Project。\n\n\n\n点击Next到下一步，输入工程名称，比如MtsAutomationTest, 然后下一步，可以选择被测的APP工程，如果没有不选，如图所示：\n\n\n\n然后进入下一步选择Android版本，这里建议与被测APP保持一致，然后确认完成即可。然后在Eclipse的工程目录里就能看到刚刚创建的工程。\n\n \n\n3. 一步步编写登录脚本\n\n \n\na. 修改AndroidManifest.xml\n\n打开刚刚创建的工程，我们能够看到AndroidManifest.xml 文件。我们需要对其进行一些修改。\n\n\n\n区域1是测试脚本的包名（后续测试脚本要像APP一样安装到手机上），区域2是刚刚选择的Android sdk 的版本，”14”代表Android 4.0。区域3是测试脚本的Instrumentation的名字，启动测试时要指定它。区域4是被测APP的包名，如果创建时没有选择目标APP，那么要修改区域4，把“com.jayway.test”修改为被测APP的包名。比如我们本次被测的APP的包名：“com.alibaba.mts.mtsdemoapp”\n\nb. 加入Robotium.jar（下载地址）\n\n下载Robotium.jar，然后在测试工程目录创建一个Robotium的文件夹（其他名字也可以，但是不要使用lib这个名字，它是特殊文件夹），并将Robotium.jar拷贝过去。然后把这个jar包，加入到工程的build path中。具体方法：右键点击测试工程，选择properties，在Libraries选项中，点击Add JARs添加，如下图：\n\n\n \n添加完毕后，如下图：\n\n\n\n选择Order And Export，将robotium的jar包勾选上\n\n\n\nc. 开始编写测试脚本\n\n在空的测试包，创建一个MtsAutomationTest.java 的文件，如下所示： \n\n\n\n然后打开MtsAutomationTest.java 并拷贝以下代码：\n\n\n\npackage com.jayway.test.test;\n\nimport com.robotium.solo.Solo;\nimport android.test.ActivityInstrumentationTestCase2;\n\npublic class MtsAutomationTest&nbsp; extends ActivityInstrumentationTestCase2 {\n\n&nbsp;&nbsp;&nbsp;&nbsp; private Solo solo;\n\n&nbsp;&nbsp;&nbsp;&nbsp; private final static String lanchActivity = &quot;com.alibaba.mts.mtsdemoapp.MainActivity&quot;;\n\n\n&nbsp;&nbsp;&nbsp;&nbsp; // 通过反射的方式，找到可以启动的Activity的Class.\n\n&nbsp;&nbsp;&nbsp;&nbsp; private static Class&lt;?&gt; launcherActivityClass;\n\n&nbsp;&nbsp;&nbsp; static{\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; try {\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; launcherActivityClass = Class.forName(lanchActivity);\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; } catch (ClassNotFoundException e) {\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; throw new RuntimeException(e);\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; }\n\n&nbsp;&nbsp;&nbsp; }\n\n\n&nbsp;&nbsp;&nbsp;&nbsp; @SuppressWarnings(&quot;unchecked&quot;)\n\n&nbsp;&nbsp;&nbsp;&nbsp; public MtsAutomationTest() throws ClassNotFoundException {\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; super(launcherActivityClass);\n\n&nbsp;&nbsp;&nbsp;&nbsp; }\n\n\n&nbsp;&nbsp;&nbsp;&nbsp; @Override\n\n&nbsp;&nbsp;&nbsp;&nbsp; public void setUp() throws Exception {\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; //setUp() 先于测试用例的执行， 用于初始化环境\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; //solo对象在这里被创建出来\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; solo = new Solo(getInstrumentation(), getActivity());\n\n&nbsp;&nbsp;&nbsp;&nbsp; }\n\n&nbsp;&nbsp;&nbsp;&nbsp; @Override\n\n&nbsp;&nbsp;&nbsp;&nbsp; public void tearDown() throws Exception {\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; //tearDown() 是执行完所有的测试用例之后被执行。\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; //finishOpenedActivities() 会终止在测试期间打开的所有的activities.\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; solo.finishOpenedActivities();\n\n&nbsp;&nbsp;&nbsp;&nbsp; }&nbsp;\n\n}&nbsp;\n\n\n把launchActivity字符串替换为，被测APP的launchable-activity，比如本次使用的APP的启动Activity：“com.alibaba.mts.mtsdemoapp.MainActivity”。\n\n然后，我们在MtsAutomationTest.java文件中添加一条测试用例: 添加一个函数testLogin（所有的测试case的函数名都要以test开始，testXXX的格式）:\n\n \n\n\n\npublic void testLogin() throws Exception {\n&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;// 启动之后，等待5s，UI界面稳定下来\n&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;solo.sleep(5000);\n&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;// 图例3.3.1：在文字&ldquo;Tab4&rdquo;上点击，进入登录页\n&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;solo.clickOnText(&quot;Tab4&quot;);\n&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;// Activity切换时，最好等待一会儿。否则，某些异步元素可能还没加载\n&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;solo.sleep(5000);\n&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;// 图例3.3.2：此Activity中只有两个EditText控件，索引0是用户名控件。\n&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;EditText user = solo.getEditText(0);\n&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;// enterText用于向EditText控件中输入内容，用户名为：admin\n&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;solo.enterText(user, &quot;admin&quot;);\n&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;//图例3.3.2：索引1是密码控件\n&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;EditText pwd &nbsp;= solo.getEditText(1);\n&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;\n&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;// 密码也是：admin\n&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;solo.enterText(pwd, &quot;admin&quot;);\n&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;\n&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;// 点击包含&ldquo;登录&rdquo;文字的控件。如果Activity中包含多个&ldquo;登录&rdquo;，我们需要指定控件索引，像下面数字2。这个索引可能需要尝试几次获取。\n&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;solo.clickOnText(&quot;登陆&quot;, 2);\n&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;\n&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;// 图例3.3.3: 测试完成之后，等待5s结束。一般登录需要跟后台交互，这里的等待是这个目的。\n&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;solo.sleep(5000);\n&nbsp;&nbsp; &nbsp;}\n\n\n\n\n除了，上面几种获取控件的方法，还有一种常用的，通过resource-id获取控件的方法：\n\n\n\nActivity act=solo.getCurrentActivity();\nTextView loginView = (TextView) solo.getView(act.getResources().getIdentifier(&quot;login&quot;, &quot;id&quot;, act.getPackageName()))\n\n\n \n\n“login”是一个密码框的resource-id, 我们通过上面这种方式就能获取到这个控件对象。\n\n然后，可以用solo.enterText(loginView, “密码xxx”); 进行密码输入。\n\n注：其他更多的Robotium API，请参见 Robotium官方文档。（如果访问不了，请加 ” 74.125.71.94  code.google.com”到host文件中）\n\n项目编译完之后是一个APK包。\n\n图3.3.1 点击“Tab 4”：\n\n\n\n图3.3.2 进入登录页：\n\n\n\n图3.3.3 登录完成页：\n\n\n\n \n\n4. 签名\n\n \n\n签名就是为了标志自己，为自己的程序打上标记，让别人看到签名的时候知道这个是跟你有关的（不管是程序，还是其他的签名都是如此的作用）。\n\nAndroid App签名是Android系统要求，Android系统要求每一个应用程序必须要经过数字签名才能安装到应用系统中，如果不进行数字签名，是没有办法安装到应用系统中的！Android通过数字签名来标识应用程序的作者和在应用程序之间建立信任关系，Android由应用程序的作者完成，并不需要权威认证，只是用来让应用程序包自我认证的。\n\n为了保持被测APP和脚本APP签名一致，我们需要对被测APP进行重签或者脚本APP进行重签：\n\na. 我是被测APP的开发者，有被测APP的签名文件\n\n这种情况可以对刚刚开发的脚本APP进行重签：\n\n方法：Eclipse内右键测试工程 -> 选择“Android 工具”（Android Tools）-> 导出签名的应用包（Export Signed Application Package）\n\n重签脚本App如图：\n\n\n\n然后，选择自己的签名文件地址，并输入签名的密码进行导出即可。\n\nb. 我不知道被测APP的签名信息\n\n如果没有被测APP的签名文件信息，我们需要对被测APP进行重签名操作。具体步骤：\n\n(1). 找到被测APP，修改文件后缀，“apk” => “zip”\n\n(2). 打开zip文件，不需要解压，直接删除“META-INF”目录，并恢复文件后缀为”apk”\n\n(3). 执行重签命令：\n\n\nJarsigner -verbose -digestalg SHA1 &ndash;sigalg MD5withRSA -keystore 用户目录/.android/debug.keystore &nbsp;被测APP.apk &nbsp;androiddebugkey\n\n\n在弹出框内输入密码：android，然后回车。\n\n注意：“用户目录”指的是：win下，”C:\\Users\\xxxx\\”, 类unix下：/home/xxx/。\n\n上面我们用的是Eclipse默认的debug签名文件进行的签名，它的aliasName是androiddebugkey，密码是：android。\n\n(4). 执行命令：jarsigner -verify 被测APP.apk\n\n(5). 执行命令：zipalign -v 4 被测APP.apk  重签好的APP.apk。如果找不到zipalign, 可以把“adt目录/build-tools/android-xxxx”加入到环境变量中。\n\n \n\n5. 在Android设备上启动测试\n\n \n\n在重签名之后，我们把重签后的被测APP和脚本APP分别安装到手机或者模拟器上（可以使用adb install xxx.apk）。然后再命令行中执行命令：\n\n\nadb shell am instrument -w com.jayway.test.test/android.test.InstrumentationTestRunner\n\n\n测试完成后，可以看到有相应的测试结果生成。如果有错误，可以根据error trace进行测试代码修改。这里的”com.jayway.test.test“是测试APP的包名；”android.test.InstrumentationTestRunner” 是TestRunner的名字，用来启动测试。\n\n \n\n6. 上传到MQC云端进行测试，并查看测试结果\n\n \n\n确认在本地测试通过后，在MQC移动云测试服务的网站上，打开兼容性或者稳定性测试，先上传被测APP，然后在高级设置里上传登录脚本。并填写通知的旺旺和邮箱。\n\n完毕后，下一步选择想要进行测试的机型，之后提交测试就可以了。\n\n测试完成后，会用旺旺和邮箱通知您。\n\n \n\n7. 常见问题\n\n \n\n1）java.lang.NoClassDefFoundError: com.robotium.solo.Solo，找不到Solo类\n\n\n\n此问题是因为robotium的jar包未被打入apk内，解决方法是在Java Build Path的Order and Export内，将robotium的jar包选中。\n\n\n\n（感谢网友cokeliang提供该问题的解决方案）\n\n2），Errors running builder \'Android Resource Manager\' on project XXX\n\n解决方案：\n\n（1）在项目文件夹中建立一个project.properties文件。\n\n（2） 输入内容“target=android-XXX”，这个android-XXX 要查看一下你的Android SDK Manager里面显示的是多少。比如，我的是22\n\n（3）保存文件后，重启Eclipse。此时Android默认的库就能显示到项目中了。\n\n（4）此时便可以进行下面的操作了，而且也不会再报“Errors running builder \'Android Resource Manager\' on project XXX”错误了！',0,5,3),(9,'2015-04-21 20:36:32','2017-03-01 16:14:17','&lt;h2&gt;1. 如何提交兼容性测试：&lt;/h2&gt;\n\n&lt;p&gt;1) 在首页点击&amp;rdquo;兼容性测试&amp;ldquo;进入功能页面，即可开始兼容性测试；&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/59f4bc812e8010d9b567423fea0a2dbc.png&quot; style=&quot;height:417px; width:800px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;2) 测试流程图：&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;测试流程图&quot; src=&quot;/static/res/b08223105a597fe6eebd294b79ed08b6.png&quot; style=&quot;height:645px; width:313px&quot; /&gt;&lt;/p&gt;\n\n&lt;h2&gt;&lt;br /&gt;\n2. 如何提交稳定性测试：&lt;/h2&gt;\n\n&lt;p&gt;&amp;nbsp;1) 在首页点击&amp;rdquo;稳定性测试&amp;ldquo;进入功能页面，即可开始稳定性测试；&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;img alt=&quot;&quot; src=&quot;/static/res/35478d5fc83afac71088d95f8814c880.png&quot; style=&quot;height:455px; width:800px&quot; /&gt;&lt;br /&gt;\n&amp;nbsp;2) 流程图同兼容性测试&lt;/p&gt;\n\n&lt;h2&gt;&lt;br /&gt;\n3. 如何提交H5测试：&lt;/h2&gt;\n\n&lt;p&gt;1) 在首页点击&amp;rdquo;H5测试&amp;ldquo;进入功能页面，即可开始H5测试；&lt;/p&gt;\n\n&lt;p&gt;2) 流程图如下：&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;H5流程图&quot; src=&quot;/static/res/3cf9d0f4f8873e1a4b377fbab14aef64.png&quot; style=&quot;height:553px; width:348px&quot; /&gt;&lt;/p&gt;','功能使用','MTS','1. 如何提交兼容性测试：\n\n1) 在首页点击”兼容性测试“进入功能页面，即可开始兼容性测试；\n\n\n\n2) 测试流程图：\n\n\n\n\n2. 如何提交稳定性测试：\n\n 1) 在首页点击”稳定性测试“进入功能页面，即可开始稳定性测试；\n\n \n 2) 流程图同兼容性测试\n\n\n3. 如何提交H5测试：\n\n1) 在首页点击”H5测试“进入功能页面，即可开始H5测试；\n\n2) 流程图如下：\n\n',0,4,1),(10,'2015-04-21 20:37:14','2015-09-22 21:17:07','&lt;p&gt;&lt;strong&gt;兼容性测试&lt;/strong&gt;：Android系统版本繁多，再加上各个厂商定制化的修改，使得Android碎片化问题非常严重。开发者需要花大量的金钱购买各类真机设备，花大量时间在不同的Android设备上进行测试，程序崩溃问题依然严重。兼容性测试就是解决这一问题。用户只需上传应用包，然后直接选择真机设备，即可提交到云端进行测试。兼容性测试会帮用户自动的在选择的真机终端上进行安装测试、启动测试、压力测试、卸载测试，最后把整体的兼容性报告、所有崩溃隐患的详细信息全部呈现给开发者，让开发者足不出户，便能体验到极致的测试服务。&lt;/p&gt;\n\n&lt;p&gt;&lt;strong&gt;稳定性测试&lt;/strong&gt;：业界普遍认为，Android 应用的质量参差不齐。明明已经经过测试的APP在发布后，依然在用户的设备上出现各类问题，大大影响APP的用户体验。这类问题通常隐藏比较深，短时间的压力测试、普通的功能测试都难以发现其踪迹。这种情况下，我们提供稳定性测试，在主流Android系统的模拟器上进行长达数个小时的不间断测试，即便Bug隐藏再深，也能把它抓住。&lt;/p&gt;\n\n&lt;p&gt;&lt;strong&gt;H5测试&lt;/strong&gt;： H5应用已经到了与Native应用平分天下的地位，越来越多的开发者愿意将精力投入到更加方便、轻量的H5应用上去。同时，H5应用的兼容性、性能等问题愈发值得重视。H5测试为开发者提供真机上H5应用的兼容性和性能测试，同时智能地遍历H5应用所有下级页面，并且给出H5应用待优化的点，让开发者快乐开发。&lt;/p&gt;\n\n&lt;p&gt;&lt;strong&gt;遍历测试&lt;/strong&gt;： 与压力测试（一般通过monkey)不同，遍历测试追求的是高覆盖率，在单位时间内，尽量多的覆盖Activity。遍历测试需要重签名，所以需要开发者上传没有签名校验版本的Apk。同时，App重签需要花费一定时间，一般在1分钟左右，请耐心等待。&lt;/p&gt;\n\n&lt;p&gt;&lt;strong&gt;ANR&lt;/strong&gt;：如果应用对输入事件(例如硬件点击或者屏幕触摸事件)在5秒内无响应，或者BroadReceiver不能够在10秒内结束接收到任务，就会发生ANR（程序无响应）。一般由在UI线程中执行了数据库、IO、网络等耗时的操作而无法响应输入事件引起。&lt;/p&gt;\n\n&lt;p&gt;&lt;strong&gt;Crash&lt;/strong&gt;：应用在运行过程中，出现异常退出。&lt;/p&gt;\n\n&lt;p&gt;&lt;strong&gt;Monkey测试&lt;/strong&gt;：Monkey是Android中的一个命令行工具，可以运行在模拟器里或实际设备中。它向系统发送伪随机的用户事件流(如按键输入、触摸屏输入、手势输入等)，实现对正在开发的应用程序进行压力测试。Monkey测试是一种为了测试软件的稳定性、健壮性的快速有效的方法。&lt;/p&gt;\n\n&lt;p&gt;&lt;strong&gt;CPU时间&lt;/strong&gt;：操作系统调度CPU交替的执行不同进程，一个进程的CPU时间就是指CPU在该进程上执行的所有时长的总和。&lt;/p&gt;\n\n&lt;p&gt;&lt;strong&gt;H5首屏加载&lt;/strong&gt;： H5页面加载完首屏所有资源、包括css、js、图片、数据等所消耗的时间。关于H5性能优化，可以参考这里的一些资料：http://club.alibabatech.org/salon_detail.htm?salonId=52。&lt;/p&gt;\n\n&lt;p&gt;&lt;strong&gt;DOM加载&lt;/strong&gt;：webView onPageStart到onPageFinished的时间。&lt;/p&gt;\n\n&lt;p&gt;&lt;strong&gt;非CDN资源&lt;/strong&gt;：CDN是构建在网络之上的内容分发网络，依靠部署在各地的边缘服务器，通过中心平台的负载均衡、内容分发、调度等功能模块，使用户就近获取所需内容，降低网络拥塞，提高用户访问响应速度和命中率。非CDN资源就是没有使用CDN的资源，加载资源时需要通过DNS层层解析。&lt;/p&gt;\n\n&lt;p&gt;&lt;strong&gt;无时间戳资源&lt;/strong&gt;：HTTP请求时没有在Header里面带上modify time和expire time这样的信息，在请求时从缓存里面找不到匹配的资源，需要重新加载，会耗用更多的流量和时间。&lt;/p&gt;\n\n&lt;p&gt;&lt;strong&gt;浏览器兼容性测试：&lt;/strong&gt;浏览器兼容性目前支持QQ、百度、UC、360四类移动端浏览器。MQC会在您选择的设备上，分别用这四款移动浏览器加载目标网页，并在加载完成后，向上滑动2次网页，分别截取H5应用图片。从而，帮助您查看在不同浏览器上的H5应用兼容性情况。&lt;/p&gt;','名词解释','MTS','兼容性测试：Android系统版本繁多，再加上各个厂商定制化的修改，使得Android碎片化问题非常严重。开发者需要花大量的金钱购买各类真机设备，花大量时间在不同的Android设备上进行测试，程序崩溃问题依然严重。兼容性测试就是解决这一问题。用户只需上传应用包，然后直接选择真机设备，即可提交到云端进行测试。兼容性测试会帮用户自动的在选择的真机终端上进行安装测试、启动测试、压力测试、卸载测试，最后把整体的兼容性报告、所有崩溃隐患的详细信息全部呈现给开发者，让开发者足不出户，便能体验到极致的测试服务。\n\n稳定性测试：业界普遍认为，Android 应用的质量参差不齐。明明已经经过测试的APP在发布后，依然在用户的设备上出现各类问题，大大影响APP的用户体验。这类问题通常隐藏比较深，短时间的压力测试、普通的功能测试都难以发现其踪迹。这种情况下，我们提供稳定性测试，在主流Android系统的模拟器上进行长达数个小时的不间断测试，即便Bug隐藏再深，也能把它抓住。\n\nH5测试： H5应用已经到了与Native应用平分天下的地位，越来越多的开发者愿意将精力投入到更加方便、轻量的H5应用上去。同时，H5应用的兼容性、性能等问题愈发值得重视。H5测试为开发者提供真机上H5应用的兼容性和性能测试，同时智能地遍历H5应用所有下级页面，并且给出H5应用待优化的点，让开发者快乐开发。\n\n遍历测试： 与压力测试（一般通过monkey)不同，遍历测试追求的是高覆盖率，在单位时间内，尽量多的覆盖Activity。遍历测试需要重签名，所以需要开发者上传没有签名校验版本的Apk。同时，App重签需要花费一定时间，一般在1分钟左右，请耐心等待。\n\nANR：如果应用对输入事件(例如硬件点击或者屏幕触摸事件)在5秒内无响应，或者BroadReceiver不能够在10秒内结束接收到任务，就会发生ANR（程序无响应）。一般由在UI线程中执行了数据库、IO、网络等耗时的操作而无法响应输入事件引起。\n\nCrash：应用在运行过程中，出现异常退出。\n\nMonkey测试：Monkey是Android中的一个命令行工具，可以运行在模拟器里或实际设备中。它向系统发送伪随机的用户事件流(如按键输入、触摸屏输入、手势输入等)，实现对正在开发的应用程序进行压力测试。Monkey测试是一种为了测试软件的稳定性、健壮性的快速有效的方法。\n\nCPU时间：操作系统调度CPU交替的执行不同进程，一个进程的CPU时间就是指CPU在该进程上执行的所有时长的总和。\n\nH5首屏加载： H5页面加载完首屏所有资源、包括css、js、图片、数据等所消耗的时间。关于H5性能优化，可以参考这里的一些资料：http://club.alibabatech.org/salon_detail.htm?salonId=52。\n\nDOM加载：webView onPageStart到onPageFinished的时间。\n\n非CDN资源：CDN是构建在网络之上的内容分发网络，依靠部署在各地的边缘服务器，通过中心平台的负载均衡、内容分发、调度等功能模块，使用户就近获取所需内容，降低网络拥塞，提高用户访问响应速度和命中率。非CDN资源就是没有使用CDN的资源，加载资源时需要通过DNS层层解析。\n\n无时间戳资源：HTTP请求时没有在Header里面带上modify time和expire time这样的信息，在请求时从缓存里面找不到匹配的资源，需要重新加载，会耗用更多的流量和时间。\n\n浏览器兼容性测试：浏览器兼容性目前支持QQ、百度、UC、360四类移动端浏览器。MQC会在您选择的设备上，分别用这四款移动浏览器加载目标网页，并在加载完成后，向上滑动2次网页，分别截取H5应用图片。从而，帮助您查看在不同浏览器上的H5应用兼容性情况。',0,4,2),(11,'2015-04-21 20:38:02','2016-10-11 12:31:39','&lt;h2&gt;技术问题及解答：&lt;/h2&gt;\n\n&lt;p&gt;1. &lt;strong&gt;INSTALL_PARSE_FAILED_INCONSISTENT_CERTIFICATES&lt;/strong&gt;&lt;/p&gt;\n\n&lt;p&gt;由于APP签名冲突造成。如果设备上已经安装了其他签名的相同包名APP，再安装其他签名的就会报出此类错误。&lt;/p&gt;\n\n&lt;p&gt;解决方法：a. 更换签名文件，重新签名 b. 更改应用的包名，避免冲突。&lt;/p&gt;\n\n&lt;p&gt;2. &lt;strong&gt;INSTALL_FAILED_DEXOPT&lt;/strong&gt;&lt;/p&gt;\n\n&lt;p&gt;方法数超标所导致。dx打包时限制了单个dx文件的最大方法数为65535。同时Dalvik VM限制内存中加载的方法数（方法，类定义及构造函数）不能超过65535个。&lt;/p&gt;\n\n&lt;p&gt;解决方法：a. 检查代码，删出无用jar包和代码，尤其是自动生成的get/set，没用的类。b. 将部分java代码封装到JNI中。&lt;/p&gt;\n\n&lt;p&gt;3. &lt;strong&gt;INSTALL_PARSE_FAILED_NO_CERTIFICATES&lt;/strong&gt;&lt;/p&gt;\n\n&lt;p&gt;应用中没有签名信息。&lt;/p&gt;\n\n&lt;p&gt;解决方法：使用Eclipse或者Android Studio对项目重新编译打包。&lt;/p&gt;\n\n&lt;p&gt;4. &lt;strong&gt;INSTALL_FAILED_MEDIA_UNAVAILABLE&lt;/strong&gt;&lt;/p&gt;\n\n&lt;p&gt;Android应用安装位置不可用。应用安装位置有两个：ROM、sdcard。如果严格指定安装到sdcard，但是设备没有sdcard时，就会报此类错误。&lt;/p&gt;\n\n&lt;p&gt;解决方法：AndroidManifest.xml中配置：&amp;lt;manifest xmlns:android=&amp;quot;http://schemas.android.com/apk/res/android&amp;quot; android:installLocation=&amp;quot;auto&amp;quot; &amp;gt;&amp;lt;/mainfest&amp;gt;&lt;/p&gt;\n\n&lt;p&gt;5. &lt;strong&gt;INSTALL_FAILED_OLDER_SDK&lt;/strong&gt;&lt;/p&gt;\n\n&lt;p&gt;设备系统版本比应用的最低支持的系统版本低。&lt;/p&gt;\n\n&lt;p&gt;解决方法：AndoidManifest.xml中将&amp;lt;uses-sdk android:minSdkVersion=&amp;quot;xxx&amp;quot; /&amp;gt;系统版本降低。&lt;/p&gt;\n\n&lt;p&gt;6. &lt;strong&gt;INSTALL_FAILED_VERSION_DOWNGRADE&lt;/strong&gt;&lt;/p&gt;\n\n&lt;p&gt;设备中已经安装了此APP的更高版本，无法降级安装。&lt;/p&gt;\n\n&lt;p&gt;解决方法：先卸载之前的版本，再安装此版本。&lt;/p&gt;\n\n&lt;p&gt;7. &lt;strong&gt;INSTALL_PARSE_FAILED_UNEXPECTED_EXCEPTION&lt;/strong&gt;&lt;/p&gt;\n\n&lt;p&gt;安装APP时，Android系统会对APP先进行解析。解析过程出错，就会报出此类错误，可能得原因很多。&lt;/p&gt;\n\n&lt;p&gt;解决方法：检查AndroidManifest.xml各项配置是否符合规范。比如sdkVersion不能用string等等。&lt;/p&gt;\n\n&lt;p&gt;8. &lt;strong&gt;INSTALL_FAILED_UID_CHANGED&lt;/strong&gt;&lt;/p&gt;\n\n&lt;p&gt;应用在上次卸载时，由于应用中的native程序未被杀死而占用/data/data/{packageName}目录，导致/data/data/目录下的APP相关内容未被删除，多数情况下能在logcat中找到报错：Installer:&amp;nbsp;rm -rf failed， directory is not empty。再次安装时无法覆盖，导致报出此类问题。&lt;/p&gt;\n\n&lt;p&gt;解决方法：如果设备Root了，则直接删除/data/data/目录下的应用包名文件夹；如果没有root，需要将手机恢复出厂设置。此外，开发者要额外注意容易出现此类问题的手机，对此类设备的用户给出提示。用户无需操心，阿里移动测试平台会帮助解决。&lt;/p&gt;\n\n&lt;p&gt;9.&amp;nbsp;&lt;strong&gt;INSTALL_FAILED_NO_MATCHING_ABIS&lt;/strong&gt;&lt;/p&gt;\n\n&lt;p&gt;当安装的APP包含native libraries（一般是so文件）的时候，如果没有对应机器CPU架构的库文件，就会出现这种问题。比如，你编译了一个armv7平台的APP，但是想要装在intel 架构的设备上，就会出现这个错误。&lt;/p&gt;\n\n&lt;p&gt;解决方法：在编译APP时，先用NDK编译出相应的CPU架构的库文件。&lt;/p&gt;\n\n&lt;p&gt;10. &lt;strong&gt;INSTALL_FAILED_CANCELLED_BY_USER&lt;/strong&gt;&lt;/p&gt;\n\n&lt;p&gt;部分机型在使用adb命令安装应用时，设备会弹窗询问用户是否允许安装，假如一段时间内（一般是30s），没有点击确认弹窗，那么此类设备会阻止安装，并提示用户：INSTALL_FAILED_CANCELLED_BY_USER&lt;/p&gt;\n\n&lt;p&gt;解决方法：联系MQC工作人员，旺旺群：&lt;a href=&quot;http://www.taobao.com/go/act/other/wwgroup.php?spm=0.0.0.0.CNrU5u&amp;amp;uid=&amp;amp;tribeid=335334143&quot; target=&quot;_blank&quot;&gt;335334143&lt;/a&gt;；QQ群：492028798&lt;/p&gt;\n\n&lt;p&gt;11. &lt;strong&gt;INSTALL_FAILED_VERICATION_TIMEOUT&lt;/strong&gt;&lt;/p&gt;\n\n&lt;p&gt;原因及解决方法同：INSTALLED_FAILED_CANCELLED_BY_USER&lt;/p&gt;\n\n&lt;p&gt;12. &lt;strong&gt;OutOfMemory问题（OOM）解决方法&lt;/strong&gt;&lt;/p&gt;\n\n&lt;p&gt;每个Android应用都有一个最大内存上限。超过这个上限，就会导致内存不足（OutOfMemory）。检查内存上限的方法：&lt;/p&gt;\n\n&lt;p&gt;int maxMemory = (int) (Runtime.getRuntime().maxMemory() / 1024); &amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;Log.d(&amp;quot;TAG&amp;quot;, &amp;quot;Max memory is &amp;quot; + maxMemory + &amp;quot;KB&amp;quot;); &amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;通常情况下，出现OOM，是由于应用中加载了大量的图片导致。鉴于此，有以下几种方式来减小应用对内存的使用：&lt;/p&gt;\n\n&lt;p&gt;a. 合理压缩展示图片，比如一个100x100的控件里，如果加载一个1024x768的图片，不会让图片的展示效果更好，反而会增加OOM的风险。所以，合理的对图片进行压缩非常重要。&lt;/p&gt;\n\n&lt;p&gt;b. 压缩完图片，但是应用里包含了太多的图，这种情况依然可能出现OOM。这种情况下，考虑使用内存缓存技术。根据每一屏要展示的图片数量，以及每个图片的大小，设定一个合理的缓存值，一般情况下不要超过1/8的最大内存值。如果图片不在显示区域，可以考虑将其进行回收，系统的垃圾回收器（GC）会认为这些内存不在被使用，从而对图片进行GC操作。这样会大大降低OOM的风险。&lt;/p&gt;\n\n&lt;p&gt;c. 更多的OOM讨论，参见：&lt;a href=&quot;http://blog.csdn.net/vshuang/article/details/39647167&quot;&gt;http://blog.csdn.net/vshuang/article/details/39647167&lt;/a&gt;&lt;/p&gt;\n\n&lt;p&gt;13.&amp;nbsp;&lt;strong&gt;iOS应用（ipa）安装失败可能的原因和解决方法&lt;/strong&gt;&lt;/p&gt;\n\n&lt;p&gt;每个ipa包本质上是一个zip包，里面包含ios应用的资源和可执行文件。&lt;/p&gt;\n\n&lt;p&gt;a. 如果提示&amp;ldquo;应用重签名失败&amp;rdquo;，很可能的原因是ipa是直接从itunes市场下载的正式发布包，这样的包经过苹果的加密，无法安装到任何没有购买过这个应用的用户手机上面。&lt;/p&gt;\n\n&lt;p&gt;b. 如果部分的手机安装失败，请检查一下你的应用支持的最低ios SDK的版本（可以很直观的从包里面的Info.plist看到）。比如最低支持ios8.3，则ios8.2版本的手机就装不上这个应用。&lt;/p&gt;\n\n&lt;p&gt;14. &lt;strong&gt;启动失败如何进行Debug？&lt;/strong&gt;&lt;/p&gt;\n\n&lt;p&gt;很多同学遇到启动失败的问题，很难进行debug，不知道该如何入手。启动失败其实也可以找到错误栈信息，并且通过这个错误栈信息，定位到具体的问题原因。如下图：&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;启动失败截图&quot; src=&quot;/static/res/ed57342015f8838445b184e4968c998e.png&quot; style=&quot;height:181px; width:1033px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;这里，我们可以看到启动失败的进程pid：26981。然后，我们需要下载日志，这里的日志就是详细的logcat日志。&lt;/p&gt;\n\n&lt;p&gt;下载之后，我们需要通过这个PID找到真正引起crash的错误栈。这里建议，使用支持正则匹配的编辑器打开logcat日志（比如nodepad++、vim等等），打开之后，使用正则规则：&amp;ldquo;26981.* E .*&amp;rdquo; 进行匹配查找。可以找到如下信息：&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;找到的错误栈&quot; src=&quot;/static/res/7c0b99279866541efc5c3a97a1d20914.png&quot; style=&quot;height:333px; width:1003px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;这样我们就能知道具体那行代码导致的错误了。&lt;/p&gt;\n\n&lt;p&gt;15. &lt;strong&gt;常见崩溃问题，NullPointerException: Attempt to invoke virtual method \'android.content.res.Resources android.content.Context.getResources()\' on a null object reference&lt;/strong&gt;&lt;/p&gt;\n\n&lt;p&gt;该问题一般是由于资源加载时，引用初始化未完全的Context对象导致。&lt;/p&gt;\n\n&lt;p&gt;解决方法：通过增加非空检查；创建View时，使用当前组件的Context（比如ActivityXXX.this），而不用getApplicationContext()等方式。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/74d764a48948b5fac5823f46ced2a95b.png&quot; style=&quot;height:356px; width:675px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;参考资料：&lt;a href=&quot;http://stackoverflow.com/questions/28248232/what-am-i-doing-wrong-with-my-handling-of-contex-java-android&quot;&gt;http://stackoverflow.com/questions/28248232/what-am-i-doing-wrong-with-my-handling-of-contex-java-android&lt;/a&gt;&lt;/p&gt;\n\n&lt;p&gt;参考资料：&lt;a href=&quot;http://stackoverflow.com/questions/25488208/java-nullpointerexception-getting-resources&quot;&gt;http://stackoverflow.com/questions/25488208/java-nullpointerexception-getting-resources&lt;/a&gt;&lt;/p&gt;','技术解答','MTS','技术问题及解答：\n\n1. INSTALL_PARSE_FAILED_INCONSISTENT_CERTIFICATES\n\n由于APP签名冲突造成。如果设备上已经安装了其他签名的相同包名APP，再安装其他签名的就会报出此类错误。\n\n解决方法：a. 更换签名文件，重新签名 b. 更改应用的包名，避免冲突。\n\n2. INSTALL_FAILED_DEXOPT\n\n方法数超标所导致。dx打包时限制了单个dx文件的最大方法数为65535。同时Dalvik VM限制内存中加载的方法数（方法，类定义及构造函数）不能超过65535个。\n\n解决方法：a. 检查代码，删出无用jar包和代码，尤其是自动生成的get/set，没用的类。b. 将部分java代码封装到JNI中。\n\n3. INSTALL_PARSE_FAILED_NO_CERTIFICATES\n\n应用中没有签名信息。\n\n解决方法：使用Eclipse或者Android Studio对项目重新编译打包。\n\n4. INSTALL_FAILED_MEDIA_UNAVAILABLE\n\nAndroid应用安装位置不可用。应用安装位置有两个：ROM、sdcard。如果严格指定安装到sdcard，但是设备没有sdcard时，就会报此类错误。\n\n解决方法：AndroidManifest.xml中配置：<manifest xmlns:android=\"http://schemas.android.com/apk/res/android\" android:installLocation=\"auto\" ></mainfest>\n\n5. INSTALL_FAILED_OLDER_SDK\n\n设备系统版本比应用的最低支持的系统版本低。\n\n解决方法：AndoidManifest.xml中将<uses-sdk android:minSdkVersion=\"xxx\" />系统版本降低。\n\n6. INSTALL_FAILED_VERSION_DOWNGRADE\n\n设备中已经安装了此APP的更高版本，无法降级安装。\n\n解决方法：先卸载之前的版本，再安装此版本。\n\n7. INSTALL_PARSE_FAILED_UNEXPECTED_EXCEPTION\n\n安装APP时，Android系统会对APP先进行解析。解析过程出错，就会报出此类错误，可能得原因很多。\n\n解决方法：检查AndroidManifest.xml各项配置是否符合规范。比如sdkVersion不能用string等等。\n\n8. INSTALL_FAILED_UID_CHANGED\n\n应用在上次卸载时，由于应用中的native程序未被杀死而占用/data/data/{packageName}目录，导致/data/data/目录下的APP相关内容未被删除，多数情况下能在logcat中找到报错：Installer: rm -rf failed， directory is not empty。再次安装时无法覆盖，导致报出此类问题。\n\n解决方法：如果设备Root了，则直接删除/data/data/目录下的应用包名文件夹；如果没有root，需要将手机恢复出厂设置。此外，开发者要额外注意容易出现此类问题的手机，对此类设备的用户给出提示。用户无需操心，阿里移动测试平台会帮助解决。\n\n9. INSTALL_FAILED_NO_MATCHING_ABIS\n\n当安装的APP包含native libraries（一般是so文件）的时候，如果没有对应机器CPU架构的库文件，就会出现这种问题。比如，你编译了一个armv7平台的APP，但是想要装在intel 架构的设备上，就会出现这个错误。\n\n解决方法：在编译APP时，先用NDK编译出相应的CPU架构的库文件。\n\n10. INSTALL_FAILED_CANCELLED_BY_USER\n\n部分机型在使用adb命令安装应用时，设备会弹窗询问用户是否允许安装，假如一段时间内（一般是30s），没有点击确认弹窗，那么此类设备会阻止安装，并提示用户：INSTALL_FAILED_CANCELLED_BY_USER\n\n解决方法：联系MQC工作人员，旺旺群：335334143；QQ群：492028798\n\n11. INSTALL_FAILED_VERICATION_TIMEOUT\n\n原因及解决方法同：INSTALLED_FAILED_CANCELLED_BY_USER\n\n12. OutOfMemory问题（OOM）解决方法\n\n每个Android应用都有一个最大内存上限。超过这个上限，就会导致内存不足（OutOfMemory）。检查内存上限的方法：\n\nint maxMemory = (int) (Runtime.getRuntime().maxMemory() / 1024);  \n\nLog.d(\"TAG\", \"Max memory is \" + maxMemory + \"KB\");  \n\n通常情况下，出现OOM，是由于应用中加载了大量的图片导致。鉴于此，有以下几种方式来减小应用对内存的使用：\n\na. 合理压缩展示图片，比如一个100x100的控件里，如果加载一个1024x768的图片，不会让图片的展示效果更好，反而会增加OOM的风险。所以，合理的对图片进行压缩非常重要。\n\nb. 压缩完图片，但是应用里包含了太多的图，这种情况依然可能出现OOM。这种情况下，考虑使用内存缓存技术。根据每一屏要展示的图片数量，以及每个图片的大小，设定一个合理的缓存值，一般情况下不要超过1/8的最大内存值。如果图片不在显示区域，可以考虑将其进行回收，系统的垃圾回收器（GC）会认为这些内存不在被使用，从而对图片进行GC操作。这样会大大降低OOM的风险。\n\nc. 更多的OOM讨论，参见：http://blog.csdn.net/vshuang/article/details/39647167\n\n13. iOS应用（ipa）安装失败可能的原因和解决方法\n\n每个ipa包本质上是一个zip包，里面包含ios应用的资源和可执行文件。\n\na. 如果提示“应用重签名失败”，很可能的原因是ipa是直接从itunes市场下载的正式发布包，这样的包经过苹果的加密，无法安装到任何没有购买过这个应用的用户手机上面。\n\nb. 如果部分的手机安装失败，请检查一下你的应用支持的最低ios SDK的版本（可以很直观的从包里面的Info.plist看到）。比如最低支持ios8.3，则ios8.2版本的手机就装不上这个应用。\n\n14. 启动失败如何进行Debug？\n\n很多同学遇到启动失败的问题，很难进行debug，不知道该如何入手。启动失败其实也可以找到错误栈信息，并且通过这个错误栈信息，定位到具体的问题原因。如下图：\n\n\n\n这里，我们可以看到启动失败的进程pid：26981。然后，我们需要下载日志，这里的日志就是详细的logcat日志。\n\n下载之后，我们需要通过这个PID找到真正引起crash的错误栈。这里建议，使用支持正则匹配的编辑器打开logcat日志（比如nodepad++、vim等等），打开之后，使用正则规则：“26981.* E .*” 进行匹配查找。可以找到如下信息：\n\n\n\n这样我们就能知道具体那行代码导致的错误了。\n\n15. 常见崩溃问题，NullPointerException: Attempt to invoke virtual method \'android.content.res.Resources android.content.Context.getResources()\' on a null object reference\n\n该问题一般是由于资源加载时，引用初始化未完全的Context对象导致。\n\n解决方法：通过增加非空检查；创建View时，使用当前组件的Context（比如ActivityXXX.this），而不用getApplicationContext()等方式。\n\n\n\n参考资料：http://stackoverflow.com/questions/28248232/what-am-i-doing-wrong-with-my-handling-of-contex-java-android\n\n参考资料：http://stackoverflow.com/questions/25488208/java-nullpointerexception-getting-resources',0,4,3),(12,'2015-04-21 20:38:33','2017-03-01 17:49:36','&lt;h2&gt;1. MQC能保证上传APP的安全性吗？&lt;/h2&gt;\n\n&lt;p&gt;1) 平台是全自动化测试，没有人为参与&lt;/p&gt;\n\n&lt;p&gt;2) 在测试完成后，安装包被卸载&lt;/p&gt;\n\n&lt;p&gt;3) 平台不会扫描APP代码，不会泄露用户APP信息&lt;/p&gt;\n\n&lt;p&gt;4) 除非在用户同意的情况下，平台绝不会公开用户的任何测试结果&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;2. MQC支持哪些平台测试：&lt;/h2&gt;\n\n&lt;p&gt;目前只支持android平台的各项自动化测试，将来计划支持其他平台的应用&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;3. MQC提供哪些测试项目：&lt;/h2&gt;\n\n&lt;p&gt;目前为用户提供兼容性测试、稳定性测试和H5测试三种&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;4. MQC支持测试的文件格式：&lt;/h2&gt;\n\n&lt;p&gt;支持后缀为.apk的文件格式&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;5. 可以上传多大的APP应用包：&lt;/h2&gt;\n\n&lt;p&gt;支持上传100M以内的应用测试，更大的应用包，请与&lt;a href=&quot;mailto:mqc_group@service.alibaba.com?subject=%E6%9B%B4%E5%A4%A7%E7%9A%84%E5%BA%94%E7%94%A8%E5%8C%85%E7%94%B3%E8%AF%B7&amp;amp;body=%E6%82%A8%E6%98%AFxxx%E7%9A%84%E5%BC%80%E5%8F%91%E8%80%85%EF%BC%8C%E6%82%A8%E7%9A%84%E6%9C%89%E6%95%88%E8%81%94%E7%B3%BB%E6%96%B9%E5%BC%8F%E3%80%82&quot;&gt;我们&lt;/a&gt;联系&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;6. 测试管理页面中数字颜色代表什么：&lt;/h2&gt;\n\n&lt;p&gt;红色：测试未通过；绿色：测试通过；橙色：测试未执行（等待中、测试中、测试异常）&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;7. 是否可以测试开发过程中的APP包？&lt;/h2&gt;\n\n&lt;p&gt;可以测试开发过程中的App包，签名与否不影响正常测试&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;8. 覆盖安装测试顺序是：&lt;/h2&gt;\n\n&lt;p&gt;1) 上传&amp;ldquo;待测APP&amp;ldquo;版本号是4.3，覆盖安装APP分布上传了4.1和4.2两个版本；&lt;/p&gt;\n\n&lt;p&gt;2) 测试时将会分别测试4.3版本覆盖4.1版本和4.3版本覆盖4.2版本两种场景&lt;/p&gt;\n\n&lt;h2&gt;&amp;nbsp;&lt;/h2&gt;\n\n&lt;h2&gt;9. iOS测试登录脚本的例子：&lt;/h2&gt;\n\n&lt;p&gt;1) var login = &amp;quot;your user name&amp;quot;; var password = &amp;quot;your password&amp;quot;;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;10. 我测试时提供的账号密码安全吗：&lt;/h2&gt;\n\n&lt;p&gt;1) 安全的，因为不会有第三方看到。而且在磁盘上不会留下记录。&lt;/p&gt;\n\n&lt;p&gt;2) 如果实在不放心，请只提供测试用的账号密码。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;11. 我提供的ios测试包会不会装不上：&lt;/h2&gt;\n\n&lt;p&gt;1) 测试包目前没有发现装不上的情况，有的话请旺旺联系我们。&lt;/p&gt;\n\n&lt;p&gt;2) 苹果官方市场下载的正式发布包加密过，在我们的平台上是装不上的。&lt;/p&gt;','常见问题','MTS','1. MQC能保证上传APP的安全性吗？\n\n1) 平台是全自动化测试，没有人为参与\n\n2) 在测试完成后，安装包被卸载\n\n3) 平台不会扫描APP代码，不会泄露用户APP信息\n\n4) 除非在用户同意的情况下，平台绝不会公开用户的任何测试结果 \n\n \n\n2. MQC支持哪些平台测试：\n\n目前只支持android平台的各项自动化测试，将来计划支持其他平台的应用\n\n \n\n3. MQC提供哪些测试项目：\n\n目前为用户提供兼容性测试、稳定性测试和H5测试三种\n\n \n\n4. MQC支持测试的文件格式：\n\n支持后缀为.apk的文件格式\n\n \n\n5. 可以上传多大的APP应用包：\n\n支持上传100M以内的应用测试，更大的应用包，请与我们联系\n\n \n\n6. 测试管理页面中数字颜色代表什么：\n\n红色：测试未通过；绿色：测试通过；橙色：测试未执行（等待中、测试中、测试异常）\n\n \n\n7. 是否可以测试开发过程中的APP包？\n\n可以测试开发过程中的App包，签名与否不影响正常测试\n\n \n\n8. 覆盖安装测试顺序是：\n\n1) 上传“待测APP“版本号是4.3，覆盖安装APP分布上传了4.1和4.2两个版本；\n\n2) 测试时将会分别测试4.3版本覆盖4.1版本和4.3版本覆盖4.2版本两种场景\n\n \n\n9. iOS测试登录脚本的例子：\n\n1) var login = \"your user name\"; var password = \"your password\";\n\n \n\n10. 我测试时提供的账号密码安全吗：\n\n1) 安全的，因为不会有第三方看到。而且在磁盘上不会留下记录。\n\n2) 如果实在不放心，请只提供测试用的账号密码。\n\n \n\n11. 我提供的ios测试包会不会装不上：\n\n1) 测试包目前没有发现装不上的情况，有的话请旺旺联系我们。\n\n2) 苹果官方市场下载的正式发布包加密过，在我们的平台上是装不上的。',0,4,4),(13,'2015-04-28 14:41:03','2016-10-12 18:45:37','&lt;h2&gt;1. 录制回放流程图&lt;/h2&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h1&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/78c896fbb600a2600934bcc1a0adc6ba.png&quot; style=&quot;height:654px; width:600px&quot; /&gt;&lt;/h1&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;2.&amp;nbsp; 待测应用重签名&lt;/h2&gt;\n\n&lt;p&gt;访问：&lt;a href=&quot;http://mts.aliyun.com/signature.htm&quot;&gt;http://mqc.aliyun.com/signature.htm&lt;/a&gt;，上传您的原始待测应用，我们会自动对它进行重签名。&lt;/p&gt;\n\n&lt;p&gt;&lt;strong&gt;注：如果您不想对待测应用重签名，或者待测应用做了签名保护，将无法使用录制回放工具。请联系 @千瞬。&lt;/strong&gt;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;3.&amp;nbsp; 安装重签后待测应用和录制回放工具&lt;/h2&gt;\n\n&lt;p&gt;重签名成功后，会出现如下界面：&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/c4fe5808cb86e51841a05878447271ce.png&quot; style=&quot;height:541px; width:600px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;手机端扫描二维码，安装待测应用和录制回放工具MTS，也可以点击相关链接下载apk到本地进行安装。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;4.&amp;nbsp; 手机端录制、回放和上传脚本&lt;/h2&gt;\n\n&lt;p&gt;手机端打开Mts应用，用登陆平台的淘宝账号登陆。登陆成功后进入应用列表界面，找到您的待测应用，点击后面绿色&amp;ldquo;录制&amp;rdquo;按钮，点击应用提示框的&amp;ldquo;安装&amp;rdquo;即可。安装成功后，会自动进入有淡紫色风格的待测应用界面，此时就能进行录制回放了。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h3&gt;&lt;strong&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; 为了能顺利快捷的录制出满意的脚本，请注意如下事项：&lt;/strong&gt;&amp;nbsp;&lt;/h3&gt;\n\n&lt;p&gt;1） 录制过程中会有一个淡紫色浮层，如果没有请等待该浮层出现再操作，否则操作不会被录制下来&lt;/p&gt;\n\n&lt;p&gt;2） 因为很多应用第一次安装打开的时候，都有一个介绍或者引导界面，所以需要先录制一个前置脚本，它包含引导页面的所有操作动作，然后在平台将该脚本设置为前置脚本。有了前置脚本就能大大提高脚本回放成功率&lt;/p&gt;\n\n&lt;p&gt;3） 录制开始时间点：选择应用程序包，点确定之后，脚本录制就开始了，之后的所有操作和停顿都会记录在脚本里，直到点击左上角小圆点，然后点击弹出的一个录像机图标的按钮就结束录制&lt;/p&gt;\n\n&lt;p&gt;4） 录制脚本前最好设计好路径，免得有多余的操作，增加无谓的时间。如果有测试用例，最好按照用例的步骤来录制。&lt;/p&gt;\n\n&lt;p&gt;5） 在录制脚本的时候尽量用比较慢的速度录制，这样能保证在多款手机上回放的准确率。&lt;/p&gt;\n\n&lt;p&gt;6) &amp;nbsp;如果发现有些输入框输入的内容没有录制下来，请先点击一下输入框再输入内容就能录制下来。&lt;/p&gt;\n\n&lt;p&gt;7） 在录制脚本时，还应考虑到程序运行时的差异，比如您录制脚本的时候手机上没插SIM卡，如果运行时手机上又插上了SIM卡，往往有些应用程序会提示3G流量的问题，类似这些提示会干扰脚本的正常运行，录制脚本时需要尽量考虑到。&lt;/p&gt;\n\n&lt;p&gt;8） 部分手机会隐藏小圆点（比如小米），请在mts应用设置中，打开&amp;ldquo;显示悬浮框&amp;rdquo;的设定。&lt;/p&gt;\n\n&lt;p&gt;录制脚本完成之后，您一定要马上试运行一下，看新录制的脚本是否能回放成功。脚本回放成功后，可以点击脚本列表页面右上角的一个云图标完成所有脚本的上传，或者单独点击某个脚本前面的云图标完成单个脚本上传。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;5.&amp;nbsp; 平台上运行脚本&lt;/h2&gt;\n\n&lt;p&gt;访问&amp;nbsp;&lt;a href=&quot;http://mqc.aliyun.com/automationscript_manager.htm&quot;&gt;http://mqc.aliyun.com/automationscript_manager.htm&lt;/a&gt;&amp;nbsp;查看上传的脚本，下载并前往 Android测试 -〉功能测试 进行功能测试任务。&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;6. 生成测试报告&lt;/h2&gt;\n\n&lt;p&gt;任务通常会在4-6小时内完成，结束后会有邮件和旺旺通知。任务完成后就能在测试管理页面查看相关测试报告。&lt;/p&gt;\n\n&lt;p&gt;&lt;strong&gt;大家使用过程中有任何疑问和建议，欢迎联系我们。&lt;/strong&gt;&lt;/p&gt;','录制回放','mts','1. 录制回放流程图\n\n \n\n\n\n \n\n2.  待测应用重签名\n\n访问：http://mqc.aliyun.com/signature.htm，上传您的原始待测应用，我们会自动对它进行重签名。\n\n注：如果您不想对待测应用重签名，或者待测应用做了签名保护，将无法使用录制回放工具。请联系 @千瞬。\n\n \n\n3.  安装重签后待测应用和录制回放工具\n\n重签名成功后，会出现如下界面： \n\n\n\n手机端扫描二维码，安装待测应用和录制回放工具MTS，也可以点击相关链接下载apk到本地进行安装。\n\n \n\n4.  手机端录制、回放和上传脚本\n\n手机端打开Mts应用，用登陆平台的淘宝账号登陆。登陆成功后进入应用列表界面，找到您的待测应用，点击后面绿色“录制”按钮，点击应用提示框的“安装”即可。安装成功后，会自动进入有淡紫色风格的待测应用界面，此时就能进行录制回放了。\n\n \n\n       为了能顺利快捷的录制出满意的脚本，请注意如下事项： \n\n1） 录制过程中会有一个淡紫色浮层，如果没有请等待该浮层出现再操作，否则操作不会被录制下来\n\n2） 因为很多应用第一次安装打开的时候，都有一个介绍或者引导界面，所以需要先录制一个前置脚本，它包含引导页面的所有操作动作，然后在平台将该脚本设置为前置脚本。有了前置脚本就能大大提高脚本回放成功率\n\n3） 录制开始时间点：选择应用程序包，点确定之后，脚本录制就开始了，之后的所有操作和停顿都会记录在脚本里，直到点击左上角小圆点，然后点击弹出的一个录像机图标的按钮就结束录制\n\n4） 录制脚本前最好设计好路径，免得有多余的操作，增加无谓的时间。如果有测试用例，最好按照用例的步骤来录制。\n\n5） 在录制脚本的时候尽量用比较慢的速度录制，这样能保证在多款手机上回放的准确率。\n\n6)  如果发现有些输入框输入的内容没有录制下来，请先点击一下输入框再输入内容就能录制下来。\n\n7） 在录制脚本时，还应考虑到程序运行时的差异，比如您录制脚本的时候手机上没插SIM卡，如果运行时手机上又插上了SIM卡，往往有些应用程序会提示3G流量的问题，类似这些提示会干扰脚本的正常运行，录制脚本时需要尽量考虑到。\n\n8） 部分手机会隐藏小圆点（比如小米），请在mts应用设置中，打开“显示悬浮框”的设定。\n\n录制脚本完成之后，您一定要马上试运行一下，看新录制的脚本是否能回放成功。脚本回放成功后，可以点击脚本列表页面右上角的一个云图标完成所有脚本的上传，或者单独点击某个脚本前面的云图标完成单个脚本上传。\n\n \n\n5.  平台上运行脚本\n\n访问 http://mqc.aliyun.com/automationscript_manager.htm 查看上传的脚本，下载并前往 Android测试 -〉功能测试 进行功能测试任务。 \n\n \n\n6. 生成测试报告\n\n任务通常会在4-6小时内完成，结束后会有邮件和旺旺通知。任务完成后就能在测试管理页面查看相关测试报告。\n\n大家使用过程中有任何疑问和建议，欢迎联系我们。',0,3,9),(14,'2015-07-14 09:45:22','2015-08-11 15:36:59',NULL,'Appium文档','字白',NULL,0,3,3),(15,'2015-07-14 09:46:27','2015-10-13 11:05:24','&lt;h3&gt;Appium是一个开源的、跨平台的测试框架，可以用来测试Native App、混合应用、移动Web应用（H5应用）。&lt;/h3&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h3&gt;Appium坚持的测试理念：&lt;/h3&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;1. 无需用户对APP进行任何修改或者重新编译，App应该Born to be automated。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;2.&amp;nbsp;不应该限制用户只能使用特定的语言或者框架来编写和执行测试。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;3.&amp;nbsp;移动测试框架的API应该是稳定的，合理的。不应对自动化API 反复的造轮子。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;4.&amp;nbsp;移动测试框架应该是开源的，包括&amp;ldquo;精神和肉体&amp;rdquo;。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;目前，Appium支持&lt;a href=&quot;https://github.com/appium/python-client&quot;&gt;Python&lt;/a&gt;、&lt;a href=&quot;https://github.com/admc/wd&quot;&gt;JavaScript&lt;/a&gt;、&lt;a href=&quot;https://github.com/appium/selenium-objective-c&quot;&gt;Objective C&lt;/a&gt;、&lt;a href=&quot;https://github.com/appium/java-client&quot;&gt;Java&lt;/a&gt;、&lt;a href=&quot;https://github.com/appium/ruby_lib&quot;&gt;Ruby&lt;/a&gt;、&lt;a href=&quot;https://github.com/appium/php-client&quot;&gt;php&lt;/a&gt;、&lt;a href=&quot;https://github.com/appium/appium-dotnet-driver&quot;&gt;c#&lt;/a&gt;。MQC目前首先选择支持&lt;a href=&quot;https://github.com/appium/python-client&quot;&gt;Python&lt;/a&gt;语言和&lt;a href=&quot;https://github.com/appium/java-client&quot;&gt;Java&lt;/a&gt;语言。其他语言将会陆续在MQC上得到支持。您也可以告诉&lt;a href=&quot;mailto:mqc_group@service.alibaba.com&quot;&gt;我们&lt;/a&gt;您希望下一个被支持的语言。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h3&gt;Appium的架构是如何设计的？&lt;/h3&gt;\n\n&lt;p&gt;事实上，Appium 真正的工作引擎全部是第三方自动化框架。这样，就不需在你的应用里植入其他任何代码。也就是说你测试使用的应用和最终发布的应用完全一致。使用以下的第三方框架如下：&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; 1.&amp;nbsp;IOS: 苹果的 UIAutomation&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; 2.&amp;nbsp;Android 4.2+: Google&amp;rsquo;s UiAutomator&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; 3.&amp;nbsp;Android 2.3+: Google&amp;rsquo;s Instrumentation. (由单独的项目Selendroid提供支持)&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;Appium把这些第三方框架封装成一套 &lt;a href=&quot;http://docs.seleniumhq.org/projects/webdriver/&quot;&gt;WebDriver&lt;/a&gt; API。(协议格式参见 &lt;a href=&quot;https://code.google.com/p/selenium/wiki/JsonWireProtocol&quot;&gt;JSON Wire Protocol&lt;/a&gt;)。使用这种CS架构，Appium就可以通过任何语言来封装API调用，从而提供不同语言的客户端给不同的人员。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;Appium 的核心是一个 web 服务器，它提供了一套 REST 的接口。它收到客户端的连接，监听到命令，接着在移动设备上执行这些命令，然后将执行结果放在 HTTP响应中返还给客户端。事实上，这种客户端/服务端的架构给予了许多的可能性：比如我们可以使用任何实现了该客户端的语言来写我们的测试代码。比如我们可以把服务端放在不同 的机器上。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h3&gt;WebDriver 的Session概念&lt;/h3&gt;\n\n&lt;p&gt;自动化始终围绕一个session进行，客户端初始化一个seesion（会话）来与服务端交互，不同的语言有不同的实现方式，但是他们最终都是发送为一个POST请求给服务端，请求中包含一个JSON对象，被称作&amp;ldquo;desired capabilities&amp;rdquo;。此时，服务端就会开启一个自动化的 session，然后返回一个 session ID，session ID将会被用户发送后续的命令。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h3&gt;什么是Desired Capabilities？&lt;/h3&gt;\n\n&lt;p&gt;Desired capabilities 是一些键值对的集合 (比如，一个 map 或者 hash），客户端将这些键值对发给服务端，告诉服务端我们想要怎么测试。比如，我们可以把platformName capability 设置为 iOS，告诉 Appium 服务端，我们想要一个iOS 的 session，而不是一个 Android 的。完整列表参见&lt;a href=&quot;https://github.com/appium/appium/blob/master/docs/en/writing-running-appium/caps.md&quot;&gt; capabilities 文档&lt;/a&gt;&lt;/p&gt;','Appium简介','字白','Appium是一个开源的、跨平台的测试框架，可以用来测试Native App、混合应用、移动Web应用（H5应用）。\n\n \n\nAppium坚持的测试理念：\n\n       1. 无需用户对APP进行任何修改或者重新编译，App应该Born to be automated。\n\n       2. 不应该限制用户只能使用特定的语言或者框架来编写和执行测试。\n\n       3. 移动测试框架的API应该是稳定的，合理的。不应对自动化API 反复的造轮子。\n\n       4. 移动测试框架应该是开源的，包括“精神和肉体”。\n\n \n\n目前，Appium支持Python、JavaScript、Objective C、Java、Ruby、php、c#。MQC目前首先选择支持Python语言和Java语言。其他语言将会陆续在MQC上得到支持。您也可以告诉我们您希望下一个被支持的语言。\n\n \n\nAppium的架构是如何设计的？\n\n事实上，Appium 真正的工作引擎全部是第三方自动化框架。这样，就不需在你的应用里植入其他任何代码。也就是说你测试使用的应用和最终发布的应用完全一致。使用以下的第三方框架如下：\n\n      1. IOS: 苹果的 UIAutomation\n\n      2. Android 4.2+: Google’s UiAutomator\n\n      3. Android 2.3+: Google’s Instrumentation. (由单独的项目Selendroid提供支持)\n\n \n\nAppium把这些第三方框架封装成一套 WebDriver API。(协议格式参见 JSON Wire Protocol)。使用这种CS架构，Appium就可以通过任何语言来封装API调用，从而提供不同语言的客户端给不同的人员。\n\n \n\nAppium 的核心是一个 web 服务器，它提供了一套 REST 的接口。它收到客户端的连接，监听到命令，接着在移动设备上执行这些命令，然后将执行结果放在 HTTP响应中返还给客户端。事实上，这种客户端/服务端的架构给予了许多的可能性：比如我们可以使用任何实现了该客户端的语言来写我们的测试代码。比如我们可以把服务端放在不同 的机器上。\n\n \n\nWebDriver 的Session概念\n\n自动化始终围绕一个session进行，客户端初始化一个seesion（会话）来与服务端交互，不同的语言有不同的实现方式，但是他们最终都是发送为一个POST请求给服务端，请求中包含一个JSON对象，被称作“desired capabilities”。此时，服务端就会开启一个自动化的 session，然后返回一个 session ID，session ID将会被用户发送后续的命令。\n\n \n\n什么是Desired Capabilities？\n\nDesired capabilities 是一些键值对的集合 (比如，一个 map 或者 hash），客户端将这些键值对发给服务端，告诉服务端我们想要怎么测试。比如，我们可以把platformName capability 设置为 iOS，告诉 Appium 服务端，我们想要一个iOS 的 session，而不是一个 Android 的。完整列表参见 capabilities 文档',0,14,1),(16,'2015-07-14 09:47:51','2015-07-28 15:39:51','&lt;h3&gt;搭建Node.js环境&lt;/h3&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;1. Node.js的&lt;a href=&quot;http://nodejs.org/&quot;&gt;官网&lt;/a&gt;下载安装Node.js 和 npm（Node.js的包管理工具）。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; 注：安装Node.js的版本要求0.10或以上，建议安装最新的稳定版。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;Linux和Mac OS X用户安装时，不要使用sudo。 如果一定要使用sudo，必须保证Node.js的所有者和Appium包的所有者保持一致。具体方法，在下面&amp;ldquo;安装Appium&amp;rdquo;章节会有介绍。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;nbsp;&lt;/p&gt;\n\n&lt;h3&gt;安装Appium&lt;/h3&gt;\n\n&lt;p&gt;1. 请先下载Node.js的&lt;a href=&quot;/static/res/appium.zip&quot;&gt;Appium.zip&lt;/a&gt; 这个包。&lt;/p&gt;\n\n&lt;p&gt;2. 然后在命令行中执行：npm config get prefix这个命令。OSX 和Linux得到输出，比如/usr或者Windows得到输出，比如C:\\Users\\xxxx\\AppData\\Roaming\\npm。 这样就可以找到Node.js的一个全局模块的根目录。&lt;/p&gt;\n\n&lt;p&gt;3. 结合刚刚找到的Node.js全局的package根目录，我们可以找到node_modules目录位置：OS X和Linux对应的位置为：/usr/lib/node_modules ；Windows对应的位置为：C:\\Users\\xxxx\\AppData\\Roaming\\npm\\node_modules&lt;/p&gt;\n\n&lt;p&gt;4. 解压下载的Appium.zip到刚刚找到的node_modules目录。&lt;/p&gt;\n\n&lt;p&gt;5. Windows用户在node_modules同级目录中，创建appium.cmd文件，并写入以下代码：&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;@IF EXIST &amp;quot;%~dp0\\node.exe&amp;quot; (\n  &amp;quot;%~dp0\\node.exe&amp;quot;  &amp;quot;%~dp0\\node_modules\\appium\\bin\\appium.js&amp;quot; %*\n) ELSE (\n  @SETLOCAL\n  @SET PATHEXT=%PATHEXT:;.JS;=;%\n  node  &amp;quot;%~dp0\\node_modules\\appium\\bin\\appium.js&amp;quot; %*\n)\n\n&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;&amp;nbsp; Linux/Mac OS用户，给node_modules/appium/bin/appium.js 增加可执行权限（chmod +x node_modules/appium/bin/appium.js），然后执行命令（可能需要sudo）：&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;ln -s &amp;nbsp;/FULL--PATH--TO/node_modules/appium/bin/appium.js &amp;nbsp;/usr/bin/appium&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;&amp;nbsp; 如果依然出现无法创建appium命令的情况，可以直接运行： node &amp;nbsp;node_modules/appium/bin/appium.js&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h3&gt;验证安装。&lt;/h3&gt;\n\n&lt;p&gt;在命令行中执行：appium -p 12345（在本地启动Appium Server并且监听端口号12345）。出现如下输出，说明Appium安装正常。否则，请到我们的旺旺交流群（群号：335334143）中反馈。&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;\ninfo: Welcome to Appium v1.3.7 (REV 72fbfaa116d3d9f6a862600ee99cf02f6d0e2182)\ninfo: Appium REST http interface listener started on 0.0.0.0:12345\ninfo: [debug] Non-default server args: {&amp;quot;port&amp;quot;:12345}\ninfo: Console LogLevel: debug\n&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;注意：请确保安装Node.js的用户和解压后的appium文件夹的所有者一致。如果不一致，Linux和OS X用户请用chown&amp;nbsp; -R&amp;nbsp; ${user}&amp;nbsp; appium 修改appium文件夹的所有者；Windows用户右键，选择&amp;ldquo;属性&amp;rdquo;修改。将&amp;rdquo;${user}&amp;rdquo;替换为相应的用户名。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h3&gt;安装Appium python客户端&lt;/h3&gt;\n\n&lt;p&gt;1. 请先确保安装了Python（最好版本为2.7.x）。如果没有安装，请到&lt;a href=&quot;https://www.python.org/&quot;&gt;Python官网&lt;/a&gt;下载安装。&lt;/p&gt;\n\n&lt;p&gt;2. 参考&lt;a href=&quot;https://pypi.python.org/pypi/setuptools&quot;&gt;https://pypi.python.org/pypi/setuptools&lt;/a&gt;文档，安装python setuptools 。&lt;/p&gt;\n\n&lt;p&gt;3. 下载&lt;a href=&quot;/static/res/python-client-master.zip&quot;&gt;Appium-python-client.zip&lt;/a&gt;。&lt;/p&gt;\n\n&lt;p&gt;4. 将文件夹解压到任意位置，然后使用命令行进入到解压后的文件夹目录，执行命令：python setup.py install（可能需要sudo）&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h3&gt;其他环境要求&lt;/h3&gt;\n\n&lt;p&gt;1. IOS&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; Mac OS X 10.7 or higher, 建议10.9.2&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; XCode &amp;gt;= 4.6.3, 建议5.1.1&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; Apple Developer Tools&lt;/p&gt;\n\n&lt;p&gt;2. Android&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&amp;nbsp;&lt;a href=&quot;http://developer.android.com/index.html&quot;&gt;Android SDK&lt;/a&gt; API &amp;gt;= 17 (建议18/19)&lt;/p&gt;\n\n&lt;p&gt;其他环境问题请参考：&lt;a href=&quot;http://appium.io/slate/en/master/#running-on-linux.md&quot;&gt;linux&lt;/a&gt;、&lt;a href=&quot;http://appium.io/slate/en/master/#running-on-osx.md&quot;&gt;osx&lt;/a&gt;、&lt;a href=&quot;http://appium.io/slate/en/master/#running-on-windows.md&quot;&gt;window&lt;/a&gt;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;','环境搭建','字白','搭建Node.js环境\n\n \n\n1. Node.js的官网下载安装Node.js 和 npm（Node.js的包管理工具）。\n\n    注：安装Node.js的版本要求0.10或以上，建议安装最新的稳定版。\n\n           Linux和Mac OS X用户安装时，不要使用sudo。 如果一定要使用sudo，必须保证Node.js的所有者和Appium包的所有者保持一致。具体方法，在下面“安装Appium”章节会有介绍。\n\n           \n\n安装Appium\n\n1. 请先下载Node.js的Appium.zip 这个包。\n\n2. 然后在命令行中执行：npm config get prefix这个命令。OSX 和Linux得到输出，比如/usr或者Windows得到输出，比如C:\\Users\\xxxx\\AppData\\Roaming\\npm。 这样就可以找到Node.js的一个全局模块的根目录。\n\n3. 结合刚刚找到的Node.js全局的package根目录，我们可以找到node_modules目录位置：OS X和Linux对应的位置为：/usr/lib/node_modules ；Windows对应的位置为：C:\\Users\\xxxx\\AppData\\Roaming\\npm\\node_modules\n\n4. 解压下载的Appium.zip到刚刚找到的node_modules目录。\n\n5. Windows用户在node_modules同级目录中，创建appium.cmd文件，并写入以下代码：\n\n\n@IF EXIST &quot;%~dp0\\node.exe&quot; (\n  &quot;%~dp0\\node.exe&quot;  &quot;%~dp0\\node_modules\\appium\\bin\\appium.js&quot; %*\n) ELSE (\n  @SETLOCAL\n  @SET PATHEXT=%PATHEXT:;.JS;=;%\n  node  &quot;%~dp0\\node_modules\\appium\\bin\\appium.js&quot; %*\n)\n\n\n\n  Linux/Mac OS用户，给node_modules/appium/bin/appium.js 增加可执行权限（chmod +x node_modules/appium/bin/appium.js），然后执行命令（可能需要sudo）：\n\n\nln -s &nbsp;/FULL--PATH--TO/node_modules/appium/bin/appium.js &nbsp;/usr/bin/appium\n\n  如果依然出现无法创建appium命令的情况，可以直接运行： node  node_modules/appium/bin/appium.js\n\n \n\n验证安装。\n\n在命令行中执行：appium -p 12345（在本地启动Appium Server并且监听端口号12345）。出现如下输出，说明Appium安装正常。否则，请到我们的旺旺交流群（群号：335334143）中反馈。\n\n\n\ninfo: Welcome to Appium v1.3.7 (REV 72fbfaa116d3d9f6a862600ee99cf02f6d0e2182)\ninfo: Appium REST http interface listener started on 0.0.0.0:12345\ninfo: [debug] Non-default server args: {&quot;port&quot;:12345}\ninfo: Console LogLevel: debug\n\n\n注意：请确保安装Node.js的用户和解压后的appium文件夹的所有者一致。如果不一致，Linux和OS X用户请用chown  -R  ${user}  appium 修改appium文件夹的所有者；Windows用户右键，选择“属性”修改。将”${user}”替换为相应的用户名。\n\n \n\n安装Appium python客户端\n\n1. 请先确保安装了Python（最好版本为2.7.x）。如果没有安装，请到Python官网下载安装。\n\n2. 参考https://pypi.python.org/pypi/setuptools文档，安装python setuptools 。\n\n3. 下载Appium-python-client.zip。\n\n4. 将文件夹解压到任意位置，然后使用命令行进入到解压后的文件夹目录，执行命令：python setup.py install（可能需要sudo）\n\n \n\n其他环境要求\n\n1. IOS\n\n  Mac OS X 10.7 or higher, 建议10.9.2\n\n  XCode >= 4.6.3, 建议5.1.1\n\n  Apple Developer Tools\n\n2. Android\n\n  Android SDK API >= 17 (建议18/19)\n\n其他环境问题请参考：linux、osx、window\n\n ',0,14,2),(17,'2015-07-14 09:49:13','2016-11-16 16:01:27','&lt;h3&gt;1. 设置Desired Capabilities&lt;/h3&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;在开始前，您可以&lt;a href=&quot;/static/res/appium_demo.zip&quot;&gt;点击下载本章所有测试相关文件。&lt;/a&gt;&lt;/p&gt;\n\n&lt;p&gt;开始第一步，创建一个文件，名为：desired_capabilities.py。内容如下：&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;\n\n#!/usr/bin/env python\n\n\ndef get_desired_capabilities():\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp; desired_caps = {\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;\'platformName\': \'Android\',\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;\'platformVersion\': \'4.0.4\',\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;\'deviceName\': \'V889F\',\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;\'appPackage\': \'com.alibaba.mts.mtsdemoapp\',\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;\'appWaitPackage\': \'com.alibaba.mts.mtsdemoapp\',\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;\'app\': &amp;quot;D:/home/mdp/result/GroovyTest/case1/task.apk&amp;quot;,\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;\'newCommandTimeout\': 30,&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;\'automationName\': \'Appium\'\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;}\n\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;return desired_caps\n\n\ndef get_uri():\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;return &amp;quot;http://localhost:50000/wd/hub&amp;quot;\n&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;里面包含两个函数：get_desired_capabilities()和get_uri()。&lt;/p&gt;\n\n&lt;p&gt;a. get_uri()&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;返回Appium Server的地址，比如这里我们在本地启动的Appium Server，并且设置默认监听端口为50000，得到的地址是&lt;a href=&quot;http://localhost:50000/wd/hub&quot;&gt;http://localhost:50000/wd/hub&lt;/a&gt;&lt;/p&gt;\n\n&lt;p&gt;b. get_desired_capabilities()&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;获取本次会话的参数。这里主要设置了8个参数。用户可以根据自己的需求进行调整。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;1. platformName，我们测试的目标机器。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;2. platformVersion，测试目标设备的系统版本。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;3. deviceName，测试机器的名称（设备名称即可）。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;4. appPackage，被测应用的包名（只有Android测试才用）。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;5. appWaitPackage，测试时会等待（只有Android测试才用）。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;6. app，被测应用文件的所在位置&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;7. newCommandTimeout，两条指令的最长时间间隔。如果超过这个间隔，Appium Server将会终止本次会话。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;8.&amp;nbsp;automationName，本次会话所使用的自动化引擎。Android 4.2以下系统请使用Selendroid；IOS、Android 4.2以上（含）请使用Appium。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;更多的选项，请参见&lt;a href=&quot;https://github.com/appium/appium/blob/master/docs/en/writing-running-appium/caps.md&quot;&gt;capabilities文档&lt;/a&gt;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h3&gt;2. 编写测试用例&lt;/h3&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;MQC会执行用户上传的main.py，所以要创建这个入口脚本：main.py。我们以一个登录的脚本main.py作为例子进行说明，代码如下:&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;# -*- coding: utf-8 -*-&lt;/code&gt;\n\n&lt;code&gt;from appium import webdriver&lt;/code&gt;\n\n&lt;code&gt;# 引入刚刚创建的同目录下的desired_capabilities.py\nimport desired_capabilities&lt;/code&gt;\n\n&lt;code&gt;# 我们使用python的unittest作为单元测试工具\nfrom unittest import TestCase&lt;/code&gt;\n\n&lt;code&gt;# 我们使用python的unittest作为单元测试工具\nimport unittest&lt;/code&gt;\n&lt;code&gt;\n# 使用time.sleep(xx)函数进行等待\nimport time&lt;/code&gt;\n\n&lt;code&gt;class MqcTest(TestCase):&lt;/code&gt;\n   \n&amp;nbsp;  global automationName\n&lt;code&gt;   \n&amp;nbsp;  def setUp(self):\n       # 获取我们设定的capabilities，通知Appium Server创建相应的会话。\n       desired_caps = desired_capabilities.get_desired_capabilities()\n       # 获取server的地址。\n       uri = desired_capabilities.get_uri()\n       # 获取使用的测试框架\n&lt;/code&gt;       self.automationName = desired_caps.get(\'automationName\')&lt;code&gt;\n       # 创建会话，得到driver对象，driver对象封装了所有的设备操作。下面会具体讲。\n       self.driver = webdriver.Remote(uri, desired_caps)&lt;/code&gt;\n\n&lt;code&gt;\n   def test_searchbox(self):\n        # 找到包含&amp;rdquo;Tab4&amp;rdquo;字符串的控件。\n        if self.automationName == \'Appium\':\n            tab4 = self.driver.find_element_by_name(&amp;quot;Tab4&amp;quot;)\n        else:\n            tab4 = self.driver.find_element_by_link_text(&amp;quot;Tab4&amp;quot;)\n        # 点击.\n        tab4.click()&lt;/code&gt;\n\n&lt;code&gt;        # 等待2秒钟\n        time.sleep(2)&lt;/code&gt;\n\n&lt;code&gt;        # 通过控件类名找到用户名和密码输入框。\n        editTexts = self.driver.find_elements_by_class_name(&amp;quot;android.widget.EditText&amp;quot;)\n        # 第一个框为用户名输入框，输入用户名；第二个框为密码框，输入密码\n        editTexts[0].send_keys(&amp;quot;admin&amp;quot;)\n        editTexts[1].send_keys(&amp;quot;admin&amp;quot;)\n        # 隐藏出现的软键盘\n        self.driver.hide_keyboard()&lt;/code&gt;\n\n&lt;code&gt;        # 找到包含&amp;ldquo;登录&amp;rdquo;的按钮并点击\n        if self.automationName == \'Appium\':\n            self.driver.find_element_by_name(&amp;quot;登陆&amp;quot;).click()\n        else:\n            self.driver.find_element_by_link_text(&amp;quot;登陆&amp;quot;).click()\n        # 等待3秒钟，登录需要与服务器通讯。 \n        time.sleep(3)&lt;/code&gt;\n\n&lt;code&gt;   def tearDown(self): \n        # 测试结束，退出会话。 \n        self.driver.quit()&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;几种查找控件的方法（在类By下）：&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; 1. ID : 通过resource-id查找。注意，测试Android应用时，Appium引擎和Selendroid引擎的id写法不同，Appium下类似这样：com.alibaba.mts.mtsdemoapp:id/login_login_button；而Selendroid下id是：login_login_button。所以，如果要写通用的脚本，建议使用其他查找方式。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; 2. XPATH : 通过xpath寻找。例如查找一个包含&amp;ldquo;Add note&amp;rdquo;字符串的TextView控件：driver.findElement(By.XPATH, &amp;quot;//android.widget.TextView[contains(@text,\'Add note\')]&amp;quot;)。&lt;a href=&quot;https://msdn.microsoft.com/zh-cn/library/ms256471.aspx&quot;&gt;点击查看更多XPATH语法&lt;/a&gt;。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; 3. LINK_TEXT : (不支持Android 4.2.1以下)通过控件的文本文字查找，比如：driver.findElement(By.LINK_TEXT, &amp;ldquo;登录&amp;rdquo;)，找到控件文字为&amp;ldquo;登录&amp;rdquo;控件。注意，它不会匹配&amp;ldquo;登录吧&amp;rdquo;、&amp;ldquo;快登录&amp;rdquo;等文字。建议使用下面的&amp;ldquo;PARTIAL_LINK_TEXT&amp;rdquo;。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; 4. PARTIAL_LINK_TEXT : (不支持Android 4.2.1以下)类似LINK_TEXT，但是可以匹配&amp;ldquo;登录吧&amp;rdquo;、&amp;ldquo;快登录&amp;rdquo;等文本的控件。只要包含&amp;ldquo;登录&amp;rdquo;即可。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; 5. NAME : 与ACCESSIBILITY_ID相同，通过content description查找。content description是为生理缺陷的人使用的，比如色盲人员看不清图片，可以通过TalkBack等软件朗读content description的内容。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; 6. TAG_NAME : 通过控件类名查找，比如EditText、Button等等。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; 7. CLASS_NAME : 通过控件全类名查找，比如android.widget.EditText 、android.widget.Button等。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; 8. CSS_SELECTOR : 只用于Hybird APP，通过CSS选择器，查找WebView中的HTML控件。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; 9. ACCESSIBILITY_ID : 同NAME。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; 更多示例请参考：&lt;a href=&quot;http://selendroid.io/hybrid.html&quot;&gt;hybird app查找方法&lt;/a&gt;、&lt;a href=&quot;http://selendroid.io/native.html&quot;&gt;native app查找方法&lt;/a&gt;。&lt;/p&gt;\n\n&lt;p&gt;关于支持操作：&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; Appium支持滑动、点击、输入、安装、启动等方法，请参考&lt;a href=&quot;http://appium.io/slate/cn/master/?python#appium-客户端库&quot;&gt;详细文档&lt;/a&gt;。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h3&gt;3. 启动Appium Server&lt;/h3&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;在本地的命令行中执行命令：&amp;nbsp;appium &amp;ndash;p 50000&lt;/p&gt;\n\n&lt;p&gt;注：启动参数释义：&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; 1. &amp;nbsp;&amp;rdquo;-p&amp;rdquo;: 指定appium server监听的端口号。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; 2.&amp;nbsp;&amp;ldquo;-a&amp;rdquo;: 指定appium server的ip地址。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; 3. &amp;nbsp;&amp;ldquo;-selendroid-port&amp;rdquo; : selendroid模式下，adb forward的端口。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; 4. &amp;nbsp;&amp;ldquo;-U&amp;rdquo; : 当挂载多个设备时，可以通过此参数指定某个设备的串号，这样Appium server就可以知道是要在这个设备上进行测试。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; 5. &amp;nbsp;&amp;ldquo;--full-reset&amp;rdquo; : 如果加上此参数，设备每个case完成时都会对设备进行完全的清理。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h3&gt;4. 执行测试用例&lt;/h3&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;在命令行中执行命令：&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;python -m unittest&amp;nbsp; main&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;其中main就是我们刚刚创建的测试用例：main.py&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h3&gt;5. 提交到MQC云平台&lt;/h3&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;本地测试通过之后，将所有测试文件打包成zip文件，然后在&amp;ldquo;功能测试&amp;rdquo;里，提交被测应用和打包后的脚本ZIP包。&lt;/p&gt;\n\n&lt;p&gt;注意，目前只支持一个main.py作为testsuite，并且请使用unittest作为用例测试工具。更多问题，请到我们的旺旺交流群（群号：335334143）中反馈。&lt;/p&gt;','Python脚本测试','字白','1. 设置Desired Capabilities\n\n \n\n在开始前，您可以点击下载本章所有测试相关文件。\n\n开始第一步，创建一个文件，名为：desired_capabilities.py。内容如下：\n\n\n\n\n#!/usr/bin/env python\n\n\ndef get_desired_capabilities():\n\n&nbsp;&nbsp;&nbsp; desired_caps = {\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\'platformName\': \'Android\',\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\'platformVersion\': \'4.0.4\',\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\'deviceName\': \'V889F\',\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\'appPackage\': \'com.alibaba.mts.mtsdemoapp\',\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\'appWaitPackage\': \'com.alibaba.mts.mtsdemoapp\',\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\'app\': &quot;D:/home/mdp/result/GroovyTest/case1/task.apk&quot;,\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\'newCommandTimeout\': 30,&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\'automationName\': \'Appium\'\n\n&nbsp;&nbsp;&nbsp;}\n\n\n&nbsp;&nbsp;&nbsp;return desired_caps\n\n\ndef get_uri():\n\n&nbsp;&nbsp;&nbsp;return &quot;http://localhost:50000/wd/hub&quot;\n\n\n里面包含两个函数：get_desired_capabilities()和get_uri()。\n\na. get_uri()\n\n     返回Appium Server的地址，比如这里我们在本地启动的Appium Server，并且设置默认监听端口为50000，得到的地址是http://localhost:50000/wd/hub\n\nb. get_desired_capabilities()\n\n     获取本次会话的参数。这里主要设置了8个参数。用户可以根据自己的需求进行调整。\n\n     1. platformName，我们测试的目标机器。\n\n     2. platformVersion，测试目标设备的系统版本。\n\n     3. deviceName，测试机器的名称（设备名称即可）。\n\n     4. appPackage，被测应用的包名（只有Android测试才用）。\n\n     5. appWaitPackage，测试时会等待（只有Android测试才用）。\n\n     6. app，被测应用文件的所在位置\n\n     7. newCommandTimeout，两条指令的最长时间间隔。如果超过这个间隔，Appium Server将会终止本次会话。\n\n     8. automationName，本次会话所使用的自动化引擎。Android 4.2以下系统请使用Selendroid；IOS、Android 4.2以上（含）请使用Appium。\n\n     更多的选项，请参见capabilities文档\n\n \n\n2. 编写测试用例\n\n \n\nMQC会执行用户上传的main.py，所以要创建这个入口脚本：main.py。我们以一个登录的脚本main.py作为例子进行说明，代码如下:\n\n\n# -*- coding: utf-8 -*-\n\nfrom appium import webdriver\n\n# 引入刚刚创建的同目录下的desired_capabilities.py\nimport desired_capabilities\n\n# 我们使用python的unittest作为单元测试工具\nfrom unittest import TestCase\n\n# 我们使用python的unittest作为单元测试工具\nimport unittest\n\n# 使用time.sleep(xx)函数进行等待\nimport time\n\nclass MqcTest(TestCase):\n   \n&nbsp;  global automationName\n   \n&nbsp;  def setUp(self):\n       # 获取我们设定的capabilities，通知Appium Server创建相应的会话。\n       desired_caps = desired_capabilities.get_desired_capabilities()\n       # 获取server的地址。\n       uri = desired_capabilities.get_uri()\n       # 获取使用的测试框架\n       self.automationName = desired_caps.get(\'automationName\')\n       # 创建会话，得到driver对象，driver对象封装了所有的设备操作。下面会具体讲。\n       self.driver = webdriver.Remote(uri, desired_caps)\n\n\n   def test_searchbox(self):\n        # 找到包含&rdquo;Tab4&rdquo;字符串的控件。\n        if self.automationName == \'Appium\':\n            tab4 = self.driver.find_element_by_name(&quot;Tab4&quot;)\n        else:\n            tab4 = self.driver.find_element_by_link_text(&quot;Tab4&quot;)\n        # 点击.\n        tab4.click()\n\n        # 等待2秒钟\n        time.sleep(2)\n\n        # 通过控件类名找到用户名和密码输入框。\n        editTexts = self.driver.find_elements_by_class_name(&quot;android.widget.EditText&quot;)\n        # 第一个框为用户名输入框，输入用户名；第二个框为密码框，输入密码\n        editTexts[0].send_keys(&quot;admin&quot;)\n        editTexts[1].send_keys(&quot;admin&quot;)\n        # 隐藏出现的软键盘\n        self.driver.hide_keyboard()\n\n        # 找到包含&ldquo;登录&rdquo;的按钮并点击\n        if self.automationName == \'Appium\':\n            self.driver.find_element_by_name(&quot;登陆&quot;).click()\n        else:\n            self.driver.find_element_by_link_text(&quot;登陆&quot;).click()\n        # 等待3秒钟，登录需要与服务器通讯。 \n        time.sleep(3)\n\n   def tearDown(self): \n        # 测试结束，退出会话。 \n        self.driver.quit()\n\n几种查找控件的方法（在类By下）：\n\n    1. ID : 通过resource-id查找。注意，测试Android应用时，Appium引擎和Selendroid引擎的id写法不同，Appium下类似这样：com.alibaba.mts.mtsdemoapp:id/login_login_button；而Selendroid下id是：login_login_button。所以，如果要写通用的脚本，建议使用其他查找方式。\n\n    2. XPATH : 通过xpath寻找。例如查找一个包含“Add note”字符串的TextView控件：driver.findElement(By.XPATH, \"//android.widget.TextView[contains(@text,\'Add note\')]\")。点击查看更多XPATH语法。\n\n    3. LINK_TEXT : (不支持Android 4.2.1以下)通过控件的文本文字查找，比如：driver.findElement(By.LINK_TEXT, “登录”)，找到控件文字为“登录”控件。注意，它不会匹配“登录吧”、“快登录”等文字。建议使用下面的“PARTIAL_LINK_TEXT”。\n\n    4. PARTIAL_LINK_TEXT : (不支持Android 4.2.1以下)类似LINK_TEXT，但是可以匹配“登录吧”、“快登录”等文本的控件。只要包含“登录”即可。\n\n    5. NAME : 与ACCESSIBILITY_ID相同，通过content description查找。content description是为生理缺陷的人使用的，比如色盲人员看不清图片，可以通过TalkBack等软件朗读content description的内容。\n\n    6. TAG_NAME : 通过控件类名查找，比如EditText、Button等等。\n\n    7. CLASS_NAME : 通过控件全类名查找，比如android.widget.EditText 、android.widget.Button等。\n\n    8. CSS_SELECTOR : 只用于Hybird APP，通过CSS选择器，查找WebView中的HTML控件。\n\n    9. ACCESSIBILITY_ID : 同NAME。\n\n    更多示例请参考：hybird app查找方法、native app查找方法。\n\n关于支持操作：\n\n    Appium支持滑动、点击、输入、安装、启动等方法，请参考详细文档。\n\n \n\n3. 启动Appium Server\n\n \n\n在本地的命令行中执行命令： appium –p 50000\n\n注：启动参数释义：\n\n    1.  ”-p”: 指定appium server监听的端口号。\n\n    2. “-a”: 指定appium server的ip地址。\n\n    3.  “-selendroid-port” : selendroid模式下，adb forward的端口。\n\n    4.  “-U” : 当挂载多个设备时，可以通过此参数指定某个设备的串号，这样Appium server就可以知道是要在这个设备上进行测试。\n\n    5.  “--full-reset” : 如果加上此参数，设备每个case完成时都会对设备进行完全的清理。\n\n \n\n4. 执行测试用例\n\n \n\n在命令行中执行命令：\n\n\npython -m unittest&nbsp; main\n\n其中main就是我们刚刚创建的测试用例：main.py\n\n \n\n5. 提交到MQC云平台\n\n \n\n本地测试通过之后，将所有测试文件打包成zip文件，然后在“功能测试”里，提交被测应用和打包后的脚本ZIP包。\n\n注意，目前只支持一个main.py作为testsuite，并且请使用unittest作为用例测试工具。更多问题，请到我们的旺旺交流群（群号：335334143）中反馈。',0,14,3),(32,'2015-07-14 10:01:25','2017-03-01 01:04:13','&lt;h3&gt;MQC一直在探索和寻找各种方法帮助用户发现更多的问题、更快速的定位问题。 为此，我们提供了两类不同的截图功能来满足不同的用户的需求。&lt;/h3&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h3&gt;自动截图&lt;/h3&gt;\n\n&lt;p&gt;自动截图是我们提供的一种默认的截图方式，测试系统会在APP测试过程中，自动的进行屏幕抓取。这种方式下，您无需增加任何成本，只需要将APP和测试脚本提交即可。&lt;/p&gt;\n\n&lt;h3&gt;自定义截图&lt;/h3&gt;\n\n&lt;p&gt;系统自动截图，有时候并不能满足您的精确截图的需求（比如把截图作为功能测试通过与否的决定条件）。为了满足精确截图的需求，我们推出了自定义截图功能， 自定义截图能够非常精确的进行截图。自定义截图是通过logcat日志发送截图消息实现的。&lt;/p&gt;\n\n&lt;h3&gt;使用方法&lt;/h3&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;1. Robotium脚本&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; 在Robotium脚本中，我们需要通过Android系统自带的日志系统（android.util.Log）进行截图消息发送，具体使用方法：&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; a. 不指定截图文件名，使用时间戳作为文件名&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;\n&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;Log.i(&amp;quot;MQC-LOG-MASTER&amp;quot;, &amp;nbsp;&amp;quot;screenshot&amp;quot;);\n\n&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;solo.sleep(2000);&amp;nbsp; // 调用截图，请等待2秒钟。\n&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; b.&amp;nbsp;指定截图文件名&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;\n&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;Log.i(&amp;quot;MQC-LOG-MASTER&amp;quot;,&amp;nbsp; &amp;quot;screenshot&amp;nbsp; picName&amp;quot;); // 以picName作为本次截图的文件名。\n\n&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;solo.sleep(2000);&amp;nbsp; // 调用截图，请等待2秒钟\n&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;2. Appium脚本&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp;&amp;nbsp;我们需要调用Appium的Python 客户端包中的方法：&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;a. 不指定截图文件名称，使用时间戳作为文件名&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;\n&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;// dirver 是Appium WebDriver的一个实例对象，可以通过driver 下的各个方法操作设备，比如shell函数，就是在手机上执行一个shell命令。\n\n&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;driver.shell(&amp;quot;log &amp;nbsp;-p &amp;nbsp;i &amp;nbsp;-t &amp;nbsp;MQC-LOG-MASTER &amp;nbsp;screenshot&amp;quot;)\n\n&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;// 需要import time 这个包\n\n&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;time.sleep(2) // 等待2s\n&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;b. 指定截图文件名&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;\n&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;// 以picName作为本次截图的名称\n\n&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;driver.shell(&amp;quot;log &amp;nbsp;-p &amp;nbsp;i &amp;nbsp;-t &amp;nbsp;MQC-LOG-MASTER &amp;nbsp;screenshot&amp;nbsp; picName&amp;quot;)\n\n&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;// 需要import time 这个包\n\n&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;time.sleep(2) // 等待2s\n&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;','截图策略','字白','MQC一直在探索和寻找各种方法帮助用户发现更多的问题、更快速的定位问题。 为此，我们提供了两类不同的截图功能来满足不同的用户的需求。\n\n \n\n自动截图\n\n自动截图是我们提供的一种默认的截图方式，测试系统会在APP测试过程中，自动的进行屏幕抓取。这种方式下，您无需增加任何成本，只需要将APP和测试脚本提交即可。\n\n自定义截图\n\n系统自动截图，有时候并不能满足您的精确截图的需求（比如把截图作为功能测试通过与否的决定条件）。为了满足精确截图的需求，我们推出了自定义截图功能， 自定义截图能够非常精确的进行截图。自定义截图是通过logcat日志发送截图消息实现的。\n\n使用方法\n\n \n\n1. Robotium脚本\n\n    在Robotium脚本中，我们需要通过Android系统自带的日志系统（android.util.Log）进行截图消息发送，具体使用方法：\n\n    a. 不指定截图文件名，使用时间戳作为文件名\n\n\n\n&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Log.i(&quot;MQC-LOG-MASTER&quot;, &nbsp;&quot;screenshot&quot;);\n\n&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;solo.sleep(2000);&nbsp; // 调用截图，请等待2秒钟。\n\n\n    b. 指定截图文件名\n\n\n\n&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Log.i(&quot;MQC-LOG-MASTER&quot;,&nbsp; &quot;screenshot&nbsp; picName&quot;); // 以picName作为本次截图的文件名。\n\n&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;solo.sleep(2000);&nbsp; // 调用截图，请等待2秒钟\n\n\n \n\n2. Appium脚本\n\n    我们需要调用Appium的Python 客户端包中的方法：\n\n     a. 不指定截图文件名称，使用时间戳作为文件名\n\n\n\n&nbsp; &nbsp; &nbsp; &nbsp;// dirver 是Appium WebDriver的一个实例对象，可以通过driver 下的各个方法操作设备，比如shell函数，就是在手机上执行一个shell命令。\n\n&nbsp; &nbsp; &nbsp; &nbsp;driver.shell(&quot;log &nbsp;-p &nbsp;i &nbsp;-t &nbsp;MQC-LOG-MASTER &nbsp;screenshot&quot;)\n\n&nbsp; &nbsp; &nbsp; &nbsp;// 需要import time 这个包\n\n&nbsp; &nbsp; &nbsp; &nbsp;time.sleep(2) // 等待2s\n\n\n     b. 指定截图文件名\n\n\n\n&nbsp; &nbsp; &nbsp; &nbsp;// 以picName作为本次截图的名称\n\n&nbsp; &nbsp; &nbsp; &nbsp;driver.shell(&quot;log &nbsp;-p &nbsp;i &nbsp;-t &nbsp;MQC-LOG-MASTER &nbsp;screenshot&nbsp; picName&quot;)\n\n&nbsp; &nbsp; &nbsp; &nbsp;// 需要import time 这个包\n\n&nbsp; &nbsp; &nbsp; &nbsp;time.sleep(2) // 等待2s\n\n\n ',0,3,10),(33,'2015-07-14 10:02:35','2016-10-12 18:45:37','&lt;h3&gt;什么是账号池？&lt;/h3&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;为了解决一些应用的账号体系只能单点登录的问题（多人登录相同账号会互踢，比如&amp;ldquo;手机淘宝&amp;rdquo;），我们提供了账号池功能。所谓账号池，实际就是要求用户在测试单点登录的APP时，需要提供多个不同的测试账号。在提交账号时，用户需要注意一下几点：&lt;/p&gt;\n\n&lt;p&gt;1. 同一单点登录的账号体系下的相同的账号不能同时在两个任务任务中提交。 用户在一个任务中提交了账号A和账号B，在这个任务执行完毕之前，不能再用账号A和账号B提交其他需要登录得任务。以防止两个任务在执行过程中，互相干扰。&lt;/p&gt;\n\n&lt;p&gt;2. 单个任务中，您提交的账号个数越多，执行的速度将会越快。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h3&gt;Robotium脚本使用账号池&lt;/h3&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;在之前的 &lt;a href=&quot;http://mqc.aliyun.com/doc.htm?id=8&quot;&gt;如何编写Robotium脚本&lt;/a&gt; 这个文档中，我们知道在命令行里启动测试的命令：&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;adb shell am instrument -w com.jayway.test.test/android.test.InstrumentationTestRunner&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;其中，android.test.InstrumentationTestRunner是用来启动测试的。事实上，InstrumentationTestRunner远非启动测试这么简单。它负责 加载测试用例、准备测试环境（setup）、执行测试用例（run）、测试完成后的清理（tear down）等一系列的内容。&lt;/p&gt;\n\n&lt;p&gt;在账号池的功能中，我们需要给测试脚本APK传入一些参数，这需要我们定制我们自己的testRunner，不再使用默认的android.test.InstrumentationTestRunner。&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;\npackage com.alibaba.mqc.test;\n\nimport android.os.Bundle;\n\nimport android.test.InstrumentationTestRunner;\n\npublic class MqcTestRunner extends InstrumentationTestRunner {\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; private String username = null;\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; private String password = null;\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; @Override\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; public void onCreate(Bundle arguments) {\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; // TODO Auto-generated method stub\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; super.onCreate(arguments);\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; if(arguments != null) {\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; if(arguments.containsKey(&amp;quot;username&amp;quot;)) {\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; username = arguments.getString(&amp;quot;username&amp;quot;);\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; }\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; if(arguments.containsKey(&amp;quot;password&amp;quot;)) {\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; password = arguments.getString(&amp;quot;password&amp;quot;);\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; }\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; }\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; }\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; public String getUsername() {\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; return username;\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; }\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; public String getPassword() {\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; return password;\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; }\n\n}\n&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;之后，我们需要修改测试脚本APK的AndroidManifest.xml文件，使用我们定制后的TestRunner:&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;\n&amp;lt;?xml version=&amp;quot;1.0&amp;quot; encoding=&amp;quot;utf-8&amp;quot;?&amp;gt;\n\n&amp;lt;manifest xmlns:android=&amp;quot;http://schemas.android.com/apk/res/android&amp;quot;\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp; package=&amp;quot;com.alibaba.mqc.test&amp;quot;\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp; android:versionCode=&amp;quot;1&amp;quot;\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp; android:versionName=&amp;quot;1.0&amp;quot; &amp;gt;\n\n&amp;nbsp;\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;lt;uses-sdk android:minSdkVersion=&amp;quot;14&amp;quot; /&amp;gt;\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; // 在这里使用我们定制的MqcTestRunner.\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;lt;instrumentation\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; android:name=&amp;quot;com.alibaba.mqc.test.MqcTestRunner&amp;quot;\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; android:targetPackage=&amp;quot;com.alibaba.mts.mtsdemoapp&amp;quot; /&amp;gt;\n\n&amp;nbsp;\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;lt;application\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; android:icon=&amp;quot;@drawable/ic_launcher&amp;quot;\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; android:label=&amp;quot;@string/app_name&amp;quot; &amp;gt;\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;lt;uses-library android:name=&amp;quot;android.test.runner&amp;quot; /&amp;gt;\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;lt;/application&amp;gt;\n\n&amp;nbsp;\n\n&amp;lt;/manifest&amp;gt;\n&lt;/code&gt;\n&lt;/pre&gt;\n\n&lt;p&gt;然后，我们需要在TestCase中需要登录的时候，获取到传入的用户名和密码，并填写到输入控件中。具体方法如下：&lt;/p&gt;\n\n&lt;p&gt;最后，本地测试功能脚本时，可以通过如下命令进行测试， 比如用户名和密码都为admin， 则启动命令为：&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;\npublic void testLogin() throws Exception {\n\n// 启动之后，等待5s，UI界面稳定下来\n\nsolo.sleep(5000);\n\n// 图例3.3.1：在文字&amp;ldquo;Tab4&amp;rdquo;上点击，进入登录页\n\nsolo.clickOnText(&amp;quot;Tab4&amp;quot;);\n\n// Activity切换时，最好等待一会儿。否则，某些异步元素可能还没加载\n\nsolo.sleep(5000);\n\n// 图例3.3.2：此Activity中只有两个EditText控件，索引0是用户名控件。\n\nEditText user = solo.getEditText(0);\n\n// enterText用于向EditText控件中输入内容，用户名为TestRunner传入的参数\n\nString username = ((MqcTestRunner)getInstrumentation()).getUsername();\n\nsolo.enterText(user, username);\n\n// 图例3.3.2：索引1是密码控件\n\nEditText pwd = solo.getEditText(1);\n\n// 密码也是TestRunner传入的参数\n\nString password = ((MqcTestRunner)getInstrumentation()).getPassword();\n\nsolo.enterText(pwd, password);\n\n// 点击包含&amp;ldquo;登录&amp;rdquo;文字的控件。如果Activity中包含多个&amp;ldquo;登录&amp;rdquo;，我们需要指定控件索引，像下面数字2。这个索引可能需要尝试几次获取。\n\nsolo.clickOnText(&amp;quot;登陆&amp;quot;, 2);\n\n// 图例3.3.3: 测试完成之后，等待5s结束。一般登录需要跟后台交互，这里的等待是这个目的。\n\nsolo.sleep(5000);\n\n}\n&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;本地测试功能脚本时，可以通过如下命令进行测试， 比如用户名和密码都为admin， 则启动命令为：&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;\nadb shell am instrument -w -e username admin -e password admin com.alibaba.mqc.test/com.alibaba.mqc.test.MqcTestRunner\n&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h3&gt;Appium脚本使用账号池&lt;/h3&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;在使用Appium 脚本测试过程中，MQC平台会为您在desired_capabilities.py注入两个函数，分别用来获取用户名和密码，示例如下：&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;\n#!/usr/bin/env python\n\n&amp;nbsp;\n\ndef get_desired_capabilities():\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp; desired_caps = {\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; \'platformName\': \'Android\',\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; \'platformVersion\': \'4.0.4\',\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; \'deviceName\': \'V889F\',\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;nbsp;&amp;nbsp; \'appPackage\': \'com.alibaba.mts.mtsdemoapp\',\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; &amp;nbsp;&amp;nbsp; \'appWaitPackage\': \'com.alibaba.mts.mtsdemoapp\',\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; \'app\': &amp;quot;/tmp/task.apk&amp;quot;,\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; \'newCommandTimeout\': 30,&amp;nbsp;\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; \'automationName\': \'Selendroid\'\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp; }\n\n&amp;nbsp;\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp; return desired_caps\n\n&amp;nbsp;\n\ndef get_uri():\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp; return &amp;quot;http://localhost:666/wd/hub&amp;quot;\n\n&amp;nbsp;\n\ndef get_username():\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp; return &amp;quot;admin&amp;quot;\n\n&amp;nbsp;\n\ndef get_password():\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp; return &amp;quot;admin&amp;quot;\n&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;这样，我们就可以通过 get_username和get_password两个方法获取被分配的用户名和密码了。&lt;/p&gt;\n\n&lt;p&gt;用Appium Python脚本进行登录的示例：&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;\nfrom appium import webdriver\n\nimport desired_capabilities\n\nimport time\n\n&amp;nbsp;\n\n// 通过desired_capabilities.py获取本次测试的参数配置\n\ndesired_caps = desired_capabilities.get_desired_capabilities()\n\n// 获取Appium Server的地址\n\nuri = desired_capabilities.get_uri()\n\n// 获取用户名\n\nusername = desired_capabilities.get_username()\n\n// 获取密码\n\npassword = desired_capabilities.get_password()\n\n// 初始化本次操作的会话（Session），构建连接。\n\ndriver = webdriver.Remote(uri, desired_caps)\n\n// 在手机的logcat中打印一条Tag为MQC-LOG-MASTER 的info日志：\n\n// screenshot picName 用以发送截图消息。\n\ndriver.shell(&amp;quot;log -p i -t MQC-LOG-MASTER screenshot&amp;quot;)\n\n// 找到id为tab_four_image的控件。\n\ntab4 = driver.find_element(value=&amp;quot;tab_four_image&amp;quot;)\n\n// 点击tab_four_image的控件\n\ntab4.click()\n\n// 等待一会儿，让Activity切换完成。\n\ntime.sleep(3)\n\n&amp;nbsp;\n\n// 找到id为login_user_edit的控件，是一个文本输入框控件\n\nusernameInput = driver.find_element(value=&amp;quot;login_user_edit&amp;quot;)\n\n// 输入被分配的用户名\n\nusernameInput.send_keys(username)\n\n&amp;nbsp;\n\n// 找到id为login_password_edit的控件，是密码输入框控件\n\npasswordInput = driver.find_element(value=&amp;quot;login_password_edit&amp;quot;)\n\n// 输入被分配的密码\n\npasswordInput.send_keys(password)\n\n&amp;nbsp;\n\n// 隐藏掉弹出的软键盘\n\ndriver.hide_keyboard()\n\n// 找到id为login_login_button的控件，登录按钮。\n\nloginBtn = driver.find_element(value=&amp;quot;login_login_button&amp;quot;)\n\n// 点击登录按钮\n\nloginBtn.click()\n\n&amp;nbsp;\n\n// 等待3s与后台服务器通信完成\n\ntime.sleep(3)\n\n&amp;nbsp;\n\n// 结束本次会话（Session）\n\ndriver.quit()\n&lt;/code&gt;&lt;/pre&gt;','账号池功能','字白','什么是账号池？\n\n \n\n为了解决一些应用的账号体系只能单点登录的问题（多人登录相同账号会互踢，比如“手机淘宝”），我们提供了账号池功能。所谓账号池，实际就是要求用户在测试单点登录的APP时，需要提供多个不同的测试账号。在提交账号时，用户需要注意一下几点：\n\n1. 同一单点登录的账号体系下的相同的账号不能同时在两个任务任务中提交。 用户在一个任务中提交了账号A和账号B，在这个任务执行完毕之前，不能再用账号A和账号B提交其他需要登录得任务。以防止两个任务在执行过程中，互相干扰。\n\n2. 单个任务中，您提交的账号个数越多，执行的速度将会越快。\n\n \n\nRobotium脚本使用账号池\n\n \n\n在之前的 如何编写Robotium脚本 这个文档中，我们知道在命令行里启动测试的命令：\n\n\nadb shell am instrument -w com.jayway.test.test/android.test.InstrumentationTestRunner\n\n其中，android.test.InstrumentationTestRunner是用来启动测试的。事实上，InstrumentationTestRunner远非启动测试这么简单。它负责 加载测试用例、准备测试环境（setup）、执行测试用例（run）、测试完成后的清理（tear down）等一系列的内容。\n\n在账号池的功能中，我们需要给测试脚本APK传入一些参数，这需要我们定制我们自己的testRunner，不再使用默认的android.test.InstrumentationTestRunner。\n\n\n\npackage com.alibaba.mqc.test;\n\nimport android.os.Bundle;\n\nimport android.test.InstrumentationTestRunner;\n\npublic class MqcTestRunner extends InstrumentationTestRunner {\n\n&nbsp;&nbsp;&nbsp;&nbsp; private String username = null;\n\n&nbsp;&nbsp;&nbsp;&nbsp; private String password = null;\n\n&nbsp;&nbsp;&nbsp;&nbsp; @Override\n\n&nbsp;&nbsp;&nbsp;&nbsp; public void onCreate(Bundle arguments) {\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; // TODO Auto-generated method stub\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; super.onCreate(arguments);\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; if(arguments != null) {\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; if(arguments.containsKey(&quot;username&quot;)) {\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; username = arguments.getString(&quot;username&quot;);\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; }\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; if(arguments.containsKey(&quot;password&quot;)) {\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; password = arguments.getString(&quot;password&quot;);\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; }\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; }\n\n&nbsp;&nbsp;&nbsp;&nbsp; }\n\n&nbsp;&nbsp;&nbsp;&nbsp; public String getUsername() {\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; return username;\n\n&nbsp;&nbsp;&nbsp;&nbsp; }\n\n&nbsp;&nbsp;&nbsp;&nbsp; public String getPassword() {\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; return password;\n\n&nbsp;&nbsp;&nbsp;&nbsp; }\n\n}\n\n\n之后，我们需要修改测试脚本APK的AndroidManifest.xml文件，使用我们定制后的TestRunner:\n\n\n\n&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-8&quot;?&gt;\n\n&lt;manifest xmlns:android=&quot;http://schemas.android.com/apk/res/android&quot;\n\n&nbsp;&nbsp;&nbsp; package=&quot;com.alibaba.mqc.test&quot;\n\n&nbsp;&nbsp;&nbsp; android:versionCode=&quot;1&quot;\n\n&nbsp;&nbsp;&nbsp; android:versionName=&quot;1.0&quot; &gt;\n\n&nbsp;\n\n&nbsp;&nbsp;&nbsp; &lt;uses-sdk android:minSdkVersion=&quot;14&quot; /&gt;\n\n&nbsp;&nbsp;&nbsp;\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; // 在这里使用我们定制的MqcTestRunner.\n\n&nbsp;&nbsp;&nbsp; &lt;instrumentation\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; android:name=&quot;com.alibaba.mqc.test.MqcTestRunner&quot;\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; android:targetPackage=&quot;com.alibaba.mts.mtsdemoapp&quot; /&gt;\n\n&nbsp;\n\n&nbsp;&nbsp;&nbsp; &lt;application\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; android:icon=&quot;@drawable/ic_launcher&quot;\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; android:label=&quot;@string/app_name&quot; &gt;\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;uses-library android:name=&quot;android.test.runner&quot; /&gt;\n\n&nbsp;&nbsp;&nbsp; &lt;/application&gt;\n\n&nbsp;\n\n&lt;/manifest&gt;\n\n\n\n然后，我们需要在TestCase中需要登录的时候，获取到传入的用户名和密码，并填写到输入控件中。具体方法如下：\n\n最后，本地测试功能脚本时，可以通过如下命令进行测试， 比如用户名和密码都为admin， 则启动命令为：\n\n\n\npublic void testLogin() throws Exception {\n\n// 启动之后，等待5s，UI界面稳定下来\n\nsolo.sleep(5000);\n\n// 图例3.3.1：在文字&ldquo;Tab4&rdquo;上点击，进入登录页\n\nsolo.clickOnText(&quot;Tab4&quot;);\n\n// Activity切换时，最好等待一会儿。否则，某些异步元素可能还没加载\n\nsolo.sleep(5000);\n\n// 图例3.3.2：此Activity中只有两个EditText控件，索引0是用户名控件。\n\nEditText user = solo.getEditText(0);\n\n// enterText用于向EditText控件中输入内容，用户名为TestRunner传入的参数\n\nString username = ((MqcTestRunner)getInstrumentation()).getUsername();\n\nsolo.enterText(user, username);\n\n// 图例3.3.2：索引1是密码控件\n\nEditText pwd = solo.getEditText(1);\n\n// 密码也是TestRunner传入的参数\n\nString password = ((MqcTestRunner)getInstrumentation()).getPassword();\n\nsolo.enterText(pwd, password);\n\n// 点击包含&ldquo;登录&rdquo;文字的控件。如果Activity中包含多个&ldquo;登录&rdquo;，我们需要指定控件索引，像下面数字2。这个索引可能需要尝试几次获取。\n\nsolo.clickOnText(&quot;登陆&quot;, 2);\n\n// 图例3.3.3: 测试完成之后，等待5s结束。一般登录需要跟后台交互，这里的等待是这个目的。\n\nsolo.sleep(5000);\n\n}\n\n\n本地测试功能脚本时，可以通过如下命令进行测试， 比如用户名和密码都为admin， 则启动命令为：\n\n\n\nadb shell am instrument -w -e username admin -e password admin com.alibaba.mqc.test/com.alibaba.mqc.test.MqcTestRunner\n\n\n \n\nAppium脚本使用账号池\n\n \n\n在使用Appium 脚本测试过程中，MQC平台会为您在desired_capabilities.py注入两个函数，分别用来获取用户名和密码，示例如下：\n\n\n\n#!/usr/bin/env python\n\n&nbsp;\n\ndef get_desired_capabilities():\n\n&nbsp;&nbsp;&nbsp; desired_caps = {\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; \'platformName\': \'Android\',\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; \'platformVersion\': \'4.0.4\',\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; \'deviceName\': \'V889F\',\n\n&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; \'appPackage\': \'com.alibaba.mts.mtsdemoapp\',\n\n&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; \'appWaitPackage\': \'com.alibaba.mts.mtsdemoapp\',\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; \'app\': &quot;/tmp/task.apk&quot;,\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; \'newCommandTimeout\': 30,&nbsp;\n\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; \'automationName\': \'Selendroid\'\n\n&nbsp;&nbsp;&nbsp; }\n\n&nbsp;\n\n&nbsp;&nbsp;&nbsp; return desired_caps\n\n&nbsp;\n\ndef get_uri():\n\n&nbsp;&nbsp;&nbsp; return &quot;http://localhost:666/wd/hub&quot;\n\n&nbsp;\n\ndef get_username():\n\n&nbsp;&nbsp;&nbsp; return &quot;admin&quot;\n\n&nbsp;\n\ndef get_password():\n\n&nbsp;&nbsp;&nbsp; return &quot;admin&quot;\n\n\n这样，我们就可以通过 get_username和get_password两个方法获取被分配的用户名和密码了。\n\n用Appium Python脚本进行登录的示例：\n\n\n\nfrom appium import webdriver\n\nimport desired_capabilities\n\nimport time\n\n&nbsp;\n\n// 通过desired_capabilities.py获取本次测试的参数配置\n\ndesired_caps = desired_capabilities.get_desired_capabilities()\n\n// 获取Appium Server的地址\n\nuri = desired_capabilities.get_uri()\n\n// 获取用户名\n\nusername = desired_capabilities.get_username()\n\n// 获取密码\n\npassword = desired_capabilities.get_password()\n\n// 初始化本次操作的会话（Session），构建连接。\n\ndriver = webdriver.Remote(uri, desired_caps)\n\n// 在手机的logcat中打印一条Tag为MQC-LOG-MASTER 的info日志：\n\n// screenshot picName 用以发送截图消息。\n\ndriver.shell(&quot;log -p i -t MQC-LOG-MASTER screenshot&quot;)\n\n// 找到id为tab_four_image的控件。\n\ntab4 = driver.find_element(value=&quot;tab_four_image&quot;)\n\n// 点击tab_four_image的控件\n\ntab4.click()\n\n// 等待一会儿，让Activity切换完成。\n\ntime.sleep(3)\n\n&nbsp;\n\n// 找到id为login_user_edit的控件，是一个文本输入框控件\n\nusernameInput = driver.find_element(value=&quot;login_user_edit&quot;)\n\n// 输入被分配的用户名\n\nusernameInput.send_keys(username)\n\n&nbsp;\n\n// 找到id为login_password_edit的控件，是密码输入框控件\n\npasswordInput = driver.find_element(value=&quot;login_password_edit&quot;)\n\n// 输入被分配的密码\n\npasswordInput.send_keys(password)\n\n&nbsp;\n\n// 隐藏掉弹出的软键盘\n\ndriver.hide_keyboard()\n\n// 找到id为login_login_button的控件，登录按钮。\n\nloginBtn = driver.find_element(value=&quot;login_login_button&quot;)\n\n// 点击登录按钮\n\nloginBtn.click()\n\n&nbsp;\n\n// 等待3s与后台服务器通信完成\n\ntime.sleep(3)\n\n&nbsp;\n\n// 结束本次会话（Session）\n\ndriver.quit()\n',0,3,11),(37,'2015-08-11 16:38:41','2016-10-12 18:45:37','&lt;h1&gt;Native Crash简介&lt;/h1&gt;\n\n&lt;p&gt;Native的Crash指在C/C++运行时出错，系统产生了Linux错误信号，导致的进程出错退出。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h1&gt;Native Crash分析定位&lt;/h1&gt;\n\n&lt;p&gt;Android开发中，在Java层可以方便的捕获crashlog，但对于Native层的crashlog通常无法直接获取，只能通过系统的logcat来分析crash日志。这里我们建议开发者使用NDK工具ndk-stack进行分析定位。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;1.&amp;nbsp;下载最新版NDK：&lt;a href=&quot;https://developer.android.com/ndk/downloads/index.html&quot;&gt;NDK下载地址&lt;/a&gt;。ndk-stack工具就在NDK主目录下。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;2.&amp;nbsp;在mqc管理中心找到出现Native Crash的测试，并下载日志，如下图所示：&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/c2309434e0cddbc1a3db08b023179791.png&quot; style=&quot;height:391px; width:900px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;3.&amp;nbsp;根据失败机型查找该机型的CPU信息ro.product.cpu.abi，如图三星N7100的cpu类型为armeabi-v7a。(目前mqc上的模拟器cpu类型均为x86_64。)&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;4.&amp;nbsp;使用ndk-stack分析出错位置，命令格式如下：&lt;/p&gt;\n\n&lt;p&gt;&lt;code&gt;$NDK/ndk-stack -sym $PROJECT_PATH/obj/local/$cpu.abi -dump $LOGCAT_PATH&lt;/code&gt;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; 本示例使用的命令如下：&lt;/p&gt;\n\n&lt;p&gt;&lt;code&gt;ndk-stack -sym ./workspace2/testNdkStack/obj/local/armeabi-v7a/ -dump ./logcat.log &amp;gt; result.log&lt;/code&gt;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; 如下图所示，可以分析定位到出现该crash的具体行数在jni.cpp的65行：&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/26e22638409aaccaa679c2b052f6ac1d.png&quot; style=&quot;height:522px; width:900px&quot; /&gt;&amp;nbsp;&lt;/p&gt;','Native Crash文档','千瞬','Native Crash简介\n\nNative的Crash指在C/C++运行时出错，系统产生了Linux错误信号，导致的进程出错退出。\n\n \n\nNative Crash分析定位\n\nAndroid开发中，在Java层可以方便的捕获crashlog，但对于Native层的crashlog通常无法直接获取，只能通过系统的logcat来分析crash日志。这里我们建议开发者使用NDK工具ndk-stack进行分析定位。\n\n \n\n 1. 下载最新版NDK：NDK下载地址。ndk-stack工具就在NDK主目录下。\n\n \n\n 2. 在mqc管理中心找到出现Native Crash的测试，并下载日志，如下图所示：\n\n\n\n \n\n 3. 根据失败机型查找该机型的CPU信息ro.product.cpu.abi，如图三星N7100的cpu类型为armeabi-v7a。(目前mqc上的模拟器cpu类型均为x86_64。)\n\n \n\n 4. 使用ndk-stack分析出错位置，命令格式如下：\n\n$NDK/ndk-stack -sym $PROJECT_PATH/obj/local/$cpu.abi -dump $LOGCAT_PATH\n\n    本示例使用的命令如下：\n\nndk-stack -sym ./workspace2/testNdkStack/obj/local/armeabi-v7a/ -dump ./logcat.log > result.log\n\n    如下图所示，可以分析定位到出现该crash的具体行数在jni.cpp的65行：\n\n ',0,3,9),(39,'2015-09-17 10:39:00','2015-09-17 10:39:00',NULL,'iOS测试','间客',NULL,0,3,5),(40,'2015-09-17 10:40:44','2015-09-17 11:56:46','&lt;h2&gt;简介&lt;/h2&gt;\n\n&lt;p&gt;UI Automation是苹果公司提供的测试框架，开发者可以利用它在真实设备或者模拟器上测试iOS应用。UI Automation的编程语言为JavaScript。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;1. 搭建并进入UI Automation环境&lt;/h2&gt;\n\n&lt;p&gt;苹果公司已经为开发者们提供了一套Instruments工具，它被包含在Xcode中。因此只需下载安装Xcode就可以使用UI Automation。&amp;nbsp;&lt;/p&gt;\n\n&lt;h3&gt;a.&amp;nbsp;安装Xcode（本文以Xcode 6.4为例）。&lt;/h3&gt;\n\n&lt;h3&gt;b.&amp;nbsp;在真机或模拟器上安装待测app。&lt;/h3&gt;\n\n&lt;h3&gt;c. 进入Xcode，在菜单栏依次点击Xcode -&amp;gt; Open Developer Tool -&amp;gt;&amp;nbsp;Instruments。&lt;/h3&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/29b8baaae4c0fb306ef4bff4216f06a1.png&quot; style=&quot;border-style:solid; border-width:0px; height:273px; margin-bottom:6px; margin-top:6px; width:500px&quot; /&gt;&lt;/p&gt;\n\n&lt;h3&gt;d.&amp;nbsp;双击Automation&lt;/h3&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/4487e0409d12f410a644e49660a592de.png&quot; style=&quot;height:263px; margin-bottom:6px; margin-top:6px; width:500px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;2.&amp;nbsp;熟悉UI Automation图形界面和基本功能&amp;nbsp;&lt;/h2&gt;\n\n&lt;p&gt;下图为UI Automation的图形界面&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/c517eb0fb8318b13615886695a5c77be.png&quot; style=&quot;height:242px; margin-bottom:6px; margin-top:6px; width:500px&quot; /&gt;&lt;/p&gt;\n\n&lt;h3&gt;a.&amp;nbsp;在左上方区域，我们可以选择模拟器或真机设备，以及设备上待测的app。&lt;/h3&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/d78050772b38ac14c1715e2cddaad5f8.png&quot; style=&quot;height:32px; margin-bottom:6px; margin-top:6px; width:321px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;本文接下来介绍的测试将在iPhone 6模拟器下进行，激活方式如下图&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/eb344ec0dc4bbc7175196392e0354c08.png&quot; style=&quot;height:289px; margin-bottom:6px; margin-top:6px; width:500px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;选择要测试的app（本文以&amp;ldquo;开源中国&amp;rdquo;为例）&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/f2370453a78f9392e1b03da741e6a2a2.png&quot; style=&quot;height:45px; margin-bottom:6px; margin-top:6px; width:359px&quot; /&gt;&lt;/p&gt;\n\n&lt;h3&gt;b.&amp;nbsp;在右下方区域，点击中间的按钮（下图红色方框），在这里我们可以点击&amp;ldquo;Add&amp;rdquo;选择&amp;ldquo;Create&amp;rdquo;新建脚本或者&amp;ldquo;Import&amp;rdquo;导入已经写好的脚本；双击脚本可以修改脚本的名称。&lt;/h3&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/44174aec77bac2f6d5bfa60b5ee1ff60.png&quot; style=&quot;height:299px; margin-bottom:6px; margin-top:6px; width:173px&quot; /&gt;&lt;/p&gt;\n\n&lt;h3&gt;c.&amp;nbsp;在左下方区域，选择Script面板可以编写脚本，选择Trace Log面板则展示日志信息。注意到，新建的脚本已经自动生成了一行代码，这行代码十分常用，几乎所有的测试脚本都需要这行代码，我们将在后面解释它。&lt;/h3&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/076536067269720bb6b78c2833a9a066.png&quot; style=&quot;height:153px; margin-bottom:6px; margin-top:6px; width:350px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;在Script面板点击右键，选择&amp;ldquo;Export&amp;rdquo;，可以导出写好的脚本。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/f1e14d148362cf220ddf8a9419bc6e9f.png&quot; style=&quot;height:122px; margin-bottom:6px; margin-top:6px; width:265px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;3. 编写脚本&lt;/h2&gt;\n\n&lt;p&gt;打开&amp;ldquo;开源中国&amp;rdquo;app，我们看到如下界面&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/59c8ab7ff8cdee7542971dd4b73373c5.png&quot; style=&quot;height:373px; margin-bottom:6px; margin-top:6px; width:200px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;我们开始编写第一个脚本，这个脚本的目标是点击导航栏左侧的有三条白色横线的按钮。&lt;/p&gt;\n\n&lt;pre&gt;\nvar target = UIATarget.localTarget();  //UIATarget是最上层的类，表示真实设备或模拟器    \n\nvar app = target.frontMostApp();  //取得设备（模拟器）最前端的app\n\nvar navigationBar = app.navigationBar();  //取得导航栏\n\nvar leftButton = navigationBar.leftButton();  //取得导航栏的左侧按钮\n\nleftButton.tap();  //点击左侧按钮&lt;/pre&gt;\n\n&lt;p&gt;运行脚本有两种方式，一种是点击左上方的红色圆圈按钮，效果相当于重新启动app，然后执行脚本内容；&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/baa3fa691b3ae0a6557457dc668865b6.png&quot; style=&quot;height:32px; margin-bottom:6px; margin-top:6px; width:334px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;还有一种是点击最下面的三角形形状的播放按钮，若待测app已经启动，则继续在该app上执行脚本内容。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/34bee5c5662ddd3df4777b17a4bb0292.png&quot; style=&quot;height:34px; margin-bottom:6px; margin-top:6px; width:118px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;上面这段代码的编程风格非常清晰，但是可能会显得繁琐，我们也可以用一行代码实现相同的效果。&lt;/p&gt;\n\n&lt;pre&gt;\n UIATarget.localTarget().frontMostApp().navigationBar().leftButton().tap();&lt;/pre&gt;\n\n&lt;p&gt;运行上述脚本后，我们发现app页面变成了下图，这说明脚本完成了目标。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/0a8ac60cd5917fc81967bc1401c598ec.png&quot; style=&quot;height:366px; margin-bottom:6px; margin-top:6px; width:200px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;打开Trace Log面板，我们发现输出日志与上面这一行代码非常相似。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/95c8f91b340d6979cacb494a8b0a02c5.png&quot; style=&quot;height:77px; margin-bottom:6px; margin-top:6px; width:600px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;接下来，我们要在点击导航栏左侧按钮的基础上，点击左侧的&amp;ldquo;技术问答&amp;rdquo;。&lt;/p&gt;\n\n&lt;pre&gt;\nvar window = app.mainWindow();  //取得app的主窗口 \n\nvar tableView = window.tableViews()[0];  //取得主窗口中的第一个tableView\n\nvar cells = tableView.cells();  //取得tableView中所有cells，返回一个数组\n\nvar techCell = cells[0];  //取得第一个cell\n\ntechCell.tap();  //点击&amp;quot;技术问答&amp;quot;&lt;/pre&gt;\n\n&lt;p&gt;将这段脚本复制到之前写好的脚本后面，执行脚本，发现运行成功，app跳到了&amp;ldquo;技术问答&amp;rdquo;的界面。注意到&lt;em&gt;var techCell = cells[0];&amp;nbsp;&lt;/em&gt;这行代码，我们选择cells[0]是因为我们事先知道&amp;ldquo;技术问答&amp;rdquo;是cells的第一个元素，我们也可以这么写：&lt;em&gt;var techCell = cells[&amp;quot;技术问答&amp;quot;]; &amp;nbsp;&lt;/em&gt;这样也能找到名字为&amp;ldquo;技术问答&amp;rdquo;的元素。&lt;/p&gt;\n\n&lt;p&gt;很多时候，app美妙的动画效果会成为自动化测试的绊脚石，如果动画时间过长，我们却尝试操作（如点击）那些还没来得及出现的元素，这样将导致错误。解决方案是在用delay()方法让脚本延迟指定的一段时间后执行。&lt;/p&gt;\n\n&lt;pre&gt;\ntarget.delay(2);  //延时2秒\n&lt;/pre&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;4. 录制脚本&lt;/h2&gt;\n\n&lt;p&gt;如果你还不熟悉UI Automation的API，那么录制功能将给你带来极大的便利，它会记录下你每次操作的步骤，生成相应的代码。然而，录制功能不能识别一些复杂的操作，因此我们不要过度依赖录制功能。&lt;/p&gt;\n\n&lt;h3&gt;a. 点击红色的录制按钮&lt;/h3&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/0f90ba37ca83a7093f8f021204af3471.png&quot; style=&quot;height:40px; margin-bottom:6px; margin-top:6px; width:112px&quot; /&gt;&lt;/p&gt;\n\n&lt;h3&gt;b. 在真机设备或者模拟器上执行期望的操作&lt;/h3&gt;\n\n&lt;h3&gt;c. 点击停止录制按钮&lt;/h3&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/6b5438ae3575255e33266f2bab37f8a5.png&quot; style=&quot;height:40px; margin-bottom:6px; margin-top:6px; width:112px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;我们录制了一段登录脚本，录制结果如下&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/b4e4400a37b6474b8796c022b3cfad5c.png&quot; style=&quot;height:180px; margin-bottom:6px; margin-top:6px; width:700px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;点击小箭头，我们可以得到更多的可选方案。如下图，buttons()[&amp;quot;我&amp;quot;]，buttons()[5]，elements()[&amp;quot;我&amp;quot;]和elements ()[7]都是等价的，我们可以任选一种，然后双击蓝色区域表示确认，小箭头也随之消失。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/a1e0af87653998c274e6df5527686785.png&quot; style=&quot;height:136px; margin-bottom:6px; margin-top:6px; width:700px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;执行过程如下：&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/cec72b56516df878a52931c97ea7cdec.png&quot; style=&quot;height:370px; margin-bottom:0px; margin-top:0px; width:200px&quot; /&gt;&amp;nbsp;-&amp;gt;&amp;nbsp;&lt;img alt=&quot;&quot; src=&quot;/static/res/be70871e55c90640a74a52721cdfb1f4.png&quot; style=&quot;height:372px; margin-bottom:0px; margin-top:0px; width:200px&quot; /&gt;&amp;nbsp;-&amp;gt;&amp;nbsp;&lt;img alt=&quot;&quot; src=&quot;/static/res/61f34be224aa7b2e2fcd7e32e0a2d484.png&quot; style=&quot;height:371px; margin-bottom:0px; margin-top:0px; width:200px&quot; /&gt;&amp;nbsp;-&amp;gt;&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/38a195db9b192e4333303830d779ffc2.png&quot; style=&quot;height:371px; margin-bottom:0px; margin-top:0px; width:200px&quot; /&gt;&amp;nbsp;-&amp;gt;&amp;nbsp;&lt;img alt=&quot;&quot; src=&quot;/static/res/8ab815304ebaa7d19b3952efe8058c36.png&quot; style=&quot;height:368px; margin-bottom:0px; margin-top:0px; width:200px&quot; /&gt;&amp;nbsp;-&amp;gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/5864170ce03be53f3ad109e18e640983.png&quot; style=&quot;height:369px; margin-bottom:0px; margin-top:0px; width:200px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;5. 理解层次结构&lt;/h2&gt;\n\n&lt;p&gt;在UI Automation框架中，每一个可访问的元素都继承自UIAElement。UIAElement有许多常用的方法，如​&lt;/p&gt;\n\n&lt;p&gt;－ name：返回元素的名称&lt;/p&gt;\n\n&lt;p&gt;－ value：返回元素的值&lt;/p&gt;\n\n&lt;p&gt;－ elements：以Array的形式返回这个元素的子元素&lt;/p&gt;\n\n&lt;p&gt;－ isVisible：若元素可见，返回1；否则返回0&lt;/p&gt;\n\n&lt;p&gt;－ tap：点击这个元素&lt;/p&gt;\n\n&lt;p&gt;－ logElementTree：在日志中输出这个元素和它的子元素的信息&lt;/p&gt;\n\n&lt;p&gt;我们运行下面一段脚本，来查看app的层次结构。&lt;/p&gt;\n\n&lt;pre&gt;\nvar target = UIATarget.localTarget();  //UIATarget是最上层的类，表示真实设备或模拟器\n\ntarget.delay(3);  //延时3秒，跳过开场动画\n\nUIALogger.logMessage(&amp;quot;Test begins&amp;quot;);  //输出测试信息\n\ntarget.logElementTree();  //输出target和它的子元素的信息\n\nUIALogger.logMessage(&amp;quot;Test ends&amp;quot;);  //输出测试信息\n&lt;/pre&gt;\n\n&lt;p&gt;在Editor Log面板，我们可以看到日志信息。UIATarget是最上层的类，它有1个子元素UIAApplication；UIAApplication有3个子元素，类型都是UIAWindow，第1个UIAWindow就是主窗口，它是app的核心部分，有非常多的子元素，我们不再展开阐述；第2个UIAWindow其实是不可见的，我们可以用isVisible方法去验证；第3个UIAWindow包含了状态栏的信息。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/ce5673a34433ca609c5c59f49113c10e.png&quot; style=&quot;height:282px; margin-bottom:6px; margin-top:6px; width:802px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;&amp;nbsp;6. UI Automation学习资料&lt;/h2&gt;\n\n&lt;p&gt;以上是UI Automation的基础教程，如果希望学习更多有关UI Automation的内容，请参考下面的资料。&lt;/p&gt;\n\n&lt;p&gt;a.&amp;nbsp;&lt;a href=&quot;https://developer.apple.com/library/ios/documentation/DeveloperTools/Reference/UIAutomationRef/index.html&quot;&gt;《UI Automation JavaScript Reference for iOS》&lt;/a&gt;，UI Automation官方文档，里面有详实的API介绍&lt;/p&gt;\n\n&lt;p&gt;b.&amp;nbsp;&lt;a href=&quot;https://developer.apple.com/library/prerelease/mac/documentation/DeveloperTools/Conceptual/InstrumentsUserGuide/UIAutomation.html&quot;&gt;《Automate UI Testing in iOS》&lt;/a&gt;，UI Automation入门教程&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;','UI Automation教程','间客','简介\n\nUI Automation是苹果公司提供的测试框架，开发者可以利用它在真实设备或者模拟器上测试iOS应用。UI Automation的编程语言为JavaScript。\n\n \n\n1. 搭建并进入UI Automation环境\n\n苹果公司已经为开发者们提供了一套Instruments工具，它被包含在Xcode中。因此只需下载安装Xcode就可以使用UI Automation。 \n\na. 安装Xcode（本文以Xcode 6.4为例）。\n\nb. 在真机或模拟器上安装待测app。\n\nc. 进入Xcode，在菜单栏依次点击Xcode -> Open Developer Tool -> Instruments。\n\n\n\nd. 双击Automation\n\n\n\n \n\n2. 熟悉UI Automation图形界面和基本功能 \n\n下图为UI Automation的图形界面\n\n\n\na. 在左上方区域，我们可以选择模拟器或真机设备，以及设备上待测的app。\n\n\n\n本文接下来介绍的测试将在iPhone 6模拟器下进行，激活方式如下图\n\n\n\n选择要测试的app（本文以“开源中国”为例）\n\n\n\nb. 在右下方区域，点击中间的按钮（下图红色方框），在这里我们可以点击“Add”选择“Create”新建脚本或者“Import”导入已经写好的脚本；双击脚本可以修改脚本的名称。\n\n\n\nc. 在左下方区域，选择Script面板可以编写脚本，选择Trace Log面板则展示日志信息。注意到，新建的脚本已经自动生成了一行代码，这行代码十分常用，几乎所有的测试脚本都需要这行代码，我们将在后面解释它。\n\n\n\n在Script面板点击右键，选择“Export”，可以导出写好的脚本。\n\n\n\n \n\n3. 编写脚本\n\n打开“开源中国”app，我们看到如下界面\n\n\n\n我们开始编写第一个脚本，这个脚本的目标是点击导航栏左侧的有三条白色横线的按钮。\n\n\nvar target = UIATarget.localTarget();  //UIATarget是最上层的类，表示真实设备或模拟器    \n\nvar app = target.frontMostApp();  //取得设备（模拟器）最前端的app\n\nvar navigationBar = app.navigationBar();  //取得导航栏\n\nvar leftButton = navigationBar.leftButton();  //取得导航栏的左侧按钮\n\nleftButton.tap();  //点击左侧按钮\n\n运行脚本有两种方式，一种是点击左上方的红色圆圈按钮，效果相当于重新启动app，然后执行脚本内容；\n\n\n\n还有一种是点击最下面的三角形形状的播放按钮，若待测app已经启动，则继续在该app上执行脚本内容。\n\n\n\n上面这段代码的编程风格非常清晰，但是可能会显得繁琐，我们也可以用一行代码实现相同的效果。\n\n\n UIATarget.localTarget().frontMostApp().navigationBar().leftButton().tap();\n\n运行上述脚本后，我们发现app页面变成了下图，这说明脚本完成了目标。\n\n\n\n打开Trace Log面板，我们发现输出日志与上面这一行代码非常相似。\n\n\n\n接下来，我们要在点击导航栏左侧按钮的基础上，点击左侧的“技术问答”。\n\n\nvar window = app.mainWindow();  //取得app的主窗口 \n\nvar tableView = window.tableViews()[0];  //取得主窗口中的第一个tableView\n\nvar cells = tableView.cells();  //取得tableView中所有cells，返回一个数组\n\nvar techCell = cells[0];  //取得第一个cell\n\ntechCell.tap();  //点击&quot;技术问答&quot;\n\n将这段脚本复制到之前写好的脚本后面，执行脚本，发现运行成功，app跳到了“技术问答”的界面。注意到var techCell = cells[0]; 这行代码，我们选择cells[0]是因为我们事先知道“技术问答”是cells的第一个元素，我们也可以这么写：var techCell = cells[\"技术问答\"];  这样也能找到名字为“技术问答”的元素。\n\n很多时候，app美妙的动画效果会成为自动化测试的绊脚石，如果动画时间过长，我们却尝试操作（如点击）那些还没来得及出现的元素，这样将导致错误。解决方案是在用delay()方法让脚本延迟指定的一段时间后执行。\n\n\ntarget.delay(2);  //延时2秒\n\n\n \n\n4. 录制脚本\n\n如果你还不熟悉UI Automation的API，那么录制功能将给你带来极大的便利，它会记录下你每次操作的步骤，生成相应的代码。然而，录制功能不能识别一些复杂的操作，因此我们不要过度依赖录制功能。\n\na. 点击红色的录制按钮\n\n\n\nb. 在真机设备或者模拟器上执行期望的操作\n\nc. 点击停止录制按钮\n\n\n\n我们录制了一段登录脚本，录制结果如下\n\n\n\n点击小箭头，我们可以得到更多的可选方案。如下图，buttons()[\"我\"]，buttons()[5]，elements()[\"我\"]和elements ()[7]都是等价的，我们可以任选一种，然后双击蓝色区域表示确认，小箭头也随之消失。\n\n\n\n执行过程如下：\n\n ->  ->  ->\n\n ->  ->\n\n \n\n5. 理解层次结构\n\n在UI Automation框架中，每一个可访问的元素都继承自UIAElement。UIAElement有许多常用的方法，如​\n\n－ name：返回元素的名称\n\n－ value：返回元素的值\n\n－ elements：以Array的形式返回这个元素的子元素\n\n－ isVisible：若元素可见，返回1；否则返回0\n\n－ tap：点击这个元素\n\n－ logElementTree：在日志中输出这个元素和它的子元素的信息\n\n我们运行下面一段脚本，来查看app的层次结构。\n\n\nvar target = UIATarget.localTarget();  //UIATarget是最上层的类，表示真实设备或模拟器\n\ntarget.delay(3);  //延时3秒，跳过开场动画\n\nUIALogger.logMessage(&quot;Test begins&quot;);  //输出测试信息\n\ntarget.logElementTree();  //输出target和它的子元素的信息\n\nUIALogger.logMessage(&quot;Test ends&quot;);  //输出测试信息\n\n\n在Editor Log面板，我们可以看到日志信息。UIATarget是最上层的类，它有1个子元素UIAApplication；UIAApplication有3个子元素，类型都是UIAWindow，第1个UIAWindow就是主窗口，它是app的核心部分，有非常多的子元素，我们不再展开阐述；第2个UIAWindow其实是不可见的，我们可以用isVisible方法去验证；第3个UIAWindow包含了状态栏的信息。\n\n\n\n \n\n 6. UI Automation学习资料\n\n以上是UI Automation的基础教程，如果希望学习更多有关UI Automation的内容，请参考下面的资料。\n\na. 《UI Automation JavaScript Reference for iOS》，UI Automation官方文档，里面有详实的API介绍\n\nb. 《Automate UI Testing in iOS》，UI Automation入门教程\n\n ',0,39,1),(41,'2015-09-22 17:20:41','2016-12-15 17:43:32','&lt;p&gt;本文分析了一份标准的iOS应用程序的Crash报告，它通常由以下6个部分组成。&lt;/p&gt;\n\n&lt;h2&gt;&amp;nbsp;&lt;/h2&gt;\n\n&lt;h2&gt;1.&amp;nbsp;报告头(Header)&lt;/h2&gt;\n\n&lt;p&gt;报告头包含了应用程序以其运行环境的一些基本信息，下面是报告头的一个例子。&lt;/p&gt;\n\n&lt;pre&gt;\nIncident Identifier: E6EBC860-0222-4B82-BF7A-2B1C26BE1E85\nCrashReporter Key: 6196484647b3431a9bc2833c19422539549f3dbe\nHardware Model: iPhone6,1\nProcess: TheElements [4637]\nPath: /private/var/mobile/Containers/Bundle/Application/5A9E4FC2-D03B-4E19-9A91-104A0D0C1D44/TheElements.app/TheElements\nIdentifier: com.example.apple-samplecode.TheElements\nVersion: 1.12\nCode Type: ARM (Native)\nParent Process: launchd [1]\n\nDate/Time: 2015-04-06 09:14:08.775 -0700\nLaunch Time: 2015-04-06 09:14:08.597 -0700\nOS Version: iOS 8.1.3 (12B466)\nReport Version: 105&lt;/pre&gt;\n\n&lt;h2&gt;&amp;nbsp;&lt;/h2&gt;\n\n&lt;h2&gt;2.&amp;nbsp;异常代码(Exception Codes)&lt;/h2&gt;\n\n&lt;p&gt;异常代码可能包含异常类型(Exception Type)、异常子类型(Exception Subtype)、处理器的详细异常代码(processor-specific Exception Codes)和其它能提供更多Crash信息的字段，最后一个字段列出了触发Crash的线程索引。下面是异常代码的示例。&lt;/p&gt;\n\n&lt;pre&gt;\nException Type: EXC_CRASH (SIGABRT)\nException Codes: 0x0000000000000000, 0x0000000000000000\nTriggered by Thread: 0\n&lt;/pre&gt;\n\n&lt;p&gt;常见的异常类型有以下几种。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h3&gt;a.&amp;nbsp;Bad Memory Access [EXC_BAD_ACCESS // SIGSEGV // SIGBUS]&lt;/h3&gt;\n\n&lt;p&gt;此类型的Excpetion是最常见的Crash，通常由访问了无效的内存导致。&lt;/p&gt;\n\n&lt;p&gt;SIGSEGV：访问了无效地址，没有物理内存对应该地址，通常由于重复释放对象导致。&lt;/p&gt;\n\n&lt;p&gt;SIGBUS：总线错误，与 SIGSEGV 不同的是，SIGBUS 访问的是有效地址，但总线访问异常，通常是访问了未对齐的数据。&lt;/p&gt;\n\n&lt;p&gt;SEGV：代表无效内存地址，比如空指针、未初始化指针、栈溢出等。&lt;/p&gt;\n\n&lt;h3&gt;&amp;nbsp;&lt;/h3&gt;\n\n&lt;h3&gt;b.&amp;nbsp;Abnormal Exit [EXC_CRASH // SIGABRT]&lt;/h3&gt;\n\n&lt;p&gt;进程异常退出，造成Crash通常是因为未捕获到Objective-C/C++的异常。&lt;/p&gt;\n\n&lt;p&gt;SIGABRT：收到Abort信号退出，通常Foundation库中的容器为了保护状态正常会做一些检测，例如插入nil到数组中等会遇到此类错误。&lt;/p&gt;\n\n&lt;h3&gt;&amp;nbsp;&lt;/h3&gt;\n\n&lt;h3&gt;c.&amp;nbsp;其它异常类型&lt;/h3&gt;\n\n&lt;p&gt;有些异常类型没有被命名，以16进制数字表示。&lt;/p&gt;\n\n&lt;p&gt;0xbaaaaaad：意味着该Crash log并非一个真正的Crash，它仅仅只是包含了整个系统某一时刻的运行状态，由用户同时按Home键和音量键触发。&lt;/p&gt;\n\n&lt;p&gt;0xbad22222：当VoIP程序在后台太过频繁的激活时，系统可能会终止此类程序。&lt;/p&gt;\n\n&lt;p&gt;0x8badf00d：程序启动或者恢复时间过长被watch dog终止。&lt;/p&gt;\n\n&lt;p&gt;0xc00010ff：程序执行大量耗费CPU和GPU的运算，导致设备过热，触发系统过热保护被系统终止。&lt;/p&gt;\n\n&lt;p&gt;0xdead10cc：程序退到后台时还占用系统资源（如通讯录）被系统终止。&lt;/p&gt;\n\n&lt;p&gt;0xdeadfa11：程序无响应用户强制退出。当用户长按电源键，直到屏幕出现关机确认画面后再长按Home键，将强制退出应用。我们可以合理认为用户这么做的原因是应用程序没有响应。&lt;/p&gt;\n\n&lt;h2&gt;&amp;nbsp;&lt;/h2&gt;\n\n&lt;h2&gt;3.&amp;nbsp;应用详情(Application Specific Information)&lt;/h2&gt;\n\n&lt;p&gt;有些Crash出现时，会产生额外的信息，这些信息能帮助用户更好地了解应用程序终止时的运行环境。示例如下。&lt;/p&gt;\n\n&lt;pre&gt;\nApplication Specific Information:\nMyApp[134] was suspended with locked system files:\n/private/var/mobile/Library/AddressBook/AddressBook.sqlitedb\n&lt;/pre&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;4.&amp;nbsp;回溯(Backtrace)&lt;/h2&gt;\n\n&lt;p&gt;这部分列出了发生Crash时线程的调用栈。示例如下。&lt;/p&gt;\n\n&lt;pre&gt;\nThread 0 name: Dispatch queue: com.apple.main-thread\nThread 0 Crashed:\n0   TheElements               0x0000000100063fdc -[AtomicElementViewController myTransitionDidStop:finished:context:] (AtomicElementViewController.m:201)\n1   UIKit                     0x000000018ca5c2ec -[UIViewAnimationState sendDelegateAnimationDidStop:finished:] + 184\n2   UIKit                     0x000000018ca5c1f4 -[UIViewAnimationState animationDidStop:finished:] + 100\n3   QuartzCore                0x000000018c380f60 CA::Layer::run_animation_callbacks(void*) + 292\n4   libdispatch.dylib         0x0000000198fb9368 _dispatch_client_callout + 12\n5   libdispatch.dylib         0x0000000198fbd97c _dispatch_main_queue_callback_4CF + 928\n6   CoreFoundation            0x000000018822dfa0 __CFRUNLOOP_IS_SERVICING_THE_MAIN_DISPATCH_QUEUE__ + 8\n7   CoreFoundation            0x000000018822c048 __CFRunLoopRun + 1488\n8   CoreFoundation            0x00000001881590a0 CFRunLoopRunSpecific + 392\n9   GraphicsServices          0x00000001912fb5a0 GSEventRunModal + 164\n10  UIKit                     0x000000018ca8aaa0 UIApplicationMain + 1484\n11  TheElements               0x000000010005d800 main (main.m:55)\n12  libdyld.dylib             0x0000000198fe2a04 start + 0\n\nThread 1 name: Dispatch queue: com.apple.libdispatch-manager\nThread 1:\n0   libsystem_kernel.dylib    0x00000001990e0c94 kevent64 + 8\n1   libdispatch.dylib         0x0000000198fc897c _dispatch_mgr_invoke + 272\n2   libdispatch.dylib         0x0000000198fbb3b0 _dispatch_mgr_thread + 48\n\n...\n&lt;/pre&gt;\n\n&lt;h2&gt;&amp;nbsp;&lt;/h2&gt;\n\n&lt;h2&gt;5.&amp;nbsp;线程状态(Thread State)&lt;/h2&gt;\n\n&lt;p&gt;这部分列出了发生Crash的线程的状态，即寄存器和寄存器的值。示例如下。&lt;/p&gt;\n\n&lt;pre&gt;\nThread 0 crashed with ARM Thread State (64-bit):\n    x0: 0x0000000000000000   x1: 0x0000000000000000   x2: 0x0000000000000000   x3: 0x00000001995f8020\n    x4: 0x0000000000000000   x5: 0x0000000000000001   x6: 0x0000000000000000   x7: 0x0000000000000000\n    x8: 0x0000000000000000   x9: 0x0000000000000015  x10: 0x0000000199601df0  x11: 0x0000000b0000000f\n   x12: 0x00000001741e8700  x13: 0x000001a5995f5779  x14: 0x0000000000000000  x15: 0x0000000044000000\n   x16: 0x00000001989724d8  x17: 0x0000000188176370  x18: 0x0000000000000000  x19: 0x00000001701dda60\n   x20: 0x0000000000000001  x21: 0x0000000136606e20  x22: 0x00000001000f6238  x23: 0x0000000000000000\n   x24: 0x000000019cc640a8  x25: 0x0000000000000020  x26: 0x0000000000000000  x27: 0x0000000000000000\n   x28: 0x000000019cc577c0  fp: 0x000000016fd1a8d0   lr: 0x00000001000effcc\n    sp: 0x000000016fd1a860   pc: 0x00000001000effdc cpsr: 0x60000000\n&lt;/pre&gt;\n\n&lt;h2&gt;&amp;nbsp;&lt;/h2&gt;\n\n&lt;h2&gt;6.&amp;nbsp;二进制映像(Binary Images)&lt;/h2&gt;\n\n&lt;p&gt;这部分列出了当Crash发生时被装载进进程内存空间的依赖库或者模块。示例如下。&lt;/p&gt;\n\n&lt;pre&gt;\nBinary Images:\n0x100058000 - 0x10006bfff TheElements arm64 &amp;lt;77b672e2b9f53b0f95adbc4f68cb80d6&amp;gt; /var/mobile/Containers/Bundle/Application/CB86658C-F349-4C7A-B73B-CE3B4502D5A4/TheElements.app/TheElements&lt;/pre&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;参考资料&lt;/h2&gt;\n\n&lt;p&gt;a. &lt;a href=&quot;https://developer.apple.com/library/ios/technotes/tn2151/_index.html&quot;&gt;《Understanding and Analyzing iOS Application Crash Reports》&lt;/a&gt;，iOS Crash分析官方文档&lt;/p&gt;\n\n&lt;p&gt;b. &lt;a href=&quot;http://www.cnblogs.com/smileEvday/p/Crash1.html&quot;&gt;《iOS Crash文件的解析（一）》&lt;/a&gt;，一篇中文博客&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;','Crash分析','间客','本文分析了一份标准的iOS应用程序的Crash报告，它通常由以下6个部分组成。\n\n \n\n1. 报告头(Header)\n\n报告头包含了应用程序以其运行环境的一些基本信息，下面是报告头的一个例子。\n\n\nIncident Identifier: E6EBC860-0222-4B82-BF7A-2B1C26BE1E85\nCrashReporter Key: 6196484647b3431a9bc2833c19422539549f3dbe\nHardware Model: iPhone6,1\nProcess: TheElements [4637]\nPath: /private/var/mobile/Containers/Bundle/Application/5A9E4FC2-D03B-4E19-9A91-104A0D0C1D44/TheElements.app/TheElements\nIdentifier: com.example.apple-samplecode.TheElements\nVersion: 1.12\nCode Type: ARM (Native)\nParent Process: launchd [1]\n\nDate/Time: 2015-04-06 09:14:08.775 -0700\nLaunch Time: 2015-04-06 09:14:08.597 -0700\nOS Version: iOS 8.1.3 (12B466)\nReport Version: 105\n\n \n\n2. 异常代码(Exception Codes)\n\n异常代码可能包含异常类型(Exception Type)、异常子类型(Exception Subtype)、处理器的详细异常代码(processor-specific Exception Codes)和其它能提供更多Crash信息的字段，最后一个字段列出了触发Crash的线程索引。下面是异常代码的示例。\n\n\nException Type: EXC_CRASH (SIGABRT)\nException Codes: 0x0000000000000000, 0x0000000000000000\nTriggered by Thread: 0\n\n\n常见的异常类型有以下几种。\n\n \n\na. Bad Memory Access [EXC_BAD_ACCESS // SIGSEGV // SIGBUS]\n\n此类型的Excpetion是最常见的Crash，通常由访问了无效的内存导致。\n\nSIGSEGV：访问了无效地址，没有物理内存对应该地址，通常由于重复释放对象导致。\n\nSIGBUS：总线错误，与 SIGSEGV 不同的是，SIGBUS 访问的是有效地址，但总线访问异常，通常是访问了未对齐的数据。\n\nSEGV：代表无效内存地址，比如空指针、未初始化指针、栈溢出等。\n\n \n\nb. Abnormal Exit [EXC_CRASH // SIGABRT]\n\n进程异常退出，造成Crash通常是因为未捕获到Objective-C/C++的异常。\n\nSIGABRT：收到Abort信号退出，通常Foundation库中的容器为了保护状态正常会做一些检测，例如插入nil到数组中等会遇到此类错误。\n\n \n\nc. 其它异常类型\n\n有些异常类型没有被命名，以16进制数字表示。\n\n0xbaaaaaad：意味着该Crash log并非一个真正的Crash，它仅仅只是包含了整个系统某一时刻的运行状态，由用户同时按Home键和音量键触发。\n\n0xbad22222：当VoIP程序在后台太过频繁的激活时，系统可能会终止此类程序。\n\n0x8badf00d：程序启动或者恢复时间过长被watch dog终止。\n\n0xc00010ff：程序执行大量耗费CPU和GPU的运算，导致设备过热，触发系统过热保护被系统终止。\n\n0xdead10cc：程序退到后台时还占用系统资源（如通讯录）被系统终止。\n\n0xdeadfa11：程序无响应用户强制退出。当用户长按电源键，直到屏幕出现关机确认画面后再长按Home键，将强制退出应用。我们可以合理认为用户这么做的原因是应用程序没有响应。\n\n \n\n3. 应用详情(Application Specific Information)\n\n有些Crash出现时，会产生额外的信息，这些信息能帮助用户更好地了解应用程序终止时的运行环境。示例如下。\n\n\nApplication Specific Information:\nMyApp[134] was suspended with locked system files:\n/private/var/mobile/Library/AddressBook/AddressBook.sqlitedb\n\n\n \n\n4. 回溯(Backtrace)\n\n这部分列出了发生Crash时线程的调用栈。示例如下。\n\n\nThread 0 name: Dispatch queue: com.apple.main-thread\nThread 0 Crashed:\n0   TheElements               0x0000000100063fdc -[AtomicElementViewController myTransitionDidStop:finished:context:] (AtomicElementViewController.m:201)\n1   UIKit                     0x000000018ca5c2ec -[UIViewAnimationState sendDelegateAnimationDidStop:finished:] + 184\n2   UIKit                     0x000000018ca5c1f4 -[UIViewAnimationState animationDidStop:finished:] + 100\n3   QuartzCore                0x000000018c380f60 CA::Layer::run_animation_callbacks(void*) + 292\n4   libdispatch.dylib         0x0000000198fb9368 _dispatch_client_callout + 12\n5   libdispatch.dylib         0x0000000198fbd97c _dispatch_main_queue_callback_4CF + 928\n6   CoreFoundation            0x000000018822dfa0 __CFRUNLOOP_IS_SERVICING_THE_MAIN_DISPATCH_QUEUE__ + 8\n7   CoreFoundation            0x000000018822c048 __CFRunLoopRun + 1488\n8   CoreFoundation            0x00000001881590a0 CFRunLoopRunSpecific + 392\n9   GraphicsServices          0x00000001912fb5a0 GSEventRunModal + 164\n10  UIKit                     0x000000018ca8aaa0 UIApplicationMain + 1484\n11  TheElements               0x000000010005d800 main (main.m:55)\n12  libdyld.dylib             0x0000000198fe2a04 start + 0\n\nThread 1 name: Dispatch queue: com.apple.libdispatch-manager\nThread 1:\n0   libsystem_kernel.dylib    0x00000001990e0c94 kevent64 + 8\n1   libdispatch.dylib         0x0000000198fc897c _dispatch_mgr_invoke + 272\n2   libdispatch.dylib         0x0000000198fbb3b0 _dispatch_mgr_thread + 48\n\n...\n\n\n \n\n5. 线程状态(Thread State)\n\n这部分列出了发生Crash的线程的状态，即寄存器和寄存器的值。示例如下。\n\n\nThread 0 crashed with ARM Thread State (64-bit):\n    x0: 0x0000000000000000   x1: 0x0000000000000000   x2: 0x0000000000000000   x3: 0x00000001995f8020\n    x4: 0x0000000000000000   x5: 0x0000000000000001   x6: 0x0000000000000000   x7: 0x0000000000000000\n    x8: 0x0000000000000000   x9: 0x0000000000000015  x10: 0x0000000199601df0  x11: 0x0000000b0000000f\n   x12: 0x00000001741e8700  x13: 0x000001a5995f5779  x14: 0x0000000000000000  x15: 0x0000000044000000\n   x16: 0x00000001989724d8  x17: 0x0000000188176370  x18: 0x0000000000000000  x19: 0x00000001701dda60\n   x20: 0x0000000000000001  x21: 0x0000000136606e20  x22: 0x00000001000f6238  x23: 0x0000000000000000\n   x24: 0x000000019cc640a8  x25: 0x0000000000000020  x26: 0x0000000000000000  x27: 0x0000000000000000\n   x28: 0x000000019cc577c0  fp: 0x000000016fd1a8d0   lr: 0x00000001000effcc\n    sp: 0x000000016fd1a860   pc: 0x00000001000effdc cpsr: 0x60000000\n\n\n \n\n6. 二进制映像(Binary Images)\n\n这部分列出了当Crash发生时被装载进进程内存空间的依赖库或者模块。示例如下。\n\n\nBinary Images:\n0x100058000 - 0x10006bfff TheElements arm64 &lt;77b672e2b9f53b0f95adbc4f68cb80d6&gt; /var/mobile/Containers/Bundle/Application/CB86658C-F349-4C7A-B73B-CE3B4502D5A4/TheElements.app/TheElements\n\n \n\n参考资料\n\na. 《Understanding and Analyzing iOS Application Crash Reports》，iOS Crash分析官方文档\n\nb. 《iOS Crash文件的解析（一）》，一篇中文博客\n\n ',0,39,6),(42,'2015-10-08 16:02:36','2015-10-08 16:02:36','&lt;h2&gt;为何要适配应用到基于intel芯片的移动设备上&lt;/h2&gt;\n\n&lt;p&gt;&lt;br /&gt;\n&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;x86指令集只要应用于PC中，ARM主要应用在嵌入式设备，如手机。intel芯片的面世打破了Android架构只有ARM指令集的尴尬局面，将x86在处理浮点数，多媒体指令集方面的优势也迁移到Android平台中来，不仅给用户提供了更多选择，同时也将Android的CPU性能带到新的高度。&lt;/p&gt;\n\n&lt;p&gt;基于X86的Android 平台是未来最有价值的Android硬件平台，将应用从ARM架构上移植到X86架构上，可以赢得宝贵的市场前景&lt;/p&gt;\n\n&lt;p&gt;另外对于应用本身来说，技术层面同时支持X86架构和ARM架构，可以很好地适配所有的Android架构。Intel芯片能够提供业界领先的强大性能，并且具备低功耗和延长电池使用寿命特点，应用移植到基于Intel芯片的移动设备上去之后能够提供全新的、最佳的用户体验。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;如何适配应用到基于intel芯片的移动设备上&lt;/h2&gt;\n\n&lt;h2&gt;&lt;br /&gt;\nAndroid应用可以按照使用的开发工具包不同分为Dalvik应用和包含原生态库（NDK）的应用两大类&lt;/h2&gt;\n\n&lt;p&gt;只基于Dalvik的应用：&lt;/p&gt;\n\n&lt;p&gt;采用Android SDK作为开发工具包，直接将应用发布到x86设备即可，不用花费任何精力。如果是为较低分辨率设计的应用。需要为大分辨率平板重新调整UI获得更好的效果。&lt;br /&gt;\n&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;包含原生态库的应用（采用Android NDK作为开发工具包或者使用了第三方开发工具如游戏引擎等）：&lt;/p&gt;\n\n&lt;p&gt;如果应用包含了ARM库。需要下载&lt;a href=&quot;http://developer.android.com/tools/sdk/ndk/index.html&quot;&gt;最新的NDK编译工具&lt;/a&gt;，在NDK中编译出x86库文件，最后生成新的APK。&lt;br /&gt;\n&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;如果使用了汇编语言，那么这些汇编指令必须属于x86指令集（IA架构的指令集）&lt;br /&gt;\n&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;如果应用使用了第三方引擎或模块，您需要向第三方确认是否提供对x86架构的支持。&lt;/p&gt;\n\n&lt;p&gt;&lt;a href=&quot;https://software.intel.com/en-us/articles/ndk-android&quot;&gt;更多介绍&lt;/a&gt;&lt;/p&gt;','x86架构适配','mts','为何要适配应用到基于intel芯片的移动设备上\n\n\n       x86指令集只要应用于PC中，ARM主要应用在嵌入式设备，如手机。intel芯片的面世打破了Android架构只有ARM指令集的尴尬局面，将x86在处理浮点数，多媒体指令集方面的优势也迁移到Android平台中来，不仅给用户提供了更多选择，同时也将Android的CPU性能带到新的高度。\n\n基于X86的Android 平台是未来最有价值的Android硬件平台，将应用从ARM架构上移植到X86架构上，可以赢得宝贵的市场前景\n\n另外对于应用本身来说，技术层面同时支持X86架构和ARM架构，可以很好地适配所有的Android架构。Intel芯片能够提供业界领先的强大性能，并且具备低功耗和延长电池使用寿命特点，应用移植到基于Intel芯片的移动设备上去之后能够提供全新的、最佳的用户体验。\n\n \n\n如何适配应用到基于intel芯片的移动设备上\n\n\nAndroid应用可以按照使用的开发工具包不同分为Dalvik应用和包含原生态库（NDK）的应用两大类\n\n只基于Dalvik的应用：\n\n采用Android SDK作为开发工具包，直接将应用发布到x86设备即可，不用花费任何精力。如果是为较低分辨率设计的应用。需要为大分辨率平板重新调整UI获得更好的效果。\n       包含原生态库的应用（采用Android NDK作为开发工具包或者使用了第三方开发工具如游戏引擎等）：\n\n如果应用包含了ARM库。需要下载最新的NDK编译工具，在NDK中编译出x86库文件，最后生成新的APK。\n       如果使用了汇编语言，那么这些汇编指令必须属于x86指令集（IA架构的指令集）\n       如果应用使用了第三方引擎或模块，您需要向第三方确认是否提供对x86架构的支持。\n\n更多介绍',0,4,5),(43,'2015-10-09 19:57:26','2017-03-01 17:45:20','&lt;h2&gt;背景&lt;/h2&gt;\n\n&lt;p&gt;MQC一直致力于帮助开发者快速发现和解决App质量问题，远程真机租用作为一种新的测试手段应运而生。&lt;/p&gt;\n\n&lt;p&gt;远程真机租用允许开发者在浏览器网页上操作远程手机，包括上传应用，输出日志等等功能，帮助开发者快速复现和定位问题。MQC远程真机租用背后的手机都是真实的设备。&lt;/p&gt;\n\n&lt;h2&gt;单机租用&lt;/h2&gt;\n\n&lt;p&gt;1、调试&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;点击立即使用便可进入调试页面。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/a3331e93297ec0fd14ed6c22151b8a8a.JPG&quot; style=&quot;height:310px; width:900px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;鼠标左键可在手机屏幕上按住进行滑动，相当于touch操作。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;下方三个按键分别对应Back、Home和Menu键。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;敲击键盘可以进行字母输入。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;Ctrl+V支持将PC端剪切板文本内容粘贴至手机。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;截图可以将手机屏幕图片在另一窗口打开。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;上传应用允许上传本地apk，上传后自动进行安装，退出调试后，apk会保留一段时间，之后会被清理。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;退出返回设备选择页面。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;在Logcat栏中，点击开始记录便可以将手机logcat实时输出，可通过下拉框选择日志级别，还可以根据时间及内容进行过滤。清除按钮会清空当前logcat。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;每次调试时长为15分钟。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/3c6e732be1d774d7624ecd60db8b4ffe.JPG&quot; style=&quot;height:523px; width:900px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;2、预约&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;由于设备有限，为了使开发者都有机会使用设备，我们提供预约功能。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;当一种型号的手机没有空闲设备时，用户可以点击我要预约进行设备预约，预约成功后，你预约过的设备将会排在前面。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;当前方排队者使用完设备释放后，你即可使用该设备。如果设备处于可用状态，但是你15分钟内没有来使用，则设备将会自动释放。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/22979c4a10fe3b294d9624e0907949a5.JPG&quot; style=&quot;height:467px; width:900px&quot; /&gt;&lt;/p&gt;\n\n&lt;h2&gt;双机租用&lt;/h2&gt;\n\n&lt;p&gt;为了方便开发者调试类似于聊天等需要两台手机互动的功能，我们提供了双机租用，允许开发者同时操作两台手机。&lt;/p&gt;\n\n&lt;p&gt;同时，有的操作流程在两台手机上其实是一样的，为此，我们提供同步操作的能力，允许开发者在一台手机上操作，另一台手机进行随动。&lt;/p&gt;\n\n&lt;p&gt;1、选择设备&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;在设备选择页面勾选双机租用，会出现双击租用的选择页面，用户可选择两台设备进行调试。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/8ab5158a411d4d7237e64c6168588f2b.JPG&quot; style=&quot;height:311px; width:900px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;2、单独调试&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;在调试页面，用户可以操作两台手机，方法与单机调试类似。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/814692e53e01f19f1238cb525890ce39.JPG&quot; style=&quot;height:519px; width:900px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;3、同步调试&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;需要同步调试，可勾选中间同步调试按钮，此时进行的鼠标滑动，Back、Home、Menu，键盘输入，复制粘贴功能均会进行同步。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;无论对哪一台手机进行操作，另外一台均会做相同动作。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/4cd16e62debed3fa19232d992d51d9d0.JPG&quot; style=&quot;height:522px; width:900px&quot; /&gt;&lt;/p&gt;\n\n&lt;h2&gt;远程调试&lt;/h2&gt;\n\n&lt;p&gt;需要在本地安装java（建议1.6或1.7版本）和adb（adb命令配置到环境变量中）&lt;/p&gt;\n\n&lt;p&gt;1、下载jar包&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;在单机调试界面，远程调试区块，&lt;a href=&quot;/static/res/MQCRemoteDebugClient.jar&quot; target=&quot;_blank&quot;&gt;下载jar包&lt;/a&gt;。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/08ee61b4f1371d6eafe846f8e66823e6.JPG&quot; style=&quot;height:404px; width:900px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;2、运行命令&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;到jar包所在目录，运行界面上的命令。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/cb12031f711b3fe5b8d7ac7199f01a75.JPG&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;3、添加adb key（首次远程调试需要）&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;如果首次进行远程调试，需要获取您的计算机信息进行授权（否则设备是为授权状态），在弹出框中点击Add key即可。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/043dc5e512a0d03ff4f6281fd9f445d7.JPG&quot; style=&quot;height:354px; width:900px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;4、开始享受&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;这时候，你的本地adb已经连接上云手机。Enjoy！&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/8bbb40429a231f03eddb9b703a1341b2.JPG&quot; style=&quot;height:404px; width:643px&quot; /&gt;&lt;/p&gt;\n\n&lt;h2&gt;常见问题&lt;/h2&gt;\n\n&lt;p&gt;1、为什么我的操作这么卡？&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;远程真机租用传输的数据量比较大，如果你的本地网络网速不够快，会出现卡顿现象。经测试，1M以上的下载速度体验会很流畅。&lt;/p&gt;\n\n&lt;p&gt;2、为什么我看不到页面，也不能操作手机？&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;远程真机租用使用了websocket技术，请确保你的浏览器支持websocket，建议使用新版本的chrome。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;如果还不行，请确保你的网络环境支持websocket，没有被防火墙阻断。&lt;/p&gt;\n\n&lt;p&gt;3、为什么我调试一会儿就提示我设备掉线？&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;如果你使用的是firefox浏览器，请在地址栏输入about:config，搜索websocket的配置项，将network.websocket.timeout.ping.request设置为10。如果是其他浏览器，请联系我们。&lt;/p&gt;','远程真机租用文档','竹逊','背景\n\nMQC一直致力于帮助开发者快速发现和解决App质量问题，远程真机租用作为一种新的测试手段应运而生。\n\n远程真机租用允许开发者在浏览器网页上操作远程手机，包括上传应用，输出日志等等功能，帮助开发者快速复现和定位问题。MQC远程真机租用背后的手机都是真实的设备。\n\n单机租用\n\n1、调试\n\n     点击立即使用便可进入调试页面。\n\n\n\n     鼠标左键可在手机屏幕上按住进行滑动，相当于touch操作。\n\n     下方三个按键分别对应Back、Home和Menu键。\n\n     敲击键盘可以进行字母输入。\n\n     Ctrl+V支持将PC端剪切板文本内容粘贴至手机。\n\n     截图可以将手机屏幕图片在另一窗口打开。\n\n     上传应用允许上传本地apk，上传后自动进行安装，退出调试后，apk会保留一段时间，之后会被清理。\n\n     退出返回设备选择页面。\n\n     在Logcat栏中，点击开始记录便可以将手机logcat实时输出，可通过下拉框选择日志级别，还可以根据时间及内容进行过滤。清除按钮会清空当前logcat。\n\n     每次调试时长为15分钟。\n\n\n\n2、预约\n\n     由于设备有限，为了使开发者都有机会使用设备，我们提供预约功能。\n\n     当一种型号的手机没有空闲设备时，用户可以点击我要预约进行设备预约，预约成功后，你预约过的设备将会排在前面。\n\n     当前方排队者使用完设备释放后，你即可使用该设备。如果设备处于可用状态，但是你15分钟内没有来使用，则设备将会自动释放。\n\n\n\n双机租用\n\n为了方便开发者调试类似于聊天等需要两台手机互动的功能，我们提供了双机租用，允许开发者同时操作两台手机。\n\n同时，有的操作流程在两台手机上其实是一样的，为此，我们提供同步操作的能力，允许开发者在一台手机上操作，另一台手机进行随动。\n\n1、选择设备\n\n     在设备选择页面勾选双机租用，会出现双击租用的选择页面，用户可选择两台设备进行调试。\n\n\n\n2、单独调试\n\n     在调试页面，用户可以操作两台手机，方法与单机调试类似。\n\n\n\n3、同步调试\n\n     需要同步调试，可勾选中间同步调试按钮，此时进行的鼠标滑动，Back、Home、Menu，键盘输入，复制粘贴功能均会进行同步。\n\n     无论对哪一台手机进行操作，另外一台均会做相同动作。\n\n\n\n远程调试\n\n需要在本地安装java（建议1.6或1.7版本）和adb（adb命令配置到环境变量中）\n\n1、下载jar包\n\n     在单机调试界面，远程调试区块，下载jar包。\n\n\n\n2、运行命令\n\n     到jar包所在目录，运行界面上的命令。\n\n\n\n3、添加adb key（首次远程调试需要）\n\n     如果首次进行远程调试，需要获取您的计算机信息进行授权（否则设备是为授权状态），在弹出框中点击Add key即可。\n\n\n\n4、开始享受\n\n     这时候，你的本地adb已经连接上云手机。Enjoy！\n\n\n\n常见问题\n\n1、为什么我的操作这么卡？\n\n     远程真机租用传输的数据量比较大，如果你的本地网络网速不够快，会出现卡顿现象。经测试，1M以上的下载速度体验会很流畅。\n\n2、为什么我看不到页面，也不能操作手机？\n\n     远程真机租用使用了websocket技术，请确保你的浏览器支持websocket，建议使用新版本的chrome。\n\n     如果还不行，请确保你的网络环境支持websocket，没有被防火墙阻断。\n\n3、为什么我调试一会儿就提示我设备掉线？\n\n     如果你使用的是firefox浏览器，请在地址栏输入about:config，搜索websocket的配置项，将network.websocket.timeout.ping.request设置为10。如果是其他浏览器，请联系我们。',0,3,12),(44,'2015-10-12 17:22:27','2015-12-07 20:50:27','&lt;p&gt;1, 环境准备&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp; 安装&lt;a href=&quot;http://wiki.eclipse.org/Eclipse/Installation&quot;&gt;Eclipse&lt;/a&gt;&amp;nbsp;(最新版即可,目前是luna) 和&lt;a href=&quot;http://www.oracle.com/technetwork/java/javase/downloads/index.html&quot;&gt;JDK 6&lt;/a&gt;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; 在开始前，&lt;a href=&quot;/static/res/ocr/device/AppDemo.zip&quot;&gt;您可以点击下载本章所有测试相关文件&lt;/a&gt;。&lt;/p&gt;\n\n&lt;p&gt;2, 在Eclipse中创建测试用例&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; a. 创建一个空白的Android测试工程。&lt;/p&gt;\n\n&lt;p&gt;点击File -&amp;gt; New -&amp;gt; Project，然后再弹出框内选择Java Project。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/9ed11f9e34b3bbb1a5ceea90d6f530ee.png&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;点击Next到下一步，输入工程名称，比如AppiumJavaTest：&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/09a840c274e578e67ce575c08af7d302.png&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;点击finish，工程建立完成，如下图：&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/5a239cbde815d6adb2df022091a4a21f.png&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;3，编写测试脚本&lt;/p&gt;\n\n&lt;p&gt;a，导入依赖的jar包。&lt;/p&gt;\n\n&lt;p&gt;AppiumJavaTest右键-&amp;gt;Properties-&amp;gt;Java Build Path-&amp;gt;Add External JARs，将下载文件appium-jar中的三个jar包导入，如下图：&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/18e6b9df6d18b6f52768ad5d4014e79a.png&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;点击OK，导入。&lt;/p&gt;\n\n&lt;p&gt;b，编写测试用例&lt;/p&gt;\n\n&lt;p&gt;创建一个Capabilities.java的文件和一个Main.java文件，，MQC会执行用户上传的Main.java，所以要创建这个入口脚本：Main.java。如下图：&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/42a45900e6979e98fecaf74a7539a7ce.png&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;打开Capabilities.java添加如下代码：&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;strong&gt;import&lt;/strong&gt; org.openqa.selenium.remote.DesiredCapabilities;\n\n&lt;strong&gt;public&lt;/strong&gt; &lt;strong&gt;class&lt;/strong&gt; &lt;strong&gt;Capabilities&lt;/strong&gt; {       \n        &lt;strong&gt;public&lt;/strong&gt; &lt;strong&gt;static&lt;/strong&gt; &lt;strong&gt;DesiredCapabilities&lt;/strong&gt; &lt;strong&gt;getCapabilities&lt;/strong&gt;()  {  \n            // set up appium \n            &lt;strong&gt;DesiredCapabilities&lt;/strong&gt; &lt;strong&gt;capabilities&lt;/strong&gt; = &lt;strong&gt;new&lt;/strong&gt; DesiredCapabilities();  \n            capabilities.setCapability(&amp;quot;platformName&amp;quot;, &amp;quot;Android&amp;quot;);  \n            capabilities.setCapability(&amp;quot;deviceName&amp;quot;,&amp;quot;Android Emulator&amp;quot;);  \n            capabilities.setCapability(&amp;quot;platformVersion&amp;quot;, &amp;quot;4.4&amp;quot;);  \n            capabilities.setCapability(&amp;quot;app&amp;quot;, &amp;quot;/Users/heilang/Documents/workspace/AppDemo/apps/ContactManager.apk&amp;quot;);  \n            capabilities.setCapability(&amp;quot;appPackage&amp;quot;, &amp;quot;com.example.android.contactmanager&amp;quot;);  \n            capabilities.setCapability(&amp;quot;automationName&amp;quot;, &amp;quot;Appium&amp;quot;);           \n\n            &lt;strong&gt;return&lt;/strong&gt; capabilities;\n        }\n        \n        &lt;strong&gt;public&lt;/strong&gt; &lt;strong&gt;static&lt;/strong&gt; &lt;strong&gt;String&lt;/strong&gt; &lt;strong&gt;getUrl&lt;/strong&gt;(){\n            &lt;strong&gt;return&lt;/strong&gt; &amp;quot;http://127.0.0.1:4723/wd/hub&amp;quot;;\n        }\n        \n        &lt;strong&gt;public&lt;/strong&gt; &lt;strong&gt;String&lt;/strong&gt; &lt;strong&gt;getUserName&lt;/strong&gt;(){\n            &lt;strong&gt;return&lt;/strong&gt; &amp;quot;username&amp;quot;;\n        }\n        \n        &lt;strong&gt;public&lt;/strong&gt; &lt;strong&gt;String&lt;/strong&gt; &lt;strong&gt;getPassWord&lt;/strong&gt;(){\n            &lt;strong&gt;return&lt;/strong&gt; &amp;quot;password&amp;quot;;\n        }    \n}&lt;/pre&gt;\n\n&lt;p&gt;打开Main.java，添加如下代码：&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;strong&gt;import&lt;/strong&gt; io.appium.java_client.AppiumDriver;\n&lt;strong&gt;import&lt;/strong&gt; io.appium.java_client.android.AndroidDriver;\n\n&lt;strong&gt;import&lt;/strong&gt; java.net.URL;\n&lt;strong&gt;import&lt;/strong&gt; java.util.List;\n\n&lt;strong&gt;import&lt;/strong&gt; org.junit.After;\n&lt;strong&gt;import&lt;/strong&gt; org.junit.Before;\n&lt;strong&gt;import&lt;/strong&gt; org.junit.Test;\n&lt;strong&gt;import&lt;/strong&gt; org.openqa.selenium.By;\n&lt;strong&gt;import&lt;/strong&gt; org.openqa.selenium.WebElement;\n&lt;strong&gt;import&lt;/strong&gt; org.openqa.selenium.remote.DesiredCapabilities;\n   \n&lt;strong&gt;public&lt;/strong&gt; &lt;strong&gt;class&lt;/strong&gt; &lt;strong&gt;Main&lt;/strong&gt; {  \n    &lt;strong&gt;private&lt;/strong&gt; &lt;strong&gt;AppiumDriver&lt;/strong&gt;&amp;lt;WebElement&amp;gt; driver; &amp;nbsp;  \n\n    &lt;strong&gt;@Before&lt;/strong&gt;  \n    &lt;strong&gt;public&lt;/strong&gt; &lt;strong&gt;void&lt;/strong&gt; &lt;strong&gt;setUp&lt;/strong&gt;() &lt;strong&gt;throws&lt;/strong&gt; &lt;strong&gt;Exception&lt;/strong&gt; {  \n        // set up appium \n        &lt;strong&gt;DesiredCapabilities&lt;/strong&gt; &lt;strong&gt;capabilities&lt;/strong&gt; =  &lt;strong&gt;Capabilities&lt;/strong&gt;.getCapabilities();\n        driver = &lt;strong&gt;new&lt;/strong&gt; AndroidDriver&amp;lt;WebElement&amp;gt;(&lt;strong&gt;new&lt;/strong&gt; URL(&lt;strong&gt;Capabilities&lt;/strong&gt;.getUrl()), capabilities);  \n    }  \n   \n    &lt;strong&gt;@After&lt;/strong&gt;  \n    &lt;strong&gt;public&lt;/strong&gt; &lt;strong&gt;void&lt;/strong&gt; &lt;strong&gt;tearDown&lt;/strong&gt;() &lt;strong&gt;throws&lt;/strong&gt; &lt;strong&gt;Exception&lt;/strong&gt; {  \n        driver.quit();  \n    }  \n   \n    &lt;strong&gt;@Test&lt;/strong&gt;  \n    &lt;strong&gt;public&lt;/strong&gt; &lt;strong&gt;void&lt;/strong&gt; &lt;strong&gt;addContact&lt;/strong&gt;(){  \n        WebElement &lt;strong&gt;el&lt;/strong&gt; = driver.findElement(&lt;strong&gt;By&lt;/strong&gt;.name(&amp;quot;Add Contact&amp;quot;));  \n        el.click();  \n        List&amp;lt;WebElement&amp;gt; &lt;strong&gt;textFieldsList&lt;/strong&gt; = driver.findElementsByClassName(&amp;quot;android.widget.EditText&amp;quot;);  \n        textFieldsList.get(0).sendKeys(&amp;quot;Some Name&amp;quot;);  \n        textFieldsList.get(2).sendKeys(&amp;quot;Some@example.com&amp;quot;);  \n        driver.findElementByName(&amp;quot;Save&amp;quot;).click();  \n    }  \n}  &lt;/pre&gt;\n\n&lt;p&gt;注意，测试app的位置要和Capabilities里面path位置一致。&lt;strong&gt;Capabilities.java无需提交，Main.java中的package需去掉。&lt;/strong&gt;&lt;/p&gt;\n\n&lt;p&gt;4，开始测试&lt;/p&gt;\n\n&lt;p&gt;a，启动本地Appium 服务，如下图：（也可指定ip和port，和Capabilities里面getUrl保持一致即可）&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/8223525dd20ac2c7dbdb4b734b69aba2.png&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;b，工程右键-&amp;gt;run as-&amp;gt; JUnit Test，如下图：（选择Eclipse JUnit Launcher）&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/a3451bac841d14c1cd35e9d767bf34fd.png&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;注意手机界面变化以及Appium server端的日志输入，如下图：&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/b4c1388490f41a65cd8ce673e0200d04.png&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;5，提交测试到MQC平台&lt;/p&gt;\n\n&lt;p&gt;本地测试通过之后，将测试文件打包成zip文件( 打包文件，不要打包文件夹)，然后在&amp;ldquo;功能测试&amp;rdquo;里，提交被测应用和打包后的脚本ZIP包。&lt;/p&gt;\n\n&lt;p&gt;注意，目前只支持一个Main.java作为testsuite，请打包测试文件（&lt;strong&gt;Capabilities.java无需提交，Main.java开头无需package&lt;/strong&gt;），不要打包文件夹，mac用户反复压缩解压打包文件时可能会出现&lt;strong&gt;__MACOSX文件夹，请仔细检查。&lt;/strong&gt;并且请使用Junit作为用例测试工具。更多问题，请到我们的旺旺交流群（群号：335334143）中反馈。&lt;/p&gt;','Java脚本测试','黑浪','1, 环境准备\n\n    安装Eclipse (最新版即可,目前是luna) 和JDK 6\n\n    在开始前，您可以点击下载本章所有测试相关文件。\n\n2, 在Eclipse中创建测试用例 \n\n  a. 创建一个空白的Android测试工程。\n\n点击File -> New -> Project，然后再弹出框内选择Java Project。\n\n\n\n点击Next到下一步，输入工程名称，比如AppiumJavaTest：\n\n\n\n点击finish，工程建立完成，如下图：\n\n\n\n3，编写测试脚本\n\na，导入依赖的jar包。\n\nAppiumJavaTest右键->Properties->Java Build Path->Add External JARs，将下载文件appium-jar中的三个jar包导入，如下图：\n\n\n\n点击OK，导入。\n\nb，编写测试用例\n\n创建一个Capabilities.java的文件和一个Main.java文件，，MQC会执行用户上传的Main.java，所以要创建这个入口脚本：Main.java。如下图：\n\n\n\n打开Capabilities.java添加如下代码：\n\n\nimport org.openqa.selenium.remote.DesiredCapabilities;\n\npublic class Capabilities {       \n        public static DesiredCapabilities getCapabilities()  {  \n            // set up appium \n            DesiredCapabilities capabilities = new DesiredCapabilities();  \n            capabilities.setCapability(&quot;platformName&quot;, &quot;Android&quot;);  \n            capabilities.setCapability(&quot;deviceName&quot;,&quot;Android Emulator&quot;);  \n            capabilities.setCapability(&quot;platformVersion&quot;, &quot;4.4&quot;);  \n            capabilities.setCapability(&quot;app&quot;, &quot;/Users/heilang/Documents/workspace/AppDemo/apps/ContactManager.apk&quot;);  \n            capabilities.setCapability(&quot;appPackage&quot;, &quot;com.example.android.contactmanager&quot;);  \n            capabilities.setCapability(&quot;automationName&quot;, &quot;Appium&quot;);           \n\n            return capabilities;\n        }\n        \n        public static String getUrl(){\n            return &quot;http://127.0.0.1:4723/wd/hub&quot;;\n        }\n        \n        public String getUserName(){\n            return &quot;username&quot;;\n        }\n        \n        public String getPassWord(){\n            return &quot;password&quot;;\n        }    \n}\n\n打开Main.java，添加如下代码：\n\n\nimport io.appium.java_client.AppiumDriver;\nimport io.appium.java_client.android.AndroidDriver;\n\nimport java.net.URL;\nimport java.util.List;\n\nimport org.junit.After;\nimport org.junit.Before;\nimport org.junit.Test;\nimport org.openqa.selenium.By;\nimport org.openqa.selenium.WebElement;\nimport org.openqa.selenium.remote.DesiredCapabilities;\n   \npublic class Main {  \n    private AppiumDriver&lt;WebElement&gt; driver; &nbsp;  \n\n    @Before  \n    public void setUp() throws Exception {  \n        // set up appium \n        DesiredCapabilities capabilities =  Capabilities.getCapabilities();\n        driver = new AndroidDriver&lt;WebElement&gt;(new URL(Capabilities.getUrl()), capabilities);  \n    }  \n   \n    @After  \n    public void tearDown() throws Exception {  \n        driver.quit();  \n    }  \n   \n    @Test  \n    public void addContact(){  \n        WebElement el = driver.findElement(By.name(&quot;Add Contact&quot;));  \n        el.click();  \n        List&lt;WebElement&gt; textFieldsList = driver.findElementsByClassName(&quot;android.widget.EditText&quot;);  \n        textFieldsList.get(0).sendKeys(&quot;Some Name&quot;);  \n        textFieldsList.get(2).sendKeys(&quot;Some@example.com&quot;);  \n        driver.findElementByName(&quot;Save&quot;).click();  \n    }  \n}  \n\n注意，测试app的位置要和Capabilities里面path位置一致。Capabilities.java无需提交，Main.java中的package需去掉。\n\n4，开始测试\n\na，启动本地Appium 服务，如下图：（也可指定ip和port，和Capabilities里面getUrl保持一致即可）\n\n\n\nb，工程右键->run as-> JUnit Test，如下图：（选择Eclipse JUnit Launcher）\n\n\n\n注意手机界面变化以及Appium server端的日志输入，如下图：\n\n\n\n5，提交测试到MQC平台\n\n本地测试通过之后，将测试文件打包成zip文件( 打包文件，不要打包文件夹)，然后在“功能测试”里，提交被测应用和打包后的脚本ZIP包。\n\n注意，目前只支持一个Main.java作为testsuite，请打包测试文件（Capabilities.java无需提交，Main.java开头无需package），不要打包文件夹，mac用户反复压缩解压打包文件时可能会出现__MACOSX文件夹，请仔细检查。并且请使用Junit作为用例测试工具。更多问题，请到我们的旺旺交流群（群号：335334143）中反馈。',0,14,4),(53,'2015-12-15 11:29:08','2016-02-19 10:32:35','&lt;p&gt;本文将介绍如何编写iOS功能测试脚本。&lt;/p&gt;\n\n&lt;p&gt;如果你还不了解UI Automation框架，或者不知道如何搭建、使用测试环境，那么请先阅读&lt;a href=&quot;http://mqc.aliyun.com/doc.htm?id=40&quot;&gt;UI Automation教程&lt;/a&gt;。除此之外，我们还提供了&lt;a href=&quot;http://mqc.aliyun.com/doc.htm?id=64&quot;&gt;视频教程&lt;/a&gt;，即使你没有太多的编程经验，也只需大约一个小时就能学会编写简单的脚本。&lt;/p&gt;\n\n&lt;p&gt;在开始前，你可以点击&lt;a href=&quot;/static/res/ocr/device/ios_demo.zip&quot;&gt;这里&lt;/a&gt;下载与本文相关的测试脚本和应用。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;1.&amp;nbsp;常用操作&lt;/h2&gt;\n\n&lt;p&gt;UI Automation提供了非常多的接口来模拟UI操作，如点击、双击、双指缩放、拖曳等。&lt;/p&gt;\n\n&lt;p&gt;单击。根据输入的绝对坐标点击屏幕。&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;UIATarget.localTarget().tap({x:100, y:200});&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;双击。根据输入的绝对坐标双击屏幕。&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;UIATarget.localTarget().doubleTap({x:100, y:200});&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;拉伸。模拟双指拉伸操作，第一个坐标点是起点，第二个坐标点是终点，最后一个参数是持续时间，单位为秒。&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;UIATarget.localTarget().pinchOpenFromToForDuration({x:20, y:200}, {x:300, y:200}, 2);&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;收缩。模拟双指收缩操作，第一个坐标点是起点，第二个坐标点是终点，最后一个参数是持续时间，单位为秒。&lt;/p&gt;\n\n&lt;pre&gt;\nUIATarget.localTarget().pinchCloseFromToForDuration({x:20, y:200}, {x:300, y:200}, 2);&lt;/pre&gt;\n\n&lt;p&gt;拖曳。模拟单指拖曳操作，第一个坐标点是起点，第二个坐标点是终点，最后一个参数是持续时间，单位为秒。&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;UIATarget.localTarget().dragFromToForDuration({x:160, y:200}, {x:160, y:400}, 1);&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;快速滑动。模拟单指快速滑动操作，第一个坐标点是起点，第二个坐标点是终点，与拖曳不同的是它没有时间参数，因为这个操作的速度很快。&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;UIATarget.localTarget().flickFromTo({x:160, y:200}, {x:160, y:400});&lt;/code&gt;\n&lt;/pre&gt;\n\n&lt;p&gt;除了根据绝对坐标进行操作，我们也可以先取得控件，然后进行相应的操作。当然，前提是这个控件是存在、有效且可见的。根据控件模拟操作要特别小心，因为有时候控件会被其他控件挡住，控件还没被加载出来，或者突然出现了弹框导致无法操作控件。&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;var addButton = UIATarget.localTarget().frontMostApp().navigationBar().buttons()[&amp;quot;Add&amp;quot;];\n\n&lt;/code&gt;if(addButton.isValid() &amp;amp;&amp;amp; addButton.isVisible()){\n\n&amp;nbsp; &amp;nbsp; addButton.tap();\n\n}&lt;/pre&gt;\n\n&lt;p&gt;如果你还不熟悉UI Automation的接口，那么录制功能将给你带来极大的便利，它会记录下你每次操作的步骤，生成相应的代码。使用方法见&lt;a href=&quot;http://mqc.aliyun.com/doc.htm?id=40&quot;&gt;UI Automation教程&lt;/a&gt;。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;2. 输出测试信息&lt;/h2&gt;\n\n&lt;p&gt;我们希望编写的测试脚本能包含尽可能多的信息，以便于发现和分析可能出现的错误，而记录信息最简单有效的方式就是编写Case。下面看一个Case。&lt;/p&gt;\n\n&lt;pre&gt;\n&lt;code&gt;var testName = &amp;quot;Module 001 Test&amp;quot;;&lt;/code&gt;\n\n&lt;code&gt;UIALogger.logStart(testName);&lt;/code&gt;\n\n&lt;code&gt;//一些测试代码&lt;/code&gt;\n\n&lt;code&gt;UIALogger.logPass(testName);&lt;/code&gt;&lt;/pre&gt;\n\n&lt;p&gt;UIALogger是一个用于记录测试信息的工具类，我们调用它的logStart函数开始一项测试，并为测试项命名。因此，上面这个Case的名称就是&amp;quot;Module 001 Test&amp;quot;。在运行一段测试代码后，我们用logPass或logFail结束一项测试，记录测试结果（成功或失败）。&lt;/p&gt;\n\n&lt;p&gt;我们还可以用logMessage输出一些信息，类似于Java或C里的print。下面的Case就使用了logMessage，它用起来更自由、方便；并用captureScreenWithName截图，记录当时的状态。除此之外，UIALogger工具类还提供了更多的函数如logError,&amp;nbsp;logWarning等，具体用法参见&lt;a href=&quot;https://developer.apple.com/library/ios/documentation/ToolsLanguages/Reference/UIALoggerClassReference/index.html&quot;&gt;UIALogger&lt;/a&gt;。&lt;/p&gt;\n\n&lt;pre&gt;\nvar testName = &amp;quot;Module 001 Test&amp;quot;;\n\nUIALogger.logStart(testName);\n\n//一些测试代码\n\nUIALogger.logMessage(&amp;quot;Starting Module 001 branch 2, validating input.&amp;quot;);\n\n//截一张图，以给定的参数命名\n\nUIATarget.localTarget().captureScreenWithName(&amp;quot;SS001-2_AddedIngredient&amp;quot;);\n\n//更多测试代码\n\nUIALogger.logPass(testName);&lt;/pre&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;3. 处理弹框&lt;/h2&gt;\n\n&lt;p&gt;UI Automation提供了一个函数接口onAlert来处理弹框，当弹框出现时，将调用这个函数。接下来，我们编写一个非常简单的弹框处理函数。&lt;/p&gt;\n\n&lt;pre&gt;\nUIATarget.onAlert = function onAlert(alert) {\n\n    var title = alert.name();\n\n    UIALogger.logWarning(&amp;quot;Alert with title \'&amp;quot; + title + &amp;quot;\' encountered.&amp;quot;);\n\n    // 返回false，使用默认处理方式\n\n    return false;\n\n}\n&lt;/pre&gt;\n\n&lt;p&gt;这个函数使用logWarning记录了弹框的名称，最后返回false，这将意味着点击默认按钮来关闭弹框。例如，当收到一条短信时，这个函数执行的操作是点击&amp;ldquo;关闭&amp;rdquo;按钮，从而关闭弹框。&lt;/p&gt;\n\n&lt;p&gt;如果弹框是app内部产生的，并且我们知道它的确切的名字，那么我们可以执行一些预期的操作，而不仅仅是关闭弹框。下面的代码为一个特定的弹框执行了点击&amp;ldquo;Continue&amp;rdquo;按钮的操作，并返回true，当然前提是我们确定&amp;ldquo;Continue&amp;rdquo;按钮是存在的。&lt;/p&gt;\n\n&lt;pre&gt;\nUIATarget.onAlert = function onAlert(alert) {\n\n    var title = alert.name();\n\n    UIALogger.logWarning(&amp;quot;Alert with title \'&amp;quot; + title + &amp;quot;\' encountered.&amp;quot;);\n\n    if (title == &amp;quot;The Alert We Expected&amp;quot;) {\n\n        alert.buttons()[&amp;quot;Continue&amp;quot;].tap();\n\n        return true;  //弹框已处理\n\n    }\n\n    //若返回false，则使用默认处理方式\n\n    return false;\n\n}&lt;/pre&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;4. 脚本示例&lt;/h2&gt;\n\n&lt;p&gt;下面以&amp;ldquo;开源中国&amp;rdquo;app为例，编写一个登陆脚本。点击&lt;a href=&quot;/static/res/ocr/device/ios_demo.zip&quot;&gt;这里&lt;/a&gt;下载测试应用和脚本。&lt;/p&gt;\n\n&lt;pre&gt;\nvar target = UIATarget.localTarget();  //UIATarget是最上层的类，表示真实设备或模拟器    \n\ntry{\n\n    target.delay(3); //等待3秒，跳过开场动画\n\n    UIALogger.logStart(&amp;quot;test 1&amp;quot;); //第1个Case\n\n    UIALogger.logMessage(&amp;quot;开始第一个测试&amp;quot;);\n\n    var leftButton = target.frontMostApp().navigationBar().leftButton();  //取得导航栏的左侧按钮\n\n    leftButton.tap(); //点击\n\n    var techCell = target.frontMostApp().mainWindow().tableViews()[0].cells()[&amp;quot;技术问答&amp;quot;];  //取得第一个cell\n\n    if (techCell.isValid() &amp;amp;&amp;amp; techCell.isVisible()) {\n\n        UIALogger.logPass(&amp;quot;find 技术问答&amp;quot;);\n\n    } else {\n\n        UIALogger.logFail(&amp;quot;cannot find 技术问答&amp;quot;);\n\n    }\n\n    UIALogger.logStart(&amp;quot;test 2&amp;quot;); //第2个Case\n\n    UIALogger.logMessage(&amp;quot;开始第二个测试&amp;quot;); \n\n    target.frontMostApp().mainWindow().buttons()[0].tap();\n\n    target.delay(1); //等待动画结束\n\n    target.frontMostApp().tabBar().buttons()[&amp;quot;我&amp;quot;].tap();\n\n    target.delay(1); //等待动画结束\n\n    target.frontMostApp().mainWindow().tableViews()[1].cells()[&amp;quot;消息&amp;quot;].tap();\n\n    target.delay(1); //等待动画结束\n\n    var loginButton = target.frontMostApp().mainWindow().buttons()[&amp;quot;登录&amp;quot;];\n\n    if(loginButton.isValid() &amp;amp;&amp;amp; loginButton.isVisible()){ //如果登陆按钮有效且可见，则表示用户未登录，接下来尝试登陆\n\n        var textField = target.frontMostApp().mainWindow().textFields()[0];\n\n        var secureTextField = target.frontMostApp().mainWindow().secureTextFields()[0];\n\n        textField.tap();\n\n        textField.setValue(&amp;quot;username&amp;quot;); //输入用户名\n\n        target.delay(0.5);\n\n        secureTextField.tap();\n\n        secureTextField.setValue(&amp;quot;password&amp;quot;); //输入密码\n\n        target.delay(0.5);\n\n        loginButton.tap();\n\n        target.delay(3);\n\n        if(loginButton.isValid() &amp;amp;&amp;amp; loginButton.isVisible()){    \n\n            UIALogger.logFail(&amp;quot;登陆失败&amp;quot;);\n\n        }else{\n\n            UIALogger.logPass(&amp;quot;登陆成功&amp;quot;);\n\n        }\n\n    }else{\n\n        UIALogger.logPass(&amp;quot;用户已经登陆&amp;quot;);\n\n    }\n\n}catch(err){\n\n    UIALogger.logError(err.toString());\n\n}&lt;/pre&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;5. 学习资料&lt;/h2&gt;\n\n&lt;p&gt;如果希望学习更多有关JavaScript脚本编写和UI Automation框架的内容，请参考下面的资料。&lt;/p&gt;\n\n&lt;p&gt;a.&amp;nbsp;&lt;a href=&quot;https://developer.apple.com/library/ios/documentation/DeveloperTools/Reference/UIAutomationRef/index.html&quot;&gt;《UI Automation JavaScript Reference for iOS》&lt;/a&gt;，UI Automation官方文档，里面有详实的API介绍&lt;/p&gt;\n\n&lt;p&gt;b.&amp;nbsp;&lt;a href=&quot;https://developer.apple.com/library/prerelease/mac/documentation/DeveloperTools/Conceptual/InstrumentsUserGuide/UIAutomation.html&quot;&gt;《Automate UI Testing in iOS》&lt;/a&gt;，UI Automation入门教程&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;','功能测试','间客','本文将介绍如何编写iOS功能测试脚本。\n\n如果你还不了解UI Automation框架，或者不知道如何搭建、使用测试环境，那么请先阅读UI Automation教程。除此之外，我们还提供了视频教程，即使你没有太多的编程经验，也只需大约一个小时就能学会编写简单的脚本。\n\n在开始前，你可以点击这里下载与本文相关的测试脚本和应用。\n\n \n\n1. 常用操作\n\nUI Automation提供了非常多的接口来模拟UI操作，如点击、双击、双指缩放、拖曳等。\n\n单击。根据输入的绝对坐标点击屏幕。\n\n\nUIATarget.localTarget().tap({x:100, y:200});\n\n双击。根据输入的绝对坐标双击屏幕。\n\n\nUIATarget.localTarget().doubleTap({x:100, y:200});\n\n拉伸。模拟双指拉伸操作，第一个坐标点是起点，第二个坐标点是终点，最后一个参数是持续时间，单位为秒。\n\n\nUIATarget.localTarget().pinchOpenFromToForDuration({x:20, y:200}, {x:300, y:200}, 2);\n\n收缩。模拟双指收缩操作，第一个坐标点是起点，第二个坐标点是终点，最后一个参数是持续时间，单位为秒。\n\n\nUIATarget.localTarget().pinchCloseFromToForDuration({x:20, y:200}, {x:300, y:200}, 2);\n\n拖曳。模拟单指拖曳操作，第一个坐标点是起点，第二个坐标点是终点，最后一个参数是持续时间，单位为秒。\n\n\nUIATarget.localTarget().dragFromToForDuration({x:160, y:200}, {x:160, y:400}, 1);\n\n快速滑动。模拟单指快速滑动操作，第一个坐标点是起点，第二个坐标点是终点，与拖曳不同的是它没有时间参数，因为这个操作的速度很快。\n\n\nUIATarget.localTarget().flickFromTo({x:160, y:200}, {x:160, y:400});\n\n\n除了根据绝对坐标进行操作，我们也可以先取得控件，然后进行相应的操作。当然，前提是这个控件是存在、有效且可见的。根据控件模拟操作要特别小心，因为有时候控件会被其他控件挡住，控件还没被加载出来，或者突然出现了弹框导致无法操作控件。\n\n\nvar addButton = UIATarget.localTarget().frontMostApp().navigationBar().buttons()[&quot;Add&quot;];\n\nif(addButton.isValid() &amp;&amp; addButton.isVisible()){\n\n&nbsp; &nbsp; addButton.tap();\n\n}\n\n如果你还不熟悉UI Automation的接口，那么录制功能将给你带来极大的便利，它会记录下你每次操作的步骤，生成相应的代码。使用方法见UI Automation教程。\n\n \n\n2. 输出测试信息\n\n我们希望编写的测试脚本能包含尽可能多的信息，以便于发现和分析可能出现的错误，而记录信息最简单有效的方式就是编写Case。下面看一个Case。\n\n\nvar testName = &quot;Module 001 Test&quot;;\n\nUIALogger.logStart(testName);\n\n//一些测试代码\n\nUIALogger.logPass(testName);\n\nUIALogger是一个用于记录测试信息的工具类，我们调用它的logStart函数开始一项测试，并为测试项命名。因此，上面这个Case的名称就是\"Module 001 Test\"。在运行一段测试代码后，我们用logPass或logFail结束一项测试，记录测试结果（成功或失败）。\n\n我们还可以用logMessage输出一些信息，类似于Java或C里的print。下面的Case就使用了logMessage，它用起来更自由、方便；并用captureScreenWithName截图，记录当时的状态。除此之外，UIALogger工具类还提供了更多的函数如logError, logWarning等，具体用法参见UIALogger。\n\n\nvar testName = &quot;Module 001 Test&quot;;\n\nUIALogger.logStart(testName);\n\n//一些测试代码\n\nUIALogger.logMessage(&quot;Starting Module 001 branch 2, validating input.&quot;);\n\n//截一张图，以给定的参数命名\n\nUIATarget.localTarget().captureScreenWithName(&quot;SS001-2_AddedIngredient&quot;);\n\n//更多测试代码\n\nUIALogger.logPass(testName);\n\n \n\n3. 处理弹框\n\nUI Automation提供了一个函数接口onAlert来处理弹框，当弹框出现时，将调用这个函数。接下来，我们编写一个非常简单的弹框处理函数。\n\n\nUIATarget.onAlert = function onAlert(alert) {\n\n    var title = alert.name();\n\n    UIALogger.logWarning(&quot;Alert with title \'&quot; + title + &quot;\' encountered.&quot;);\n\n    // 返回false，使用默认处理方式\n\n    return false;\n\n}\n\n\n这个函数使用logWarning记录了弹框的名称，最后返回false，这将意味着点击默认按钮来关闭弹框。例如，当收到一条短信时，这个函数执行的操作是点击“关闭”按钮，从而关闭弹框。\n\n如果弹框是app内部产生的，并且我们知道它的确切的名字，那么我们可以执行一些预期的操作，而不仅仅是关闭弹框。下面的代码为一个特定的弹框执行了点击“Continue”按钮的操作，并返回true，当然前提是我们确定“Continue”按钮是存在的。\n\n\nUIATarget.onAlert = function onAlert(alert) {\n\n    var title = alert.name();\n\n    UIALogger.logWarning(&quot;Alert with title \'&quot; + title + &quot;\' encountered.&quot;);\n\n    if (title == &quot;The Alert We Expected&quot;) {\n\n        alert.buttons()[&quot;Continue&quot;].tap();\n\n        return true;  //弹框已处理\n\n    }\n\n    //若返回false，则使用默认处理方式\n\n    return false;\n\n}\n\n \n\n4. 脚本示例\n\n下面以“开源中国”app为例，编写一个登陆脚本。点击这里下载测试应用和脚本。\n\n\nvar target = UIATarget.localTarget();  //UIATarget是最上层的类，表示真实设备或模拟器    \n\ntry{\n\n    target.delay(3); //等待3秒，跳过开场动画\n\n    UIALogger.logStart(&quot;test 1&quot;); //第1个Case\n\n    UIALogger.logMessage(&quot;开始第一个测试&quot;);\n\n    var leftButton = target.frontMostApp().navigationBar().leftButton();  //取得导航栏的左侧按钮\n\n    leftButton.tap(); //点击\n\n    var techCell = target.frontMostApp().mainWindow().tableViews()[0].cells()[&quot;技术问答&quot;];  //取得第一个cell\n\n    if (techCell.isValid() &amp;&amp; techCell.isVisible()) {\n\n        UIALogger.logPass(&quot;find 技术问答&quot;);\n\n    } else {\n\n        UIALogger.logFail(&quot;cannot find 技术问答&quot;);\n\n    }\n\n    UIALogger.logStart(&quot;test 2&quot;); //第2个Case\n\n    UIALogger.logMessage(&quot;开始第二个测试&quot;); \n\n    target.frontMostApp().mainWindow().buttons()[0].tap();\n\n    target.delay(1); //等待动画结束\n\n    target.frontMostApp().tabBar().buttons()[&quot;我&quot;].tap();\n\n    target.delay(1); //等待动画结束\n\n    target.frontMostApp().mainWindow().tableViews()[1].cells()[&quot;消息&quot;].tap();\n\n    target.delay(1); //等待动画结束\n\n    var loginButton = target.frontMostApp().mainWindow().buttons()[&quot;登录&quot;];\n\n    if(loginButton.isValid() &amp;&amp; loginButton.isVisible()){ //如果登陆按钮有效且可见，则表示用户未登录，接下来尝试登陆\n\n        var textField = target.frontMostApp().mainWindow().textFields()[0];\n\n        var secureTextField = target.frontMostApp().mainWindow().secureTextFields()[0];\n\n        textField.tap();\n\n        textField.setValue(&quot;username&quot;); //输入用户名\n\n        target.delay(0.5);\n\n        secureTextField.tap();\n\n        secureTextField.setValue(&quot;password&quot;); //输入密码\n\n        target.delay(0.5);\n\n        loginButton.tap();\n\n        target.delay(3);\n\n        if(loginButton.isValid() &amp;&amp; loginButton.isVisible()){    \n\n            UIALogger.logFail(&quot;登陆失败&quot;);\n\n        }else{\n\n            UIALogger.logPass(&quot;登陆成功&quot;);\n\n        }\n\n    }else{\n\n        UIALogger.logPass(&quot;用户已经登陆&quot;);\n\n    }\n\n}catch(err){\n\n    UIALogger.logError(err.toString());\n\n}\n\n \n\n5. 学习资料\n\n如果希望学习更多有关JavaScript脚本编写和UI Automation框架的内容，请参考下面的资料。\n\na. 《UI Automation JavaScript Reference for iOS》，UI Automation官方文档，里面有详实的API介绍\n\nb. 《Automate UI Testing in iOS》，UI Automation入门教程\n\n ',0,39,3),(56,'2015-12-27 15:22:59','2016-06-08 00:25:56',NULL,'线上课程','mts',NULL,0,0,6),(57,'2015-12-27 15:25:50','2016-04-12 18:34:45','&lt;a href=&quot;http://v.youku.com/v_show/id_XMTQyMzk3MDQ4NA==.html&quot; target=&quot;_blank&quot;&gt;http://v.youku.com/v_show/id_XMTQyMzk3MDQ4NA==.html&lt;/a&gt;\n\n&lt;iframe height=498 width=800 src=&quot;http://player.youku.com/embed/XMTQyMzk3MDQ4NA==&quot; frameborder=0 allowfullscreen&gt;&lt;/iframe&gt;','性能测试－内存篇','mts','http://v.youku.com/v_show/id_XMTQyMzk3MDQ4NA==.html\n\n',0,56,1),(58,'2016-01-07 16:32:02','2016-04-12 18:34:07','&lt;a href=&quot;http://v.youku.com/v_show/id_XMTQzNzg3Njk4OA==.html&quot; target=&quot;_blank&quot;&gt;http://v.youku.com/v_show/id_XMTQzNzg3Njk4OA==.html&lt;/a&gt;\n&lt;iframe height=498 width=800 src=&quot;http://player.youku.com/embed/XMTQzNzg3Njk4OA==&quot; frameborder=0 allowfullscreen&gt;&lt;/iframe&gt;','功能测试及常见问题','mts','http://v.youku.com/v_show/id_XMTQzNzg3Njk4OA==.html\n',0,56,2),(61,'2016-01-18 17:10:11','2016-01-18 17:10:11',NULL,'性能测试','末非',NULL,0,3,5),(62,'2016-01-18 17:11:32','2016-01-18 17:11:32','&lt;h2&gt;背景&lt;/h2&gt;\n\n&lt;p&gt;一款优秀的APP应用，除了有强大的功能外，优秀的性能体验也是决定用户留存的重要因素。在这种情况下，MQC为了帮助开发者监测Android应用的性能并定位问题，在测试过程中采集了丰富的性能数据，并以图表的形式展示给用户。&lt;/p&gt;\n\n&lt;p&gt;性能曲线展示的数据主要包括：CPU占用率、内存(应用占用RAM、堆内存)、流量 (上行/下行)、帧率、流畅度SM、电量。&lt;/p&gt;\n\n&lt;h2&gt;性能曲线数据介绍&lt;/h2&gt;\n\n&lt;p&gt;1、CPU&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;如果应用的CPU使用率过高，CPU过于繁忙，会使整个手机无法响应用户，整体性能降低，影响用户体验，也容易引起ANR等问题。&lt;/p&gt;\n\n&lt;p&gt;2、内存&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;内存泄露是Android开发者十分关心的问题，因为内存泄露可能导致的后果是应用进程直接被kill掉。MQC采集应用的RAM占用、堆内存，通过内存变化趋势分析OOM问题。内存泄露导致的原因通常是由于new的对象被长时间引用未及时释放导致。如果观察性能曲线的内存数据，发现存在持续性地增长，则很有可能存在内存泄露的风险。&lt;/p&gt;\n\n&lt;p&gt;3、流量&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;对于APP用户来说，流量=钱，通过流量的实时监测，帮开发者分析应用的资源加载大小、网络请求是否合理。&lt;/p&gt;\n\n&lt;p&gt;4、帧率和流畅度&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;应用的帧率和流畅度是最直接影响用户体验的。通过帧率和流畅度曲线，帮开发者分析是否存在UI问题。fps取的是每秒应用产生新帧数量的均值，和每秒vsync(垂直同步)中断的循环次数是有区别的。 vsync(垂直同步)的loop一直在运行(一般60次/s)，即使没有新帧产生也会运行，但运行的频率受cpu和gpu的处理时间影响，cpu和gpu处理时间过长会造成卡顿、丢帧，vsync的执行频率会降低，所以我们要度量app的流畅情况使用vsync的执行频率和丢帧率是最合适、最有意义的。&amp;nbsp;对于一直在刷新(产生新的帧)的应用（比如一些手游），fps就接近于vsync 的刷新率，此时fps有意义，但是对于其它大部分应用，fps的数值取决于画面是否静默，用户是否在操作，所以fps均值对这些应用意义不是很大。但是对于功能测试中的某些特定场景，比如滑动操作(持续1s以上)，性能曲线上的fps数值可以起到参考作用。 &amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;5、电量&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;通过电量曲线，观察应用在操作过程中耗电情况。&lt;/p&gt;\n\n&lt;h2&gt;性能概况&lt;/h2&gt;\n\n&lt;p&gt;除了上述的性能曲线数据，MQC还提供性能概况报告，主要是设备之间的各指标对比，列出如启动时间、CPU、内存、流量等指标表现最好和最差的设备。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;','性能指标','末非','背景\n\n一款优秀的APP应用，除了有强大的功能外，优秀的性能体验也是决定用户留存的重要因素。在这种情况下，MQC为了帮助开发者监测Android应用的性能并定位问题，在测试过程中采集了丰富的性能数据，并以图表的形式展示给用户。\n\n性能曲线展示的数据主要包括：CPU占用率、内存(应用占用RAM、堆内存)、流量 (上行/下行)、帧率、流畅度SM、电量。\n\n性能曲线数据介绍\n\n1、CPU\n\n     如果应用的CPU使用率过高，CPU过于繁忙，会使整个手机无法响应用户，整体性能降低，影响用户体验，也容易引起ANR等问题。\n\n2、内存\n\n     内存泄露是Android开发者十分关心的问题，因为内存泄露可能导致的后果是应用进程直接被kill掉。MQC采集应用的RAM占用、堆内存，通过内存变化趋势分析OOM问题。内存泄露导致的原因通常是由于new的对象被长时间引用未及时释放导致。如果观察性能曲线的内存数据，发现存在持续性地增长，则很有可能存在内存泄露的风险。\n\n3、流量\n\n     对于APP用户来说，流量=钱，通过流量的实时监测，帮开发者分析应用的资源加载大小、网络请求是否合理。\n\n4、帧率和流畅度\n\n     应用的帧率和流畅度是最直接影响用户体验的。通过帧率和流畅度曲线，帮开发者分析是否存在UI问题。fps取的是每秒应用产生新帧数量的均值，和每秒vsync(垂直同步)中断的循环次数是有区别的。 vsync(垂直同步)的loop一直在运行(一般60次/s)，即使没有新帧产生也会运行，但运行的频率受cpu和gpu的处理时间影响，cpu和gpu处理时间过长会造成卡顿、丢帧，vsync的执行频率会降低，所以我们要度量app的流畅情况使用vsync的执行频率和丢帧率是最合适、最有意义的。 对于一直在刷新(产生新的帧)的应用（比如一些手游），fps就接近于vsync 的刷新率，此时fps有意义，但是对于其它大部分应用，fps的数值取决于画面是否静默，用户是否在操作，所以fps均值对这些应用意义不是很大。但是对于功能测试中的某些特定场景，比如滑动操作(持续1s以上)，性能曲线上的fps数值可以起到参考作用。  \n\n5、电量\n\n     通过电量曲线，观察应用在操作过程中耗电情况。\n\n性能概况\n\n除了上述的性能曲线数据，MQC还提供性能概况报告，主要是设备之间的各指标对比，列出如启动时间、CPU、内存、流量等指标表现最好和最差的设备。\n\n ',0,61,1),(64,'2016-01-21 12:57:26','2016-04-12 18:35:39','&lt;a href=&quot;http://v.youku.com/v_show/id_XMTQ1MjEwMTU2OA==.html&quot; target=&quot;_blank&quot;&gt;http://v.youku.com/v_show/id_XMTQ1MjEwMTU2OA==.html&lt;/a&gt;\n&lt;iframe height=498 width=800 src=&quot;http://player.youku.com/embed/XMTQ1MjEwMTU2OA==&quot; frameborder=0 allowfullscreen&gt;&lt;/iframe&gt;','iOS功能测试脚本','间客','http://v.youku.com/v_show/id_XMTQ1MjEwMTU2OA==.html\n',0,56,3),(65,'2016-02-19 20:05:19','2017-03-01 17:43:12','&lt;h2&gt;背景&lt;/h2&gt;\n\n&lt;p&gt;MQC一直致力于帮助开发者快速发现和解决App质量问题，在线录制主要解决人工编写脚本效率低，成本高，兼容性差等等问题。&lt;/p&gt;\n\n&lt;p&gt;在线录制允许用户通过远程租用手机的方式，在线录制一些动作，录制的动作可以被自动转化为自动化脚本，并且可以在远程租用的手机上进行回放，大大节省了人力成本。&lt;/p&gt;\n\n&lt;h2&gt;使用详解&lt;/h2&gt;\n\n&lt;p&gt;1、初始界面如下图所示，1为手机操作区域，操作方式与远程真机租用使用方式无异；2为刷新按钮，点击该按钮后，会重新解析当前界面的控件树；3为控件信息显示区域，可以显示当前鼠标所在控件的信息；4为上传应用按钮，点击后可以上传被测应用。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/7d28235dd5762e5560593bb691e72ddc.jpg&quot; style=&quot;height:483px; width:900px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;2、点击刷新按钮后，会进行控件解析，此时如果在录制状态，请不要录制任何动作，大概两秒左右，控件解析完毕。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/49ca8c57944cb61e5927db6c58eb9bc8.jpg&quot; style=&quot;height:480px; width:900px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;3、解析屏幕完毕后，鼠标再次移到手机操作区域，鼠标所在位置的控件会被红色虚线框标出，同时，在控件信息显示区域会显示当前控件的信息&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/2f11eb12920f62c14e53273a1acd46f7.jpg&quot; style=&quot;height:490px; width:900px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;4、注意，没有上传应用前，是不能进行录制的，上传完应用后，会出现开始录制的按钮。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/806e53bf901528efe224e00bd35e2bda.jpg&quot; style=&quot;height:493px; width:900px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;5、点击开始录制，就会进入录制的状态，这时候，操作手机的动作都会被录制下来。每次操作结束后，都会自动刷新控件树，无需再手动点击刷新按钮。同时，会生成一个操作动作，操作动作中有些参数是可编辑的，以蓝色下划线表示，点击后，可进行编辑，编辑结束后，点击其他区域即可。鼠标移到某一个控件上，会出现try和x两个按钮，x表示删除当前动作，try表示在该动作上加上try catch。清空按钮可以将录制的步骤全部删除，截图按钮可以加入截图命令。点击停止录制按钮可以停止录制状态。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/102f30b4ce6106f7f5fa46968a2307c6.jpg&quot; style=&quot;height:393px; width:900px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;6、动作录制好后，点击右上角的构建脚本按钮，可以自动生成测试脚本。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/dab06642781bb3bde90fe0f573241dae.jpg&quot; style=&quot;height:35px; width:900px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;脚本生成后，进入如下界面，在脚本区域，我们能看到生成的脚本，上面的返回录制按钮，可以返回之前的录制界面；下载脚本按钮，可以下载脚本的压缩包，压缩包中包括main.py，desired_capabilities.py和readme.txt。其中main.py为生成的脚本，desired_capabilities.py对应Appium的Desired capabilities，readme.txt为说明。上传脚本按钮会将生成的脚本及被测APP打包自动上传至脚本管理。点击执行按钮，可以执行脚本，脚本会在远程租用的手机上执行。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/7f56eab4f5b41a1f79606334f6a32ad2.jpg&quot; style=&quot;height:468px; width:900px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;7、脚本执行结束后，会在Log区域中返回执行的结果。&lt;/p&gt;\n\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;/static/res/fdacceaf879cbda07e8d88159423f39c.jpg&quot; style=&quot;height:492px; width:900px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;执行成功后，可通过上传脚本按钮将脚本上传至脚本管理。然后在功能测试中使用该脚本。&lt;/p&gt;','在线录制文档','竹逊','背景\n\nMQC一直致力于帮助开发者快速发现和解决App质量问题，在线录制主要解决人工编写脚本效率低，成本高，兼容性差等等问题。\n\n在线录制允许用户通过远程租用手机的方式，在线录制一些动作，录制的动作可以被自动转化为自动化脚本，并且可以在远程租用的手机上进行回放，大大节省了人力成本。\n\n使用详解\n\n1、初始界面如下图所示，1为手机操作区域，操作方式与远程真机租用使用方式无异；2为刷新按钮，点击该按钮后，会重新解析当前界面的控件树；3为控件信息显示区域，可以显示当前鼠标所在控件的信息；4为上传应用按钮，点击后可以上传被测应用。\n\n\n\n2、点击刷新按钮后，会进行控件解析，此时如果在录制状态，请不要录制任何动作，大概两秒左右，控件解析完毕。\n\n\n\n3、解析屏幕完毕后，鼠标再次移到手机操作区域，鼠标所在位置的控件会被红色虚线框标出，同时，在控件信息显示区域会显示当前控件的信息\n\n\n\n4、注意，没有上传应用前，是不能进行录制的，上传完应用后，会出现开始录制的按钮。\n\n\n\n5、点击开始录制，就会进入录制的状态，这时候，操作手机的动作都会被录制下来。每次操作结束后，都会自动刷新控件树，无需再手动点击刷新按钮。同时，会生成一个操作动作，操作动作中有些参数是可编辑的，以蓝色下划线表示，点击后，可进行编辑，编辑结束后，点击其他区域即可。鼠标移到某一个控件上，会出现try和x两个按钮，x表示删除当前动作，try表示在该动作上加上try catch。清空按钮可以将录制的步骤全部删除，截图按钮可以加入截图命令。点击停止录制按钮可以停止录制状态。\n\n\n\n6、动作录制好后，点击右上角的构建脚本按钮，可以自动生成测试脚本。\n\n\n\n脚本生成后，进入如下界面，在脚本区域，我们能看到生成的脚本，上面的返回录制按钮，可以返回之前的录制界面；下载脚本按钮，可以下载脚本的压缩包，压缩包中包括main.py，desired_capabilities.py和readme.txt。其中main.py为生成的脚本，desired_capabilities.py对应Appium的Desired capabilities，readme.txt为说明。上传脚本按钮会将生成的脚本及被测APP打包自动上传至脚本管理。点击执行按钮，可以执行脚本，脚本会在远程租用的手机上执行。\n\n\n\n7、脚本执行结束后，会在Log区域中返回执行的结果。\n\n\n\n执行成功后，可通过上传脚本按钮将脚本上传至脚本管理。然后在功能测试中使用该脚本。',0,3,15),(66,'2016-03-11 16:22:36','2016-04-12 18:36:52','&lt;a href=&quot;http://v.youku.com/v_show/id_XMTQ5NjYxNDkxMg==.html&quot; target=&quot;_blank&quot;&gt;http://v.youku.com/v_show/id_XMTQ5NjYxNDkxMg==.html&lt;/a&gt;\n&lt;embed src=&quot;http://player.youku.com/player.php/sid/XMTQ5NjYxNDkxMg==/v.swf&quot; allowFullScreen=&quot;true&quot; quality=&quot;high&quot; width=&quot;800&quot; height=&quot;498&quot; align=&quot;middle&quot; allowScriptAccess=&quot;always&quot; type=&quot;application/x-shockwave-flash&quot;&gt;&lt;/embed&gt;','在线录制','竹逊','http://v.youku.com/v_show/id_XMTQ5NjYxNDkxMg==.html\n',0,56,4),(101,'2016-06-27 17:57:08','2017-03-01 17:44:12','&lt;p&gt;appium环境搭建，请参考&lt;a href=&quot;http://mqc.yunos.com/doc.htm?id=16&quot;&gt;帮助文档&lt;/a&gt;。Windows用户可直接下载官方&lt;a href=&quot;https://bitbucket.org/appium/appium.app/downloads/&quot;&gt;客户端&lt;/a&gt;。appium python版&amp;nbsp;&lt;a href=&quot;http://blog.csdn.net/hqzxsc2006/article/details/50112109&quot;&gt;API文档参考&lt;/a&gt;&amp;nbsp;。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;1. 安装好了以后，appium server起不来怎么办？&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; 第一步先要确保appium环境变量已配置好。命令行输入appium -v，确保能看到appium的版本号。然后用appium-doctor命令检查相关配置项，如下图所示。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;&lt;img alt=&quot;&quot; src=&quot;/static/res/1519d3d294b0aa245f15031ff3a6ee22.png&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; 一般比较多的情况是android-sdk没安装好，ANDROID_HOME环境变量没设置。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;2. &amp;nbsp;appium &amp;nbsp;python脚本报 IndentationError:expected an indented block 错误。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;这种情况是您的python脚本，在错误的那行存在缩进问题，请仔细检查。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;3. &amp;nbsp;本地调试脚本,appium server报 &amp;nbsp;error: &amp;nbsp;Activity used to start app doesn\'t exist or cannot &amp;nbsp;be lauched!&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;确保本地的 Desired Capabilities 文件，appActivity 参数指定的 启动页activity是正确的。如何知道app的启动activity？可通过 &amp;nbsp;{android-sdks}/build-tools/aapt d badging &amp;nbsp; xx.apk 命令，返回的结果里 launchable-activity，就是你的应用启动activity。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;4. &amp;nbsp;定位元素出现error:Invalid&amp;nbsp;locator&amp;nbsp;strategy:&amp;nbsp;partial&amp;nbsp;link&amp;nbsp;text?&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;link_text 和&amp;nbsp;partial&amp;nbsp;link&amp;nbsp;text 方法在低版本手机不支持。 建议使用 by_id、by_class_name等更通用的api来定位元素。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;5. &amp;nbsp;输入框需要输入中文，脚本应该如何配置？&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;本地调试的时候，desired_capabilities文件，需要增加配置项 &amp;nbsp; {&amp;nbsp;\'unicodeKeyboard\': True,&amp;nbsp;&amp;nbsp;\'resetKeyBoard\': True&amp;nbsp;} ；脚本里&amp;nbsp;send_keys(text.decode(\'UTF-8\') ，其中text就是你要输入的中文内容，务必加上 decode(\'UTF-8\')，否则会出现乱码。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;6. &amp;nbsp;脚本调用swipe滑动 app 引导页， 但是滑动失败了怎么办？&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;appium框架特性，如果操作出异常，脚本会停止继续执行。碰到swipe操作没滑动过去，可以给脚本增加适当的异常处理，增加重试机制，提高脚本成功率。如下例子&lt;/p&gt;\n\n&lt;blockquote&gt;\n&lt;p&gt;&amp;nbsp; &amp;nbsp; self.swipe([1,1],[100,100])&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; try:&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; self.click_element(\'xxx:id/login_btn\', \'text\', 1, 100, None) &amp;nbsp; &amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp;&amp;nbsp;except:&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; self.swipe([1,1],[100,100])&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; self.click_element(\'xxx:id/login_btn\', \'text\', 1, 100, None)&amp;nbsp;&lt;/p&gt;\n&lt;/blockquote&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; 用户可根据自己的实际情况，对脚本进行优化。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;7. &amp;nbsp;脚本里想调用手机的返回键，应该如何处理？&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;返回事件封装在driver端，可通过 self.driver.back()，即发送了返回事件。&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;8. &amp;nbsp;我的应用是hybrid型, 脚本里如何测试？&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; appium支持hybrid型应用测试。如果测试native页面后，需要对webview页面进行操作。通过driver.switch_to_context(\'WEBVIEW\')切换上下文，这里切换到 webview，之后即可通过&amp;nbsp;find_element_by_css_selector 方式来定位html页面的元素。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;脚本在本地测试通过以后，就可以提交到我们平台进行测试啦。在编写脚本的过程中遇到问题，可多查阅api文档，多尝试多调试，好的脚本需要不断的打磨和优化。&lt;/p&gt;\n\n&lt;p&gt;后续这个文档会不断更新，记录一些用户的常见问题和解决方法，欢迎大家保持关注。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp; &amp;nbsp;&amp;nbsp;&lt;/p&gt;','功能测试常见问题','思杭','appium环境搭建，请参考帮助文档。Windows用户可直接下载官方客户端。appium python版 API文档参考 。\n\n \n\n1. 安装好了以后，appium server起不来怎么办？\n\n    第一步先要确保appium环境变量已配置好。命令行输入appium -v，确保能看到appium的版本号。然后用appium-doctor命令检查相关配置项，如下图所示。\n\n     \n\n    一般比较多的情况是android-sdk没安装好，ANDROID_HOME环境变量没设置。\n\n \n\n2.  appium  python脚本报 IndentationError:expected an indented block 错误。\n\n     这种情况是您的python脚本，在错误的那行存在缩进问题，请仔细检查。\n\n \n\n3.  本地调试脚本,appium server报  error:  Activity used to start app doesn\'t exist or cannot  be lauched! \n\n     确保本地的 Desired Capabilities 文件，appActivity 参数指定的 启动页activity是正确的。如何知道app的启动activity？可通过  {android-sdks}/build-tools/aapt d badging   xx.apk 命令，返回的结果里 launchable-activity，就是你的应用启动activity。\n\n \n\n4.  定位元素出现error:Invalid locator strategy: partial link text?\n\n     link_text 和 partial link text 方法在低版本手机不支持。 建议使用 by_id、by_class_name等更通用的api来定位元素。\n\n \n\n5.  输入框需要输入中文，脚本应该如何配置？\n\n     本地调试的时候，desired_capabilities文件，需要增加配置项   { \'unicodeKeyboard\': True,  \'resetKeyBoard\': True } ；脚本里 send_keys(text.decode(\'UTF-8\') ，其中text就是你要输入的中文内容，务必加上 decode(\'UTF-8\')，否则会出现乱码。\n\n \n\n6.  脚本调用swipe滑动 app 引导页， 但是滑动失败了怎么办？\n\n     appium框架特性，如果操作出异常，脚本会停止继续执行。碰到swipe操作没滑动过去，可以给脚本增加适当的异常处理，增加重试机制，提高脚本成功率。如下例子\n\n\n    self.swipe([1,1],[100,100])\n\n    try:\n\n            self.click_element(\'xxx:id/login_btn\', \'text\', 1, 100, None)    \n\n    except:\n\n            self.swipe([1,1],[100,100])\n\n            self.click_element(\'xxx:id/login_btn\', \'text\', 1, 100, None) \n\n\n      用户可根据自己的实际情况，对脚本进行优化。\n\n \n\n7.  脚本里想调用手机的返回键，应该如何处理？\n\n     返回事件封装在driver端，可通过 self.driver.back()，即发送了返回事件。                     \n\n \n\n8.  我的应用是hybrid型, 脚本里如何测试？\n\n      appium支持hybrid型应用测试。如果测试native页面后，需要对webview页面进行操作。通过driver.switch_to_context(\'WEBVIEW\')切换上下文，这里切换到 webview，之后即可通过 find_element_by_css_selector 方式来定位html页面的元素。\n\n \n\n脚本在本地测试通过以后，就可以提交到我们平台进行测试啦。在编写脚本的过程中遇到问题，可多查阅api文档，多尝试多调试，好的脚本需要不断的打磨和优化。\n\n后续这个文档会不断更新，记录一些用户的常见问题和解决方法，欢迎大家保持关注。\n\n \n\n \n\n     \n\n    ',0,3,16),(118,'2016-10-08 22:23:32','2016-10-22 19:39:12','&lt;h1&gt;简介&lt;/h1&gt;\n\n&lt;p&gt;深度性能测试能协助测试人员发现APP中存在的深层次性能问题，直接定位多项性能问题及瓶颈的根本原因，方便开发者快速提升APP性能表现，使得APP运行得更加稳定。MQC深度性能测试能够帮助开发者发现深层次的性能问题，更精准地定位问题。&lt;/p&gt;\n\n&lt;p&gt;功能决定现在，性能决定未来！&lt;/p&gt;\n\n&lt;h1&gt;一、内存泄漏&lt;/h1&gt;\n\n&lt;p&gt;内存泄漏是指由于代码编写不当导致不再使用的对象无法得到及时释放。内存泄漏产生的内存垃圾不仅浪费资源，拖慢运行效率，甚至还可能造成内存溢出，直接导致应用崩溃。&lt;/p&gt;\n\n&lt;p&gt;对于Android应用，比较容易发生泄漏的是Activity、Fragment对象，此类对象的共性是其都有一定的生命周期。以Activity为例，一个Activity实例的生命起始于onCreate()，终结于onDestroy()。当一个Activity不再使用时，系统会调用回调方法Activity.onDestroy()方法做一些清理操作。但是对于Activity对象本身所占内存，则完全由虚拟机的垃圾回收器来完成回收。垃圾回收器会检查该实例是否被持有强引用，如果存在指向该对象的强引用，则不会回收其所占内存空间，这块内存空间也就成了内存垃圾。由此可见内存泄漏是由不当的强引用导致的。&lt;/p&gt;\n\n&lt;p&gt;MQC支持对Activity、Fragment对象的内存泄漏检测，检测结果可在性能报告－性能问题模块查看。&lt;/p&gt;\n\n&lt;h2&gt;1.1 对象的引用链&lt;/h2&gt;\n\n&lt;p&gt;从GC ROOT到泄漏对象的引用链能精准地定位导致内存泄漏的原因。对象无法被垃圾回收器回收，一定是由于GC ROOT直接或间接持有了它的强引用。&lt;/p&gt;\n\n&lt;p&gt;常见的GC ROOT有：声明为static的变量，未停止的线程，Application对象，甚至是栈内存中的局部变量。&lt;/p&gt;\n\n&lt;h2&gt;1.2 Android中常见的内存泄露&lt;/h2&gt;\n\n&lt;h3&gt;a. 集合中对象没清理造成的内存泄露&lt;/h3&gt;\n\n&lt;p&gt;编程过程中，我们常常会把一些对象加入到集合中。在我们不再需要该对象时，如果没有及时把它从集合中清理掉，就会导致这个集合占用的内存越来越大。同时如果这个集合是静态的话，那情况就更严重了。如下的代码段中在每次启动Activity的时候都往静态集合中添加了一个对象，如果Activity被频繁启动，set将不断变大，影响APP的正常运行。&lt;/p&gt;\n\n&lt;p&gt;&lt;img src=&quot;/static/res/1a88acd1d74bc1d92146d6d6e0c3ca5e.PNG&quot; style=&quot;height:160px; width:533px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;所以，集合中不再使用的对象应及时释放掉。上述代码应该在Activity的onDestroy()方法中，及时清理set里的元素，避免无用对象继续存在强引用，例如：&lt;/p&gt;\n\n&lt;p&gt;&lt;img src=&quot;/static/res/53ddae99e09cbc6e556210dff6c190c6.PNG&quot; style=&quot;height:100px; width:533px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;这样可以保证set持有的强引用都被释放。&lt;/p&gt;\n\n&lt;h3&gt;b. 单例模式造成的内存泄漏&lt;/h3&gt;\n\n&lt;p&gt;单例的静态特性使得其生命周期可能跟应用的生命周期一样长，如果使用不恰当的话，很容易造成内存泄漏。&lt;/p&gt;\n\n&lt;p&gt;如下代码是一个简单的单例模式实现：&lt;/p&gt;\n\n&lt;p&gt;&lt;img src=&quot;/static/res/367da554d7e07822762b37dcb85e3a6e.PNG&quot; style=&quot;height:260px; width:502px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;在创建单例的时候，如果我们传入当前Activity的Context，例如：&lt;/p&gt;\n\n&lt;p&gt;&lt;img src=&quot;/static/res/3816794e7041f9021fbccfec187e6b99.PNG&quot; style=&quot;height:180px; width:492px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;单例testContextHelper里面一直保存着该Activity的引用，当这个 Context 对应的 Activity 退出时，由于该 Context 的引用一直被单例对象持有，所以该Activity占用的内存并不会被回收，造成泄漏。在使用单例模式时，一定要避免持有短生命周期对象的引用，比如上述代码在引用Context时可以使用Application的Context代替Activity的Context， 即：&lt;/p&gt;\n\n&lt;p&gt;&lt;img src=&quot;/static/res/cd43a435bbbf4124362b151535637e5c.PNG&quot; style=&quot;height:21px; width:537px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;因为Application在应用的运行过程中一直存在，不会退出。&lt;/p&gt;\n\n&lt;h3&gt;c. 非静态内部类创建静态实例造成的内存泄漏&lt;/h3&gt;\n\n&lt;p&gt;在启动频繁的Activity中，为了避免反复创建某些资源，提高加载速度，我们可能会在Activity内部创建一个静态实例，每次启动Activity时都会使用该实例，如下代码：&lt;/p&gt;\n\n&lt;p&gt;&lt;img src=&quot;/static/res/03bf679edf3d72aba0de2c576c5a8e4d.PNG&quot; style=&quot;height:220px; width:499px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;此时Activity内部有一个静态单例，且为非静态内部类的实例。由于非静态内部类默认会持有外部类的引用，并且该类创建了一个静态实例，该实例的生命周期和应用的一样长，这就导致了该静态实例一直会持有该Activity的引用，导致Activity的内存资源不能正常回收。为了避免这一问题，在使用过程中，正确的做法是将内部类设为静态类或者变成单独的类。&lt;/p&gt;\n\n&lt;h3&gt;d. 使用handler时的内存问题&lt;/h3&gt;\n\n&lt;p&gt;在Android应用中，Handler通过发送Message与其他线程交互，发出的Message被存储在目标线程的MessageQueue中的，并且Message不一定马上就被处理，驻留时间可能比较久。比如我们用Handler发送一个延时比较久的Message：&lt;/p&gt;\n\n&lt;p&gt;&lt;img src=&quot;/static/res/7739b21f8c592a4b93de19a28ba1c412.PNG&quot; style=&quot;height:320px; width:466px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;而Message中持有Handler实例的强引用，如果Message在Queue中一直存在，就会导致Handler实例无法被回收，而Handler持有Activity的强引用，Activity对象也不会被回收，这就造成了实例泄露。所以，在创建Handler时，最好使用弱引用来引用目标Activity对象，比如：&lt;/p&gt;\n\n&lt;p&gt;&lt;img src=&quot;/static/res/8afc48a6a8b05cb6d76a2e42b0a2738a.PNG&quot; style=&quot;height:220px; width:483px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;这样可以避免由于Handler持有强引用导致Activity无法回收。&lt;/p&gt;\n\n&lt;h3&gt;e. 静态成员变量造成的内存泄露&lt;/h3&gt;\n\n&lt;p&gt;如果成员变量被声明为 static，其生命周期将与整个应用进程的生命周期一样。如果静态变量直接或间接强引用了某一短生命周期对象(比如Activity)，这会导致即使app切到后台，这部分内存也不会被释放。下面的错误示范代码中，在Activity启动的时候，直接将其引用赋给了静态变量obj，会导致该Activity一直不能被回收，导致内存泄露。&lt;/p&gt;\n\n&lt;p&gt;&lt;img src=&quot;/static/res/e710f5ed6e99411629ae2e889aea80a2.PNG&quot; style=&quot;height:180px; width:386px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;因此，在使用静态变量时，应该避免其持有短生命周期对象的强引用，可以使用弱引用来代替强引用。&lt;/p&gt;\n\n&lt;h3&gt;f. 资源未关闭造成的内存泄漏&lt;/h3&gt;\n\n&lt;p&gt;对于使用了BroadcastReceiver，ContentObserver，File，游标 Cursor，Stream，Bitmap等资源的使用，应该在Activity销毁时及时关闭或者注销，否则这些资源将可能不会被回收，造成内存泄漏。虽然有些系统程序，它本身可以自动取消注册的(非即时)，但是我们还是应该在我们的程序中明确的取消注册，程序结束时应该把所有的注册都取消掉。&lt;/p&gt;\n\n&lt;h2&gt;1.3 MQC提供的内存泄露分析&lt;/h2&gt;\n\n&lt;p&gt;MQC提供的深度性能测试能够帮助您发现并定位发生了内存泄露的地方。当发生内存泄漏时，测试报告中会给出发生泄露的内存大小，泄露类型，发生泄露的对象，以及该对象的引用链等信息，下图是MQC检测到的APP内存泄漏案例。&lt;img src=&quot;/static/res/cbfcdc400e72f1eec7924da30cf911c8.PNG&quot; style=&quot;width:980px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;图中可以看到检测到了两条内存泄漏信息。并指出了泄露内存的大小和对象类型，均为Activity对象泄露。查看引用链得知，APP在ActivityManager里面持有了所有Activity的强引用，最终导致Activity退出后无法回收，属于前述介绍的集合对象使用不当造成的内存泄露。可以看到，MQC提供的内存泄漏分析能直接定位到相关代码，方便您快速修复BUG。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h1&gt;二、&amp;nbsp;内存溢出&lt;/h1&gt;\n\n&lt;p&gt;内存溢出(OOM, Out Of Memory)是指当已存在的对象的占用了绝大部分或者全部分配给该进程的内存空间时，如果进程再申请新的内存空间，由于没有空余内存可用于分配，或可分配的内存不够满足申请者的需求，此时系统就会抛出内存溢出异常。&lt;/p&gt;\n\n&lt;h2&gt;2.1 常见的内存溢出原因&lt;/h2&gt;\n\n&lt;p&gt;很大一部分内存溢出都是由于内存泄露导致，由于已分配的内存被泄露对象占用并且无法释放，随着泄露的对象实例越来越多，导致可用内存越来越少，最终当内存耗尽时，系统就会抛出内存溢出异常。此时只要解决了内存泄露，也就解决了内存溢出。&lt;/p&gt;\n\n&lt;p&gt;另一个内存溢出的重要原因就是应用加载了多个占用内存较多的对象。比如应用在运行过程中加载并保存了多个较大的Bitmap，导致可用内存急剧减少。因此，在代码编写过程中，对于可能占据大量内存空间的对象，我们应该使用软引用或虚引用持有该对象，使得系统GC能在内存吃紧时回收该对象释放空间。并且在不使用Bitmap时，应及时recycle，主动释放内存空间。&lt;/p&gt;\n\n&lt;h2&gt;2.2 MQC提供的内存溢出分析&lt;/h2&gt;\n\n&lt;p&gt;在应用抛出内存溢出时，深度性能测试会主动捕获这一异常，给出抛出该异常的堆栈信息。并分析当前应用进程占用的总内存大小，已分配的内存大小和可用内存大小，方便开发者定位问题。&lt;/p&gt;\n\n&lt;p&gt;如下图，测试报告中首先给出发生内存溢出的机型，同时指出检测到内存溢出时应用自身和设备内存的使用情况，可以看到Native Heap和VM Heap的空余内存都已不多。打开StackTrace后，可以看到出现OOM错误的代码行，由此我们发现可能是在加载Bitmap的时候导致的内存溢出。图中红色箭头所指的地方是应用自身的代码，我们根据这些提示就能够快速找到源文件中出错的代码，立即修复。&lt;img src=&quot;/static/res/d7cfc11916b0c56e7a8b041e2a1574a3.png&quot; style=&quot;width:980px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h1&gt;三、内存抖动&lt;/h1&gt;\n\n&lt;p&gt;内存抖动指的是短时间内大量对象被创建和回收。由于短时间内产生了大量的对象，需要分配大量内存，此时需要垃圾回收器(GC)频繁工作，回收不再使用的对象来腾出内存空间。GC的频繁启动占用了一定的系统资源，最终影响应用表现。&lt;/p&gt;\n\n&lt;h2&gt;3.1 常见的内存抖动&lt;/h2&gt;\n\n&lt;p&gt;常见的内存抖动主要是由于在循环或其他场合中不停地创建新对象，并且短时间内这些对象又被释放。瞬间产生大量的对象会严重占用内存区域，当达到阀值，剩余空间不够的时候触发GC。即使每次分配的对象占用了很少的内存，但是他们叠加在一起会增加Heap的压力。GC启动时会占用CPU等资源，直接导致应用运行受到影响，可能出现界面操作不流畅等现象。&lt;/p&gt;\n\n&lt;h2&gt;3.2 MQC提供的内存抖动分析&lt;/h2&gt;\n\n&lt;p&gt;MQC能够监控系统的每一次GC，并给出GC发生时的内存使用情况，如下图所示。&lt;img src=&quot;/static/res/c563b3f2c402c7a403c4a7d9ba09da56.PNG&quot; style=&quot;width:980px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;图中给出了3种GC发生的时刻和内存变化的曲线图。3种GC分别为：&lt;/p&gt;\n\n&lt;p&gt;GC_EXPLICIT：应用主动调用System.gc()产生的GC事件&lt;/p&gt;\n\n&lt;p&gt;GC_FOR_ALLOC：内存分配时，发现可用内存不够时触发的GC事件&lt;/p&gt;\n\n&lt;p&gt;GC_CONCURRENT：已分配的内存大小达到某一阈值时会触发的GC事件&lt;/p&gt;\n\n&lt;p&gt;其中后两种是系统自己决定启动的GC，应用无法控制。但是我们可以优化代码，避免频繁生成和回收对象，比如不要在循环中频繁new新的对象。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h1&gt;四、界面卡顿&lt;/h1&gt;\n\n&lt;p&gt;界面卡顿指的是短时间内界面对用户操作没有响应。应用在出现卡顿的时候，就算知道是哪个页面出了问题，但是很难定位到具体的代码。应用卡顿检测就是帮助您快速定位卡顿的具体位置，方便您进行针对性的修复。&lt;/p&gt;\n\n&lt;h2&gt;4.1 常见的界面卡顿原因&lt;/h2&gt;\n\n&lt;p&gt;Android应用的UI绘制和用户操作消息分发都发生在应用主线程，如果主线程来不及处理UI更新和响应用户操作，用户就会感觉应用发生了卡顿。因此卡顿发生时尝尝伴随着主线程阻塞。如果在主线程中进行磁盘读写、网络操作或者大量计算时，尝尝会导致主线程被阻塞，发生界面卡顿。&lt;/p&gt;\n\n&lt;h2&gt;4.2 MQC提供的界面卡顿分析&lt;img src=&quot;/static/res/25a49fc547f2c3a085fa33f8d5a46db2.JPG&quot; style=&quot;width:980px&quot; /&gt;&lt;/h2&gt;\n\n&lt;p&gt;如上图所示，在应用运行过程中出现卡顿时，MQC会记录当前卡顿的时长，例如图中为1935 ms，用于给开发者评估本次卡顿的严重性，随后给出发生卡顿时系统CPU和内存的使用情况等信息辅助开发者分析问题。也会给出卡顿发生时的应用调用的完整堆栈，用于定位发生卡顿的代码，MQC同时归纳出具体的关键代码，免去开发者在大量堆栈中寻找关键行的麻烦。&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h1&gt;五、过度绘制&lt;/h1&gt;\n\n&lt;p&gt;过度绘制一般指的是屏幕上的某些区域在一帧中被多次绘制，一般是在界面的同一个地方叠加了多个控件。这样会加重GPU的工作负担，可能导致应用运行过程中频繁掉帧，影响用户体验。&lt;/p&gt;\n\n&lt;h2&gt;5.1 过度绘制详细介绍&lt;/h2&gt;\n\n&lt;p&gt;当手机开启过度绘制时，屏幕上会标记发生过度绘制的区域，并根据不同的绘制次数使用不同的颜色，颜色标识从好到差依次是：蓝色-绿色-淡红色-红色，分别代表该区域被绘制1次、2次、3次和4次。一般情况下，最好把绘制控制在2次以下，3次绘制有时候是不能避免的，尽量避免，4次的绘制基本上是不允许的。&lt;/p&gt;\n\n&lt;p&gt;为了减少过度绘制，开发者应减少复杂的、层级较多的布局，去掉多余的背景色。简单的界面尽量使用线性布局；较为复杂的界面可以使用相对布局，避免嵌套过多的线性布局。可以使用ViewStub来动态加载界面。&lt;/p&gt;\n\n&lt;h2&gt;5.2 MQC提供的过度绘制分析&lt;/h2&gt;\n\n&lt;p&gt;MQC实时监测界面的过度绘制指数，该指数大于1.5时，MQC认为该界面可能需要优化。最终，测试报告显示过度绘制指数大于1.5的界面截图，并告诉开发者该界面对应的Activity，给出过度绘制指数的具体数值。下图展示了两个Activity的信息，过度绘制指数分别为1.85和1.48，并给出了对应的截图。&lt;img src=&quot;/static/res/41d5fcc1e9e5f1d2a46bee383592e9bc.PNG&quot; style=&quot;width:980px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h1&gt;六、启动分析&lt;/h1&gt;\n\n&lt;p&gt;启动分析通过分析应用启动过程产生的trace文件来得到应用的启动时间等信息。通常来说，Android应用的启动方式分为两种：冷启动和热启动。&lt;/p&gt;\n\n&lt;p&gt;冷启动：当启动应用时，后台没有该应用的进程，此时系统会创建一个新的进程分配给该应用。冷启动因为系统会创建一个新的进程分配给它，所以会先创建和初始化Application类，随后创建和初始化MainActivity类（包括一系列的测量、布局、绘制），最后显示在界面上。&lt;/p&gt;\n\n&lt;p&gt;热启动：当启动应用时，后台已有该应用的进程（例：按back键、home键，应用虽然会退出，但是该应用的进程是依然会保留在后台，可进入任务列表查看），这种启动会从已有的进程中来启动应用。热启动因为会从已有的进程中来启动，所以热启动就不会创建新的Application，而是直接创建和初始化MainActivity，而不必创建和初始化Application，因为一个应用从新进程的创建到进程的销毁，Application只会初始化一次。一般来讲，热启动时间都会在一定程度上小于冷启动时间。&lt;/p&gt;\n\n&lt;p&gt;MQC会分析应用的冷启动时间和热启动时间，给开发者作为参考。包括耗时方法定位等更详细的启动分析即将发布。&lt;img src=&quot;/static/res/4b0d67ec04d2da1b059540f313145379.PNG&quot; style=&quot;width:980px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h1&gt;七、严苛模式(StrictMode)&lt;/h1&gt;\n\n&lt;p&gt;严苛模式(StrictMode)是一个开发辅助工具，可以帮助开发者发现那些由于编码过程中不注意而造成的问题。&lt;/p&gt;\n\n&lt;h2&gt;7.1严苛模式的详细介绍&lt;/h2&gt;\n\n&lt;p&gt;StrictMode经常用于捕获那些在应用主线程中进行的磁盘读写操作和网络请求。由于应用主线程是接收UI操作消息和执行界面渲染的地方，为了使应用运行更加流畅和更快响应，请尽量不要在主线程执行磁盘操作和网络请求。当然，这也是避免系统弹出ANR对话框和提高应用稳定性的好方法。一旦检测到违反策略(policy violation)，系统将会输出一条相关的日志，其一般包含一个调用栈，来显示应用在何处发生违例。&lt;/p&gt;\n\n&lt;p&gt;注意：尽管Android设备的磁盘一般都是闪存盘，然而实际中很多设备只能以很有限的并发数来操作文件系统。虽然磁盘读写很快，但是具体过程中可能由于其他进程占用了I/O接口，等待的过程会导致整个磁盘操作流程比较慢。如果可以，请尽量假设磁盘读写是一个比较耗时的操作。&lt;/p&gt;\n\n&lt;p&gt;StricMode除了可以检测主线程的磁盘操作和网络请求以外，还可以发现主线程中执行时间较长的方法。当应用中有继承了Closeable接口的对象没有关闭的时候，例如文件流等，或者没有使用HTTPS进行网络请求，或者同一个Activity的实例太多，StrictMode都会给出提示。其能发现的错误主要包括：&lt;/p&gt;\n\n&lt;p&gt;a. 应用在主线程中进行磁盘读写；&lt;/p&gt;\n\n&lt;p&gt;b. 应用在主线程中进行网络请求；&lt;/p&gt;\n\n&lt;p&gt;c. 应用在主线程中的某些自定义方法的执行时间比较长；&lt;/p&gt;\n\n&lt;p&gt;d. SQL Cursor对象在使用之后没有关闭；&lt;/p&gt;\n\n&lt;p&gt;e. 继承了Closeable接口的对象在使用之后没有关闭；&lt;/p&gt;\n\n&lt;p&gt;f. 某一Activity有较多的实例；&lt;/p&gt;\n\n&lt;p&gt;g. 文件读取接口暴露给外部应用；&lt;/p&gt;\n\n&lt;p&gt;h. 注册某些对象(广播接收器、观察者、Listener等)后没有取消注册；&lt;/p&gt;\n\n&lt;p&gt;i. 没有使用加密网络(HTTPS)进行网络数据传输。&lt;/p&gt;\n\n&lt;h2&gt;7.2 MQC提供的严苛模式检测&lt;/h2&gt;\n\n&lt;p&gt;在MQC深度性能测试检测到您的应用存在违反上述要求的时候，MQC首先会指出应用违反了哪些严苛模式的策略，随后分析问题发生时的应用堆栈信息，指出问题出现在哪儿，并统计该问题出现了多少次。针对在检测到的主线程操作(例如出现主线程磁盘操作，主线程网络操作等)时，还会给出该操作的持续时间等信息，辅助开发者评估问题的严重程度。&lt;img src=&quot;/static/res/f25181f0b2dc09fd0e6b60a40f6eaf36.JPG&quot; style=&quot;width:980px&quot; /&gt;&lt;/p&gt;\n\n&lt;p&gt;上图显示MQC检测到应用中存在主线程IO的情况，具体是在主线程中进行了文件读取操作，最长的一次持续了2356毫秒，测试过程中一共出现了62次磁盘读取操作。根据后面的堆栈信息，可以看到com.stephen.performance.MainActivity类里面的readFile方法是在主线程中执行的，因此这里我们就可以针对这一信息来进行修改。&lt;/p&gt;','深度性能测试','末非','简介\n\n深度性能测试能协助测试人员发现APP中存在的深层次性能问题，直接定位多项性能问题及瓶颈的根本原因，方便开发者快速提升APP性能表现，使得APP运行得更加稳定。MQC深度性能测试能够帮助开发者发现深层次的性能问题，更精准地定位问题。\n\n功能决定现在，性能决定未来！\n\n一、内存泄漏\n\n内存泄漏是指由于代码编写不当导致不再使用的对象无法得到及时释放。内存泄漏产生的内存垃圾不仅浪费资源，拖慢运行效率，甚至还可能造成内存溢出，直接导致应用崩溃。\n\n对于Android应用，比较容易发生泄漏的是Activity、Fragment对象，此类对象的共性是其都有一定的生命周期。以Activity为例，一个Activity实例的生命起始于onCreate()，终结于onDestroy()。当一个Activity不再使用时，系统会调用回调方法Activity.onDestroy()方法做一些清理操作。但是对于Activity对象本身所占内存，则完全由虚拟机的垃圾回收器来完成回收。垃圾回收器会检查该实例是否被持有强引用，如果存在指向该对象的强引用，则不会回收其所占内存空间，这块内存空间也就成了内存垃圾。由此可见内存泄漏是由不当的强引用导致的。\n\nMQC支持对Activity、Fragment对象的内存泄漏检测，检测结果可在性能报告－性能问题模块查看。\n\n1.1 对象的引用链\n\n从GC ROOT到泄漏对象的引用链能精准地定位导致内存泄漏的原因。对象无法被垃圾回收器回收，一定是由于GC ROOT直接或间接持有了它的强引用。\n\n常见的GC ROOT有：声明为static的变量，未停止的线程，Application对象，甚至是栈内存中的局部变量。\n\n1.2 Android中常见的内存泄露\n\na. 集合中对象没清理造成的内存泄露\n\n编程过程中，我们常常会把一些对象加入到集合中。在我们不再需要该对象时，如果没有及时把它从集合中清理掉，就会导致这个集合占用的内存越来越大。同时如果这个集合是静态的话，那情况就更严重了。如下的代码段中在每次启动Activity的时候都往静态集合中添加了一个对象，如果Activity被频繁启动，set将不断变大，影响APP的正常运行。\n\n\n\n所以，集合中不再使用的对象应及时释放掉。上述代码应该在Activity的onDestroy()方法中，及时清理set里的元素，避免无用对象继续存在强引用，例如：\n\n\n\n这样可以保证set持有的强引用都被释放。\n\nb. 单例模式造成的内存泄漏\n\n单例的静态特性使得其生命周期可能跟应用的生命周期一样长，如果使用不恰当的话，很容易造成内存泄漏。\n\n如下代码是一个简单的单例模式实现：\n\n\n\n在创建单例的时候，如果我们传入当前Activity的Context，例如：\n\n\n\n单例testContextHelper里面一直保存着该Activity的引用，当这个 Context 对应的 Activity 退出时，由于该 Context 的引用一直被单例对象持有，所以该Activity占用的内存并不会被回收，造成泄漏。在使用单例模式时，一定要避免持有短生命周期对象的引用，比如上述代码在引用Context时可以使用Application的Context代替Activity的Context， 即：\n\n\n\n因为Application在应用的运行过程中一直存在，不会退出。\n\nc. 非静态内部类创建静态实例造成的内存泄漏\n\n在启动频繁的Activity中，为了避免反复创建某些资源，提高加载速度，我们可能会在Activity内部创建一个静态实例，每次启动Activity时都会使用该实例，如下代码：\n\n\n\n此时Activity内部有一个静态单例，且为非静态内部类的实例。由于非静态内部类默认会持有外部类的引用，并且该类创建了一个静态实例，该实例的生命周期和应用的一样长，这就导致了该静态实例一直会持有该Activity的引用，导致Activity的内存资源不能正常回收。为了避免这一问题，在使用过程中，正确的做法是将内部类设为静态类或者变成单独的类。\n\nd. 使用handler时的内存问题\n\n在Android应用中，Handler通过发送Message与其他线程交互，发出的Message被存储在目标线程的MessageQueue中的，并且Message不一定马上就被处理，驻留时间可能比较久。比如我们用Handler发送一个延时比较久的Message：\n\n\n\n而Message中持有Handler实例的强引用，如果Message在Queue中一直存在，就会导致Handler实例无法被回收，而Handler持有Activity的强引用，Activity对象也不会被回收，这就造成了实例泄露。所以，在创建Handler时，最好使用弱引用来引用目标Activity对象，比如：\n\n\n\n这样可以避免由于Handler持有强引用导致Activity无法回收。\n\ne. 静态成员变量造成的内存泄露\n\n如果成员变量被声明为 static，其生命周期将与整个应用进程的生命周期一样。如果静态变量直接或间接强引用了某一短生命周期对象(比如Activity)，这会导致即使app切到后台，这部分内存也不会被释放。下面的错误示范代码中，在Activity启动的时候，直接将其引用赋给了静态变量obj，会导致该Activity一直不能被回收，导致内存泄露。\n\n\n\n因此，在使用静态变量时，应该避免其持有短生命周期对象的强引用，可以使用弱引用来代替强引用。\n\nf. 资源未关闭造成的内存泄漏\n\n对于使用了BroadcastReceiver，ContentObserver，File，游标 Cursor，Stream，Bitmap等资源的使用，应该在Activity销毁时及时关闭或者注销，否则这些资源将可能不会被回收，造成内存泄漏。虽然有些系统程序，它本身可以自动取消注册的(非即时)，但是我们还是应该在我们的程序中明确的取消注册，程序结束时应该把所有的注册都取消掉。\n\n1.3 MQC提供的内存泄露分析\n\nMQC提供的深度性能测试能够帮助您发现并定位发生了内存泄露的地方。当发生内存泄漏时，测试报告中会给出发生泄露的内存大小，泄露类型，发生泄露的对象，以及该对象的引用链等信息，下图是MQC检测到的APP内存泄漏案例。\n\n图中可以看到检测到了两条内存泄漏信息。并指出了泄露内存的大小和对象类型，均为Activity对象泄露。查看引用链得知，APP在ActivityManager里面持有了所有Activity的强引用，最终导致Activity退出后无法回收，属于前述介绍的集合对象使用不当造成的内存泄露。可以看到，MQC提供的内存泄漏分析能直接定位到相关代码，方便您快速修复BUG。\n\n \n\n二、 内存溢出\n\n内存溢出(OOM, Out Of Memory)是指当已存在的对象的占用了绝大部分或者全部分配给该进程的内存空间时，如果进程再申请新的内存空间，由于没有空余内存可用于分配，或可分配的内存不够满足申请者的需求，此时系统就会抛出内存溢出异常。\n\n2.1 常见的内存溢出原因\n\n很大一部分内存溢出都是由于内存泄露导致，由于已分配的内存被泄露对象占用并且无法释放，随着泄露的对象实例越来越多，导致可用内存越来越少，最终当内存耗尽时，系统就会抛出内存溢出异常。此时只要解决了内存泄露，也就解决了内存溢出。\n\n另一个内存溢出的重要原因就是应用加载了多个占用内存较多的对象。比如应用在运行过程中加载并保存了多个较大的Bitmap，导致可用内存急剧减少。因此，在代码编写过程中，对于可能占据大量内存空间的对象，我们应该使用软引用或虚引用持有该对象，使得系统GC能在内存吃紧时回收该对象释放空间。并且在不使用Bitmap时，应及时recycle，主动释放内存空间。\n\n2.2 MQC提供的内存溢出分析\n\n在应用抛出内存溢出时，深度性能测试会主动捕获这一异常，给出抛出该异常的堆栈信息。并分析当前应用进程占用的总内存大小，已分配的内存大小和可用内存大小，方便开发者定位问题。\n\n如下图，测试报告中首先给出发生内存溢出的机型，同时指出检测到内存溢出时应用自身和设备内存的使用情况，可以看到Native Heap和VM Heap的空余内存都已不多。打开StackTrace后，可以看到出现OOM错误的代码行，由此我们发现可能是在加载Bitmap的时候导致的内存溢出。图中红色箭头所指的地方是应用自身的代码，我们根据这些提示就能够快速找到源文件中出错的代码，立即修复。\n\n \n\n三、内存抖动\n\n内存抖动指的是短时间内大量对象被创建和回收。由于短时间内产生了大量的对象，需要分配大量内存，此时需要垃圾回收器(GC)频繁工作，回收不再使用的对象来腾出内存空间。GC的频繁启动占用了一定的系统资源，最终影响应用表现。\n\n3.1 常见的内存抖动\n\n常见的内存抖动主要是由于在循环或其他场合中不停地创建新对象，并且短时间内这些对象又被释放。瞬间产生大量的对象会严重占用内存区域，当达到阀值，剩余空间不够的时候触发GC。即使每次分配的对象占用了很少的内存，但是他们叠加在一起会增加Heap的压力。GC启动时会占用CPU等资源，直接导致应用运行受到影响，可能出现界面操作不流畅等现象。\n\n3.2 MQC提供的内存抖动分析\n\nMQC能够监控系统的每一次GC，并给出GC发生时的内存使用情况，如下图所示。\n\n图中给出了3种GC发生的时刻和内存变化的曲线图。3种GC分别为：\n\nGC_EXPLICIT：应用主动调用System.gc()产生的GC事件\n\nGC_FOR_ALLOC：内存分配时，发现可用内存不够时触发的GC事件\n\nGC_CONCURRENT：已分配的内存大小达到某一阈值时会触发的GC事件\n\n其中后两种是系统自己决定启动的GC，应用无法控制。但是我们可以优化代码，避免频繁生成和回收对象，比如不要在循环中频繁new新的对象。\n\n \n\n四、界面卡顿\n\n界面卡顿指的是短时间内界面对用户操作没有响应。应用在出现卡顿的时候，就算知道是哪个页面出了问题，但是很难定位到具体的代码。应用卡顿检测就是帮助您快速定位卡顿的具体位置，方便您进行针对性的修复。\n\n4.1 常见的界面卡顿原因\n\nAndroid应用的UI绘制和用户操作消息分发都发生在应用主线程，如果主线程来不及处理UI更新和响应用户操作，用户就会感觉应用发生了卡顿。因此卡顿发生时尝尝伴随着主线程阻塞。如果在主线程中进行磁盘读写、网络操作或者大量计算时，尝尝会导致主线程被阻塞，发生界面卡顿。\n\n4.2 MQC提供的界面卡顿分析\n\n如上图所示，在应用运行过程中出现卡顿时，MQC会记录当前卡顿的时长，例如图中为1935 ms，用于给开发者评估本次卡顿的严重性，随后给出发生卡顿时系统CPU和内存的使用情况等信息辅助开发者分析问题。也会给出卡顿发生时的应用调用的完整堆栈，用于定位发生卡顿的代码，MQC同时归纳出具体的关键代码，免去开发者在大量堆栈中寻找关键行的麻烦。\n\n \n\n五、过度绘制\n\n过度绘制一般指的是屏幕上的某些区域在一帧中被多次绘制，一般是在界面的同一个地方叠加了多个控件。这样会加重GPU的工作负担，可能导致应用运行过程中频繁掉帧，影响用户体验。\n\n5.1 过度绘制详细介绍\n\n当手机开启过度绘制时，屏幕上会标记发生过度绘制的区域，并根据不同的绘制次数使用不同的颜色，颜色标识从好到差依次是：蓝色-绿色-淡红色-红色，分别代表该区域被绘制1次、2次、3次和4次。一般情况下，最好把绘制控制在2次以下，3次绘制有时候是不能避免的，尽量避免，4次的绘制基本上是不允许的。\n\n为了减少过度绘制，开发者应减少复杂的、层级较多的布局，去掉多余的背景色。简单的界面尽量使用线性布局；较为复杂的界面可以使用相对布局，避免嵌套过多的线性布局。可以使用ViewStub来动态加载界面。\n\n5.2 MQC提供的过度绘制分析\n\nMQC实时监测界面的过度绘制指数，该指数大于1.5时，MQC认为该界面可能需要优化。最终，测试报告显示过度绘制指数大于1.5的界面截图，并告诉开发者该界面对应的Activity，给出过度绘制指数的具体数值。下图展示了两个Activity的信息，过度绘制指数分别为1.85和1.48，并给出了对应的截图。\n\n \n\n六、启动分析\n\n启动分析通过分析应用启动过程产生的trace文件来得到应用的启动时间等信息。通常来说，Android应用的启动方式分为两种：冷启动和热启动。\n\n冷启动：当启动应用时，后台没有该应用的进程，此时系统会创建一个新的进程分配给该应用。冷启动因为系统会创建一个新的进程分配给它，所以会先创建和初始化Application类，随后创建和初始化MainActivity类（包括一系列的测量、布局、绘制），最后显示在界面上。\n\n热启动：当启动应用时，后台已有该应用的进程（例：按back键、home键，应用虽然会退出，但是该应用的进程是依然会保留在后台，可进入任务列表查看），这种启动会从已有的进程中来启动应用。热启动因为会从已有的进程中来启动，所以热启动就不会创建新的Application，而是直接创建和初始化MainActivity，而不必创建和初始化Application，因为一个应用从新进程的创建到进程的销毁，Application只会初始化一次。一般来讲，热启动时间都会在一定程度上小于冷启动时间。\n\nMQC会分析应用的冷启动时间和热启动时间，给开发者作为参考。包括耗时方法定位等更详细的启动分析即将发布。\n\n \n\n七、严苛模式(StrictMode)\n\n严苛模式(StrictMode)是一个开发辅助工具，可以帮助开发者发现那些由于编码过程中不注意而造成的问题。\n\n7.1严苛模式的详细介绍\n\nStrictMode经常用于捕获那些在应用主线程中进行的磁盘读写操作和网络请求。由于应用主线程是接收UI操作消息和执行界面渲染的地方，为了使应用运行更加流畅和更快响应，请尽量不要在主线程执行磁盘操作和网络请求。当然，这也是避免系统弹出ANR对话框和提高应用稳定性的好方法。一旦检测到违反策略(policy violation)，系统将会输出一条相关的日志，其一般包含一个调用栈，来显示应用在何处发生违例。\n\n注意：尽管Android设备的磁盘一般都是闪存盘，然而实际中很多设备只能以很有限的并发数来操作文件系统。虽然磁盘读写很快，但是具体过程中可能由于其他进程占用了I/O接口，等待的过程会导致整个磁盘操作流程比较慢。如果可以，请尽量假设磁盘读写是一个比较耗时的操作。\n\nStricMode除了可以检测主线程的磁盘操作和网络请求以外，还可以发现主线程中执行时间较长的方法。当应用中有继承了Closeable接口的对象没有关闭的时候，例如文件流等，或者没有使用HTTPS进行网络请求，或者同一个Activity的实例太多，StrictMode都会给出提示。其能发现的错误主要包括：\n\na. 应用在主线程中进行磁盘读写；\n\nb. 应用在主线程中进行网络请求；\n\nc. 应用在主线程中的某些自定义方法的执行时间比较长；\n\nd. SQL Cursor对象在使用之后没有关闭；\n\ne. 继承了Closeable接口的对象在使用之后没有关闭；\n\nf. 某一Activity有较多的实例；\n\ng. 文件读取接口暴露给外部应用；\n\nh. 注册某些对象(广播接收器、观察者、Listener等)后没有取消注册；\n\ni. 没有使用加密网络(HTTPS)进行网络数据传输。\n\n7.2 MQC提供的严苛模式检测\n\n在MQC深度性能测试检测到您的应用存在违反上述要求的时候，MQC首先会指出应用违反了哪些严苛模式的策略，随后分析问题发生时的应用堆栈信息，指出问题出现在哪儿，并统计该问题出现了多少次。针对在检测到的主线程操作(例如出现主线程磁盘操作，主线程网络操作等)时，还会给出该操作的持续时间等信息，辅助开发者评估问题的严重程度。\n\n上图显示MQC检测到应用中存在主线程IO的情况，具体是在主线程中进行了文件读取操作，最长的一次持续了2356毫秒，测试过程中一共出现了62次磁盘读取操作。根据后面的堆栈信息，可以看到com.stephen.performance.MainActivity类里面的readFile方法是在主线程中执行的，因此这里我们就可以针对这一信息来进行修改。',0,61,3),(125,'2016-11-03 16:35:38','2016-11-03 16:35:38','&lt;h2&gt;FAQ：&lt;/h2&gt;\n\n&lt;p&gt;Q：MQC客户端依赖我主机上的其它软件吗？&lt;/p&gt;\n\n&lt;p&gt;A：如果仅仅是共享设备给MQC，不依赖于您电脑的任何软件。 如果您是专业的测试人员，需要使用MQC的测试能力，如在线录制和远程调试，对于安卓设备，需要安装好安卓开发环境，设置相应的环境变量。对于iOS设备，目前只有OSX系统支持，需要安装Xcode软件。特别的，如果需要获得测试手机的实时视频，需要安装ffmpeg软件来压制视频文件。&lt;/p&gt;\n\n&lt;p&gt;Q：&amp;ldquo;共享设备&amp;rdquo;页面里面找不到任何设备，什么原因？&lt;/p&gt;\n\n&lt;p&gt;A：插入您的手机，需打开USB调试模式，然后点击刷新按键。如果还是没有设备，可加入我们的官方QQ群：492028798。我们值班的同学会帮助您解决。&lt;/p&gt;\n\n&lt;p&gt;Q：执行任务中弹窗提示设备异常？该怎么解决！&lt;/p&gt;\n\n&lt;p&gt;A：设备异常可能是多方面原因导致。常见几种原因及解决方法如下：&lt;/p&gt;\n\n&lt;p&gt;（1）安装失败：请查看手机是否设置复杂锁屏，以及手机的安全软件是否弹窗阻止任务的执行，请关闭手机的安全软件。&lt;/p&gt;\n\n&lt;p&gt;（2）DEVICE_ERROR：请查看手机是否正常连接，MQC客户端是否正常运行。可尝试重启手机、恢复出厂设置、重启MQC客户端。&lt;/p&gt;\n\n&lt;p&gt;（3）ABNORMAL：请查看手机是否正常连接，可尝试重启插拔手机、重启MQC客户端。&lt;/p&gt;\n\n&lt;p&gt;（4）TIMEOUT：请查看手机是否正常连接，MQC是否正常运行。可尝试重启MQC客户端。&lt;/p&gt;\n\n&lt;p&gt;（5）安卓手机长时间开机运行可能会导致不可预知的错误，故长时间运行手机及MQC客户端后，保持重启手机和MQC客户端的好习惯。&lt;/p&gt;\n\n&lt;p&gt;（6）其他问题：可加入MQC官方QQ答疑群492028798。会有专人联系您解决问题！&lt;/p&gt;\n\n&lt;p&gt;Q：&amp;ldquo;共享设备&amp;rdquo;后就能立即挣钱吗？&lt;/p&gt;\n\n&lt;p&gt;A：点击&amp;ldquo;共享设备&amp;rdquo;后，需同意&amp;ldquo;设备接入协议&amp;rdquo;并补充设备信息。然后MQC会在一个工作日内对您的设备进行审核，审核通过后才能有执行任务来挣钱的资格。所以一定要同意协议和补充设备信息哦！&lt;/p&gt;\n\n&lt;p&gt;Q：&amp;ldquo;审核中&amp;rdquo;后能断开设备吗？&lt;/p&gt;\n\n&lt;p&gt;A：审核中可以断开设备，不影响审核，下次接入自动更新。&amp;nbsp;&lt;/p&gt;\n\n&lt;p&gt;Q：执行任务需要手动领取任务吗？执行任务中手机能做其他操作吗？&lt;/p&gt;\n\n&lt;p&gt;A：不需要手动领取任务，只需保持手机非锁屏常亮状态即可，MQC会自动下发任务执行。 &amp;nbsp;执行任务过程中，手机不能做其他操作，否则会影响任务的执行，影响奖励哦！&lt;/p&gt;\n\n&lt;p&gt;Q：如何提高设备审核通过的概率和执行任务的概率？&lt;/p&gt;\n\n&lt;p&gt;A：一般来说，只要是正常的Android设备，同意协议和补充设备信息后，MQC都会审核通过。但执行任务的概率取决于您设备的稀缺程度，如果是比较主流的机器，执行到任务的概率会大很多，而且得到的奖励也会多一些。&lt;/p&gt;\n\n&lt;p&gt;Q：挣取的现金如何提现？&lt;/p&gt;\n\n&lt;p&gt;A：从MQC客户端争取的现金是可以在&lt;a href=&quot;https://mqc.aliyun.com/crowdtest/userAccount.htm&quot;&gt;个人中心&lt;/a&gt;查看并申请提现的。&lt;/p&gt;\n\n&lt;p&gt;Q：接入后每天执行的任务量可以保证吗？&lt;/p&gt;\n\n&lt;p&gt;A：您设备的任务量取决于您设备的款型和提交任务的数量。MQC正处于快速发展的阶段，每天任务的执行量是非常可观的，一般工作日任务量较多，节假日和周末会少一些。&lt;/p&gt;\n\n&lt;p&gt;Q：除了通过共享设备来挣钱，还有其他方式吗？&lt;/p&gt;\n\n&lt;p&gt;A：有！您可以在MQC的&lt;a href=&quot;https://mqc.aliyun.com/crowdtest/task_square.htm&quot;&gt;众测广场&lt;/a&gt;来领取测试任务来挣取现金和积分。积分还可以用来&lt;a href=&quot;https://mqc.aliyun.com/crowdtest/gift_center.htm&quot;&gt;兑换奖品&lt;/a&gt;哦！&lt;/p&gt;','常见问题','MQC','FAQ：\n\nQ：MQC客户端依赖我主机上的其它软件吗？\n\nA：如果仅仅是共享设备给MQC，不依赖于您电脑的任何软件。 如果您是专业的测试人员，需要使用MQC的测试能力，如在线录制和远程调试，对于安卓设备，需要安装好安卓开发环境，设置相应的环境变量。对于iOS设备，目前只有OSX系统支持，需要安装Xcode软件。特别的，如果需要获得测试手机的实时视频，需要安装ffmpeg软件来压制视频文件。\n\nQ：“共享设备”页面里面找不到任何设备，什么原因？\n\nA：插入您的手机，需打开USB调试模式，然后点击刷新按键。如果还是没有设备，可加入我们的官方QQ群：492028798。我们值班的同学会帮助您解决。\n\nQ：执行任务中弹窗提示设备异常？该怎么解决！\n\nA：设备异常可能是多方面原因导致。常见几种原因及解决方法如下：\n\n（1）安装失败：请查看手机是否设置复杂锁屏，以及手机的安全软件是否弹窗阻止任务的执行，请关闭手机的安全软件。\n\n（2）DEVICE_ERROR：请查看手机是否正常连接，MQC客户端是否正常运行。可尝试重启手机、恢复出厂设置、重启MQC客户端。\n\n（3）ABNORMAL：请查看手机是否正常连接，可尝试重启插拔手机、重启MQC客户端。\n\n（4）TIMEOUT：请查看手机是否正常连接，MQC是否正常运行。可尝试重启MQC客户端。\n\n（5）安卓手机长时间开机运行可能会导致不可预知的错误，故长时间运行手机及MQC客户端后，保持重启手机和MQC客户端的好习惯。\n\n（6）其他问题：可加入MQC官方QQ答疑群492028798。会有专人联系您解决问题！\n\nQ：“共享设备”后就能立即挣钱吗？\n\nA：点击“共享设备”后，需同意“设备接入协议”并补充设备信息。然后MQC会在一个工作日内对您的设备进行审核，审核通过后才能有执行任务来挣钱的资格。所以一定要同意协议和补充设备信息哦！\n\nQ：“审核中”后能断开设备吗？\n\nA：审核中可以断开设备，不影响审核，下次接入自动更新。 \n\nQ：执行任务需要手动领取任务吗？执行任务中手机能做其他操作吗？\n\nA：不需要手动领取任务，只需保持手机非锁屏常亮状态即可，MQC会自动下发任务执行。  执行任务过程中，手机不能做其他操作，否则会影响任务的执行，影响奖励哦！\n\nQ：如何提高设备审核通过的概率和执行任务的概率？\n\nA：一般来说，只要是正常的Android设备，同意协议和补充设备信息后，MQC都会审核通过。但执行任务的概率取决于您设备的稀缺程度，如果是比较主流的机器，执行到任务的概率会大很多，而且得到的奖励也会多一些。\n\nQ：挣取的现金如何提现？\n\nA：从MQC客户端争取的现金是可以在个人中心查看并申请提现的。\n\nQ：接入后每天执行的任务量可以保证吗？\n\nA：您设备的任务量取决于您设备的款型和提交任务的数量。MQC正处于快速发展的阶段，每天任务的执行量是非常可观的，一般工作日任务量较多，节假日和周末会少一些。\n\nQ：除了通过共享设备来挣钱，还有其他方式吗？\n\nA：有！您可以在MQC的众测广场来领取测试任务来挣取现金和积分。积分还可以用来兑换奖品哦！',0,114,4),(126,'2016-12-05 15:43:10','2016-12-15 17:36:24','&lt;h2&gt;1.上传脚本总是提示脚本不合法。&lt;/h2&gt;\n\n&lt;p&gt;上传脚本前，请检查脚本中是否使用了包含有以下关键字的包：&lt;/p&gt;\n\n&lt;p&gt;subprocess, os, sys, pexpect, fabric, sh, commands, plumbum, shell_command。&lt;/p&gt;\n\n&lt;p&gt;目前 MQC 功能测试不能提交此类脚本。&lt;/p&gt;\n\n&lt;h2&gt;&amp;nbsp;&lt;/h2&gt;\n\n&lt;h2&gt;2.Appium 报错 Error: %nowActivity%&amp;nbsp;never&amp;nbsp;started.&amp;nbsp;Current: %currentActivity%&lt;/h2&gt;\n\n&lt;p&gt;capabilities 中添加 appWaitActivity: %currentActivity%&lt;/p&gt;\n\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\n&lt;h2&gt;3.Appium 报错&amp;nbsp;Unable to findElement by id&lt;/h2&gt;\n\n&lt;p&gt;find_element_by_id 不支持 4.3 及 4.3 以下版本，参考&amp;nbsp;&lt;a href=&quot;https://github.com/appium/appium/issues/2340&quot;&gt;https://github.com/appium/appium/issues/2340&lt;/a&gt;&lt;/p&gt;','功能测试FAQ','mts','1.上传脚本总是提示脚本不合法。\n\n上传脚本前，请检查脚本中是否使用了包含有以下关键字的包：\n\nsubprocess, os, sys, pexpect, fabric, sh, commands, plumbum, shell_command。\n\n目前 MQC 功能测试不能提交此类脚本。\n\n \n\n2.Appium 报错 Error: %nowActivity% never started. Current: %currentActivity%\n\ncapabilities 中添加 appWaitActivity: %currentActivity%\n\n \n\n3.Appium 报错 Unable to findElement by id\n\nfind_element_by_id 不支持 4.3 及 4.3 以下版本，参考 https://github.com/appium/appium/issues/2340',0,4,8),(129,'2016-12-15 17:41:56','2016-12-28 11:22:22','&lt;p&gt;本章介绍了使用Appium对iOS 10设备进行功能测试的方法。在开始前，您可以先&lt;a href=&quot;/static/res/ios_appium_demo.zip&quot;&gt;下载本章的测试App和示例脚本&lt;/a&gt;。&lt;/p&gt;\n\n&lt;h2&gt;1. 配置环境&lt;/h2&gt;\n\n&lt;p&gt;iOS 10测试的环境要求：&lt;/p&gt;\n\n&lt;p&gt;a. macOS 10.11.5及以上&lt;/p&gt;\n\n&lt;p&gt;b. Xcode 8.0及以上&lt;/p&gt;\n\n&lt;p&gt;c. Appium 1.6.0及以上&lt;/p&gt;\n\n&lt;p&gt;我们使用Appium对iOS 10及以上的设备进行功能测试。您可以查看&lt;a href=&quot;/doc.htm?id=15&quot;&gt;Appium简介&lt;/a&gt;和&lt;a href=&quot;/doc.htm?id=16&quot;&gt;环境搭建&lt;/a&gt;来学习Appium。&lt;/p&gt;\n\n&lt;p&gt;本章的示例脚本使用Python作为Appium客户端的编程语言，建议阅读安卓的&lt;a href=&quot;/doc.htm?id=17&quot;&gt;Python脚本测试&lt;/a&gt;来熟悉脚本编写方式。&lt;/p&gt;\n\n&lt;h2&gt;2. 设置Desired Capabilities&lt;/h2&gt;\n\n&lt;p&gt;创建一个文件，名为：desired_capabilities.py。内容如下：&lt;/p&gt;\n\n&lt;pre&gt;\n#!/usr/bin/env python\n\nimport sys\n\ndef get_desired_capabilities():\n    desired_caps = {\n        \'platformName\': \'iOS\',\n        \'platformVersion\': \'10.0\',\n        \'deviceName\': \'iPhone 6s\',\n        \'udid\': \'36317c0f81086d7f4f99a9771179720b7962a2ad\',\n        \'realDeviceLogger\':\'/usr/local/lib/node_modules/deviceconsole/deviceconsole\',\n&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;&amp;nbsp;\'app\': \'/Users/adam/iosapp.app\',\n        \'bundleId\':\'net.oschina.iosapp\',\n        \'newCommandTimeout\': 60,    \n        \'automationName\': \'Appium\',\n        \'noReset\': True\n    }\n\n    return desired_caps\n\ndef get_uri():\n    return &amp;quot;http://localhost:56000/wd/hub&amp;quot;\n\ndef flushio():\n    sys.stdout.flush()\n\n&lt;/pre&gt;\n\n&lt;p&gt;其中，realDeviceLogger参数对应的deviceconsole用于获取iOS真机的日志；若不填写app参数，则根据bundleId运行手机上已安装的应用。&lt;/p&gt;\n\n&lt;h2&gt;3. 编写测试用例&lt;/h2&gt;\n\n&lt;p&gt;MQC会执行用户上传的main.py，所以要创建这个入口脚本：main.py。我们以一个登录的脚本main.py作为例子进行说明，代码如下：&lt;/p&gt;\n\n&lt;pre&gt;\n# -*- coding: utf-8 -*-\n\nfrom appium import webdriver\n\n# 引入刚刚创建的同目录下的desired_capabilities.py\nimport desired_capabilities\n\n# 我们使用python的unittest作为单元测试工具\nfrom unittest import TestCase\n\n# 我们使用python的unittest作为单元测试工具\nimport unittest\n\n# 使用time.sleep(xx)函数进行等待\nimport time\n\nclass MqcTest(TestCase):\n\n    def setUp(self):\n        # 获取我们设定的capabilities，通知Appium Server创建相应的会话。\n        desired_caps = desired_capabilities.get_desired_capabilities()\n        # 获取server的地址\n        uri = desired_capabilities.get_uri()\n        # 创建会话，得到driver对象，driver对象封装了所有的设备操作。\n        self.driver = webdriver.Remote(uri, desired_caps)\n        # 等待app完全加载\n        time.sleep(3)\n\n    # 第1个用例，如果检测到弹框，就点掉\n    def test_case_a_dismiss_alert(self):\n        while True:\n            time.sleep(3)\n            alertEle = self.driver.find_elements_by_class_name(&amp;quot;XCUIElementTypeAlert&amp;quot;)\n            if alertEle:\n                print \'find an alert\'\n                notAllowBtn = self.driver.find_element_by_xpath(&amp;quot;//XCUIElementTypeButton[@label=\'不允许\']&amp;quot;)\n                notAllowBtn.click()\n            else:\n                break\n\n    # 第2个用例，登录\n    def test_case_b_login(self):\n        # 取得导航栏的左侧按钮\n        leftBtn = self.driver.find_element_by_xpath(&amp;quot;//XCUIElementTypeButton[@label=\'navigationbar sidebar\']&amp;quot;)\n        leftBtn.click()\n        time.sleep(3)\n\n        # 点击&amp;ldquo;点击头像登录&amp;rdquo;按钮\n        potraitEle = self.driver.find_element_by_xpath(&amp;quot;//XCUIElementTypeStaticText[@label=\'点击头像登录\']&amp;quot;)\n        potraitEle.click()\n        time.sleep(3)\n\n        # 开始登录，输入账号密码\n        tfEle = self.driver.find_element_by_class_name(&amp;quot;XCUIElementTypeTextField&amp;quot;)\n        stfEle = self.driver.find_element_by_class_name(&amp;quot;XCUIElementTypeSecureTextField&amp;quot;)\n        tfEle.send_keys(&amp;quot;mqctest&amp;quot;.decode(\'UTF-8\'))\n        time.sleep(1)\n        stfEle.send_keys(&amp;quot;123456&amp;quot;.decode(\'UTF-8\'))\n        time.sleep(2)\n\n        # 点击&amp;ldquo;登录&amp;rdquo;按钮\n        loginBtn = self.driver.find_element_by_xpath(&amp;quot;//XCUIElementTypeButton[@label=\'登录\']&amp;quot;)\n        loginBtn.click()\n\n        # 等待登录成功\n        time.sleep(5)\n\n    def tearDown(self):\n        # 测试结束，退出会话\n        self.driver.quit()\n\nif __name__ == \'__main__\':\n    try: unittest.main()\n    except SystemExit: pass\n\n&lt;/pre&gt;\n\n&lt;h2&gt;4. 启动Appium Server&lt;/h2&gt;\n\n&lt;p&gt;在本地的命令行中执行命令：&lt;/p&gt;\n\n&lt;pre&gt;\nappium -p 56000\n&lt;/pre&gt;\n\n&lt;h2&gt;5. 执行测试用例&lt;/h2&gt;\n\n&lt;p&gt;在命令行中执行命令：&lt;/p&gt;\n\n&lt;pre&gt;\npython main.py -v&lt;/pre&gt;\n\n&lt;p&gt;其中main.py就是我们刚刚创建的测试用例。&lt;/p&gt;\n\n&lt;h2&gt;6. 提交到MQC云平台&lt;/h2&gt;\n\n&lt;p&gt;本地测试通过之后，将main.py打包成zip文件（无需打包desired_capabilities.py），然后进入&lt;a href=&quot;/iosFuncPub.htm&quot;&gt;iOS功能测试&lt;/a&gt;，提交被测应用和打包后的脚本zip包。&lt;/p&gt;','Appium教程','间客','本章介绍了使用Appium对iOS 10设备进行功能测试的方法。在开始前，您可以先下载本章的测试App和示例脚本。\n\n1. 配置环境\n\niOS 10测试的环境要求：\n\na. macOS 10.11.5及以上\n\nb. Xcode 8.0及以上\n\nc. Appium 1.6.0及以上\n\n我们使用Appium对iOS 10及以上的设备进行功能测试。您可以查看Appium简介和环境搭建来学习Appium。\n\n本章的示例脚本使用Python作为Appium客户端的编程语言，建议阅读安卓的Python脚本测试来熟悉脚本编写方式。\n\n2. 设置Desired Capabilities\n\n创建一个文件，名为：desired_capabilities.py。内容如下：\n\n\n#!/usr/bin/env python\n\nimport sys\n\ndef get_desired_capabilities():\n    desired_caps = {\n        \'platformName\': \'iOS\',\n        \'platformVersion\': \'10.0\',\n        \'deviceName\': \'iPhone 6s\',\n        \'udid\': \'36317c0f81086d7f4f99a9771179720b7962a2ad\',\n        \'realDeviceLogger\':\'/usr/local/lib/node_modules/deviceconsole/deviceconsole\',\n&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;\'app\': \'/Users/adam/iosapp.app\',\n        \'bundleId\':\'net.oschina.iosapp\',\n        \'newCommandTimeout\': 60,    \n        \'automationName\': \'Appium\',\n        \'noReset\': True\n    }\n\n    return desired_caps\n\ndef get_uri():\n    return &quot;http://localhost:56000/wd/hub&quot;\n\ndef flushio():\n    sys.stdout.flush()\n\n\n\n其中，realDeviceLogger参数对应的deviceconsole用于获取iOS真机的日志；若不填写app参数，则根据bundleId运行手机上已安装的应用。\n\n3. 编写测试用例\n\nMQC会执行用户上传的main.py，所以要创建这个入口脚本：main.py。我们以一个登录的脚本main.py作为例子进行说明，代码如下：\n\n\n# -*- coding: utf-8 -*-\n\nfrom appium import webdriver\n\n# 引入刚刚创建的同目录下的desired_capabilities.py\nimport desired_capabilities\n\n# 我们使用python的unittest作为单元测试工具\nfrom unittest import TestCase\n\n# 我们使用python的unittest作为单元测试工具\nimport unittest\n\n# 使用time.sleep(xx)函数进行等待\nimport time\n\nclass MqcTest(TestCase):\n\n    def setUp(self):\n        # 获取我们设定的capabilities，通知Appium Server创建相应的会话。\n        desired_caps = desired_capabilities.get_desired_capabilities()\n        # 获取server的地址\n        uri = desired_capabilities.get_uri()\n        # 创建会话，得到driver对象，driver对象封装了所有的设备操作。\n        self.driver = webdriver.Remote(uri, desired_caps)\n        # 等待app完全加载\n        time.sleep(3)\n\n    # 第1个用例，如果检测到弹框，就点掉\n    def test_case_a_dismiss_alert(self):\n        while True:\n            time.sleep(3)\n            alertEle = self.driver.find_elements_by_class_name(&quot;XCUIElementTypeAlert&quot;)\n            if alertEle:\n                print \'find an alert\'\n                notAllowBtn = self.driver.find_element_by_xpath(&quot;//XCUIElementTypeButton[@label=\'不允许\']&quot;)\n                notAllowBtn.click()\n            else:\n                break\n\n    # 第2个用例，登录\n    def test_case_b_login(self):\n        # 取得导航栏的左侧按钮\n        leftBtn = self.driver.find_element_by_xpath(&quot;//XCUIElementTypeButton[@label=\'navigationbar sidebar\']&quot;)\n        leftBtn.click()\n        time.sleep(3)\n\n        # 点击&ldquo;点击头像登录&rdquo;按钮\n        potraitEle = self.driver.find_element_by_xpath(&quot;//XCUIElementTypeStaticText[@label=\'点击头像登录\']&quot;)\n        potraitEle.click()\n        time.sleep(3)\n\n        # 开始登录，输入账号密码\n        tfEle = self.driver.find_element_by_class_name(&quot;XCUIElementTypeTextField&quot;)\n        stfEle = self.driver.find_element_by_class_name(&quot;XCUIElementTypeSecureTextField&quot;)\n        tfEle.send_keys(&quot;mqctest&quot;.decode(\'UTF-8\'))\n        time.sleep(1)\n        stfEle.send_keys(&quot;123456&quot;.decode(\'UTF-8\'))\n        time.sleep(2)\n\n        # 点击&ldquo;登录&rdquo;按钮\n        loginBtn = self.driver.find_element_by_xpath(&quot;//XCUIElementTypeButton[@label=\'登录\']&quot;)\n        loginBtn.click()\n\n        # 等待登录成功\n        time.sleep(5)\n\n    def tearDown(self):\n        # 测试结束，退出会话\n        self.driver.quit()\n\nif __name__ == \'__main__\':\n    try: unittest.main()\n    except SystemExit: pass\n\n\n\n4. 启动Appium Server\n\n在本地的命令行中执行命令：\n\n\nappium -p 56000\n\n\n5. 执行测试用例\n\n在命令行中执行命令：\n\n\npython main.py -v\n\n其中main.py就是我们刚刚创建的测试用例。\n\n6. 提交到MQC云平台\n\n本地测试通过之后，将main.py打包成zip文件（无需打包desired_capabilities.py），然后进入iOS功能测试，提交被测应用和打包后的脚本zip包。',0,39,4);
/*!40000 ALTER TABLE `mts_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_execution`
--

DROP TABLE IF EXISTS `mts_execution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_execution` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `mts_uid` bigint(20) unsigned NOT NULL COMMENT '用户id，对应mts_user表',
  `user_group_id` bigint(20) unsigned NOT NULL COMMENT '用户组id，对应mts_user_group表',
  `platform` varchar(32) NOT NULL COMMENT '平台：ANDROID，IOS',
  `test_type` varchar(64) NOT NULL COMMENT '测试类型：稳定性-STABILITY，兼容性-COMPATIBILITY',
  `test_ability_ids` varchar(512) DEFAULT NULL COMMENT '测试能力id组：1,2,3',
  `status` varchar(32) NOT NULL COMMENT '状态：WAITING，RUNNING，SUCCESS，TEST_FAIL，USER_CANCELED，TIMEOUT',
  `result_json` varchar(1024) DEFAULT NULL COMMENT '结果，json串',
  `begin_time` datetime NOT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0-未删除，1-已删除',
  `callback_url` varchar(512) DEFAULT NULL COMMENT '回调地址',
  `emails` varchar(1024) DEFAULT NULL COMMENT '通知邮箱',
  `wangwangs` varchar(512) DEFAULT NULL COMMENT '通知旺旺',
  `package_id` bigint(20) unsigned NOT NULL COMMENT '应用id，对应mts_package表',
  `ak` varchar(32) DEFAULT NULL COMMENT '通过API提交的任务的ak值',
  `extension` varchar(1024) DEFAULT NULL COMMENT '扩展字段',
  `replay_script_ids` varchar(64) DEFAULT NULL COMMENT '录制回放脚本id，多个脚本id以逗号分隔',
  `h5_test_urls` varchar(1024) DEFAULT NULL COMMENT 'H5测试被测的url地址',
  `login_param` varchar(1024) DEFAULT NULL COMMENT '登陆参数，json格式的用户名密码',
  `share_users` varchar(512) DEFAULT NULL COMMENT '共享用户名单',
  `description` varchar(100) DEFAULT NULL COMMENT '任务名称或者叫任务自定义标签，让用户可以更新和编辑',
  `role_name` varchar(128) DEFAULT 'FREE_USER' COMMENT '创建任务的用户的所属角色',
  `priority` varchar(64) DEFAULT NULL COMMENT '优先级',
  `service_name` varchar(45) DEFAULT NULL COMMENT '服务名',
  `share_code` varchar(32) DEFAULT NULL COMMENT '分享码',
  `gmt_share_validate` datetime DEFAULT NULL COMMENT '分享码的有效截止时间',
  `baseline_name` varchar(256) DEFAULT NULL COMMENT '性能基线名称',
  `base_check_result` varchar(1024) DEFAULT NULL COMMENT '游戏应用基础检测结果',
  `test_mode` varchar(64) DEFAULT 'DEVICE_FIRST' COMMENT '测试策略，如用例优先(CASE_FIRST)、设备优先(DEVICE_FIRST)',
  PRIMARY KEY (`id`),
  KEY `ins_mtsuid` (`mts_uid`),
  KEY `ins_paid` (`package_id`),
  KEY `idx_ak` (`ak`),
  KEY `idx_status` (`status`),
  KEY `idx_extension` (`extension`(100)),
  KEY `idx_test_type` (`test_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ִ执行表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_execution`
--

LOCK TABLES `mts_execution` WRITE;
/*!40000 ALTER TABLE `mts_execution` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_execution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_execution_report`
--

DROP TABLE IF EXISTS `mts_execution_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_execution_report` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `execution_id` bigint(20) unsigned NOT NULL COMMENT 'mts_execution 的id',
  `result_json` text COMMENT '统计结果',
  `oss_file` varchar(1024) DEFAULT NULL COMMENT '上传统计结果到oss, 与result_json二选一',
  `extension` varchar(1024) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='execution的统计数据';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_execution_report`
--

LOCK TABLES `mts_execution_report` WRITE;
/*!40000 ALTER TABLE `mts_execution_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_execution_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_execution_task`
--

DROP TABLE IF EXISTS `mts_execution_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_execution_task` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `mts_uid` bigint(20) unsigned NOT NULL COMMENT '用户id',
  `test_ability_id` bigint(20) unsigned NOT NULL COMMENT '测试能力id，对应mts_test_abilities表',
  `execution_id` bigint(20) unsigned NOT NULL COMMENT '执行id，对应mts_execution表',
  `task_suite_id` bigint(20) unsigned NOT NULL COMMENT '任务id，对应mts_execution_task表',
  `device_type_id` bigint(20) unsigned NOT NULL COMMENT '设备id，对应mts_device_type表',
  `device_group_id` bigint(20) unsigned NOT NULL COMMENT '设备组id，对应mts_device_group表',
  `package_id` bigint(20) unsigned NOT NULL COMMENT '应用包 id',
  `case_suite_id` bigint(20) unsigned DEFAULT '0' COMMENT '用例集 id',
  `status` varchar(32) NOT NULL COMMENT '状态：WAITING，RUNNING，SUCCESS，TEST_FAIL，USER_CANCELED，TIMEOUT',
  `task_type` varchar(128) NOT NULL COMMENT '测试能力名字：稳定性-STABILITY，兼容性-COMPATIBILITY',
  `task_params` varchar(4096) NOT NULL COMMENT 'json串',
  `msg` varchar(1024) DEFAULT NULL COMMENT '结果字符串',
  `result_json` text COMMENT '结果全集，json串',
  `begin_time` datetime NOT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `asset_num` varchar(256) DEFAULT NULL COMMENT '执行任务的设备的资产编号',
  `timeout` int(10) unsigned DEFAULT '30' COMMENT '执行任务超时timeout，默认30分钟',
  `extension` varchar(1024) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`id`),
  KEY `ins_exeid` (`execution_id`),
  KEY `ins_tasuid` (`task_suite_id`),
  KEY `ins_mtsuid` (`mts_uid`),
  KEY `ins_status` (`status`),
  KEY `ins_tasktype` (`task_type`),
  KEY `ins_begin_end` (`begin_time`,`end_time`)
) ENGINE=InnoDB AUTO_INCREMENT=254 DEFAULT CHARSET=utf8 COMMENT='执行任务表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_execution_task`
--

LOCK TABLES `mts_execution_task` WRITE;
/*!40000 ALTER TABLE `mts_execution_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_execution_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_execution_task_suite`
--

DROP TABLE IF EXISTS `mts_execution_task_suite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_execution_task_suite` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `mts_uid` bigint(20) unsigned NOT NULL COMMENT '用户id，对应mts_user表',
  `execution_id` bigint(20) unsigned NOT NULL COMMENT '执行id，对应mts_execution表',
  `device_group_id` bigint(20) unsigned NOT NULL COMMENT '设备组id，对应mts_device_group表',
  `status` varchar(32) NOT NULL COMMENT '状态：WAITING，RUNNING，SUCCESS，TEST_FAIL，USER_CANCELED，TIMEOUT',
  `result_json` varchar(1024) DEFAULT NULL COMMENT '任务集执行结果，json串',
  `begin_time` datetime NOT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `package_id` bigint(20) unsigned NOT NULL COMMENT '应用id，对应mts_package表',
  `asset_num` varchar(256) DEFAULT NULL COMMENT '资产编号',
  `device_type_id` bigint(20) unsigned NOT NULL COMMENT '设备类型id，对应mts_device_type表',
  `extension` varchar(1024) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`id`),
  KEY `ins_status` (`status`),
  KEY `ins_exid` (`execution_id`),
  KEY `ins_assetnum` (`asset_num`(255)),
  KEY `ins_devicetype` (`device_type_id`),
  KEY `ins_begin_end` (`begin_time`,`end_time`)
) ENGINE=InnoDB AUTO_INCREMENT=160 DEFAULT CHARSET=utf8 COMMENT='执行任务集表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_execution_task_suite`
--

LOCK TABLES `mts_execution_task_suite` WRITE;
/*!40000 ALTER TABLE `mts_execution_task_suite` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_execution_task_suite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_free_res_record`
--

DROP TABLE IF EXISTS `mts_free_res_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_free_res_record` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `user_id` bigint(20) unsigned NOT NULL COMMENT '用户表id',
  `havana_id` bigint(20) unsigned NOT NULL COMMENT '哈瓦那id',
  `service_name` varchar(256) NOT NULL COMMENT '服务标志',
  `start_time` datetime DEFAULT NULL COMMENT '订购开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '订购结束时间',
  `num` bigint(20) DEFAULT NULL COMMENT '资源量',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='免费资源开通记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_free_res_record`
--

LOCK TABLES `mts_free_res_record` WRITE;
/*!40000 ALTER TABLE `mts_free_res_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_free_res_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_function_control`
--

DROP TABLE IF EXISTS `mts_function_control`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_function_control` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `function_name` varchar(64) DEFAULT NULL COMMENT '功能块名字：COMPABILITY、STABILITY、H5、REPLAY',
  `pages` varchar(512) DEFAULT NULL COMMENT '对应的页面(逗号分隔)：compability.htm,stability.htm',
  `is_open` tinyint(4) NOT NULL DEFAULT '1' COMMENT '是否开放该功能',
  `is_delete` tinyint(4) NOT NULL DEFAULT '0' COMMENT '该记录是否删除',
  PRIMARY KEY (`id`),
  KEY `ids_function_name` (`function_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='功能块控制表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_function_control`
--

LOCK TABLES `mts_function_control` WRITE;
/*!40000 ALTER TABLE `mts_function_control` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_function_control` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_game_problem_details`
--

DROP TABLE IF EXISTS `mts_game_problem_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_game_problem_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `execution_id` bigint(20) unsigned NOT NULL COMMENT '任务id',
  `device_type_id` bigint(20) unsigned NOT NULL COMMENT '设备id',
  `type` varchar(128) NOT NULL COMMENT '问题类型',
  `description` text COMMENT '问题描述',
  `count` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '出现次数',
  `screenshots` text COMMENT '截图路径',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0-未删除，1-已删除',
  `extension` varchar(1024) DEFAULT NULL COMMENT '扩展字段',
  `mergelog_id` bigint(20) unsigned DEFAULT NULL COMMENT 'mts_mergelog_per_tasksuite 的id，用于关联日志信息',
  PRIMARY KEY (`id`),
  KEY `idx_exid` (`execution_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='游戏测试问题详情';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_game_problem_details`
--

LOCK TABLES `mts_game_problem_details` WRITE;
/*!40000 ALTER TABLE `mts_game_problem_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_game_problem_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_groovy_script`
--

DROP TABLE IF EXISTS `mts_groovy_script`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_groovy_script` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `name` varchar(256) NOT NULL COMMENT 'groovy脚本名字',
  `url` varchar(1024) NOT NULL COMMENT 'groovy脚本地址',
  `extension` varchar(1024) DEFAULT NULL COMMENT '扩展字段',
  `remark` varchar(1024) DEFAULT NULL COMMENT '备注',
  `mender` varchar(64) DEFAULT NULL COMMENT '最后修改者',
  PRIMARY KEY (`id`),
  KEY `ins_name` (`name`(255)),
  KEY `ins_name_url` (`name`(255),`url`(255))
) ENGINE=InnoDB AUTO_INCREMENT=170 DEFAULT CHARSET=utf8 COMMENT='groovy脚本表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_groovy_script`
--

LOCK TABLES `mts_groovy_script` WRITE;
/*!40000 ALTER TABLE `mts_groovy_script` DISABLE KEYS */;
INSERT INTO `mts_groovy_script` VALUES (1,'2015-01-26 11:14:13','2015-01-26 11:14:13','h5Test.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/h5Test.groovy',NULL,'系统默认','admin'),(2,'2015-02-02 19:01:40','2015-02-02 19:01:40','coverInstallTest.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/coverInstallTest.groovy',NULL,'系统默认','admin'),(3,'2015-02-02 19:01:46','2015-02-02 19:01:46','ExecuteLogcatTask.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/ExecuteLogcatTask.groovy',NULL,'系统默认','admin'),(4,'2015-02-02 19:01:50','2015-02-02 19:01:50','FileWriteMultiLineRecevier.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/FileWriteMultiLineRecevier.groovy',NULL,'系统默认','admin'),(5,'2015-02-02 19:01:59','2015-02-02 19:01:59','lib.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/lib.groovy',NULL,'系统默认','admin'),(6,'2015-02-02 19:02:23','2015-02-02 19:02:23','LogcatManager.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/LogcatManager.groovy',NULL,'系统默认','admin'),(7,'2015-02-02 19:02:30','2015-02-02 19:02:30','monkeyTest.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/monkeyTest.groovy',NULL,'系统默认','admin'),(8,'2015-02-02 19:02:34','2015-02-02 19:02:34','pretest.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/pretest.groovy',NULL,'系统默认','admin'),(9,'2015-02-02 19:02:38','2015-02-02 19:02:38','ReplayScriptTest.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/ReplayScriptTest.groovy',NULL,'系统默认','admin'),(10,'2015-02-02 19:02:43','2015-02-02 19:02:43','ResultAnalyseMultiLineReceiver.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/ResultAnalyseMultiLineReceiver.groovy',NULL,'系统默认','admin'),(11,'2015-02-02 19:02:47','2017-12-28 17:15:09','StabilityTest.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/StabilityTest.groovy',NULL,'系统默认','admin'),(12,'2015-02-02 19:02:50','2015-02-02 19:02:50','startManyTimesTest.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/startManyTimesTest.groovy',NULL,'系统默认','admin'),(13,'2015-04-29 16:34:47','2015-04-29 16:34:47','NewActivityScreenshotReceiver.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/NewActivityScreenshotReceiver.groovy',NULL,'系统默认','admin'),(14,'2015-04-30 09:33:25','2015-04-30 09:33:25','AutomationTest.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/AutomationTest.groovy',NULL,'系统默认','admin'),(15,'2015-04-30 09:33:31','2015-04-30 09:33:31','ScriptEngines.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/ScriptEngines.groovy',NULL,'系统默认','admin'),(16,'2015-04-30 09:33:40','2015-04-30 09:33:40','MtsInstrument.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/MtsInstrument.groovy',NULL,'系统默认','admin'),(17,'2015-04-30 09:33:44','2015-04-30 09:33:44','MtsAppium.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/MtsAppium.groovy',NULL,'系统默认','admin'),(18,'2015-06-02 16:14:54','2015-06-02 16:14:54','UserLogcatOrderReceiver.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/UserLogcatOrderReceiver.groovy',NULL,'系统默认','admin'),(19,'2015-06-30 09:53:32','2015-06-30 09:53:32','desired_capabilities.py.tpl.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/desired_capabilities.py.tpl.groovy',NULL,'系统默认','admin'),(20,'2015-07-09 17:38:33','2015-07-09 17:38:33','appium.py.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/appium.py.groovy',NULL,'系统默认','admin'),(21,'2015-08-24 16:41:42','2015-08-24 16:41:42','H5forBrowser.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/H5forBrowser.groovy',NULL,'系统默认','admin'),(22,'2015-09-08 09:58:45','2017-12-26 19:05:56','iOSMonkey.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/iOSMonkey.groovy',NULL,'系统默认','admin'),(23,'2015-09-08 09:58:55','2017-12-27 20:22:32','iOSLib.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/iOSLib.groovy',NULL,'系统默认','admin'),(24,'2015-09-08 10:06:27','2015-09-08 10:06:27','iMonkeyTest.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/iMonkeyTest.groovy',NULL,'系统默认','admin'),(25,'2015-09-08 18:56:34','2015-09-08 18:56:34','SceneLib.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/SceneLib.groovy',NULL,'系统默认','admin'),(26,'2015-09-08 19:02:41','2015-09-08 19:02:41','Battery.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/Battery.groovy',NULL,'系统默认','admin'),(27,'2015-10-08 19:22:14','2015-10-08 19:22:14','AutoLoginScreenshotReceiver.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/AutoLoginScreenshotReceiver.groovy',NULL,'系统默认','admin'),(28,'2015-10-08 19:24:24','2015-10-08 19:24:24','H5Standard.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/H5Standard.groovy',NULL,'系统默认','admin'),(29,'2015-10-08 19:24:32','2015-10-08 19:24:32','H5DataProcess.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/H5DataProcess.groovy',NULL,'系统默认','admin'),(30,'2015-10-08 19:24:40','2015-10-08 19:24:40','redirect_all_resources_V2.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/redirect_all_resources_V2.groovy',NULL,'系统默认','admin'),(31,'2015-11-13 09:43:44','2015-11-13 09:43:44','DesiredCapabilities.java.tpl.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/DesiredCapabilities.java.tpl.groovy',NULL,'系统默认','admin'),(32,'2015-11-13 17:31:38','2015-11-13 17:31:38','har.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/har.groovy',NULL,'系统默认','admin'),(33,'2015-12-07 16:42:11','2015-12-07 16:42:11','iOSFuncPub.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/iOSFuncPub.groovy',NULL,'系统默认','admin'),(34,'2015-12-07 16:42:20','2015-12-07 16:42:20','iOSFuncPubLib.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/iOSFuncPubLib.groovy',NULL,'系统默认','admin'),(35,'2016-01-12 21:50:47','2016-01-12 21:50:47','ImageProcess.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/ImageProcess.groovy',NULL,'系统默认','admin'),(36,'2016-01-13 19:23:41','2017-12-17 17:30:52','PerformanceLib.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/PerformanceLib.groovy',NULL,'系统默认','admin'),(37,'2016-02-22 15:25:55','2016-02-22 15:25:55','DropboxManager.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/DropboxManager.groovy',NULL,'系统默认','admin'),(38,'2016-02-22 15:29:08','2016-02-22 15:29:08','StabilityTest-5.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/StabilityTest-5.groovy',NULL,'系统默认','admin'),(39,'2016-03-03 14:25:17','2017-12-27 20:22:50','iOSCommon.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/iOSCommon.groovy',NULL,'系统默认','admin'),(42,'2016-05-30 16:34:59','2016-05-30 16:34:59','SilenceTest.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/SilenceTest.groovy',NULL,'系统默认','admin'),(50,'2016-10-08 20:13:41','2017-12-17 17:31:08','newPerformanceTest.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/newPerformanceTest.groovy',NULL,'系统默认','admin'),(51,'2016-10-08 20:16:57','2016-10-08 20:16:57','PerfOverdrawReceiver.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/PerfOverdrawReceiver.groovy',NULL,'系统默认','admin'),(52,'2016-10-08 20:17:16','2016-10-08 20:17:16','PerfStrictMode.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/PerfStrictMode.groovy',NULL,'系统默认','admin'),(53,'2016-11-04 22:06:51','2016-11-04 22:06:51','PerfMemReceiver.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/PerfMemReceiver.groovy',NULL,'系统默认','admin'),(54,'2016-11-07 11:43:32','2016-11-07 11:43:32','PerformanceTest.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/PerformanceTest.groovy',NULL,'系统默认','admin'),(55,'2016-11-30 23:28:02','2016-11-30 23:28:02','PerfLaunchReceiver.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/PerfLaunchReceiver.groovy',NULL,'系统默认','admin'),(56,'2016-11-30 23:28:30','2017-12-17 17:30:30','PerfSmoothReceiver.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/PerfSmoothReceiver.groovy',NULL,'系统默认','admin'),(57,'2016-12-16 19:57:16','2016-12-16 19:57:16','PerfActivitySwitchReceiver.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/PerfActivitySwitchReceiver.groovy',NULL,'系统默认','admin'),(58,'2016-12-16 19:57:32','2017-12-17 17:29:05','LogcatReceiverProxy.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/LogcatReceiverProxy.groovy',NULL,'系统默认','admin'),(59,'2017-01-11 10:17:24','2017-01-11 10:17:24','LogcatFilter.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/LogcatFilter.groovy',NULL,'系统默认','admin'),(62,'2017-03-23 10:29:41','2017-03-23 10:29:41','GameTest.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/GameTest.groovy',NULL,'系统默认','admin'),(63,'2017-05-18 10:47:14','2017-05-18 10:47:14','H5Automation.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/H5Automation.groovy',NULL,'系统默认','admin'),(64,'2017-05-25 22:09:39','2017-05-25 22:09:39','test.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/test.groovy',NULL,'系统默认','admin'),(65,'2017-07-25 09:37:35','2017-07-25 09:37:35','AutomationTestNew.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/AutomationTestNew.groovy',NULL,'系统默认','admin'),(66,'2017-07-25 09:37:44','2017-07-25 09:37:44','desired_capabilities.py.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/desired_capabilities.py.groovy',NULL,'系统默认','admin'),(67,'2017-07-25 09:37:49','2017-07-25 09:37:49','main.py.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/main.py.groovy',NULL,'系统默认','admin'),(68,'2017-07-25 09:37:54','2017-07-25 09:37:54','MqcAppium.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/MqcAppium.groovy',NULL,'系统默认','admin'),(69,'2017-07-25 09:37:58','2017-07-25 09:37:58','mts_appium.py.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/mts_appium.py.groovy',NULL,'系统默认','admin'),(70,'2017-07-27 22:19:07','2017-07-27 22:19:07','MqcInstrument.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/MqcInstrument.groovy',NULL,'系统默认','admin'),(71,'2017-08-03 13:34:00','2017-12-18 14:20:05','ios_desired_capabilities.py.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/ios_desired_capabilities.py.groovy',NULL,'系统默认','admin'),(72,'2017-08-03 13:34:18','2017-12-25 15:02:42','ios_main.py.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/ios_main.py.groovy',NULL,'系统默认','admin'),(73,'2017-08-03 13:34:27','2017-12-20 20:36:36','iOSNewFuncPub.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/iOSNewFuncPub.groovy',NULL,'系统默认','admin'),(74,'2017-08-03 13:34:42','2017-12-26 15:21:44','iOSNewFuncPubLib.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/iOSNewFuncPubLib.groovy',NULL,'系统默认','admin'),(75,'2017-08-03 13:35:03','2017-12-26 15:58:36','LogAnalyseWhileSaveFileReceiver.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/LogAnalyseWhileSaveFileReceiver.groovy',NULL,'系统默认','admin'),(76,'2017-08-03 13:35:36','2017-08-03 13:35:36','SaveOutputToFileReceiver.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/SaveOutputToFileReceiver.groovy',NULL,'系统默认','admin'),(77,'2017-08-25 20:11:46','2017-08-25 20:11:46','remoteDebug.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/remoteDebug.groovy',NULL,'系统默认','admin'),(78,'2017-09-14 20:10:38','2017-09-14 20:10:38','AppiumLib.py.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/AppiumLib.py.groovy',NULL,'系统默认','admin'),(79,'2017-11-15 19:44:44','2017-11-15 19:44:44','RobotFramework.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/RobotFramework.groovy',NULL,NULL,'admin'),(80,'2017-11-15 19:44:55','2017-11-15 19:44:55','RobotFrameworkTest.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/RobotFrameworkTest.groovy',NULL,NULL,'admin'),(81,'2017-11-15 19:45:48','2017-12-27 20:23:28','TestRunnerAgent.py.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/TestRunnerAgent.py.groovy',NULL,NULL,'admin'),(82,'2017-11-15 21:05:36','2017-11-27 10:43:36','IOSRobotFrameworkTest.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/IOSRobotFrameworkTest.groovy',NULL,NULL,'admin'),(94,'2017-11-16 17:53:36','2017-12-27 19:34:42','IOSRobotFramework.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/IOSRobotFramework.groovy',NULL,NULL,'admin'),(163,'2017-12-13 12:07:13','2017-12-21 16:21:33','run_testsuite.py.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/run_testsuite.py.groovy',NULL,NULL,'admin'),(182,'2018-06-13 10:43:19','2018-06-13 10:43:19','uiwatcher.json.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/uiwatcher.json.groovy',NULL,'系统默认','admin'),(183,'2018-06-13 10:43:19','2018-06-13 10:43:19','Parser.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/Parser.groovy',NULL,'系统默认','admin'),(185,'2018-06-13 10:43:19','2018-06-13 10:43:19','PerfMonitorTest.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/PerfMonitorTest.groovy',NULL,'系统默认','admin'),(186,'2018-06-13 10:43:19','2018-06-13 10:43:19','PerfDataCollector.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/PerfDataCollector.groovy',NULL,'系统默认','admin'),(187,'2018-06-13 10:43:19','2018-06-13 10:43:19','PerfMonitorLib.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/PerfMonitorLib.groovy',NULL,'系统默认','admin'),(188,'2018-06-13 10:43:19','2018-06-13 10:43:19','PerfStatusCollector.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/PerfStatusCollector.groovy',NULL,'系统默认','admin'),(189,'2018-06-13 10:43:19','2018-06-13 10:43:19','PerfStrictCollector.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/PerfStrictCollector.groovy',NULL,'系统默认','admin'),(190,'2018-06-13 10:43:19','2018-06-13 10:43:19','NewLib.groovy','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/NewLib.groovy',NULL,'系统默认','admin');
/*!40000 ALTER TABLE `mts_groovy_script` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_h5_suites`
--

DROP TABLE IF EXISTS `mts_h5_suites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_h5_suites` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `mts_uid` bigint(20) unsigned NOT NULL COMMENT 'user id\n',
  `url_script_json` text NOT NULL COMMENT 'url scriptPath json\n',
  `type` varchar(256) NOT NULL COMMENT 'userScript or recordedAction',
  `record_action` text COMMENT 'user recorded action.',
  `name` varchar(2048) NOT NULL COMMENT 'whole {url, js} suite name',
  `description` text COMMENT 'describe this suite',
  `is_deleted` int(11) NOT NULL DEFAULT '0' COMMENT '是否删除，1删除。',
  `url` varchar(2048) NOT NULL COMMENT '主url',
  `suite_case_name` text COMMENT '按顺序存储用例集、用例名称，方便查找。',
  PRIMARY KEY (`id`),
  KEY `IDX_MTS_UID` (`mts_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='H5用例集表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_h5_suites`
--

LOCK TABLES `mts_h5_suites` WRITE;
/*!40000 ALTER TABLE `mts_h5_suites` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_h5_suites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_h5_suites_result`
--

DROP TABLE IF EXISTS `mts_h5_suites_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_h5_suites_result` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `execution_id` bigint(20) unsigned NOT NULL COMMENT 'execution id\n',
  `suite_id` bigint(20) unsigned NOT NULL COMMENT 'suite id，包含了deviceTypeId',
  `suite_name` varchar(4069) NOT NULL COMMENT '用例集名称',
  `case_name` varchar(4069) NOT NULL COMMENT '用例名称',
  `is_success` int(11) NOT NULL COMMENT '是否成功,0是成功,1是失败',
  `duration` bigint(20) unsigned DEFAULT NULL COMMENT '运行时间',
  `err` text COMMENT 'json 内容',
  PRIMARY KEY (`id`),
  KEY `IDX_EXECUTION_ID` (`execution_id`),
  KEY `IDX_SUITE_ID` (`suite_id`),
  KEY `IDX_IS_SUCCESS` (`is_success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用例集执行结果表，包含成功、失败所有用例';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_h5_suites_result`
--

LOCK TABLES `mts_h5_suites_result` WRITE;
/*!40000 ALTER TABLE `mts_h5_suites_result` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_h5_suites_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_keystore`
--

DROP TABLE IF EXISTS `mts_keystore`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_keystore` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `signature` varchar(8192) DEFAULT NULL COMMENT 'keystore生成的信息',
  `keystore_path` varchar(256) DEFAULT NULL COMMENT 'keystore路径',
  `key_passwd` varchar(256) DEFAULT NULL COMMENT 'key密码',
  `store_passwd` varchar(256) DEFAULT NULL COMMENT 'store密码',
  `cert_chain` varchar(256) DEFAULT NULL COMMENT '证书链',
  `signature_hashcode` bigint(20) DEFAULT NULL COMMENT '签名hash',
  `extension` varchar(1024) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`id`),
  KEY `ins_sig` (`signature`(255)),
  KEY `ins_sighash` (`signature_hashcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='keystore文件表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_keystore`
--

LOCK TABLES `mts_keystore` WRITE;
/*!40000 ALTER TABLE `mts_keystore` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_keystore` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_mergelog_per_execution`
--

DROP TABLE IF EXISTS `mts_mergelog_per_execution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_mergelog_per_execution` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `execution_id` bigint(20) unsigned NOT NULL COMMENT 'execution_id，对应mts_execution表',
  `type` varchar(256) NOT NULL COMMENT '类型：CRASH、ANR、EXCEPTION',
  `keyline` text COMMENT '关键行',
  `signature` varchar(256) DEFAULT NULL COMMENT '摘要信息，sha1',
  `count` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '数量',
  `content` text COMMENT '日志',
  `path` varchar(1024) DEFAULT NULL COMMENT '日志路径',
  PRIMARY KEY (`id`),
  KEY `ids_execution_id_signature` (`execution_id`,`signature`(255))
) ENGINE=InnoDB AUTO_INCREMENT=366 DEFAULT CHARSET=utf8 COMMENT='为每个execution进行日志合并';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_mergelog_per_execution`
--

LOCK TABLES `mts_mergelog_per_execution` WRITE;
/*!40000 ALTER TABLE `mts_mergelog_per_execution` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_mergelog_per_execution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_mergelog_per_tasksuite`
--

DROP TABLE IF EXISTS `mts_mergelog_per_tasksuite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_mergelog_per_tasksuite` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `execution_id` bigint(20) unsigned NOT NULL COMMENT 'execution_id，对应mts_execution表',
  `task_suite_id` bigint(20) unsigned NOT NULL COMMENT 'task_suite_id，对应mts_task_suite表',
  `task_id` bigint(20) unsigned NOT NULL COMMENT 'task_id，对应mts_task表',
  `type` varchar(128) NOT NULL COMMENT '类型：CRASH、ANR、EXCEPTION',
  `keyline` text COMMENT '关键行',
  `signature` varchar(256) DEFAULT NULL COMMENT '信息摘要，sha1',
  `count` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '数量',
  `content` text COMMENT '内容',
  `path` varchar(1024) DEFAULT NULL COMMENT '日志路径',
  `is_performance_log` tinyint(4) DEFAULT NULL COMMENT '是否性能测试输出的日志，0或null表示不是，1表示StrictMode输出的日志',
  `timestamps` varchar(1024) DEFAULT NULL COMMENT 'the time caught the logs',
  PRIMARY KEY (`id`),
  KEY `ids_task_id` (`task_id`),
  KEY `ids_execution_id` (`execution_id`),
  KEY `idx_task_suite_id` (`task_suite_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7807 DEFAULT CHARSET=utf8 COMMENT='每一个tasksuite的log合并';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_mergelog_per_tasksuite`
--

LOCK TABLES `mts_mergelog_per_tasksuite` WRITE;
/*!40000 ALTER TABLE `mts_mergelog_per_tasksuite` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_mergelog_per_tasksuite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_notice`
--

DROP TABLE IF EXISTS `mts_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_notice` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `content` text NOT NULL COMMENT '消息内容',
  `type` varchar(64) NOT NULL COMMENT '消息类型\nsystem_notice, user_notice',
  `has_read` tinyint(3) unsigned DEFAULT '0' COMMENT '对于user_notice的消息，用户是否已读',
  `filter_device` text COMMENT '过滤notice的设备信息',
  `mts_uid` bigint(20) unsigned DEFAULT NULL COMMENT 'user_notice的用户id',
  `is_delete` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否已经删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='mqc消息通知';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_notice`
--

LOCK TABLES `mts_notice` WRITE;
/*!40000 ALTER TABLE `mts_notice` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_order`
--

DROP TABLE IF EXISTS `mts_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '订单id',
  `gmt_create` datetime NOT NULL COMMENT '创建日期',
  `gmt_modified` datetime NOT NULL COMMENT '修改日期',
  `amount` decimal(12,2) NOT NULL COMMENT '订单金额（折后）',
  `detail_json` text COMMENT '服务明细',
  `status` varchar(20) NOT NULL COMMENT '订单状态：PENDING_PAYMENT-待付款，UNDER_PAYMENT-付款中，PAID－已付款，PAYMENT_FAILED－付款失败，BEING_REFUNDED－退款中，REFUNDED-已退款，REFUND_FAILED-退款失败  IN_PROGRESS-按量付费订单进行中 FINISHED-按量付费订单结束',
  `service_name` varchar(256) NOT NULL COMMENT '服务标志',
  `user_id` bigint(20) DEFAULT NULL COMMENT '用户表里的id',
  `execution_id` bigint(20) DEFAULT NULL COMMENT '对应的任务id，可为空。',
  `original_amount` decimal(12,2) NOT NULL COMMENT '原价',
  `payment_detail` varchar(256) DEFAULT NULL COMMENT '支付明细',
  `sku_code` varchar(45) DEFAULT NULL COMMENT '汇金商品代码',
  `havana_id` bigint(20) DEFAULT NULL COMMENT '哈瓦那id',
  `cash_amount` decimal(12,2) DEFAULT NULL COMMENT '现金支付金额，方便数据统计',
  `coupon_amount` decimal(12,2) DEFAULT NULL COMMENT '使用代金券金额，方便数据统计',
  `refund_amount` decimal(12,2) DEFAULT NULL COMMENT '已退款金额，方便数据统计',
  `order_type` varchar(45) NOT NULL COMMENT '订单类型：预付费PREPAY，消耗型CONSUME，免费型FREE',
  `num` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '购买数量',
  `price` decimal(12,2) NOT NULL COMMENT '下单时的单价',
  `discount_flag` tinyint(4) DEFAULT '0' COMMENT '享受的折扣标志，一般不用这个字段，因为以后折扣标志的含义可能会变化',
  `discount_info` varchar(45) DEFAULT NULL COMMENT '折扣信息，展示在前端',
  `updated_num` int(11) DEFAULT NULL COMMENT '执行成功的机器数量',
  `updated_price` decimal(12,2) DEFAULT NULL COMMENT '重新批价后的价格',
  `resource_use` int(11) DEFAULT '0' COMMENT '抵扣的资源数量',
  `updated_resource_use` int(11) DEFAULT '0' COMMENT '重新批价后抵扣的资源数量',
  PRIMARY KEY (`id`),
  KEY `ins_user_id` (`user_id`),
  KEY `ins_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_order`
--

LOCK TABLES `mts_order` WRITE;
/*!40000 ALTER TABLE `mts_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_package`
--

DROP TABLE IF EXISTS `mts_package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_package` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `package_type` varchar(32) NOT NULL COMMENT 'NATIVE、HYBRID',
  `size` bigint(20) unsigned NOT NULL COMMENT '包大小',
  `md5` varchar(256) NOT NULL COMMENT '文件的md5',
  `path` varchar(512) DEFAULT NULL COMMENT 'OSS url地址',
  `icon_path` varchar(512) DEFAULT NULL COMMENT '图标地址',
  `file_name` varchar(256) NOT NULL COMMENT '文件名',
  `parent_id` bigint(20) unsigned DEFAULT NULL COMMENT '重签的parent_id指向未重签id，录制回放test.apk的parent_id指向重签的',
  `upload_type` varchar(32) NOT NULL COMMENT '是URL还是文件：URL、FILE',
  `mts_uid` bigint(20) unsigned NOT NULL COMMENT '用户id，对应mts_user表',
  `package_name` varchar(128) DEFAULT NULL COMMENT '应用包名',
  `target_package_name` varchar(128) DEFAULT NULL COMMENT '需要额外apk测试被测包时，被测包名',
  `app_name` varchar(128) DEFAULT NULL COMMENT '应用名',
  `app_version` varchar(128) DEFAULT NULL COMMENT '应用版本号，4.2.2',
  `app_version_code` varchar(128) DEFAULT NULL COMMENT '大版本号，4',
  `launch_activity` varchar(128) DEFAULT NULL COMMENT '启动Activity',
  `finger_md5` varchar(256) DEFAULT NULL COMMENT '签名相关指纹',
  `platform_type` varchar(32) DEFAULT NULL COMMENT 'ANDROID、IOS',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0-未删除，1-已删除',
  `is_virus` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0-不是病毒，1-是病毒',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '-2 正在重签名，-1应用进入黑名单，0-上传完成，1-病毒检测完成，2-数据校验完成，3-检测合法性完成，4-检测结果为病毒，5-合法性检测失败',
  `extension` varchar(1024) DEFAULT NULL COMMENT '扩展字段',
  `two_dimensional_code` varchar(1024) DEFAULT NULL COMMENT '重签包存储地址对应的二维码在oss的存储地址',
  `resigned_apk_path` varchar(512) DEFAULT NULL COMMENT '重签包存储在oss地址',
  `qrcode` varchar(1024) DEFAULT NULL COMMENT '二维码地址',
  `min_sdk_version` int(10) unsigned DEFAULT NULL COMMENT 'manifest里指定的minSdkVersion',
  `shrink_analysis` varchar(512) DEFAULT NULL COMMENT '包瘦身扫描的结果',
  `main_url` text COMMENT 'H5App包解析后存储对应的url',
  `param` text,
  PRIMARY KEY (`id`),
  KEY `ins_appname` (`app_name`),
  KEY `ins_status` (`status`),
  KEY `ins_uploadtype` (`upload_type`,`mts_uid`,`platform_type`,`is_deleted`,`is_virus`,`status`,`gmt_create`),
  KEY `ins_mtsuid` (`mts_uid`),
  KEY `ins_packagename` (`package_name`),
  KEY `ins_mtsuid_md5` (`md5`(255),`mts_uid`),
  KEY `ins_appversion` (`app_version`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COMMENT='应用表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_package`
--

LOCK TABLES `mts_package` WRITE;
/*!40000 ALTER TABLE `mts_package` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_package` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_perf_data`
--

DROP TABLE IF EXISTS `mts_perf_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_perf_data` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `execution_id` bigint(20) unsigned NOT NULL COMMENT '任务id',
  `execution_task_suite_id` bigint(20) unsigned NOT NULL COMMENT '任务集id',
  `execution_task_id` bigint(20) unsigned NOT NULL COMMENT '设备任务id',
  `mts_uid` bigint(20) unsigned NOT NULL COMMENT '用户表id',
  `launch_time` int(10) unsigned NOT NULL COMMENT '启动时间(ms)',
  `avg_cpu` float(10,3) NOT NULL COMMENT '平均cpu占用率(%)',
  `max_cpu` float(10,3) NOT NULL COMMENT '峰值cpu占用率(%)',
  `avg_mem` float(10,3) NOT NULL COMMENT '平均内存占用(byte)',
  `max_mem` float(10,3) NOT NULL COMMENT '最大内存占用(byte)',
  `avg_web_traffic` float(10,3) NOT NULL COMMENT '平均流量耗用',
  `avg_battery` float(10,3) NOT NULL COMMENT '平均电量耗用',
  `avg_fps` float(10,3) NOT NULL COMMENT '平均fps',
  `device_type_id` bigint(20) unsigned NOT NULL COMMENT '设备类型id',
  `package_name` varchar(128) DEFAULT NULL COMMENT 'APP包名',
  `app_version` varchar(128) DEFAULT NULL COMMENT '应用版本号，4.2.2',
  `app_version_code` varchar(128) DEFAULT NULL COMMENT '大版本号，4',
  `package_id` bigint(20) unsigned DEFAULT NULL COMMENT '应用id，对应mts_package表',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_execution_task_id` (`execution_task_id`),
  KEY `idx_package_name` (`package_name`),
  KEY `idx_device_type_id` (`device_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8 COMMENT='性能数据表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_perf_data`
--

LOCK TABLES `mts_perf_data` WRITE;
/*!40000 ALTER TABLE `mts_perf_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_perf_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_read_notice`
--

DROP TABLE IF EXISTS `mts_read_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_read_notice` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `notice_id` bigint(20) unsigned NOT NULL COMMENT '消息id',
  `mts_uid` bigint(20) unsigned NOT NULL COMMENT '用户id',
  `is_delete` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'mts_notice系统消息是否已经删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idunique` (`notice_id`,`mts_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='system_notice是否已读';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_read_notice`
--

LOCK TABLES `mts_read_notice` WRITE;
/*!40000 ALTER TABLE `mts_read_notice` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_read_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_remote_case`
--

DROP TABLE IF EXISTS `mts_remote_case`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_remote_case` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `user_id` bigint(20) unsigned NOT NULL COMMENT '用户id',
  `name` varchar(512) NOT NULL COMMENT '用例名',
  `description` varchar(4096) DEFAULT NULL COMMENT '用例描述',
  `step_num` int(10) unsigned DEFAULT NULL COMMENT '步数',
  `step_detail` text COMMENT '步骤，json表示',
  `package_id` bigint(20) unsigned DEFAULT NULL COMMENT '被测包id',
  `app_name` varchar(256) DEFAULT NULL COMMENT '被测包名称',
  `script_id` bigint(20) unsigned DEFAULT NULL COMMENT '脚本id',
  `is_deleted` tinyint(4) NOT NULL COMMENT '是否被删除，0-未删除，1-删除',
  `package_name` varchar(256) NOT NULL COMMENT '被测应用包名',
  `app_version` varchar(256) DEFAULT NULL COMMENT '被测应用版本号',
  `is_draft` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否是草稿，0-－不是，1-－是',
  `script_type` varchar(128) DEFAULT NULL COMMENT '脚本类型：录制脚本，上传脚本',
  `precondition` varchar(4096) DEFAULT NULL COMMENT '前置条件',
  `test_step` varchar(4096) DEFAULT NULL COMMENT '测试步骤',
  `expected_result` varchar(4096) DEFAULT NULL COMMENT '预期结果',
  `lock_user_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '被谁锁定',
  `lock_begin_date` datetime DEFAULT NULL COMMENT '锁定的起始时间',
  `case_version_id` bigint(20) unsigned NOT NULL,
  `case_dir_id` bigint(20) unsigned NULL DEFAULT 0 COMMENT '用例目录id',
  `referred_case_ids` varchar(1024) COMMENT '引用的用例id列表',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=671 DEFAULT CHARSET=utf8 COMMENT='在线录制用例';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_remote_case`
--

LOCK TABLES `mts_remote_case` WRITE;
/*!40000 ALTER TABLE `mts_remote_case` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_remote_case` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_remote_case_func`
--

DROP TABLE IF EXISTS `mts_remote_case_func`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_remote_case_func` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `gmt_create` datetime NOT NULL,
  `gmt_modified` datetime NOT NULL,
  `name` varchar(1024) CHARACTER SET utf8 NOT NULL COMMENT '代码块 名称',
  `func_name` varchar(512) CHARACTER SET utf8 NOT NULL COMMENT '函数名',
  `code` mediumtext CHARACTER SET utf8 NOT NULL COMMENT '代码块',
  `package_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '为 0 表示代码块全局共享，其它表示绑定对应的app',
  `description` varchar(4096) CHARACTER SET utf8 DEFAULT NULL COMMENT '代码块描述',
  `param` varchar(10240) CHARACTER SET utf8 DEFAULT NULL COMMENT '参数',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0',
  `platform_type` varchar(64) NOT NULL DEFAULT 'ANDROID' COMMENT '平台类型，如ANDROID,IOS',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_remote_case_func`
--

LOCK TABLES `mts_remote_case_func` WRITE;
/*!40000 ALTER TABLE `mts_remote_case_func` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_remote_case_func` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_remote_case_suite`
--

DROP TABLE IF EXISTS `mts_remote_case_suite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_remote_case_suite` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `user_id` bigint(20) unsigned NOT NULL COMMENT '用户id',
  `name` varchar(512) NOT NULL COMMENT '用例集名称',
  `description` varchar(8192) DEFAULT NULL COMMENT '用例集描述',
  `case_ids` varchar(1024) NOT NULL COMMENT '下面包含的case_id，逗号隔开',
  `package_id` bigint(20) unsigned DEFAULT NULL,
  `app_name` varchar(512) DEFAULT NULL COMMENT '测试包名称',
  `script_id` bigint(20) unsigned DEFAULT NULL COMMENT '对应脚本id',
  `is_deleted` tinyint(4) DEFAULT '0' COMMENT '是否被删除，1-删除，0-未删除',
  `package_name` varchar(512) NOT NULL COMMENT '被测应用包名',
  `case_module_id` bigint(20) unsigned NOT NULL COMMENT '用例模块id',
  `case_version_id` bigint(20) unsigned NOT NULL COMMENT '参数空间id',
  `script_type` varchar(128) NOT NULL DEFAULT 'RECORD',
  `step_detail` text COMMENT '步骤，json表示，这里主要设置用例参数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2104 DEFAULT CHARSET=utf8 COMMENT='在线录制用例集';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_remote_case_suite`
--

LOCK TABLES `mts_remote_case_suite` WRITE;
/*!40000 ALTER TABLE `mts_remote_case_suite` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_remote_case_suite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_remote_order_debug`
--

DROP TABLE IF EXISTS `mts_remote_order_debug`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_remote_order_debug` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `user_id` bigint(20) unsigned DEFAULT NULL COMMENT '用户id',
  `user_name` varchar(512) DEFAULT NULL COMMENT '用户名',
  `device_id` bigint(20) unsigned DEFAULT NULL COMMENT '设备id',
  `start_time` datetime DEFAULT NULL COMMENT '开始调试时间',
  `status` tinyint(4) DEFAULT NULL COMMENT '0--预约，1--立即调试，2--正在调试',
  `extension` varchar(1024) DEFAULT NULL COMMENT '扩展字段',
  `device_type_id` bigint(20) unsigned DEFAULT NULL COMMENT '设备类型id',
  `has_add_time` tinyint(4) DEFAULT NULL COMMENT '是否增加了时间',
  `port` bigint(20) unsigned DEFAULT NULL COMMENT '端口',
  `third_snapshot` varchar(4096) DEFAULT NULL COMMENT '第三方APP快照',
  `is_exist` tinyint(4) DEFAULT NULL COMMENT '是否存在，0--不存在，1--存在',
  `end_time` datetime DEFAULT NULL COMMENT '结束调试时间',
  `debug_time` datetime DEFAULT NULL COMMENT '远程调试的时间',
  `role_name` varchar(45) DEFAULT NULL COMMENT '提交任务的角色名',
  `service_name` varchar(45) DEFAULT NULL COMMENT '服务名',
  `interval_second` int(11) DEFAULT NULL COMMENT '服务时长，秒',
  `order_id` bigint(20) unsigned DEFAULT NULL COMMENT '订单表id',
  `package_id` varchar(128) DEFAULT NULL COMMENT '对应mts_package表，如果有多个package，则以逗号","分隔，升序排列',
  `free_interval_second` bigint(20) unsigned DEFAULT NULL COMMENT '免费时长，秒',
  `assigned_free_second` bigint(20) unsigned DEFAULT NULL COMMENT '配额分给这个设备的免费时间。如果是预约则没有值。如果开始确认开始使用设备，则存储可用的免费的时间。',
  `charge_time` datetime DEFAULT NULL COMMENT '开始收费的时间',
  PRIMARY KEY (`id`),
  KEY `ins_user_id` (`user_id`),
  KEY `idx_device_type_id` (`device_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=733 DEFAULT CHARSET=utf8 COMMENT='远程调试表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_remote_order_debug`
--

LOCK TABLES `mts_remote_order_debug` WRITE;
/*!40000 ALTER TABLE `mts_remote_order_debug` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_remote_order_debug` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_rerun_task_suite`
--

DROP TABLE IF EXISTS `mts_rerun_task_suite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_rerun_task_suite` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `execution_id` bigint(20) unsigned NOT NULL COMMENT '对应mts_execution表',
  `execution_task_suite_id` bigint(20) unsigned NOT NULL COMMENT '对应mts_execution_task_suite表',
  `asset_num` varchar(128) DEFAULT NULL COMMENT '资产编号',
  `operation` varchar(256) DEFAULT NULL COMMENT 'rerun之前的操作，例如：reboot手机，用来统计哪种操作可以让手机恢复执行',
  `rerun_status` varchar(32) DEFAULT NULL COMMENT 'rerun之后的状态，SUCCESS，FAIL，DEVICE_ERROR',
  `extension` varchar(1024) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8 COMMENT='重试任务表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_rerun_task_suite`
--

LOCK TABLES `mts_rerun_task_suite` WRITE;
/*!40000 ALTER TABLE `mts_rerun_task_suite` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_rerun_task_suite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_role`
--

DROP TABLE IF EXISTS `mts_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_role` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `config_json` text NOT NULL COMMENT '角色配置',
  `priority` int(11) NOT NULL COMMENT '角色优先级',
  `role_name` varchar(64) NOT NULL COMMENT '角色名称',
  `description` varchar(256) DEFAULT NULL COMMENT '角色描述信息',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '记录是否被删除',
  `role_name_ch` varchar(64) NOT NULL COMMENT '角色中文名',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uni_role_name` (`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='用户角色表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_role`
--

LOCK TABLES `mts_role` WRITE;
/*!40000 ALTER TABLE `mts_role` DISABLE KEYS */;
INSERT INTO `mts_role` VALUES (1,'2016-05-27 11:14:14','2017-03-16 19:27:52','{\"H5_FREE\":3,\"SECURITY_FREE\":3,\"ANDROID_COM_FREE\":3,\"IOS_COM_FREE\":3,\"ANDROID_AUTO_FREE\":3,\"IOS_AUTO_FREE\":3,\"ANDROID_STA_FREE\":3,\"REMOTE_DEBUG\":3,\"REMOTE_DEBUG_FREE_SECOND\":300,\"REMOTE_DEBUG_FREE_STEP\":20,\"IOS_REMOTE_DEBUG\":0,\"IOS_REMOTE_DEBUG_FREE_SECOND\":0,\"IOS_REMOTE_DEBUG_FREE_STEP\":100,\"maxCustomEmuNum\":3,\"BRAND_COM_FREE\":3,\"ANDROID_COM_PRIVATE\":40,\"ANDROID_AUTO_PRIVATE\":40,\"IOS_COM_PRIVATE\":40,\"IOS_AUTO_PRIVATE\":40,\"ANDROID_PERF_CHARGE\":3}',0,'FREE_USER','普通用户',0,'普通用户'),(2,'2016-05-27 11:14:52','2017-03-16 19:29:11','{\"H5_FREE\":5,\"SECURITY_FREE\":5,\"ANDROID_COM_FREE\":5,\"IOS_COM_FREE\":5,\"ANDROID_AUTO_FREE\":5,\"IOS_AUTO_FREE\":5,\"ANDROID_STA_FREE\":5,\"REMOTE_DEBUG\":10,\"REMOTE_DEBUG_FREE_SECOND\":600,\"REMOTE_DEBUG_FREE_STEP\":500,\"IOS_REMOTE_DEBUG\":0,\"IOS_REMOTE_DEBUG_FREE_SECOND\":0,\"IOS_REMOTE_DEBUG_FREE_STEP\":100,\"maxCustomEmuNum\":6,\"BRAND_COM_FREE\":5,\"ANDROID_COM_PRIVATE\":40,\"ANDROID_AUTO_PRIVATE\":40,\"IOS_COM_PRIVATE\":40,\"IOS_AUTO_PRIVATE\":40,\"ANDROID_PERF_CHARGE\":5}',1,'COMMON_VIP','普通VIP',0,'普通VIP'),(3,'2016-05-30 11:07:03','2017-03-16 19:30:30','{\"H5_FREE\":5,\"SECURITY_FREE\":5,\"ANDROID_COM_FREE\":5,\"IOS_COM_FREE\":5,\"ANDROID_AUTO_FREE\":5,\"IOS_AUTO_FREE\":5,\"ANDROID_STA_FREE\":5,\"REMOTE_DEBUG\":10,\"REMOTE_DEBUG_FREE_SECOND\":300,\"REMOTE_DEBUG_FREE_STEP\":500,\"IOS_REMOTE_DEBUG\":0,\"IOS_REMOTE_DEBUG_FREE_SECOND\":0,\"IOS_REMOTE_DEBUG_FREE_STEP\":100,\"maxCustomEmuNum\":6,\"BRAND_COM_FREE\":5,\"ANDROID_COM_PRIVATE\":40,\"ANDROID_AUTO_PRIVATE\":40,\"IOS_COM_PRIVATE\":40,\"IOS_AUTO_PRIVATE\":40,\"ANDROID_PERF_CHARGE\":5}',2,'GOLD_VIP','黄金用户',0,'黄金用户');
/*!40000 ALTER TABLE `mts_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_service`
--

DROP TABLE IF EXISTS `mts_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_service` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `service_name` varchar(45) NOT NULL COMMENT '服务标识名',
  `service_name_ch` varchar(45) DEFAULT NULL COMMENT '服务中文名',
  `sku_code` varchar(45) DEFAULT NULL COMMENT '阿里通信商品编码service_code（原汇金商品编码）',
  `price` decimal(12,2) NOT NULL COMMENT '服务单价',
  `spec_json` varchar(256) DEFAULT NULL COMMENT '商品规格信息',
  `service_type` varchar(45) NOT NULL COMMENT '服务类型：预付费PREPAY，消耗型CONSUME，免费型FREE',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '标注是否删除',
  `discount_flag` tinyint(4) NOT NULL DEFAULT '0' COMMENT '折扣标记',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COMMENT='服务商品表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_service`
--

LOCK TABLES `mts_service` WRITE;
/*!40000 ALTER TABLE `mts_service` DISABLE KEYS */;
INSERT INTO `mts_service` VALUES (1,'2016-05-28 22:39:03','2016-08-09 15:38:58','H5_FREE','H5免费','null',0.00,'{\"executionType\":\"H5\"}','FREE',0,0),(2,'2016-05-28 22:39:28','2016-05-30 21:30:24','SECURITY_FREE','安全测试',NULL,0.00,'{\"executionType\":\"SECURITY\"}','FREE',0,0),(3,'2016-05-28 22:40:18','2016-08-05 17:53:15','ANDROID_COM_FREE','Android兼容性测试(随机30款)','$item.skuCode',0.00,'{\"executionType\":\"COMPATIBILITY\", \"duration\":5, \"deviceNum\":30, \"newDeviceTypeIds\":\"249,245,242,246,248,244,214,371,540,649,276,557,561,598,559,597,374,466,498,268,563,564,216,452,638,630,373,642,651,555,372,644,647,556\"}','FREE',0,0),(4,'2016-05-28 22:41:00','2016-05-28 22:41:00','ANDROID_AUTO_FREE','Android功能测试(随机6款)',NULL,0.00,'{\"executionType\":\"AUTOMATION\", \"duration\":5, \"deviceNum\":6}','FREE',0,0),(5,'2016-05-28 22:49:16','2016-05-28 22:49:16','ANDROID_STA_FREE','Android稳定性测试(自定义3款)',NULL,0.00,'{\"executionType\":\"STABILITY\", \"duration\":60,\"deviceNum\":3}','FREE',0,0),(6,'2016-05-28 22:51:57','2017-02-20 15:33:40','IOS_COM_FREE','iOS兼容性测试(随机3款)','$item.skuCode',0.00,'{\"executionType\":\"IOSMONKEY\",\"duration\":5,\"deviceNum\":3, \"newDeviceTypeIds\":\"209,202,207,289,708,709,1023,1154,1155\"}','FREE',0,0),(7,'2016-05-28 22:52:34','2016-09-06 22:12:29','IOS_AUTO_FREE','iOS功能测试(随机3款)','$item.skuCode',0.00,'{\"executionType\":\"IOSFUNCPUB\", \"duration\" : 5, \"deviceNum\":3, \"newDeviceTypeIds\":\"209,202,207,289,708,709\"}','FREE',0,0),(8,'2016-05-28 22:53:40','2017-10-10 17:35:34','ANDROID_COM_CHARGE','Android兼容性测试(自选机型)','100001',10.00,'{\"executionType\":\"COMPATIBILITY\", \"duration\":10}','PREPAY',0,0),(9,'2016-05-28 22:54:32','2016-10-28 21:24:44','ANDROID_AUTO_CHARGE','Android功能测试(自选机型)','100003',10.00,'{\"executionType\":\"AUTOMATION\", \"duration\":30}','PREPAY',0,0),(10,'2016-05-28 22:55:14','2016-08-31 12:54:38','IOS_COM_CHARGE','iOS兼容性测试(自选机型)','100005',20.00,'{\"executionType\":\"IOSMONKEY\", \"duration\" : 20}','PREPAY',0,0),(11,'2016-05-28 22:56:03','2016-10-28 21:26:10','IOS_AUTO_CHARGE','iOS功能测试(自选机型)','100007',20.00,'{\"executionType\":\"IOSFUNCPUB\", \"duration\" : 10}','PREPAY',0,0),(12,'2016-05-28 22:56:50','2017-03-16 19:37:55','REMOTE_DEBUG','Android远程调试','100009',1.00,'{\"duration\":10}','CONSUME',0,0),(19,'2016-05-29 21:18:09','2016-05-29 21:18:09','ANDROID_COM_ALL','Android兼容性测试(全机型)','100002',500.00,'{\"executionType\":\"COMPATIBILITY\", \"duration\":10}','PREPAY',0,6),(20,'2016-05-29 21:20:55','2016-05-29 21:20:55','ANDROID_AUTO_ALL','Android功能测试(全机型)','100004',500.00,'{\"executionType\":\"AUTOMATION\", \"duration\":30}','PREPAY',0,6),(21,'2016-05-29 21:22:29','2016-05-29 21:22:29','IOS_COM_ALL','iOS兼容性测试(全机型)','100006',500.00,'{\"executionType\":\"IOSMONKEY\", \"duration\" : 10}','PREPAY',0,6),(22,'2016-05-29 21:23:56','2016-05-29 21:23:56','IOS_AUTO_ALL','iOS功能测试(全机型)','100008',500.00,'{\"executionType\":\"IOSFUNCPUB\", \"duration\" : 10}','PREPAY',0,6),(23,'2016-06-07 11:11:58','2016-06-07 11:11:58','BRAND_COM_FREE','厂商专区免费测试',NULL,0.00,'{\"executionType\":\"COMPATIBILITY\", \"duration\":30, \"deviceNum\":5}','FREE',0,0),(24,'2016-06-08 19:46:03','2016-08-17 16:40:58','ANDROID_COM_PRIVATE','Android私有设备兼容性测试',NULL,0.00,'{\"executionType\":\"COMPATIBILITY\", \"duration\":5}','FREE',0,0),(25,'2016-06-08 19:46:43','2016-06-08 19:46:43','ANDROID_AUTO_PRIVATE','Android私有设备功能性测试',NULL,0.00,'{\"executionType\":\"AUTOMATION\", \"duration\":30}','FREE',0,0),(26,'2016-06-08 19:47:10','2016-06-08 19:47:10','IOS_COM_PRIVATE','iOS私有设备兼容性测试',NULL,0.00,'{\"executionType\":\"IOSMONKEY\", \"duration\":20}','FREE',0,0),(29,'2016-10-08 19:57:16','2016-10-08 19:57:16','ANDROID_PERF_CHARGE','Android深度性能测试',NULL,0.00,'{\"executionType\":\"PERFORMANCE\", \"duration\":10}','FREE',0,0);
/*!40000 ALTER TABLE `mts_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_settings`
--

DROP TABLE IF EXISTS `mts_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `cfg_name` varchar(50) NOT NULL COMMENT '配置项名字',
  `data_json` longtext NOT NULL COMMENT '具体配置内容json串',
  PRIMARY KEY (`id`),
  KEY `idx_cfg_name` (`cfg_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='设置项（配置项）内容';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_settings`
--

LOCK TABLES `mts_settings` WRITE;
/*!40000 ALTER TABLE `mts_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_stats`
--

DROP TABLE IF EXISTS `mts_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_stats` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `execution_id` bigint(20) unsigned NOT NULL COMMENT '关联任务ID',
  `package_id` bigint(20) unsigned DEFAULT NULL COMMENT '产品对应的版本信息',
  `bug_num` int(11) DEFAULT NULL COMMENT 'bug数量',
  `crash_num` int(11) DEFAULT NULL COMMENT 'crash数量',
  `anr_num` int(11) DEFAULT NULL COMMENT 'anr数量',
  `perf_launch_time` decimal(10,3) DEFAULT NULL COMMENT '性能-启动时间ms',
  `perf_cpu_usage` decimal(10,3) DEFAULT NULL COMMENT '性能-CPU占用率',
  `perf_mem_usage` decimal(10,3) DEFAULT NULL COMMENT '性能-内存占用',
  `is_deleted` tinyint(4) DEFAULT '0' COMMENT '是否被删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_execution_id` (`execution_id`),
  KEY `idx_package_id` (`package_id`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8 COMMENT='产品统计信息存储';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_stats`
--

LOCK TABLES `mts_stats` WRITE;
/*!40000 ALTER TABLE `mts_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_task_config`
--

DROP TABLE IF EXISTS `mts_task_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_task_config` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `mts_uid` bigint(20) NOT NULL COMMENT '用户id，对应mts_user表',
  `test_type` varchar(64) NOT NULL COMMENT '测试类型：稳定性-STABILITY，兼容性-COMPATIBILITY',
  `emails` varchar(1024) DEFAULT NULL COMMENT '通知邮箱',
  `wangwangs` varchar(512) DEFAULT NULL COMMENT '通知旺旺',
  `params` varchar(512) NOT NULL COMMENT '任务参数',
  `call_from` varchar(512) NOT NULL COMMENT '业务方标识',
  `priority` int(11) DEFAULT '0' COMMENT '标志这个业务组提交了execution后的priority。一些用户组他们有自己的设备，还有一些用户组目前在用我们的设备。',
  `status` int(11) DEFAULT '0' COMMENT '标识此配置状态。0是正常使用中，1是已删除，2是已过期（用于黄金用户等配置中）',
  `is_baichuan` int(11) DEFAULT '0' COMMENT '对应mts_user表， is_baichuan字段',
  PRIMARY KEY (`id`),
  KEY `idx_call_from` (`call_from`(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='任务模板';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_task_config`
--

LOCK TABLES `mts_task_config` WRITE;
/*!40000 ALTER TABLE `mts_task_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_task_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_test_abilities`
--

DROP TABLE IF EXISTS `mts_test_abilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_test_abilities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `mts_uid` bigint(20) unsigned NOT NULL COMMENT '用户id，对应mts_user表',
  `ability_version` varchar(32) NOT NULL DEFAULT '1.0.1' COMMENT '测试能力版本号，用于agent本地缓存更新',
  `name` varchar(64) NOT NULL COMMENT '测试能力名字',
  `ability_type` varchar(32) NOT NULL DEFAULT 'GROOVY' COMMENT '测试能力类型：GROOVY，PYTHON',
  `ability_urls` varchar(2048) NOT NULL COMMENT '测试能力脚本下载地址，可能多个',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0-未删除，1-已删除',
  `extension` varchar(1024) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COMMENT='测试能力表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_test_abilities`
--

LOCK TABLES `mts_test_abilities` WRITE;
/*!40000 ALTER TABLE `mts_test_abilities` DISABLE KEYS */;
INSERT INTO `mts_test_abilities` VALUES (1,'2014-12-05 14:31:58','2015-02-02 19:04:13',218,'1.0.1','PRETEST','GROOVY','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/pretest.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/lib.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/ResultAnalyseMultiLineReceiver.groovy',0,NULL),(2,'2014-12-05 14:31:58','2017-12-20 17:48:31',17465,'1.0.1','MONKEY','GROOVY','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/StabilityTest.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/lib.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/NewActivityScreenshotReceiver.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/SceneLib.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/AutoLoginScreenshotReceiver.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/PerformanceLib.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/DropboxManager.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/LogcatFilter.groovy',0,NULL),(3,'2014-12-05 14:31:58','2015-02-02 19:06:07',218,'1.0.1','COVERINSTALL','GROOVY','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/coverInstallTest.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/ExecuteLogcatTask.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/FileWriteMultiLineRecevier.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/lib.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/LogcatManager.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/ResultAnalyseMultiLineReceiver.groovy',0,NULL),(4,'2015-02-02 18:55:32','2016-03-03 22:14:16',17465,'1.0.1','H5','GROOVY','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/h5Test.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/lib.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/H5Standard.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/H5DataProcess.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/redirect_all_resources_V2.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/har.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/ImageProcess.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/YunOS_H5.groovy',0,NULL),(5,'2015-02-02 19:07:30','2015-02-02 19:07:30',218,'1.0.1','REPLAY','GROOVY','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/ReplayScriptTest.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/lib.groovy',0,NULL),(6,'2015-04-30 09:36:14','2017-01-16 10:25:32',17465,'1.0.1','AUTOMATION','GROOVY','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/AutomationTest.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/NewActivityScreenshotReceiver.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/lib.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/ScriptEngines.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/MtsInstrument.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/MtsAppium.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/UserLogcatOrderReceiver.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/SceneLib.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/LogcatFilter.groovy',0,NULL),(7,'2015-08-24 16:42:58','2015-08-24 16:42:58',22,'1.0.1','BROWSER','GROOVY','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/H5forBrowser.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/lib.groovy',0,NULL),(8,'2015-09-06 14:13:25','2017-08-17 23:09:37',17465,'1.0.1','IOSMONKEY','GROOVY','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/iOSMonkey.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/iOSLib.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/iOSCommon.groovy',0,NULL),(9,'2015-09-06 14:15:53','2015-09-08 10:06:51',218,'1.0.1','IMONKEY','GROOVY','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/iMonkeyTest.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/lib.groovy',0,NULL),(12,'2015-12-07 16:43:17','2017-08-17 23:09:52',17465,'1.0.1','IOSFUNCPUB','GROOVY','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/iOSFuncPub.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/iOSFuncPubLib.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/iOSCommon.groovy',0,NULL),(13,'2016-05-14 15:12:05','2016-06-16 20:18:56',22,'1.0.1','YUNOS_GAME','GROOVY','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/YunOS_Compatibility.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/NewActivityScreenshotReceiver.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/SceneLib.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/AutoLoginScreenshotReceiver.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/PerformanceLib.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/DropboxManager.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/lib.groovy',0,NULL),(14,'2016-05-30 17:06:12','2016-05-30 17:06:12',22,'1.0.1','SILENCE','GROOVY','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/SilenceTest.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/lib.groovy',0,NULL),(20,'2016-07-28 16:22:43','2016-07-28 16:22:43',17465,'1.0.1','YUNOS_MEMORYLEAK','GROOVY','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/ThirdPart_MemoryLeak.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/lib.groovy',0,NULL),(21,'2016-09-26 15:55:08','2016-09-26 15:55:08',17465,'1.0.1','YUNOS4_STABILITY','GROOVY','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/Yunos4StatibilityTest.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/Yunos4Lib.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/Yunos4ScreenshotThread.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/Yunos4CaseUtil.groovy',0,NULL),(22,'2016-09-26 15:55:34','2016-09-26 15:55:34',17465,'1.0.1','YUNOS4_AUTOMATION','GROOVY','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/Yunos4_Automation.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/Yunos4CaseUtil.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/Yunos4Lib.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/Yunos4ScreenshotThread.groovy',0,NULL),(23,'2016-10-08 20:20:09','2016-12-16 20:01:11',17465,'1.0.1','PERFORMANCE','GROOVY','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/PerfMonitorTest.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/lib.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/PerfDataCollector.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/PerfMonitorLib.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/PerfStatusCollector.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/PerfStrictCollector.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/NewLib.groovy',0,NULL),(24,'2017-03-30 15:49:49','2017-03-30 16:23:03',17465,'1.0.1','YUNOS4_WEBENGINE','GROOVY','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/Yunos4_Webengine.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/Yunos4ScreenshotThread.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/Yunos4Lib.groovy',0,NULL),(27,'2017-03-30 15:50:22','2017-03-30 16:23:22',17465,'1.0.1','YUNOS4_BROWSER','GROOVY','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/Yunos4_Browser.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/Yunos4ScreenshotThread.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/Yunos4Lib.groovy',0,NULL),(28,'2017-04-24 14:51:46','2017-05-18 10:51:17',17465,'1.0.1','H5_AUTOMATION','GROOVY','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/H5Automation.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/H5Standard.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/H5DataProcess.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/redirect_all_resources_V2.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/ImageProcess.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/lib.groovy',0,NULL),(29,'2017-07-25 09:34:54','2017-12-15 19:39:29',17465,'1.0.1','NEW_AUTOMATION','GROOVY','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/AutomationTestNew.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/lib.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/desired_capabilities.py.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/main.py.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/MqcAppium.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/mts_appium.py.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/MqcInstrument.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/AppiumLib.py.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/uiwatcher.json.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/Parser.groovy',0,NULL),(30,'2017-08-03 13:37:30','2017-08-25 15:32:21',17465,'1.0.1','NEW_IOS_FUNC','GROOVY','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/iOSNewFuncPub.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/ios_desired_capabilities.py.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/mts_appium.py.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/iOSNewFuncPubLib.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/LogAnalyseWhileSaveFileReceiver.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/SaveOutputToFileReceiver.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/Parser.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/AppiumLib.py.ios.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/main.py.groovy',0,NULL),(31,'2017-08-25 20:12:57','2017-08-25 20:12:57',17465,'1.0.1','REMOTE_DEBUG','GROOVY','http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/remoteDebug.groovy,http://swift.mqc.com:8080/v1/AUTH_admin/public/daily/lib.groovy',0,NULL);
/*!40000 ALTER TABLE `mts_test_abilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_user`
--

DROP TABLE IF EXISTS `mts_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `uid` bigint(20) unsigned NOT NULL COMMENT '用户外部id',
  `password` varchar(32) NOT NULL DEFAULT '' COMMENT 'md5加密的密码',
  `user_group_id` bigint(20) unsigned NOT NULL COMMENT '用户组id',
  `user_type` varchar(64) NOT NULL DEFAULT 'TAOBAO' COMMENT '用户来源，如淘宝-TAOBAO、腾讯-TENGXUN、新浪-XINLANG',
  `username` varchar(512) NOT NULL COMMENT '用户名',
  `email` varchar(128) DEFAULT NULL COMMENT '邮箱',
  `vip` tinyint(4) NOT NULL DEFAULT '0' COMMENT '用户级别',
  `description` varchar(512) DEFAULT NULL COMMENT '描述',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `is_in_whitelist` tinyint(4) NOT NULL DEFAULT '1' COMMENT '是否在白名单',
  `extension` varchar(1024) DEFAULT NULL COMMENT '扩展字段',
  `is_baichuan` tinyint(4) DEFAULT '0' COMMENT '是否是百川用户',
  `mobile` varchar(64) DEFAULT NULL COMMENT '用户手机号',
  `device_type_ids` varchar(64) DEFAULT NULL COMMENT '用户创建的模拟器',
  `point` bigint(20) unsigned DEFAULT '0' COMMENT '用户积分',
  `work_experience` tinyint(4) DEFAULT NULL COMMENT '工作经验\n1-在校学生\n2-工作或实习1年以内\n3-工作1-3年\n4-工作3-5年\n5-工作5年以上',
  `address` varchar(128) DEFAULT NULL COMMENT '住址',
  `gender` tinyint(4) DEFAULT NULL COMMENT '性别，0-女，1-男',
  `education` tinyint(4) DEFAULT NULL COMMENT '教育程度\n1-小学及以下\n2-初中\n3-高中\n4-中专\n5-大专\n6-大学本科\n7-硕士\n8-博士\n9-博士以上',
  `crowdtest_type` tinyint(4) DEFAULT '0' COMMENT '众测用户，默认0，1--已验证过邮箱，2--已验证过手机，3--手机和邮箱都验证过',
  `role_name` varchar(64) DEFAULT 'FREE_USER' COMMENT '标志用户类型，默认是普通免费用户（FREE_USER），另有付费用户(PAID_VIP)、黄金用户(GOLD_VIP)。',
  `ip_address` varchar(64) DEFAULT NULL COMMENT '记录用户最近一次登录的IP地址',
  `test_experience` tinyint(4) DEFAULT NULL COMMENT '测试经验\n1-无测试经验\n2-测试经验1年以内\n3-测试经验1-3年\n4-测试经验3-5年\n5-测试经验5年以上',
  `own_device_ids` varchar(1024) DEFAULT NULL COMMENT '用户持有的设备',
  `last_notice_id` bigint(20) unsigned DEFAULT '0' COMMENT '用户最近查看的最后一条消息',
  `config` text COMMENT '保存用户是否有确认法律点信息等。',
  `account_balance` decimal(12,2) DEFAULT '0.00' COMMENT '账户余额，用户记录众测相关的账户信息。和收费充值无关',
  `alipay` varchar(128) DEFAULT NULL COMMENT '支付宝账号',
  `aliyun_pk` bigint(20) unsigned DEFAULT NULL COMMENT 'Aliyun PK后台接口常作为UserID使用',
  `aliyun_subscriber_status` tinyint(4) DEFAULT NULL COMMENT 'xxxxxxxx-未在阿里云开通服务 1xxxxxxx-已在阿里云开通服务 x1xxxxxx-用户已欠费 xx1xxxxx-欠费超期 xxx1xxxx-风控禁止',
  `aliyun_subscriber_status_gmt_update` datetime DEFAULT NULL COMMENT '阿里云用户状态上次更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ins_uid` (`uid`),
  UNIQUE KEY `unq_username` (`username`(255)),
  KEY `index_ip` (`ip_address`),
  KEY `idx_aliyun_pk` (`aliyun_pk`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_user`
--

LOCK TABLES `mts_user` WRITE;
/*!40000 ALTER TABLE `mts_user` DISABLE KEYS */;
INSERT INTO `mts_user` VALUES (1,'2017-08-22 10:33:04','2017-09-13 16:52:40',1503369189231,'21232f297a57a5a743894a0e4a801fc3',1,'TAOBAO','admin','',0,NULL,0,2,'{\"curPerson\":\"0\",\"limitPerson\":\"10\",\"announcement\":\"\",\"demoId\":\"875\"}',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'FREE_USER',NULL,NULL,NULL,NULL,'{\"yunosLoginDeal\":true,\"firstLoginDeal\":true,\"privateDevicesDeal\":\"true\",\"billDeal\":true}',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `mts_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_user_device_suite`
--

DROP TABLE IF EXISTS `mts_user_device_suite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_user_device_suite` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `mts_uid` bigint(20) unsigned NOT NULL COMMENT '用户id',
  `deviceids` varchar(8192) NOT NULL COMMENT '设备ids，以逗号分隔，如：1,2,3',
  `name` varchar(1024) DEFAULT NULL COMMENT '设备组名字',
  `type` text COMMENT '用户所选择的系统版本、分辨率、品牌等组合。比如{platformId:[1,2,3],brandId:[1,2,3], resolutionId:[1,2,3]}',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='用户的设备组集';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_user_device_suite`
--

LOCK TABLES `mts_user_device_suite` WRITE;
/*!40000 ALTER TABLE `mts_user_device_suite` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_user_device_suite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_user_feedback`
--

DROP TABLE IF EXISTS `mts_user_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_user_feedback` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `content` text NOT NULL COMMENT 'json，对话信息',
  `mts_uid` bigint(20) unsigned NOT NULL COMMENT '用户id',
  `notice_id` bigint(20) unsigned DEFAULT NULL COMMENT '消息id',
  `is_delete` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否已经删除',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '反馈状态：0待查看 1已查看',
  `comment` varchar(1024) DEFAULT NULL COMMENT '消息备注，处理状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户反馈';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_user_feedback`
--

LOCK TABLES `mts_user_feedback` WRITE;
/*!40000 ALTER TABLE `mts_user_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_user_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mts_user_group`
--

DROP TABLE IF EXISTS `mts_user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_user_group` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `admin_uid` bigint(20) unsigned NOT NULL COMMENT '管理员id',
  `group_name` varchar(128) NOT NULL COMMENT '组名',
  `group_password` varchar(32) DEFAULT NULL COMMENT '密码，md5',
  `description` varchar(512) DEFAULT NULL COMMENT '描述',
  `group_email` varchar(64) DEFAULT NULL COMMENT '组邮箱',
  `vip` tinyint(4) NOT NULL COMMENT '与个人权限取最高，0表示优先级最低',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否被删除',
  `extension` varchar(1024) DEFAULT NULL COMMENT '扩展字段',
  `max_submit_per_day` bigint(20) DEFAULT '0' COMMENT '该组每天能提交的最大任务数，-1表示无限制',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户组';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mts_user_group`
--

LOCK TABLES `mts_user_group` WRITE;
/*!40000 ALTER TABLE `mts_user_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `mts_user_group` ENABLE KEYS */;
UNLOCK TABLES;


--
-- Table structure for table `mts_chromedriver_version_mapping`
--

DROP TABLE IF EXISTS `mts_chromedriver_version_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mts_chromedriver_version_mapping` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `asset_num` varchar(128) NOT NULL COMMENT '资产编号',
  `package_name` varchar(128) NOT NULL COMMENT '应用包名',
  `chromedriver_version` int(11) NOT NULL COMMENT 'chromedriver版本',
  `extension` varchar(1024) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_asset_num_package_name` (`asset_num`,`package_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='chromedriver版本映射';
/*!40101 SET character_set_client = @saved_cs_client */;