USE `emas_mqc`;
set names utf8;

ALTER TABLE `mts_remote_order_debug`
	MODIFY COLUMN `start_time` datetime NULL COMMENT '开始计费时间',
	MODIFY COLUMN `end_time` datetime NULL COMMENT '结束计费时间',
	ADD COLUMN `sign` varchar(512) NULL COMMENT '远程调试签名',
	ADD COLUMN `begin_time` datetime NULL COMMENT '远程调试启动时间',
	ADD COLUMN `usable_time` datetime NULL COMMENT '远程调试可用时间（前端接收到图片）',
	ADD COLUMN `exit_time` datetime NULL COMMENT '远程调试异常退出时间';