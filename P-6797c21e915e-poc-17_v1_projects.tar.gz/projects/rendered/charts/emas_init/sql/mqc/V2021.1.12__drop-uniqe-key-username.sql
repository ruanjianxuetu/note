USE `emas_mqc`;
set names utf8;

ALTER TABLE `mts_user`
    DROP INDEX unq_username;
