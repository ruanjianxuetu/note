USE `emas_mqc`;
set names utf8;

ALTER TABLE `mts_device_type`
	ADD COLUMN `publish_date` datetime NULL COMMENT '机型发布日期',
	ADD KEY `idx_publish_date` (`publish_date`);

ALTER TABLE `mts_perf_data`
	ADD COLUMN `flr` decimal(10,2) NULL COMMENT '丢帧率';

ALTER TABLE `mts_app_device_perf`
	ADD COLUMN `flr` decimal(10,2) NULL COMMENT '丢帧率',
	ADD KEY `idx_flr` (`flr`);