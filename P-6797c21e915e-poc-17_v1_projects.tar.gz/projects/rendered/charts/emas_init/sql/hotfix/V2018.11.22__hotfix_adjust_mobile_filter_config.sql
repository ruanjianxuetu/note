USE `emas`;
UPDATE `emas_hotfix_config`
SET
  value = '9.*'
WHERE
  namespace = 'PUBLISH_STRATEGY_SOPHIX' AND value = '9.0.*';

INSERT INTO `emas_hotfix_config` (`gmt_create`, `gmt_modified`, `namespace`, `key`, `value`)
VALUES
  (now(), now(), 'PUBLISH_STRATEGY_WAX', 'OS_VERSION', '12.*');
