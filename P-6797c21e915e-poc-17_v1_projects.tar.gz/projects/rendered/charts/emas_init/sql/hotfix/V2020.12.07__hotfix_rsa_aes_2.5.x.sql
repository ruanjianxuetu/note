USE `emas`;
ALTER TABLE `emas_hotfix_apply`
  ADD COLUMN `aes_pair` varchar(128) default null COMMENT 'AES秘钥-内容(key|iv)' ;


CREATE TABLE `emas_hotfix_rsa` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '数据库自增id',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '最后修改时间',
  `app_key` varchar(255) NOT NULL COMMENT 'app key',
  `public_key` varchar(1024) DEFAULT NULL COMMENT 'rsa公钥',
  PRIMARY KEY (`id`),
  KEY `idx_app_key` (`app_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;