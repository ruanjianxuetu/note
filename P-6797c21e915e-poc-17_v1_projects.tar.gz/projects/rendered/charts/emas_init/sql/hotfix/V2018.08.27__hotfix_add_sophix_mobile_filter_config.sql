USE `emas`;
INSERT INTO `emas_hotfix_config` (`gmt_create`, `gmt_modified`, `namespace`, `key`, `value`)
VALUES
  (now(), now(), 'PUBLISH_STRATEGY_DEXPATCH', 'OS_VERSION', '8.1.*'),
  (now(), now(), 'PUBLISH_STRATEGY_SOPHIX', 'OS_VERSION', '4.0.*'),
  (now(), now(), 'PUBLISH_STRATEGY_SOPHIX', 'OS_VERSION', '4.1.*'),
  (now(), now(), 'PUBLISH_STRATEGY_SOPHIX', 'OS_VERSION', '4.2.*'),
  (now(), now(), 'PUBLISH_STRATEGY_SOPHIX', 'OS_VERSION', '4.3.*'),
  (now(), now(), 'PUBLISH_STRATEGY_SOPHIX', 'OS_VERSION', '4.4.*'),
  (now(), now(), 'PUBLISH_STRATEGY_SOPHIX', 'OS_VERSION', '5.0.*'),
  (now(), now(), 'PUBLISH_STRATEGY_SOPHIX', 'OS_VERSION', '5.1.*'),
  (now(), now(), 'PUBLISH_STRATEGY_SOPHIX', 'OS_VERSION', '6.0.*'),
  (now(), now(), 'PUBLISH_STRATEGY_SOPHIX', 'OS_VERSION', '7.0.*'),
  (now(), now(), 'PUBLISH_STRATEGY_SOPHIX', 'OS_VERSION', '7.1.*'),
  (now(), now(), 'PUBLISH_STRATEGY_SOPHIX', 'OS_VERSION', '8.0.*'),
  (now(), now(), 'PUBLISH_STRATEGY_SOPHIX', 'OS_VERSION', '8.1.*'),
  (now(), now(), 'PUBLISH_STRATEGY_SOPHIX', 'OS_VERSION', '9.0.*');
