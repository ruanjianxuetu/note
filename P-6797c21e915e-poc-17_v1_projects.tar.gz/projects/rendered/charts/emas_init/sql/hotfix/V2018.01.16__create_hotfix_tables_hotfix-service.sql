USE `emas`;
# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 47.96.131.244 (MySQL 5.5.5-10.2.11-MariaDB)
# Database: emas
# Generation Time: 2018-01-16 06:50:52 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;



# Dump of table emas_hotfix_workspace
# patch的发布区条目，appId-appVersion-patchType联合唯一
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `emas_hotfix_workspace` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '数据库自增id',
  `status` tinyint(4) NOT NULL COMMENT '1: 正常\n-1: 已删除',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '最后修改时间',
  `creator` varchar(63) NOT NULL COMMENT '创建人',
  `modifier` varchar(63) NOT NULL COMMENT '最后修改人',
  `app_id` bigint(20) NOT NULL,
  `app_key` varchar(45) NOT NULL COMMENT 'app_key，来自产品表',
  `platform` varchar(45) NOT NULL COMMENT 'app对应系统平台',
  `app_version` varchar(45) NOT NULL COMMENT 'app版本号',
  `patch_type` tinyint(4) NOT NULL COMMENT '1 - dexpatch\n2 - wax\n3 - sophix',
  `project_id` bigint(20) DEFAULT NULL COMMENT 'dexpatch下的集成区项目id\n',
  `current_pub_version` int(11) DEFAULT NULL COMMENT 'dexpatch下的发布单当前最大版本号',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8;



# Dump of table emas_hotfix_apply
# 存储发布需求单相关的信息
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `emas_hotfix_apply` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '数据库自增id',
  `status` tinyint(4) NOT NULL COMMENT '-1：已删除\n1：回归中\n2：灰度中\n3：已发布',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '最后修改时间',
  `creator` varchar(63) NOT NULL COMMENT '创建人',
  `modifier` varchar(63) NOT NULL COMMENT '最后修改人',
  `version` int(10) NOT NULL COMMENT '需求单版本号',
  `workspace_id` bigint(20) NOT NULL COMMENT '需求所在的发布区id',
  `hotfix_type` tinyint(4) DEFAULT NULL COMMENT 'hotfix需求类型 - \n1: 不区分\n2: 故障\n3: 缺陷\n4: 需求',
  `hotfix_desc` text DEFAULT NULL COMMENT '发布patch的原因',
  `repo_basic_address` varchar(1000) DEFAULT NULL COMMENT '仓库地址',
  `repo_branch` varchar(150) DEFAULT NULL COMMENT '仓库分支',
  `project_id` bigint(20) DEFAULT NULL COMMENT 'dexpatch下的个人项目Id',
  `beta_form_id` bigint(20) DEFAULT NULL COMMENT 'dexpatch下的灰度发布单id\n',
  `release_form_id` bigint(20) DEFAULT NULL COMMENT 'dexpatch下的正式发布单id\n',
  `progress` varchar(20) DEFAULT NULL COMMENT '该需求单已经进行到哪个阶段',
  PRIMARY KEY (`id`),
  KEY `workspace_id` (`workspace_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8;



# Dump of table emas_hotfix_package
# 每个发布单构建发布包时，存储发布包对应的构建号
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `emas_hotfix_package` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '数据库自增id',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '最后修改时间',
  `apply_id` bigint(20) NOT NULL COMMENT 'apply id',
  `isolate_build_id` bigint(20) NOT NULL COMMENT '独立构建的构建id',
  `integrate_build_id` bigint(20) NOT NULL COMMENT '集成构建的构建id，只在dexpatch下有意义',
  `isolate_locked` tinyint(4) NOT NULL COMMENT '独立构建是否已经锁定',
  `integrate_locked` tinyint(4) NOT NULL COMMENT '集成构建是否已经锁定',
  PRIMARY KEY (`id`),
  UNIQUE KEY `apply_id` (`apply_id`),
  KEY `isolate_build_id` (`isolate_build_id`),
  KEY `integrate_build_id` (`integrate_build_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8;



# Dump of table emas_hotfix_patch
# 自建patch流程的patch包信息，包括wax、sophix等
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `emas_hotfix_patch` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '数据库自增id',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '最后修改时间',
  `patch_uuid` varchar(80) NOT NULL COMMENT 'patch唯一标识id',
  `build_id` bigint(20) NOT NULL COMMENT 'patch属于哪次构建的产物',
  `patch_size` int(10) DEFAULT NULL COMMENT 'patch包大小',
  `patch_url` varchar(1000) DEFAULT NULL COMMENT 'patch下载url',
  `patch_md5` varchar(33) DEFAULT NULL COMMENT 'patch包md5',
  `attribute` text DEFAULT NULL COMMENT 'patch额外属性',
  PRIMARY KEY (`id`),
  UNIQUE KEY `patch_uuid_UNIQUE` (`patch_uuid`),
  UNIQUE KEY `build_id` (`build_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8;



# Dump of table emas_hotfix_pub_batch
# 存储自建patch流程批次的信息
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `emas_hotfix_pub_batch` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '数据库自增id',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '最后修改时间',
  `apply_id` bigint(20) NOT NULL COMMENT '发布需求id',
  `pub_version` bigint(10) NOT NULL COMMENT '发布批次',
  `strategy_id` bigint(20) NOT NULL COMMENT 'publish strategy id',
  `status` tinyint(4) NOT NULL COMMENT '发布状态 -\n1: ACTIVE\n2: HALTED\n3: FINISHED',
  `start_time` datetime DEFAULT NULL COMMENT '发布任务开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '发布任务结束时间',
  `creator` varchar(63) NOT NULL,
  `modifier` varchar(63) NOT NULL,
  `type` tinyint(4) NOT NULL COMMENT '发布类型 -\n1: 全量\n2: 灰度',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8;



# Dump of table emas_hotfix_pub_batch_stat
# 自建patch流程批次的相关统计信息
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `emas_hotfix_pub_batch_stat` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '数据库自增id',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '最后修改时间',
  `batch_id` bigint(20) NOT NULL COMMENT '对应发布单id',
  `push_success_count` int(10) DEFAULT NULL COMMENT '下载成功设备数',
  `download_success_count` int(10) DEFAULT NULL COMMENT '下载成功设备数',
  `preload_success_count` int(10) DEFAULT NULL COMMENT '预加载成功设备数',
  `load_success_count` int(10) DEFAULT NULL COMMENT '加载patch成功设备数',
  `clean_success_count` int(10) DEFAULT NULL COMMENT '清除patch成功的设备数',
  PRIMARY KEY (`id`),
  UNIQUE KEY `publish_id` (`batch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8;



# Dump of table emas_hotfix_pub_strategy
# 自建patch流程批次的策略
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `emas_hotfix_pub_strategy` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '数据库自增id',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '最后修改时间',
  `type` tinyint(4) NOT NULL COMMENT '发布类型 - \n1：全量发布\n2：实时灰度\n3：白名单灰度',
  `preview_count` int(10) DEFAULT NULL COMMENT '灰度发布人数，仅在发布类型为灰度是有意义',
  `preset_start_time` datetime DEFAULT NULL COMMENT '预设开始时间',
  `preset_end_time` datetime DEFAULT NULL COMMENT '预设结束时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
