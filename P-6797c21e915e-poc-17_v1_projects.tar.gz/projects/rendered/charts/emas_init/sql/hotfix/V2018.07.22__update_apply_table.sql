USE `emas`;
ALTER TABLE `emas_hotfix_apply`
  ADD COLUMN `build_time` DATETIME DEFAULT NULL AFTER `release_form_id`,
  ADD COLUMN `publish_project_id` BIGINT(10) DEFAULT 0 AFTER `build_time`,
  ADD COLUMN `pubserv_publish_id` BIGINT(20) DEFAULT 0 AFTER `publish_project_id`;

# 兼容处理
UPDATE `emas_hotfix_apply` SET `pubserv_publish_id` = `beta_form_id`;
