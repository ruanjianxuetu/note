USE `emas`;
alter table `emas_hotfix_pub_strategy` add column `tags` varchar(1023) default null comment '需要匹配的标签JSON列表';
