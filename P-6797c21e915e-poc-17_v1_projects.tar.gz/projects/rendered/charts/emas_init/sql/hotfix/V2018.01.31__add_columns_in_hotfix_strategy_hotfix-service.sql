USE `emas`;
ALTER TABLE `emas_hotfix_pub_strategy`
  ADD `os_version` varchar(255) DEFAULT NULL COMMENT '系统版本JSON列表',
  ADD `brand` varchar(1023) DEFAULT NULL COMMENT '手机品牌JSON列表，只对安卓适用',
  ADD `model` varchar(1023) DEFAULT NULL COMMENT '手机机型JSON列表，只对安卓适用',
  ADD `excluded_brand` varchar(1023) DEFAULT NULL COMMENT '排除的手机品牌JSON列表',
  ADD `excluded_model` varchar(1023) DEFAULT NULL COMMENT '排除的手机机型JSON列表';

