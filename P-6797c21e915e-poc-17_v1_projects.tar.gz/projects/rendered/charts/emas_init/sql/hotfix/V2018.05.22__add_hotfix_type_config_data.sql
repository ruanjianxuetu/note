USE `emas`;
INSERT INTO `emas_hotfix_config` (`gmt_create`, `gmt_modified`, `namespace`, `key`, `value`)
VALUES
  ('2018-05-22 15:20:12', '2018-05-22 15:20:12', 'HOTFIX_AVAIL_TYPE', 'ANDROID', 'DEXPATCH,SOPHIX'),
  ('2018-05-22 15:20:30', '2018-05-22 15:20:30', 'HOTFIX_AVAIL_TYPE', 'IOS', 'WAX'),
  ('2018-05-22 15:21:10', '2018-05-22 15:21:10', 'HOTFIX_PROCESS_NODE', 'DEXPATCH', 'change,build,isolate_pack,isolate_pub,integrate_pack,integrate_pub'),
  ('2018-05-22 15:21:29', '2018-05-22 15:21:29', 'HOTFIX_PROCESS_NODE', 'SOPHIX', 'build,isolate_pack,isolate_pub'),
  ('2018-05-22 15:21:46', '2018-05-22 15:21:46', 'HOTFIX_PROCESS_NODE', 'WAX', 'build,isolate_pack,isolate_pub');

