USE `emas`;
ALTER TABLE `emas_hotfix_patch`
  ADD COLUMN `description` VARCHAR(200) DEFAULT "" AFTER `patch_md5`,
  MODIFY COLUMN `build_id` BIGINT(20) DEFAULT NULL;
