USE `emas`;
# 新增扩展的strategy，方便后续发布策略扩展
CREATE TABLE `emas_hotfix_pub_strategy_ext` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `creator` varchar(64) NOT NULL COMMENT '创建人',
  `modifier` varchar(64) NOT NULL COMMENT '修改人',
  `batch_id` bigint(20) DEFAULT NULL COMMENT '批次ID',
  `strategy_type` varchar(64) NOT NULL COMMENT '策略类型',
  `params` text NOT NULL COMMENT '策略参数',
  PRIMARY KEY (`id`),
  KEY `batch_id_idx` (`batch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='批次策略';
