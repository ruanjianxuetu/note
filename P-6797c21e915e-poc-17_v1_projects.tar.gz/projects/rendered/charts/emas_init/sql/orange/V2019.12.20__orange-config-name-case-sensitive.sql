USE `emas`;
alter table wap_orange_config modify column `name` varchar(64) CHARACTER set utf8 COLLATE utf8_bin not null comment '配置名称，appKey内唯一';
