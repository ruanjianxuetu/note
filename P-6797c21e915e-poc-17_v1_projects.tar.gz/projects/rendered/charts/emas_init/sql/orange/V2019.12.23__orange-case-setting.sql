USE `emas`;
alter table wap_orange_config_snapshot modify `case_snapshot_ids` text not null comment '包含的场景列表ID';

alter table wap_orange_config_change modify `detail` mediumtext not null comment '变更内容详情';

