USE `emas`;
drop table  if EXISTS  wap_orange_dictionary;
create table `wap_orange_dictionary` (
  `id` bigint unsigned  not null auto_increment comment '主键',
  `gmt_create` datetime  not null comment '创建时间',
  `gmt_modified` datetime  not null comment '修改时间',
  `dict_code` varchar(128)  not null comment '字典表code，唯一标志',
  `dict_name` varchar(128)  not null comment '字典表名称',
  `dict_desc` varchar(256) comment '字典表描述',
  `creator` varchar(32)  not null comment '记录创建者',
  `modifier` varchar(32)  not null comment '记录修改者',
  primary key (id),
  unique key `uk_dict_code` (dict_code)
) comment='orange字典表';
drop table  if EXISTS  wap_orange_dictionary_item;
create table `wap_orange_dictionary_item` (
  `id` bigint unsigned  not null auto_increment comment '主键',
  `gmt_create` datetime  not null comment '创建时间',
  `gmt_modified` datetime  not null comment '修改时间',
  `dict_item_key` varchar(128)  not null comment '字典项key，唯一标识',
  `dict_item_value` text  not null comment '字典项值',
  `dict_item_desc` varchar(256) comment '字典项描述',
  `dict_code` varchar(128)  not null comment '字典项所属的字典',
  `creator` varchar(32)  not null comment '记录创建者',
  `modifier` varchar(32)  not null comment '记录修改者',
  primary key (id),
  unique key `uk_dict_item_key` (dict_item_key)
) comment='orange字典表项';


drop table  if EXISTS  wap_orange_config;
create table `wap_orange_config` (
	`id` bigint unsigned  not null auto_increment comment '主键',
	`gmt_create` datetime  not null comment '创建时间',
	`gmt_modified` datetime  not null comment '修改时间',
	`config_id` varchar(50)  not null comment 'Config的唯一业务ID',
`name` varchar(30)  not null comment '配置名称，appKey内唯一',
`app_key` varchar(30)  not null comment '配置所属应用appKey',
`detail` varchar(1000)  null comment '配置说明',
`type` smallint unsigned  not null comment '配置内容类型: KV(1),CUSTOM(3)',
`load_level` smallint unsigned  not null comment '配置加载级别: HIGH(10),DEFAULT(0)''',
`owners` varchar(1000)  not null comment '负责人，多个以,分隔',
`creator` varchar(50)  not null comment '创建者id',
`modifier` varchar(50)  default null comment '最后修改者id',
  `available` SMALLINT not null COMMENT '1在线，0下线',
primary key (id),
unique key `uk_config_id` (config_id),
unique key `uk_app_key_config_name` (app_key,name)
) comment='配置基本信息表';

drop table  if EXISTS  wap_orange_config_snapshot;
create table `wap_orange_config_snapshot` (
  `id` bigint unsigned  not null auto_increment comment '主键',
  `gmt_create` datetime  not null comment '创建时间',
  `gmt_modified` datetime  not null comment '修改时间',
  `config_snapshot_id` varchar(50)  not null comment '业务唯一ID',
  `config_change_id` varchar(50)  not null comment '所属的变更单ID',
  `config_id` varchar(50)  not null comment '所属configId',
  `case_snapshot_ids` varchar(1024) null comment '包含的场景列表ID',
  `available` smallint unsigned  not null comment '生效中：1失效：0,同一个config_id下只有一个可用',
  primary key (id),
  unique key `uk_config_snapshot_id` (config_snapshot_id),
  key `idx_config_id_available` (config_id,available),
  key `idx_config_change_id` (config_change_id)
) comment='config快照表';

drop table  if EXISTS  wap_orange_config_case_snapshot;
create table `wap_orange_config_case_snapshot` (
  `id` bigint unsigned  not null auto_increment comment '主键',
  `gmt_create` datetime  not null comment '创建时间',
  `gmt_modified` datetime  not null comment '修改时间',
  `case_snapshot_id` varchar(50)  not null comment '唯一业务ID',
  `config_id` varchar(50)  not null comment '所属configId',
  `case_id` varchar(50)  not null comment '修改产生的case此id会复制传递。',
  `name` varchar(20)  not null comment '场景名称',
  `expression` varchar(500)  not null comment '条件表达式',
  `content` text  not null comment '内容',
  `content_ref` text  not null comment '内容引用，内容被静态服务器托管的访问id',
  `content_digest` text  not null comment '内容摘要',
  `priority` int  comment '优先级的值值越大越优先匹配',
  `available` SMALLINT not null comment '0可用，1不可用，同一个config_id下的同一个case_id下只有一个可用',
  primary key (id),
  unique key `uk_case_snapshot_id` (case_snapshot_id)
) comment='场景快照';


drop table  if EXISTS  wap_orange_config_change;
create table `wap_orange_config_change` (
  `id` bigint unsigned  not null auto_increment comment '主键',
  `gmt_create` datetime  not null comment '创建时间',
  `gmt_modified` datetime  not null comment '修改时间',
  `config_change_id` varchar(50)  not null comment '业务唯一ID',
  `config_id` varchar(50)  not null comment '所属config',
  `detail` varchar(2000)  not null comment '变更内容详情',
  `creator` varchar(20) comment '创建人',
  `operator` varchar(20) comment '审核人/操作人',
  `status` smallint unsigned  not null comment '状态',
  `based_snapshot_id` varchar(50) comment '基于哪个快照的变更,可能为空',
  `invoked_snapshot_id` varchar(50) comment '变更执行后生成的快照指向,可能为空',
  primary key (id),
  key `idx_config_id_status` (config_id,status)
) comment='变更记录';

drop table if EXISTS wap_orange_app_snapshot_item ;
create table `wap_orange_app_snapshot_item` (
  `id` bigint unsigned  not null auto_increment comment '主键',
  `gmt_create` datetime  not null comment '创建时间',
  `gmt_modified` datetime  not null comment '修改时间',
  `app_key` varchar(30)  not null comment 'app_key',
  `base_id` varchar(50)  not null comment '全量的索引快照id',
  `incs` varchar(1000)  comment '增量的索引快照详情',
  `digest` varchar(100)  comment '内容摘要',
  `prefix` varchar(100)  comment '索引的地址前缀',
  primary key (id),
  unique key `uk_app_key` (app_key)
) comment='应用快照摘要';

drop table if EXISTS wap_orange_app_snapshot;
create table `wap_orange_app_snapshot` (
  `id` bigint unsigned  not null auto_increment comment '主键',
  `gmt_create` datetime  not null comment '创建时间',
  `gmt_modified` datetime  not null comment '修改时间',
  `app_key` varchar(30)  not null comment 'app_key',
  `app_snapshot_id` varchar(50)  not null comment '本次发布的快照ID，唯一',
  `detail` TEXT not null COMMENT '快照内容详情',
  primary key (id)
) comment='应用快照详情';

drop table if EXISTS wap_orange_push_task;
create table `wap_orange_push_task` (
  `id` bigint unsigned  not null auto_increment comment '主键',
  `gmt_create` datetime  not null comment '创建时间',
  `gmt_modified` datetime  not null comment '修改时间',
  `task_id` varchar(128)  not null comment '任务id',
  `task_type` int  not null comment '任务类型',
  `config_id` varchar(128)  not null comment '配置唯一标识',
  `target_range` int  not null comment '推送目标类型：APP/APP+VERSION/DEVICE',
  `target` varchar(1024)  not null comment '如果targetRange=APP,target为appKey; 如果targetRange=APP+VERSION,target=appKey:appVersion；如果targetRange=DEVICE，target为utdid',
  `msg_from_console` text  not null comment 'orange控制台前端给服务端的消息内容',
  `need_response` boolean  not null comment '是否需要response',
  `msg_to_app` text  not null comment 'orange服务端给app的消息内容',
  primary key (id),
  unique key `uk_taskid` (task_id)
) comment='orange push任务内容';

drop table if EXISTS wap_orange_push_task_execute;
create table `wap_orange_push_task_execute` (
  `id` bigint unsigned  not null auto_increment comment '主键',
  `gmt_create` datetime  not null comment '创建时间',
  `gmt_modified` datetime  not null comment '修改时间',
  `task_id` varchar(128)  not null comment '任务唯一标识',
  `target` varchar(128)  not null comment '目标设备',
  `msg_status` int  not null comment '消息状态',
  `response_data` text comment 'app相应数据',
  primary key (id),
  unique key `uk_taskid_target` (task_id,target)
) comment='orange推送任务执行状态';

drop table if EXISTS wap_orange_publish_record;
create table `wap_orange_publish_record` (
  `id` bigint unsigned  not null auto_increment comment '主键',
  `gmt_create` datetime  not null comment '创建时间',
  `gmt_modified` datetime  not null comment '修改时间',
  `app_key` varchar(64)  not null comment 'app唯一标识',
  `change_cnt` int  not null comment '变更次数',
  primary key (id),
  unique key `uk_appkey` (app_key)
) comment='app配置变更记录(两次发布diamond期间app变更)';
