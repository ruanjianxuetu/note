
use emas_ha;

alter table emas_ha_overview add saved tinyint(1) default 0 not null;

update emas_ha_overview set saved = 1 where directoryId in (
    select id from emas_ha_directory where directoryType = 1
);
