INSERT INTO `emas_ha`.`emas_ha_report_type` (gmt_create, gmt_modified, type_id, log_category, name, core_content_type, os, display_name, description, status)
VALUES ( '2018-11-20 17:34:00', '2018-11-20 17:34:00', 'd012', 'CUSTOM_ERROR', 'H5_ERROR', 'JS_STACK', 'ANDROID',
            'H5 Js错误', 'H5 js error', 'NORMAL');
INSERT INTO `emas_ha`.`emas_ha_report_type` (gmt_create, gmt_modified, type_id, log_category, name, core_content_type, os, display_name, description, status)
VALUES ( '2018-11-20 17:34:00', '2018-11-20 17:34:00', 'd013', 'CUSTOM_ERROR', 'H5_ERROR', 'JS_STACK', 'IOS',
            'H5 Js错误', 'H5 js error', 'NORMAL');