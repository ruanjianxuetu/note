-- crash消费配置,修改kafka server

INSERT INTO `emas_ha`.`emas_ha_report_subscribe`
(`gmt_create`, `gmt_modified`, `topic`, `data_source`, `data_block_type`, `group_id`, `access_key`, `queue_size`, `ext_data`, `author`, `server`, `status`, `consumer_app`)
VALUES
  ('2017-11-22 15:43:40', '2017-11-22 15:43:40', 'emas-crash', 'KAFKA', 'UT', 'emas-ha-report', NULL, NULL, NULL,
                          NULL,
                          '$<<emas_kafka_host>>:$<<emas_kafka_port>>', 'NORMAL', 'report');



INSERT INTO `emas_ha`.`emas_ha_report_subscribe`
(`gmt_create`, `gmt_modified`, `topic`, `data_source`, `data_block_type`, `group_id`, `access_key`, `queue_size`, `ext_data`, `author`, `server`, `status`, `consumer_app`)
VALUES
  ('2017-11-22 15:43:40', '2017-11-22 15:43:40', 'emas-etl-es', 'KAFKA', 'UT', 'emas-ha-error', NULL, NULL, NULL,
                          NULL,
                          '$<<emas_kafka_host>>:$<<emas_kafka_port>>', 'NORMAL', 'tracking');