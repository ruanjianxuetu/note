INSERT INTO `emas_ha`.`emas_ha_report_type` ( gmt_create, gmt_modified, type_id, log_category, name, core_content_type, os, display_name, description, status)
VALUES ( '2017-12-04 11:58:24', '2017-12-04 11:58:24', 'd001', 'CUSTOM_ERROR', 'WEEX_ERROR', 'JS_STACK', 'ANDROID',
           'Weex Js错误', 'weex js error', 'NORMAL');
INSERT INTO `emas_ha`.`emas_ha_report_type` (gmt_create, gmt_modified, type_id, log_category, name, core_content_type, os, display_name, description, status)
VALUES ( '2017-12-04 11:58:24', '2017-12-04 11:58:24', 'd002', 'CUSTOM_ERROR', 'WEEX_ERROR', 'JS_STACK', 'IOS',
           'Weex Js错误', 'weex js error', 'NORMAL');

INSERT INTO `emas_ha`.`emas_ha_report_type` (gmt_create, gmt_modified, type_id, log_category, name, core_content_type, os, display_name, description, status)
VALUES
  ('2017-12-04 11:58:24', '2017-12-04 11:58:24', 'd003', 'CUSTOM_ERROR', 'HA_MEM_LEAK', 'TEXT_CONTENT', 'ANDROID', '内存泄露',
   '内存泄露', 'NORMAL');

INSERT INTO `emas_ha`.`emas_ha_report_type` (gmt_create, gmt_modified, type_id, log_category, name, core_content_type, os, display_name, description, status)
VALUES
  ('2017-12-04 11:58:24', '2017-12-04 11:58:24', 'd004', 'CUSTOM_ERROR', 'HA_MEM_LEAK', 'IOS_STACK', 'IOS', '内存泄露',
      '内存泄露', 'NORMAL');
INSERT INTO `emas_ha`.`emas_ha_report_type` (gmt_create, gmt_modified, type_id, log_category, name, core_content_type, os, display_name, description, status)
VALUES
  ( '2017-12-04 11:58:24', '2017-12-04 11:58:24', 'd006', 'CUSTOM_ERROR', 'HA_MAIN_THREAD_IO', 'JAVA_STACK', 'ANDROID',
      '主线程IO', '主线程IO', 'NORMAL');
INSERT INTO `emas_ha`.`emas_ha_report_type` (gmt_create, gmt_modified, type_id, log_category, name, core_content_type, os, display_name, description, status)
VALUES ( '2017-12-04 11:58:24', '2017-12-04 11:58:24', 'd007', 'CUSTOM_ERROR', 'HA_BIG_BITMAP', 'JAVA_STACK', 'ANDROID',
           '大内存图片', '大内存图片', 'NORMAL');
INSERT INTO `emas_ha`.`emas_ha_report_type` (gmt_create, gmt_modified, type_id, log_category, name, core_content_type, os, display_name, description, status)
VALUES
  ( '2017-12-04 11:58:24', '2017-12-04 11:58:24', 'd008', 'CUSTOM_ERROR', 'HA_FD_OVERFLOW', 'JAVA_STACK', 'ANDROID',
      '文件句柄使用过量', '文件句柄使用过量', 'NORMAL');
INSERT INTO `emas_ha`.`emas_ha_report_type` (gmt_create, gmt_modified, type_id, log_category, name, core_content_type, os, display_name, description, status)
VALUES
  ( '2017-12-04 11:58:24', '2017-12-04 11:58:24', 'd009', 'CUSTOM_ERROR', 'HA_RESOURCE_LEAK', 'JAVA_STACK', 'ANDROID',
      '资源泄露', '资源泄露', 'NORMAL');
INSERT INTO `emas_ha`.`emas_ha_report_type` (gmt_create, gmt_modified, type_id, log_category, name, core_content_type, os, display_name, description, status)
VALUES ( '2017-12-04 11:58:24', '2017-12-04 11:58:24', 'd010', 'CUSTOM_ERROR', 'HA_LEAK_ALIVE_OBJECT', 'IOS_STACK',
           'IOS', '对象存活数量', '对象存活数量', 'NORMAL');
INSERT INTO `emas_ha`.`emas_ha_report_type` (gmt_create, gmt_modified, type_id, log_category, name, core_content_type, os, display_name, description, status)
VALUES ( '2017-12-04 11:58:24', '2017-12-04 11:58:24', 'd011', 'CUSTOM_ERROR', 'HA_BIG_MALLOC', 'IOS_STACK', 'IOS',
            '大内存分配', '大内存分配', 'NORMAL');