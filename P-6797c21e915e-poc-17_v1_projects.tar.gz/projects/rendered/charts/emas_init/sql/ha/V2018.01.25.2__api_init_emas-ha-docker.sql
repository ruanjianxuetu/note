INSERT INTO `emas_ha`.`emas_ha_api_consumer` (client_name, client_key, status, params, type, description, owner, gmt_create, gmt_modified)
VALUES ('emas-log-agent', '3ba716cdb548b930a50c33aa035652ca', 'NORMAL',
        '{"apiPurview":"SPECIFIED","apis":"LogAgentApi","purview":"ALL_APP"}', 'PRIVATE', 'emas-log-agent', NULL,
        '2017-12-12 14:21:43', '2017-12-12 14:21:43');
INSERT INTO `emas_ha`.`emas_ha_api_consumer` (client_name, client_key, status, params, type, description, owner, gmt_create, gmt_modified)
VALUES
  ('emas-publish-parent', '12cbf9db9de9789e6e2ea251b7cb35ff', 'NORMAL', '{"apiPurview":"ALL_API","purview":"ALL_APP"}',
   'PRIVATE', 'emas-publish-parent', NULL, '2017-12-12 14:21:43', '2017-12-12 14:21:43');
INSERT INTO `emas_ha`.`emas_ha_api_consumer` (client_name, client_key, status, params, type, description, owner, gmt_create, gmt_modified)
VALUES ('emas_ha_weex', '3d1e23853de266cfed8a9fc718580d41', 'NORMAL', '{"apiPurview":"ALL_API","purview":"ALL_APP"}',
        'PRIVATE', 'emas_ha_weex', NULL, '2017-12-18 11:41:13', '2017-12-18 11:41:13');
INSERT INTO `emas_ha`.`emas_ha_api_consumer` (client_name, client_key, status, params, type, description, owner, gmt_create, gmt_modified)
VALUES ('emas-hotfix', '9445b55ac8737f29b87da99232dfe486', 'NORMAL', '{"apiPurview":"ALL_API","purview":"ALL_APP"}',
        'PRIVATE', 'emas-hotfix', NULL, '2017-12-18 11:41:13', '2017-12-18 11:41:13');
