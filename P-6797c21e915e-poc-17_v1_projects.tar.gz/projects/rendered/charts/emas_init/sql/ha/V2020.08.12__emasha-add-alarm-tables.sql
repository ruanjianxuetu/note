use emas_ha;

CREATE TABLE `emas_ha_alarm_item_new` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `name` varchar(256) NOT NULL COMMENT '名称',
  `alarm_id` bigint(20) NOT NULL COMMENT 'alarm id',
  `unique_app_id` varchar(32) NOT NULL COMMENT 'app id',
  `category` varchar(32) NOT NULL COMMENT '类别',
  `subscribers` text COMMENT '订阅人列表',
  `filters` text COMMENT '维度过滤器',
  `rules` text COMMENT '规则详情',
  `logical_operator` varchar(32) NOT NULL DEFAULT '' COMMENT '条件逻辑关系',
  `status` varchar(32) NOT NULL COMMENT '规则状态',
  `alarm_item_type` varchar(32) NOT NULL DEFAULT 'USER_DEFINE' COMMENT '告警类别',
  `notify_types` text COMMENT '通知方式列表',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '删除标记',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`unique_app_id`,`category`,`name`(128)),
  KEY `idx_gmt_modified` (`gmt_modified`),
  KEY `idx_alarm_id` (`alarm_id`),
  KEY `idx_status` (`status`),
  KEY `idx_app_id` (`unique_app_id`,`category`,`is_deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=243445 DEFAULT CHARSET=utf8 COMMENT='emas_ha_alarm_item的更新版'
;

CREATE TABLE `emas_ha_alarm_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `aliyun_user_id` varchar(64) NOT NULL COMMENT '所属阿里云账号',
  `name` varchar(64) NOT NULL COMMENT '名称',
  `mail` varchar(64) DEFAULT NULL COMMENT '邮箱地址',
  `web_hook` varchar(256) DEFAULT NULL COMMENT 'webhook地址',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '删除标记',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`aliyun_user_id`,`name`),
  KEY `idx_aliyun_id` (`aliyun_user_id`,`is_deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8 COMMENT='告警联系人'
;

CREATE TABLE `emas_ha_alarm_user_group` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `aliyun_user_id` varchar(64) NOT NULL COMMENT '阿里云账号id',
  `name` varchar(64) NOT NULL COMMENT '名称',
  `alarm_user_ids` text COMMENT '包含的告警联系人id列表',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '删除状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`aliyun_user_id`,`name`),
  KEY `idx_aliyun_id` (`aliyun_user_id`,`is_deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=516 DEFAULT CHARSET=utf8 COMMENT='告警联系人列表'
;
