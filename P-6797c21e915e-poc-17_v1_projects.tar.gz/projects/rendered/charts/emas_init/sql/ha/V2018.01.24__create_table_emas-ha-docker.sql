CREATE TABLE `emas_ha`.`emas_ha_api_consumer` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `client_name` varchar(50) NOT NULL COMMENT 'name',
  `client_key` varchar(50) NOT NULL COMMENT 'key',
  `status` varchar(50) NOT NULL COMMENT 'status',
  `params` text NOT NULL COMMENT 'params',
  `type` varchar(50) NOT NULL COMMENT 'type',
  `description` text DEFAULT NULL COMMENT 'description',
  `owner` varchar(50) DEFAULT NULL COMMENT 'owner',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`client_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='api consumer';

CREATE TABLE `emas_ha`.`emas_ha_app` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `unique_app_id` varchar(255) NOT NULL COMMENT '唯一appId',
  `base_app_key` varchar(128) DEFAULT NULL COMMENT 'baseAppKey',
  `current_app_key` varchar(128) DEFAULT NULL COMMENT 'currentAppKey',
  `platform` varchar(128) NOT NULL COMMENT '操作系统平台',
  `name` varchar(255) NOT NULL COMMENT '应用名称',
  `status` varchar(128) NOT NULL COMMENT '应用状态',
  `params` varchar(1024) DEFAULT NULL COMMENT '应用参数',
  `app_group_id` bigint(20) unsigned DEFAULT NULL COMMENT '应用分组',
  `app_product_id` bigint(20) unsigned DEFAULT NULL COMMENT '产品id',
  `icon` varchar(256) DEFAULT NULL COMMENT 'icon',
  `app_type` varchar(50) DEFAULT NULL,
  `source_type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_unique_app_id` (`unique_app_id`(128)),
  KEY `idx_name` (`name`(128))
) ENGINE=InnoDB AUTO_INCREMENT=227 DEFAULT CHARSET=utf8 COMMENT='app基础表';


CREATE TABLE `emas_ha`.`emas_ha_app_files` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `unique_app_id` varchar(128) DEFAULT NULL COMMENT '应用id',
  `app_version_id` varchar(128) DEFAULT NULL COMMENT '版本id',
  `file_type` varchar(50) NOT NULL COMMENT '文件类型,mapping,dsym',
  `file_path` varchar(1024) NOT NULL COMMENT '文件路径',
  `file_name` varchar(256) NOT NULL COMMENT '文件名',
  `status` tinyint(4) DEFAULT NULL COMMENT '状态',
  `url` varchar(256) DEFAULT NULL COMMENT 'url',
  `uuid` varchar(256) DEFAULT NULL COMMENT 'uuid',
  `md5` varchar(128) DEFAULT NULL COMMENT '文件MD5码',
  `source_type` varchar(32) DEFAULT NULL COMMENT '文件来源',
  `storage_type` varchar(32) DEFAULT NULL COMMENT '存储类型',
  `build_id` varchar(256) DEFAULT NULL COMMENT '应用so文件buildId',
  `model` varchar(256) DEFAULT NULL COMMENT '系统so文件model',
  `build_time` varchar(256) DEFAULT NULL COMMENT '系统so文件buildTime',
  `upload_status` varchar(20) DEFAULT NULL COMMENT 'so文件上传状态',
  `build_version` varchar(256) DEFAULT NULL COMMENT '系统Lib版本号',
  `export_status` varchar(20) DEFAULT NULL COMMENT '导出状态',
  PRIMARY KEY (`id`),
  KEY `idx_unique_app_id` (`unique_app_id`),
  KEY `idx_app_version_id` (`app_version_id`)
) ENGINE=InnoDB AUTO_INCREMENT=152 DEFAULT CHARSET=utf8 COMMENT='mapping、symbol、so文件管理';


CREATE TABLE `emas_ha`.`emas_ha_app_remote_config` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `appkey` varchar(32) NOT NULL COMMENT 'appkey',
  `config` text NOT NULL COMMENT '配置',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='远程控制配置';

CREATE TABLE `emas_ha`.`emas_ha_app_report_type_relation` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `unique_app_id` varchar(128) NOT NULL COMMENT '应用位置标志',
  `record_type_id` bigint(20) unsigned DEFAULT NULL COMMENT '自定义record唯一标志',
  `status` varchar(128) NOT NULL COMMENT '状态',
  `record_type_name` varchar(128) DEFAULT NULL COMMENT 'name',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_1` (`unique_app_id`,`record_type_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='app和recordType的关联关系';

CREATE TABLE `emas_ha`.`emas_ha_app_version` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `unique_app_id` varchar(255) NOT NULL COMMENT '唯一app标志',
  `app_version` varchar(128) NOT NULL COMMENT 'app版本',
  `status` varchar(128) NOT NULL COMMENT '状态',
  `params` varchar(1024) DEFAULT NULL COMMENT '参数',
  `type` varchar(128) NOT NULL COMMENT '类型：正式、灰度等',
  `release_time` datetime DEFAULT NULL COMMENT '发布时间',
  `release_status` varchar(20) DEFAULT NULL COMMENT '发布状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_version` (`unique_app_id`(128),`app_version`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8 COMMENT='emas_ha_app_version';

CREATE TABLE `emas_ha`.`emas_ha_cluster` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `data` varchar(1000) NOT NULL COMMENT 'data',
  `cluster_name` varchar(1000) NOT NULL COMMENT 'cluster_name',
  `type` varchar(100) NOT NULL COMMENT 'type',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='emax_ha_cluster';

CREATE TABLE `emas_ha`.`emas_ha_dashboard` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `dashboard_label` varchar(200) NOT NULL COMMENT 'label',
  `snapshots` varchar(200) NOT NULL COMMENT 'snapshots',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='emas_ha_dashboard';

CREATE TABLE `emas_ha`.`emas_ha_data_clean` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(128) NOT NULL COMMENT 'name',
  `global` tinyint(4) NOT NULL COMMENT 'global',
  `config` text DEFAULT NULL COMMENT 'config',
  `creator` varchar(50) DEFAULT NULL COMMENT 'creator',
  `modifier` varchar(50) DEFAULT NULL COMMENT 'modifier',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='emas_ha_data_clean';

CREATE TABLE `emas_ha`.`emas_ha_data_store` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(128) NOT NULL COMMENT '数仓名',
  `type` varchar(32) NOT NULL COMMENT '类型',
  `config` text NOT NULL COMMENT '配置类型, json格式',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `identity` varchar(128) NOT NULL COMMENT '数仓唯一标识符',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_identity` (`identity`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='数据存储';

CREATE TABLE `emas_ha`.`emas_ha_log_agent` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `topic` varchar(128) NOT NULL COMMENT 'kafka topic',
  `root` varchar(128) NOT NULL COMMENT '采集根目录',
  `file_regular` varchar(128) NOT NULL COMMENT '采集文件名/文件名正则',
  `delimiter` varchar(50) NOT NULL COMMENT '16进制换行符字符串',
  `description` text DEFAULT NULL COMMENT '描述信息',
  `status` varchar(50) NOT NULL COMMENT '状态信息',
  `groups` text NOT NULL COMMENT '采集groups,分割',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_1` (`topic`,`root`,`file_regular`),
  KEY `idx_topic` (`topic`,`status`),
  KEY `idx_topic_1` (`topic`),
  KEY `idx_groups` (`groups`(128))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='emas 文件采集配置';

CREATE TABLE `emas_ha`.`emas_ha_log_collection` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `ip` varchar(30) NOT NULL COMMENT 'ip',
  `file_path` varchar(180) NOT NULL COMMENT '文件全路径',
  `file_length` bigint(20) NOT NULL COMMENT '最后文件长度',
  `collected_position` bigint(20) NOT NULL COMMENT '最后采集位置',
  `collected_time_ms` bigint(20) NOT NULL COMMENT '最后采集时间',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `topic` varchar(128) NOT NULL COMMENT 'topic',
  `log_agent_id` bigint(20) NOT NULL COMMENT 'log agent id',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_1` (`ip`,`topic`,`file_path`),
  KEY `idx_1` (`topic`)
) ENGINE=InnoDB AUTO_INCREMENT=163 DEFAULT CHARSET=utf8 COMMENT='emas日志采集进度';

CREATE TABLE `emas_ha`.`emas_ha_log_topic` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `topic` varchar(128) NOT NULL COMMENT 'kafka topic',
  `bootstrap_servers` varchar(256) DEFAULT NULL COMMENT 'kafka bootstrapServers',
  `topic_partition` int(11) NOT NULL COMMENT 'kafka topic partition',
  `replication` int(11) NOT NULL COMMENT 'kafka replication',
  `description` text DEFAULT NULL COMMENT '描述信息',
  `status` varchar(50) NOT NULL COMMENT '状态信息',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_1` (`topic`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='emas log topic';

CREATE TABLE `emas_ha`.`emas_ha_meta_event` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `name` varchar(60) NOT NULL COMMENT '元数据名称',
  `app_id` varchar(50) NOT NULL COMMENT 'appId',
  `event_id` varchar(30) NOT NULL COMMENT 'EventId',
  `identity` varchar(255) NOT NULL COMMENT '业务标识',
  `owner` varchar(30) NOT NULL COMMENT '元数据负责人',
  `modifier` varchar(30) NOT NULL COMMENT '最后修改者',
  `ref` bigint(20) DEFAULT NULL COMMENT '引用元数据ID',
  `data` text NOT NULL COMMENT '元数据序列化数据',
  `module` varchar(100) NOT NULL COMMENT '元数据模块名',
  `monitor_point` varchar(100) NOT NULL COMMENT '元数据监控点',
  `creator` varchar(20) NOT NULL COMMENT '创建者',
  `type` varchar(32) NOT NULL COMMENT '埋点类型',
  PRIMARY KEY (`id`),
  KEY `idx_ref` (`ref`),
  KEY `idx_common` (`app_id`,`name`,`event_id`,`module`,`monitor_point`),
  KEY `idx_identity` (`identity`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='埋点元数据';

CREATE TABLE `emas_ha`.`emas_ha_meta_template_instance` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `meta_id` varchar(30) NOT NULL COMMENT '模板ID',
  `app_id` varchar(30) NOT NULL COMMENT 'AppID',
  `type` varchar(32) NOT NULL COMMENT '埋点类型',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_meta_app` (`meta_id`,`app_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='App和模板实例表';

CREATE TABLE `emas_ha`.`emas_ha_olap_snapshot` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(500) NOT NULL COMMENT 'name',
  `appId` varchar(200) NOT NULL COMMENT 'appId',
  `snapShot` varchar(1000) NOT NULL COMMENT 'snapShot',
  `createTime` datetime NOT NULL COMMENT 'createTime',
  `type` varchar(200) NOT NULL COMMENT 'type',
  `isDefault` tinyint(1) NOT NULL COMMENT 'isDefault',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COMMENT='olap_snapshot';

CREATE TABLE `emas_ha`.`emas_ha_performance_config` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `app_id` varchar(255) NOT NULL COMMENT 'appId',
  `type` varchar(255) NOT NULL COMMENT 'type',
  `config` varchar(1023) NOT NULL COMMENT 'config',
  `label` varchar(255) NOT NULL COMMENT 'label',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='emas_ha_performance_config';

CREATE TABLE `emas_ha`.`emas_ha_product` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `name` varchar(255) NOT NULL COMMENT 'name',
  `app_type` varchar(255) NOT NULL COMMENT '产品类型',
  `source_type` varchar(255) NOT NULL COMMENT '产品来源',
  `status` varchar(128) NOT NULL COMMENT '状态',
  `params` varchar(255) DEFAULT NULL COMMENT '额外参数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='产品表';

CREATE TABLE `emas_ha`.`emas_ha_remote_debug_task` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `title` varchar(128) DEFAULT NULL COMMENT '标题',
  `type` varchar(64) NOT NULL COMMENT '类型',
  `device_num` int(11) NOT NULL COMMENT '设备数量',
  `author` varchar(128) NOT NULL COMMENT '作者\n',
  `auditor` varchar(128) NOT NULL COMMENT '审核人',
  `data` text NOT NULL COMMENT '内容',
  `comments` text NOT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='远程控制任务';

CREATE TABLE `emas_ha`.`emas_ha_report_subscribe` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `topic` varchar(128) NOT NULL COMMENT '名称',
  `data_source` varchar(128) NOT NULL COMMENT 'data_source',
  `data_block_type` varchar(128) NOT NULL COMMENT 'data_block_type',
  `group_id` varchar(128) DEFAULT NULL COMMENT '组别',
  `access_key` varchar(128) DEFAULT NULL COMMENT 'access_key',
  `queue_size` varchar(128) DEFAULT NULL COMMENT 'queue_size',
  `ext_data` varchar(255) DEFAULT NULL COMMENT '拓展字段',
  `author` varchar(128) DEFAULT NULL COMMENT '作者',
  `server` varchar(256) DEFAULT NULL COMMENT 'server',
  `status` varchar(50) DEFAULT NULL COMMENT '状态',
  `consumer_app` varchar(128) DEFAULT NULL COMMENT 'consumerApp',
  `index_weight` varchar(10) DEFAULT NULL COMMENT '索引权重,字符串表示double',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='report订阅表';

CREATE TABLE `emas_ha`.`emas_ha_report_type` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `type_id` varchar(128) NOT NULL COMMENT 'type_id',
  `log_category` varchar(128) NOT NULL COMMENT '分类',
  `name` varchar(128) NOT NULL COMMENT '名称',
  `core_content_type` varchar(128) NOT NULL COMMENT 'core_content_type',
  `os` varchar(128) NOT NULL COMMENT '操作系统',
  `display_name` varchar(255) NOT NULL COMMENT '显示名称',
  `description` varchar(255) NOT NULL COMMENT '描述',
  `status` varchar(128) NOT NULL COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_typeid` (`type_id`),
  UNIQUE KEY `uk_name_os` (`name`,`os`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='自定义专项表'
;

CREATE TABLE `emas_ha`.`emas_ha_overview` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `directoryId` bigint(20) unsigned NOT NULL COMMENT 'directoryId',
  `label` varchar(200) NOT NULL COMMENT 'label',
  `appId` varchar(200) NOT NULL COMMENT 'appId',
  `snapshots` varchar(200) NOT NULL COMMENT 'snapshots',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COMMENT='emas_ha_overview';


CREATE TABLE `emas_ha`.`emas_ha_directory` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `label` varchar(200) NOT NULL COMMENT 'label',
  `appId` varchar(200) NOT NULL COMMENT 'appId',
  `directoryType` bigint(20) unsigned NOT NULL COMMENT 'directoryType',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='emas_ha_directory';
