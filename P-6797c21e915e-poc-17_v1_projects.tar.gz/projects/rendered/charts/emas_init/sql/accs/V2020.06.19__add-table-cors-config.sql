use accs_lite;

CREATE TABLE `accs_auth_cors_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `origin` text COMMENT '允许访问的origin',
  `expose_headers` text COMMENT '允许暴露的header',
  `expiration` bigint(20) NOT NULL DEFAULT '0' COMMENT 'CORS的缓存时间',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='全局的跨域配置存储表';

