use accs_lite;

CREATE TABLE `device_alias` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `appkey` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'appKey',
  `device_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '设备ID',
  `alias` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '设备别名（推送使用）',
  `alias_token` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '绑定别名后返回的token，用于解绑',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_appkey_device_id_alias` (`appkey`,`device_id`,`alias`) USING BTREE,
  KEY `idx_appkey_device_id` (`appkey`,`device_id`) USING BTREE,
  KEY `idx_appkey_alias` (`appkey`,`alias`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

CREATE TABLE `device_alias0` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `appkey` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'appKey',
  `device_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '设备ID',
  `alias` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '设备别名（推送使用）',
  `alias_token` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '绑定别名后返回的token，用于解绑',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_appkey_device_id_alias` (`appkey`,`device_id`,`alias`) USING BTREE,
  KEY `idx_appkey_device_id` (`appkey`,`device_id`) USING BTREE,
  KEY `idx_appkey_alias` (`appkey`,`alias`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

CREATE TABLE `device_alias1` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `appkey` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'appKey',
  `device_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '设备ID',
  `alias` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '设备别名（推送使用）',
  `alias_token` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '绑定别名后返回的token，用于解绑',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_appkey_device_id_alias` (`appkey`,`device_id`,`alias`) USING BTREE,
  KEY `idx_appkey_device_id` (`appkey`,`device_id`) USING BTREE,
  KEY `idx_appkey_alias` (`appkey`,`alias`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

CREATE TABLE `device_alias2` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `appkey` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'appKey',
  `device_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '设备ID',
  `alias` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '设备别名（推送使用）',
  `alias_token` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '绑定别名后返回的token，用于解绑',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_appkey_device_id_alias` (`appkey`,`device_id`,`alias`) USING BTREE,
  KEY `idx_appkey_device_id` (`appkey`,`device_id`) USING BTREE,
  KEY `idx_appkey_alias` (`appkey`,`alias`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

CREATE TABLE `device_alias3` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `appkey` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'appKey',
  `device_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '设备ID',
  `alias` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '设备别名（推送使用）',
  `alias_token` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '绑定别名后返回的token，用于解绑',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_appkey_device_id_alias` (`appkey`,`device_id`,`alias`) USING BTREE,
  KEY `idx_appkey_device_id` (`appkey`,`device_id`) USING BTREE,
  KEY `idx_appkey_alias` (`appkey`,`alias`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=146 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;