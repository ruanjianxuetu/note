use accs_lite;

alter table `device`
add column `vender_os_name` varchar(128) comment '厂商操作系统',
add column `vender_os_version` varchar(128) comment '厂商操作系统版本';

alter table `app_device`
add column `unbind_services` varchar(1024) comment 'unbind services';
