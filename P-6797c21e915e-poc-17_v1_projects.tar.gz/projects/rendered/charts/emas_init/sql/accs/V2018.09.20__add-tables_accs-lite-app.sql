use accs_lite;


CREATE TABLE `device0` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `device_id` varchar(128) NOT NULL COMMENT '设备id',
  `appkey` varchar(64) NOT NULL COMMENT 'app key',
  `package_name` varchar(128) DEFAULT NULL COMMENT 'package name',
  `app_version` varchar(32) DEFAULT NULL COMMENT 'app 版本',
  `sdk_version` varchar(32) DEFAULT NULL COMMENT 'sdk 版本',
  `ttid` varchar(256) DEFAULT NULL COMMENT '渠道id',
  `user_info` varchar(128) DEFAULT NULL COMMENT '用户信息',
  `status` tinyint(4) DEFAULT NULL COMMENT '1：正常 0：卸载 -1：删除',
  `ext` varchar(256) DEFAULT NULL COMMENT '扩展',
  `push_token` text COMMENT '保存所有pushtoken，这是一个json架构，便于扩展，需要common-lib中',
  `notification_status` int(11) DEFAULT NULL COMMENT '当前设备的notification状态，如果是关闭的，则说明该设备普通弹窗是无法显示的',
  `app_device_token` varchar(128) DEFAULT NULL COMMENT '注册后服务端返回的设备token',
  `push_user_token` varchar(128) DEFAULT NULL COMMENT '绑定别名后返回的token，用于解绑',
  `last_action_time` datetime DEFAULT NULL COMMENT '最后一次客户端活跃事件',
  `brand` varchar(128) DEFAULT NULL COMMENT '品牌',
  `model` varchar(128) DEFAULT NULL COMMENT '型号',
  `imsi` varchar(128) DEFAULT NULL COMMENT 'imsi',
  `imei` varchar(128) DEFAULT NULL COMMENT 'imei',
  `mac_address` varchar(128) DEFAULT NULL COMMENT 'mac address',
  `os_version` varchar(32) DEFAULT NULL COMMENT 'os version',
  `os_type` varchar(32) DEFAULT NULL COMMENT 'os type',
  `vender_os_name` varchar(128) DEFAULT NULL COMMENT 'vender os name',
  `vender_os_version` varchar(128) DEFAULT NULL COMMENT 'vender os version',
  `unbind_service` varchar(1024) DEFAULT NULL COMMENT 'unbind_service',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_device_id_appkey` (`device_id`,`appkey`),
  key `idx_device_id` (device_id),
  key `idx_appkey_app_version` (appkey,app_version)
) ENGINE=InnoDB AUTO_INCREMENT=335 DEFAULT CHARSET=utf8mb4 COMMENT='device0'
;


CREATE TABLE `device1` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `device_id` varchar(128) NOT NULL COMMENT '设备id',
  `appkey` varchar(64) NOT NULL COMMENT 'app key',
  `package_name` varchar(128) DEFAULT NULL COMMENT 'package name',
  `app_version` varchar(32) DEFAULT NULL COMMENT 'app 版本',
  `sdk_version` varchar(32) DEFAULT NULL COMMENT 'sdk 版本',
  `ttid` varchar(256) DEFAULT NULL COMMENT '渠道id',
  `user_info` varchar(128) DEFAULT NULL COMMENT '用户信息',
  `status` tinyint(4) DEFAULT NULL COMMENT '1：正常 0：卸载 -1：删除',
  `ext` varchar(256) DEFAULT NULL COMMENT '扩展',
  `push_token` text COMMENT '保存所有pushtoken，这是一个json架构，便于扩展，需要common-lib中',
  `notification_status` int(11) DEFAULT NULL COMMENT '当前设备的notification状态，如果是关闭的，则说明该设备普通弹窗是无法显示的',
  `app_device_token` varchar(128) DEFAULT NULL COMMENT '注册后服务端返回的设备token',
  `push_user_token` varchar(128) DEFAULT NULL COMMENT '绑定别名后返回的token，用于解绑',
  `last_action_time` datetime DEFAULT NULL COMMENT '最后一次客户端活跃事件',
  `brand` varchar(128) DEFAULT NULL COMMENT '品牌',
  `model` varchar(128) DEFAULT NULL COMMENT '型号',
  `imsi` varchar(128) DEFAULT NULL COMMENT 'imsi',
  `imei` varchar(128) DEFAULT NULL COMMENT 'imei',
  `mac_address` varchar(128) DEFAULT NULL COMMENT 'mac address',
  `os_version` varchar(32) DEFAULT NULL COMMENT 'os version',
  `os_type` varchar(32) DEFAULT NULL COMMENT 'os type',
  `vender_os_name` varchar(128) DEFAULT NULL COMMENT 'vender os name',
  `vender_os_version` varchar(128) DEFAULT NULL COMMENT 'vender os version',
  `unbind_service` varchar(1024) DEFAULT NULL COMMENT 'unbind_service',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_device_id_appkey` (`device_id`,`appkey`),
  key `idx_device_id` (device_id),
  key `idx_appkey_app_version` (appkey,app_version)
) ENGINE=InnoDB AUTO_INCREMENT=335 DEFAULT CHARSET=utf8mb4 COMMENT='device1'
;



CREATE TABLE `device2` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `device_id` varchar(128) NOT NULL COMMENT '设备id',
  `appkey` varchar(64) NOT NULL COMMENT 'app key',
  `package_name` varchar(128) DEFAULT NULL COMMENT 'package name',
  `app_version` varchar(32) DEFAULT NULL COMMENT 'app 版本',
  `sdk_version` varchar(32) DEFAULT NULL COMMENT 'sdk 版本',
  `ttid` varchar(256) DEFAULT NULL COMMENT '渠道id',
  `user_info` varchar(128) DEFAULT NULL COMMENT '用户信息',
  `status` tinyint(4) DEFAULT NULL COMMENT '1：正常 0：卸载 -1：删除',
  `ext` varchar(256) DEFAULT NULL COMMENT '扩展',
  `push_token` text COMMENT '保存所有pushtoken，这是一个json架构，便于扩展，需要common-lib中',
  `notification_status` int(11) DEFAULT NULL COMMENT '当前设备的notification状态，如果是关闭的，则说明该设备普通弹窗是无法显示的',
  `app_device_token` varchar(128) DEFAULT NULL COMMENT '注册后服务端返回的设备token',
  `push_user_token` varchar(128) DEFAULT NULL COMMENT '绑定别名后返回的token，用于解绑',
  `last_action_time` datetime DEFAULT NULL COMMENT '最后一次客户端活跃事件',
  `brand` varchar(128) DEFAULT NULL COMMENT '品牌',
  `model` varchar(128) DEFAULT NULL COMMENT '型号',
  `imsi` varchar(128) DEFAULT NULL COMMENT 'imsi',
  `imei` varchar(128) DEFAULT NULL COMMENT 'imei',
  `mac_address` varchar(128) DEFAULT NULL COMMENT 'mac address',
  `os_version` varchar(32) DEFAULT NULL COMMENT 'os version',
  `os_type` varchar(32) DEFAULT NULL COMMENT 'os type',
  `vender_os_name` varchar(128) DEFAULT NULL COMMENT 'vender os name',
  `vender_os_version` varchar(128) DEFAULT NULL COMMENT 'vender os version',
  `unbind_service` varchar(1024) DEFAULT NULL COMMENT 'unbind_service',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_device_id_appkey` (`device_id`,`appkey`),
  key `idx_device_id` (device_id),
  key `idx_appkey_app_version` (appkey,app_version)
) ENGINE=InnoDB AUTO_INCREMENT=335 DEFAULT CHARSET=utf8mb4 COMMENT='device2'
;

CREATE TABLE `device3` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `device_id` varchar(128) NOT NULL COMMENT '设备id',
  `appkey` varchar(64) NOT NULL COMMENT 'app key',
  `package_name` varchar(128) DEFAULT NULL COMMENT 'package name',
  `app_version` varchar(32) DEFAULT NULL COMMENT 'app 版本',
  `sdk_version` varchar(32) DEFAULT NULL COMMENT 'sdk 版本',
  `ttid` varchar(256) DEFAULT NULL COMMENT '渠道id',
  `user_info` varchar(128) DEFAULT NULL COMMENT '用户信息',
  `status` tinyint(4) DEFAULT NULL COMMENT '1：正常 0：卸载 -1：删除',
  `ext` varchar(256) DEFAULT NULL COMMENT '扩展',
  `push_token` text COMMENT '保存所有pushtoken，这是一个json架构，便于扩展，需要common-lib中',
  `notification_status` int(11) DEFAULT NULL COMMENT '当前设备的notification状态，如果是关闭的，则说明该设备普通弹窗是无法显示的',
  `app_device_token` varchar(128) DEFAULT NULL COMMENT '注册后服务端返回的设备token',
  `push_user_token` varchar(128) DEFAULT NULL COMMENT '绑定别名后返回的token，用于解绑',
  `last_action_time` datetime DEFAULT NULL COMMENT '最后一次客户端活跃事件',
  `brand` varchar(128) DEFAULT NULL COMMENT '品牌',
  `model` varchar(128) DEFAULT NULL COMMENT '型号',
  `imsi` varchar(128) DEFAULT NULL COMMENT 'imsi',
  `imei` varchar(128) DEFAULT NULL COMMENT 'imei',
  `mac_address` varchar(128) DEFAULT NULL COMMENT 'mac address',
  `os_version` varchar(32) DEFAULT NULL COMMENT 'os version',
  `os_type` varchar(32) DEFAULT NULL COMMENT 'os type',
  `vender_os_name` varchar(128) DEFAULT NULL COMMENT 'vender os name',
  `vender_os_version` varchar(128) DEFAULT NULL COMMENT 'vender os version',
  `unbind_service` varchar(1024) DEFAULT NULL COMMENT 'unbind_service',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_device_id_appkey` (`device_id`,`appkey`),
  key `idx_device_id` (device_id),
  key `idx_appkey_app_version` (appkey,app_version)
) ENGINE=InnoDB AUTO_INCREMENT=335 DEFAULT CHARSET=utf8mb4 COMMENT='device3'
;



CREATE TABLE `user_device0` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `device_id` varchar(128) NOT NULL COMMENT '设备id',
  `appkey` varchar(64) NOT NULL COMMENT 'app key',
  `user_info` varchar(128) DEFAULT NULL COMMENT '用户信息',
  PRIMARY KEY (`id`),
  key `idx_user_info` (user_info),
  key `idx_appkey_user` (appkey,user_info)
) ENGINE=InnoDB AUTO_INCREMENT=335 DEFAULT CHARSET=utf8mb4 COMMENT='user_device0'
;

CREATE TABLE `user_device1` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `device_id` varchar(128) NOT NULL COMMENT '设备id',
  `appkey` varchar(64) NOT NULL COMMENT 'app key',
  `user_info` varchar(128) DEFAULT NULL COMMENT '用户信息',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_device_id_userinfo` (`device_id`,`appkey`,`user_info`),
  key `idx_user_info` (user_info),
  key `idx_appkey_user` (appkey,user_info)
) ENGINE=InnoDB AUTO_INCREMENT=335 DEFAULT CHARSET=utf8mb4 COMMENT='user_device1'
;

CREATE TABLE `user_device2` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `device_id` varchar(128) NOT NULL COMMENT '设备id',
  `appkey` varchar(64) NOT NULL COMMENT 'app key',
  `user_info` varchar(128) DEFAULT NULL COMMENT '用户信息',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_device_id_userinfo` (`device_id`,`appkey`,`user_info`),
  key `idx_user_info` (user_info),
  key `idx_appkey_user` (appkey,user_info)
) ENGINE=InnoDB AUTO_INCREMENT=335 DEFAULT CHARSET=utf8mb4 COMMENT='user_device2'
;

CREATE TABLE `user_device3` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `device_id` varchar(128) NOT NULL COMMENT '设备id',
  `appkey` varchar(64) NOT NULL COMMENT 'app key',
  `user_info` varchar(128) DEFAULT NULL COMMENT '用户信息',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_device_id_userinfo` (`device_id`,`appkey`,`user_info`),
  key `idx_user_info` (user_info),
  key `idx_appkey_user` (appkey,user_info)
) ENGINE=InnoDB AUTO_INCREMENT=335 DEFAULT CHARSET=utf8mb4 COMMENT='user_device3'
;


/******************************************/
/*   消息相关表  start */
/******************************************/
/******************************************/
/*   数据库全名 = accs_lite_app   */
/*   表名称 = accs_device_msg   */
/******************************************/
CREATE TABLE `device_msg0` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `device_id` varchar(128) NOT NULL COMMENT '设备id',
  `msg_id` varchar(128) NOT NULL COMMENT '消息id',
  `app_key` varchar(128) NOT NULL COMMENT 'app对应的appkey',
  `service_name` varchar(128) DEFAULT NULL COMMENT '业务服务名称',
  `user` varchar(64) DEFAULT NULL COMMENT '用户标识',
  `data` blob COMMENT '消息内容',
  `data_ref` varchar(64) DEFAULT NULL COMMENT '消息内容refence',
  `status` tinyint(4) DEFAULT '0' COMMENT '消息状态（0:未消费，1:已消费）',
  `src_service_name` varchar(128) DEFAULT NULL COMMENT '消息来源服务',
  `src_ip` varchar(15) DEFAULT NULL COMMENT '消息来源ip',
  `compress_alg` tinyint(4) DEFAULT '0' COMMENT '压缩算法（0：未压缩，1：gzip，2：zlib）算法',
  `dispatch_type` tinyint(4) DEFAULT '1' COMMENT '分发方式（0：所有连接，1：最后一个连接）',
  `flag` int(11) DEFAULT NULL COMMENT 'flag',
  `commit_time` datetime NOT NULL COMMENT '提交时间',
  `expired_time` datetime NOT NULL COMMENT '过期时间',
  `task_id` varchar(128) DEFAULT NULL COMMENT 'task id',
  `protocol_version` tinyint(4) DEFAULT NULL COMMENT '版本',
  `ext_headers` blob COMMENT 'header',
  PRIMARY KEY (`id`),
  KEY `idx_dev_id_ak` (`device_id`,`app_key`),
  KEY `idx_dev_id_expired` (`device_id`,`expired_time`),
  unique key `uk_dev_id_msg` (device_id,msg_id),
  KEY `idx_expired_time` (`expired_time`),
  KEY `idx_msgid` (`msg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2001421 DEFAULT CHARSET=utf8mb4 COMMENT='设备维度消息表'
;


/******************************************/
/*   数据库全名 = accs_lite_app   */
/*   表名称 = accs_device_msg   */
/******************************************/
CREATE TABLE `device_msg1` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `device_id` varchar(128) NOT NULL COMMENT '设备id',
  `msg_id` varchar(128) NOT NULL COMMENT '消息id',
  `app_key` varchar(128) NOT NULL COMMENT 'app对应的appkey',
  `service_name` varchar(128) DEFAULT NULL COMMENT '业务服务名称',
  `user` varchar(64) DEFAULT NULL COMMENT '用户标识',
  `data` blob COMMENT '消息内容',
  `data_ref` varchar(64) DEFAULT NULL COMMENT '消息内容refence',
  `status` tinyint(4) DEFAULT '0' COMMENT '消息状态（0:未消费，1:已消费）',
  `src_service_name` varchar(128) DEFAULT NULL COMMENT '消息来源服务',
  `src_ip` varchar(15) DEFAULT NULL COMMENT '消息来源ip',
  `compress_alg` tinyint(4) DEFAULT '0' COMMENT '压缩算法（0：未压缩，1：gzip，2：zlib）算法',
  `dispatch_type` tinyint(4) DEFAULT '1' COMMENT '分发方式（0：所有连接，1：最后一个连接）',
  `flag` int(11) DEFAULT NULL COMMENT 'flag',
  `commit_time` datetime NOT NULL COMMENT '提交时间',
  `expired_time` datetime NOT NULL COMMENT '过期时间',
  `task_id` varchar(128) DEFAULT NULL COMMENT 'task id',
  `protocol_version` tinyint(4) DEFAULT NULL COMMENT '版本',
  `ext_headers` blob COMMENT 'header',
  PRIMARY KEY (`id`),
  KEY `idx_dev_id_ak` (`device_id`,`app_key`),
  KEY `idx_dev_id_expired` (`device_id`,`expired_time`),
  unique key `uk_dev_id_msg` (device_id,msg_id),
  KEY `idx_expired_time` (`expired_time`),
  KEY `idx_msgid` (`msg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2001421 DEFAULT CHARSET=utf8mb4 COMMENT='设备维度消息表'
;

/******************************************/
/*   数据库全名 = accs_lite_app   */
/*   表名称 = accs_device_msg   */
/******************************************/
CREATE TABLE `device_msg2` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `device_id` varchar(128) NOT NULL COMMENT '设备id',
  `msg_id` varchar(128) NOT NULL COMMENT '消息id',
  `app_key` varchar(128) NOT NULL COMMENT 'app对应的appkey',
  `service_name` varchar(128) DEFAULT NULL COMMENT '业务服务名称',
  `user` varchar(64) DEFAULT NULL COMMENT '用户标识',
  `data` blob COMMENT '消息内容',
  `data_ref` varchar(64) DEFAULT NULL COMMENT '消息内容refence',
  `status` tinyint(4) DEFAULT '0' COMMENT '消息状态（0:未消费，1:已消费）',
  `src_service_name` varchar(128) DEFAULT NULL COMMENT '消息来源服务',
  `src_ip` varchar(15) DEFAULT NULL COMMENT '消息来源ip',
  `compress_alg` tinyint(4) DEFAULT '0' COMMENT '压缩算法（0：未压缩，1：gzip，2：zlib）算法',
  `dispatch_type` tinyint(4) DEFAULT '1' COMMENT '分发方式（0：所有连接，1：最后一个连接）',
  `flag` int(11) DEFAULT NULL COMMENT 'flag',
  `commit_time` datetime NOT NULL COMMENT '提交时间',
  `expired_time` datetime NOT NULL COMMENT '过期时间',
  `task_id` varchar(128) DEFAULT NULL COMMENT 'task id',
  `protocol_version` tinyint(4) DEFAULT NULL COMMENT '版本',
  `ext_headers` blob COMMENT 'header',
  PRIMARY KEY (`id`),
  KEY `idx_dev_id_ak` (`device_id`,`app_key`),
  KEY `idx_dev_id_expired` (`device_id`,`expired_time`),
  unique key `uk_dev_id_msg` (device_id,msg_id),
  KEY `idx_expired_time` (`expired_time`),
  KEY `idx_msgid` (`msg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2001421 DEFAULT CHARSET=utf8mb4 COMMENT='设备维度消息表'
;

/******************************************/
/*   数据库全名 = accs_lite_app   */
/*   表名称 = accs_device_msg   */
/******************************************/
CREATE TABLE `device_msg3` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `device_id` varchar(128) NOT NULL COMMENT '设备id',
  `msg_id` varchar(128) NOT NULL COMMENT '消息id',
  `app_key` varchar(128) NOT NULL COMMENT 'app对应的appkey',
  `service_name` varchar(128) DEFAULT NULL COMMENT '业务服务名称',
  `user` varchar(64) DEFAULT NULL COMMENT '用户标识',
  `data` blob COMMENT '消息内容',
  `data_ref` varchar(64) DEFAULT NULL COMMENT '消息内容refence',
  `status` tinyint(4) DEFAULT '0' COMMENT '消息状态（0:未消费，1:已消费）',
  `src_service_name` varchar(128) DEFAULT NULL COMMENT '消息来源服务',
  `src_ip` varchar(15) DEFAULT NULL COMMENT '消息来源ip',
  `compress_alg` tinyint(4) DEFAULT '0' COMMENT '压缩算法（0：未压缩，1：gzip，2：zlib）算法',
  `dispatch_type` tinyint(4) DEFAULT '1' COMMENT '分发方式（0：所有连接，1：最后一个连接）',
  `flag` int(11) DEFAULT NULL COMMENT 'flag',
  `commit_time` datetime NOT NULL COMMENT '提交时间',
  `expired_time` datetime NOT NULL COMMENT '过期时间',
  `task_id` varchar(128) DEFAULT NULL COMMENT 'task id',
  `protocol_version` tinyint(4) DEFAULT NULL COMMENT '版本',
  `ext_headers` blob COMMENT 'header',
  PRIMARY KEY (`id`),
  KEY `idx_dev_id_ak` (`device_id`,`app_key`),
  KEY `idx_dev_id_expired` (`device_id`,`expired_time`),
  unique key `uk_dev_id_msg` (device_id,msg_id),
  KEY `idx_expired_time` (`expired_time`),
  KEY `idx_msgid` (`msg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2001421 DEFAULT CHARSET=utf8mb4 COMMENT='设备维度消息表'
;


/******************************************/
/*   数据库全名 = accs_lite_app   */
/*   表名称 = accs_user_msg   */
/******************************************/
CREATE TABLE `user_msg0` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `msg_id` varchar(128) NOT NULL COMMENT '用户标识，分表字段',
  `app_key` varchar(128) DEFAULT NULL COMMENT 'app对应的appkey',
  `app_name` varchar(128) DEFAULT NULL COMMENT '业务服务名称',
  `platform` tinyint(4) DEFAULT NULL COMMENT '平台类型（0：全部，1：ANDROID，2：IOS）',
  `service_name` varchar(128) DEFAULT NULL COMMENT '业务服务名称\n',
  `user` varchar(128) NOT NULL COMMENT '用户标识，分表字段',
  `data` blob COMMENT '消息内容',
  `data_ref` varchar(128) DEFAULT NULL COMMENT '消息内容refence',
  `src_service_name` varchar(128) DEFAULT NULL COMMENT '消息来源服务',
  `src_ip` varchar(128) DEFAULT NULL COMMENT '消息来源ip',
  `compress_alg` tinyint(4) DEFAULT '0' COMMENT '压缩算法（0：未压缩，1：gzip，2：zlib）',
  `dispatch_type` tinyint(4) DEFAULT '1' COMMENT '分发方式（0：所有连接，1：最后一个连接）',
  `flag` int(11) DEFAULT NULL COMMENT '消息标识（重发时需要）',
  `status` tinyint(4) DEFAULT '0' COMMENT '消息状态（0:未消费，1:已消费）',
  `commit_time` datetime NOT NULL COMMENT '提交时间',
  `expired_time` datetime NOT NULL COMMENT '过期时间',
  `task_id` varchar(128) DEFAULT NULL COMMENT '任务id',
  `protocol_version` tinyint(4) DEFAULT '1' COMMENT '协议版本',
  `ext_headers` blob COMMENT '扩展头',
  PRIMARY KEY (`id`),
  KEY `idx_expired_time` (`expired_time`),
  KEY `idx_msgid` (`msg_id`),
  KEY `idx_user_appkey` (`user`,`app_key`),
  unique key `uk_user_msgid` (user,msg_id),
  KEY `idx_user_exp` (`user`,`expired_time`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='用户维度消息表'
;


CREATE TABLE `user_msg1` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `msg_id` varchar(128) NOT NULL COMMENT '用户标识，分表字段',
  `app_key` varchar(128) DEFAULT NULL COMMENT 'app对应的appkey',
  `app_name` varchar(128) DEFAULT NULL COMMENT '业务服务名称',
  `platform` tinyint(4) DEFAULT NULL COMMENT '平台类型（0：全部，1：ANDROID，2：IOS）',
  `service_name` varchar(128) DEFAULT NULL COMMENT '业务服务名称\n',
  `user` varchar(128) NOT NULL COMMENT '用户标识，分表字段',
  `data` blob COMMENT '消息内容',
  `data_ref` varchar(128) DEFAULT NULL COMMENT '消息内容refence',
  `src_service_name` varchar(128) DEFAULT NULL COMMENT '消息来源服务',
  `src_ip` varchar(128) DEFAULT NULL COMMENT '消息来源ip',
  `compress_alg` tinyint(4) DEFAULT '0' COMMENT '压缩算法（0：未压缩，1：gzip，2：zlib）',
  `dispatch_type` tinyint(4) DEFAULT '1' COMMENT '分发方式（0：所有连接，1：最后一个连接）',
  `flag` int(11) DEFAULT NULL COMMENT '消息标识（重发时需要）',
  `status` tinyint(4) DEFAULT '0' COMMENT '消息状态（0:未消费，1:已消费）',
  `commit_time` datetime NOT NULL COMMENT '提交时间',
  `expired_time` datetime NOT NULL COMMENT '过期时间',
  `task_id` varchar(128) DEFAULT NULL COMMENT '任务id',
  `protocol_version` tinyint(4) DEFAULT '1' COMMENT '协议版本',
  `ext_headers` blob COMMENT '扩展头',
  PRIMARY KEY (`id`),
  KEY `idx_expired_time` (`expired_time`),
  KEY `idx_msgid` (`msg_id`),
  KEY `idx_user_appkey` (`user`,`app_key`),
  unique key `uk_user_msgid` (user,msg_id),
  KEY `idx_user_exp` (`user`,`expired_time`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='用户维度消息表'
;


CREATE TABLE `user_msg2` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `msg_id` varchar(128) NOT NULL COMMENT '用户标识，分表字段',
  `app_key` varchar(128) DEFAULT NULL COMMENT 'app对应的appkey',
  `app_name` varchar(128) DEFAULT NULL COMMENT '业务服务名称',
  `platform` tinyint(4) DEFAULT NULL COMMENT '平台类型（0：全部，1：ANDROID，2：IOS）',
  `service_name` varchar(128) DEFAULT NULL COMMENT '业务服务名称\n',
  `user` varchar(128) NOT NULL COMMENT '用户标识，分表字段',
  `data` blob COMMENT '消息内容',
  `data_ref` varchar(128) DEFAULT NULL COMMENT '消息内容refence',
  `src_service_name` varchar(128) DEFAULT NULL COMMENT '消息来源服务',
  `src_ip` varchar(128) DEFAULT NULL COMMENT '消息来源ip',
  `compress_alg` tinyint(4) DEFAULT '0' COMMENT '压缩算法（0：未压缩，1：gzip，2：zlib）',
  `dispatch_type` tinyint(4) DEFAULT '1' COMMENT '分发方式（0：所有连接，1：最后一个连接）',
  `flag` int(11) DEFAULT NULL COMMENT '消息标识（重发时需要）',
  `status` tinyint(4) DEFAULT '0' COMMENT '消息状态（0:未消费，1:已消费）',
  `commit_time` datetime NOT NULL COMMENT '提交时间',
  `expired_time` datetime NOT NULL COMMENT '过期时间',
  `task_id` varchar(128) DEFAULT NULL COMMENT '任务id',
  `protocol_version` tinyint(4) DEFAULT '1' COMMENT '协议版本',
  `ext_headers` blob COMMENT '扩展头',
  PRIMARY KEY (`id`),
  KEY `idx_expired_time` (`expired_time`),
  KEY `idx_msgid` (`msg_id`),
  KEY `idx_user_appkey` (`user`,`app_key`),
  unique key `uk_user_msgid` (user,msg_id),
  KEY `idx_user_exp` (`user`,`expired_time`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='用户维度消息表'
;


CREATE TABLE `user_msg3` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `msg_id` varchar(128) NOT NULL COMMENT '用户标识，分表字段',
  `app_key` varchar(128) DEFAULT NULL COMMENT 'app对应的appkey',
  `app_name` varchar(128) DEFAULT NULL COMMENT '业务服务名称',
  `platform` tinyint(4) DEFAULT NULL COMMENT '平台类型（0：全部，1：ANDROID，2：IOS）',
  `service_name` varchar(128) DEFAULT NULL COMMENT '业务服务名称\n',
  `user` varchar(128) NOT NULL COMMENT '用户标识，分表字段',
  `data` blob COMMENT '消息内容',
  `data_ref` varchar(128) DEFAULT NULL COMMENT '消息内容refence',
  `src_service_name` varchar(128) DEFAULT NULL COMMENT '消息来源服务',
  `src_ip` varchar(128) DEFAULT NULL COMMENT '消息来源ip',
  `compress_alg` tinyint(4) DEFAULT '0' COMMENT '压缩算法（0：未压缩，1：gzip，2：zlib）',
  `dispatch_type` tinyint(4) DEFAULT '1' COMMENT '分发方式（0：所有连接，1：最后一个连接）',
  `flag` int(11) DEFAULT NULL COMMENT '消息标识（重发时需要）',
  `status` tinyint(4) DEFAULT '0' COMMENT '消息状态（0:未消费，1:已消费）',
  `commit_time` datetime NOT NULL COMMENT '提交时间',
  `expired_time` datetime NOT NULL COMMENT '过期时间',
  `task_id` varchar(128) DEFAULT NULL COMMENT '任务id',
  `protocol_version` tinyint(4) DEFAULT '1' COMMENT '协议版本',
  `ext_headers` blob COMMENT '扩展头',
  PRIMARY KEY (`id`),
  KEY `idx_expired_time` (`expired_time`),
  KEY `idx_msgid` (`msg_id`),
  KEY `idx_user_appkey` (`user`,`app_key`),
  KEY `idx_user_msgid` (`user`,`msg_id`),
  KEY `idx_user_exp` (`user`,`expired_time`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='用户维度消息表'
;


/******************************************/
/*   消息相关表  end */
/******************************************/



/******************************************/
/*   数据库全名 = accs_lite_app   */
/*   表名称 = operation_log   */
/******************************************/
CREATE TABLE `operation_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `operator` varchar(128) NOT NULL COMMENT '操作者',
  `content` text NOT NULL COMMENT '操作内容',
  `biz_type` varchar(128) NOT NULL COMMENT '日志类型',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='操作日志'
;