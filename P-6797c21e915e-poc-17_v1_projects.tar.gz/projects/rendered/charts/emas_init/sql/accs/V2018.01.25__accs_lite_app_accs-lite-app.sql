DROP SCHEMA IF EXISTS `accs_lite` ;
CREATE SCHEMA `accs_lite` COLLATE utf8mb4_unicode_ci ;

CREATE DATABASE IF NOT EXISTS accs_lite;

use accs_lite;


/******************************************/
/*   数据库全名 = accs_lite   */
/*   表名称 = accs_app_service_ref   */
/******************************************/
CREATE TABLE `accs_app_service_ref` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `app_key` varchar(128) DEFAULT NULL COMMENT 'appkey',
  `service_name` varchar(128) DEFAULT NULL COMMENT '服务名',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_app_service` (`app_key`,`service_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COMMENT='app与service的映射'
;

/******************************************/
/*   数据库全名 = accs_lite   */
/*   表名称 = accs_device_msg   */
/******************************************/
CREATE TABLE `accs_device_msg` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `device_id` varchar(128) NOT NULL COMMENT '设备id',
  `msg_id` varchar(128) NOT NULL COMMENT '消息id',
  `app_key` varchar(128) NOT NULL COMMENT 'app对应的appkey',
  `service_name` varchar(128) DEFAULT NULL COMMENT '业务服务名称',
  `user` varchar(64) DEFAULT NULL COMMENT '用户标识',
  `data` blob COMMENT '消息内容',
  `data_ref` varchar(64) DEFAULT NULL COMMENT '消息内容refence',
  `status` tinyint(4) DEFAULT '0' COMMENT '消息状态（0:未消费，1:已消费）',
  `src_service_name` varchar(128) DEFAULT NULL COMMENT '消息来源服务',
  `src_ip` varchar(15) DEFAULT NULL COMMENT '消息来源ip',
  `compress_alg` tinyint(4) DEFAULT '0' COMMENT '压缩算法（0：未压缩，1：gzip，2：zlib）算法',
  `dispatch_type` tinyint(4) DEFAULT '1' COMMENT '分发方式（0：所有连接，1：最后一个连接）',
  `flag` int(11) DEFAULT NULL COMMENT 'flag',
  `commit_time` datetime NOT NULL COMMENT '提交时间',
  `expired_time` datetime NOT NULL COMMENT '过期时间',
  `task_id` varchar(128) DEFAULT NULL COMMENT 'task id',
  `protocol_version` tinyint(4) DEFAULT NULL COMMENT '版本',
  `ext_headers` blob COMMENT 'header',
  PRIMARY KEY (`id`),
  KEY `idx_dev_id_ak` (`device_id`,`app_key`),
  KEY `idx_dev_id_expired` (`device_id`,`expired_time`),
  KEY `idx_dev_id_msg` (`device_id`,`msg_id`),
  KEY `idx_expired_time` (`expired_time`),
  KEY `idx_msgid` (`msg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=231 DEFAULT CHARSET=utf8mb4 COMMENT='设备维度消息表'
;

/******************************************/
/*   数据库全名 = accs_lite   */
/*   表名称 = accs_service_info   */
/******************************************/
CREATE TABLE `accs_service_info` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `service_name` varchar(128) NOT NULL COMMENT '服务名称',
  `service_memo` varchar(512) DEFAULT NULL COMMENT '服务描述',
  `create_user` varchar(128) DEFAULT NULL COMMENT '创建者',
  `update_user` varchar(128) DEFAULT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_service_name` (`service_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='accs服务信息表'
;

/******************************************/
/*   数据库全名 = accs_lite   */
/*   表名称 = accs_user_msg   */
/******************************************/
CREATE TABLE `accs_user_msg` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `msg_id` varchar(128) NOT NULL COMMENT '用户标识，分表字段',
  `app_key` varchar(128) DEFAULT NULL COMMENT 'app对应的appkey',
  `app_name` varchar(128) DEFAULT NULL COMMENT '业务服务名称',
  `platform` tinyint(4) DEFAULT NULL COMMENT '平台类型（0：全部，1：ANDROID，2：IOS）',
  `service_name` varchar(128) DEFAULT NULL COMMENT '业务服务名称\n',
  `user` varchar(128) NOT NULL COMMENT '用户标识，分表字段',
  `data` blob COMMENT '消息内容',
  `data_ref` varchar(128) DEFAULT NULL COMMENT '消息内容refence',
  `src_service_name` varchar(128) DEFAULT NULL COMMENT '消息来源服务',
  `src_ip` varchar(128) DEFAULT NULL COMMENT '消息来源ip',
  `compress_alg` tinyint(4) DEFAULT '0' COMMENT '压缩算法（0：未压缩，1：gzip，2：zlib）',
  `dispatch_type` tinyint(4) DEFAULT '1' COMMENT '分发方式（0：所有连接，1：最后一个连接）',
  `flag` int(11) DEFAULT NULL COMMENT '消息标识（重发时需要）',
  `status` tinyint(4) DEFAULT '0' COMMENT '消息状态（0:未消费，1:已消费）',
  `commit_time` datetime NOT NULL COMMENT '提交时间',
  `expired_time` datetime NOT NULL COMMENT '过期时间',
  `task_id` varchar(128) DEFAULT NULL COMMENT '任务id',
  `protocol_version` tinyint(4) DEFAULT '1' COMMENT '协议版本',
  `ext_headers` blob COMMENT '扩展头',
  PRIMARY KEY (`id`),
  KEY `idx_expired_time` (`expired_time`),
  KEY `idx_msgid` (`msg_id`),
  KEY `idx_user_appkey` (`user`,`app_key`),
  KEY `idx_user_msgid` (`user`,`msg_id`),
  KEY `idx_user_exp` (`user`,`expired_time`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COMMENT='用户维度消息表'
;

/******************************************/
/*   数据库全名 = accs_lite   */
/*   表名称 = app_device   */
/******************************************/
CREATE TABLE `app_device` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `device_id` varchar(128) NOT NULL COMMENT '设备id',
  `appkey` varchar(64) NOT NULL COMMENT 'app key',
  `package_name` varchar(128) DEFAULT NULL COMMENT 'package name',
  `app_version` varchar(32) DEFAULT NULL COMMENT 'app 版本',
  `sdk_version` varchar(32) DEFAULT NULL COMMENT 'sdk 版本',
  `ttid` varchar(256) DEFAULT NULL COMMENT '渠道id',
  `user_info` varchar(128) DEFAULT NULL COMMENT '用户信息',
  `status` tinyint(4) DEFAULT NULL COMMENT '1：正常 0：卸载 -1：删除',
  `ext` varchar(256) DEFAULT NULL COMMENT '扩展',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_device_id_appkey` (`device_id`,`appkey`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COMMENT='app->device关联表'
;

/******************************************/
/*   数据库全名 = accs_lite   */
/*   表名称 = app_info   */
/******************************************/
CREATE TABLE `app_info` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `appkey` varchar(64) NOT NULL COMMENT 'appkey',
  `app_name` varchar(64) NOT NULL COMMENT '应用名称',
  `os_type` varchar(32) DEFAULT NULL COMMENT '操作系统类型',
  `memo` varchar(2048) DEFAULT NULL COMMENT '备注',
  `package_name` varchar(128) DEFAULT NULL COMMENT '包名',
  `status` tinyint(4) NOT NULL COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_appkey_name_idx` (`appkey`,`app_name`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COMMENT='app信息'
;

/******************************************/
/*   数据库全名 = accs_lite   */
/*   表名称 = device   */
/******************************************/
CREATE TABLE `device` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `device_id` varchar(128) NOT NULL COMMENT 'device id客户端上传',
  `brand` varchar(128) DEFAULT NULL COMMENT '品牌',
  `model` varchar(128) DEFAULT NULL COMMENT '型号',
  `imsi` varchar(128) DEFAULT NULL COMMENT 'imsi',
  `imei` varchar(128) DEFAULT NULL COMMENT 'imei',
  `mac_address` varchar(128) DEFAULT NULL COMMENT 'mac address',
  `status` tinyint(4) NOT NULL COMMENT '设备状态：1：正常，0：失效',
  `ext` varchar(256) DEFAULT NULL COMMENT '扩展用，服务端不使用，一般给客户端使用',
  `os_version` varchar(32) DEFAULT NULL COMMENT '操作系统版本',
  `os_type` varchar(32) DEFAULT NULL COMMENT '操作系统类型',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_device_id` (`device_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COMMENT='设备信息'
;