use accs_lite;

alter table `device0`
  add column `alias` varchar(128) DEFAULT NULL COMMENT '别名（推送使用）',
  add index `idx_gmt_modified`(`gmt_modified`);

alter table `device1`
  add column `alias` varchar(128) DEFAULT NULL COMMENT '别名（推送使用）',
  add index `idx_gmt_modified`(`gmt_modified`);

alter table `device2`
  add column `alias` varchar(128) DEFAULT NULL COMMENT '别名（推送使用）',
  add index `idx_gmt_modified`(`gmt_modified`);

alter table `device3`
  add column `alias` varchar(128) DEFAULT NULL COMMENT '别名（推送使用）',
  add index `idx_gmt_modified`(`gmt_modified`);
