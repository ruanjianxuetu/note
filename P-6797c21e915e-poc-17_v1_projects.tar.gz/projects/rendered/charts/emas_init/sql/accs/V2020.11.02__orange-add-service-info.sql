
insert into `accs_lite`.`accs_service_info`(`service_name`, `type`, `gmt_create`, `gmt_modified`)
  values('accs-mass-lite', 0, now(), now());
insert into `accs_lite`.`accs_service_info`(`service_name`, `type`, `gmt_create`, `gmt_modified`)
  values('orange', 0, now(), now());