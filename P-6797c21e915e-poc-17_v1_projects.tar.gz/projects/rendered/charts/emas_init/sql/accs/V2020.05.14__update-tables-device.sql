use accs_lite;

alter table device0 modify column alias varchar(8500);
alter table device1 modify column alias varchar(8500);
alter table device2 modify column alias varchar(8500);
alter table device3 modify column alias varchar(8500);
