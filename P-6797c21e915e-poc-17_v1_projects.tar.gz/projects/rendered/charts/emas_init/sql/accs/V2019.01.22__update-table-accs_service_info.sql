use accs_lite;

alter table `accs_service_info`
  add column `type` int(11) DEFAULT 1 COMMENT '类别：0预置，1主动创建，2测试',
  add column `managers` varchar(1020) NOT NULL DEFAULT '|' COMMENT '管理员列表',
  add column `appkeys` varchar(1020) NOT NULL DEFAULT '|' COMMENT 'appkey列表',
  add index `idx_type`(`type`);

insert into `accs_lite`.`accs_service_info`(`service_name`, `type`, `gmt_create`, `gmt_modified`)
  values('emas-test', 2, now(), now());
