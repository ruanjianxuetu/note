USE `emas`;
CREATE TABLE `emas_miniprogram_app` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `miniprogram_id` varchar(32) NOT NULL DEFAULT '' COMMENT 'mpaas h5id 16位',
  `miniprogram_product_id` varchar(32) NOT NULL DEFAULT '' COMMENT 'mpaas app_id',
  `product_id` bigint(20) NOT NULL COMMENT '关联产品ID',
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '名称',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述64字以内',
  `icon_url` varchar(1000) NOT NULL COMMENT 'icon_url',
  `market_online` tinyint(4) NOT NULL DEFAULT '0' COMMENT '云市场在线状态 0 待上线 1上线 2下线',
  `gmt_online_time` datetime DEFAULT NULL COMMENT '上线日期',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建日期',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改日期',
  `creator` varchar(32) NOT NULL DEFAULT '' COMMENT '创建人',
  `modifier` varchar(32) NOT NULL COMMENT '修改人',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除 0未删除, 1已删除',
  PRIMARY KEY (`id`),
  KEY `uniq_product_and_miniprogram_id` (`miniprogram_product_id`,`miniprogram_id`),
  KEY `uniq_emas_product_miniprogram_id` (`product_id`,`miniprogram_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='小程序表,对应一个mpaas 小程序';

CREATE TABLE `emas_miniprogram_container` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `product_id` bigint(20) unsigned NOT NULL COMMENT '关联emas产品ID',
  `app_id` bigint(20) NOT NULL COMMENT '关联emas应用ID',
  `app_name` varchar(255) NOT NULL DEFAULT '' COMMENT '名称',
  `creator` varchar(255) NOT NULL COMMENT '创建人',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建日期',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改日期',
  PRIMARY KEY (`id`),
  KEY `uniq_product_id_app_id` (`product_id`,`app_id`),
  KEY `uniq_app_id` (`app_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='小程序容器表,对应一个emas app';

CREATE TABLE `emas_miniprogram_package` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `miniprogram_product_id` varchar(32) NOT NULL DEFAULT '' COMMENT 'mpaas h5id 16位',
  `miniprogram_id` varchar(32) NOT NULL COMMENT 'mpaas h5id 16位',
  `package_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'mds 资源包id',
  `version` varchar(32) NOT NULL DEFAULT '' COMMENT '小程序版本',
  `publish_audit_flow_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'emas审批单号,0 表示为创建',
  `publish_audit_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '审批结果',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建日期',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改日期',
  `creator` varchar(255) NOT NULL COMMENT '创建人',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_package_id` (`package_id`),
  KEY `idx_miniprogram_id` (`miniprogram_product_id`,`miniprogram_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='小程序版本包';


CREATE TABLE `emas_miniprogram_product` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `miniprogram_product_id` varchar(32) NOT NULL COMMENT '对应mpaas应用app ID',
  `product_id` bigint(20) unsigned NOT NULL COMMENT '关联emas产品ID',
  `product_name` varchar(255) NOT NULL DEFAULT '' COMMENT '名称',
  `creator` varchar(255) NOT NULL COMMENT '创建人',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建日期',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改日期',
  `is_rsa_synced` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'rsa密钥是否配置成功 0未成功, 1已成功',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_miniprogram_product_id` (`miniprogram_product_id`),
  KEY `uniq_product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='小程序产品表';


CREATE TABLE `emas_miniprogram_publish_batch` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `batch_id` bigint(20) NOT NULL COMMENT '发布任务ID',
  `package_id` bigint(20) unsigned NOT NULL COMMENT 'mpaas h5id 16位数字',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建日期',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改日期',
  `creator` varchar(255) NOT NULL COMMENT '创建人',
  PRIMARY KEY (`id`),
  KEY `uniq_batch_id` (`package_id`),
  KEY `idx_package_id` (`package_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='版本发布任务表';