USE `emas`;
CREATE TABLE IF NOT EXISTS `emas_publish_channel` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `publish_project_id` bigint(20) NOT NULL COMMENT '发布单id',
  `channel_number` varchar(64) COLLATE utf8_unicode_ci NOT NULL COMMENT '渠道号',
  `channel_group_name` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '渠道分组名称',
  `channel_description` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '渠道号描述',
  `task_id` bigint(20) DEFAULT NULL COMMENT '构建id',
  `file_id` bigint(20) DEFAULT NULL COMMENT '文件id',
  `cdn_status` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'cdn上传状态',
  `channel_package_status` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '渠道包状态',
  `is_deleted` tinyint(4) NOT NULL COMMENT '是否删除',
  `creator` varchar(64) COLLATE utf8_unicode_ci NOT NULL COMMENT '构建人',
  `modifier` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '更新人',
  `build_status` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '构建状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci
;

alter table emas_publish_config_info add build_channel_package_enabled tinyint(4) default 0 comment '是否启用构建渠道包';
alter table emas_publish_config_info add default_channel_number varchar(64) comment '默认渠道号';
alter table emas_publish_project add build_channel_package_enabled tinyint(4) default 0 comment '是否启用构建渠道包';