USE `emas`;
BEGIN;
ALTER TABLE `emas_pubserver_file` MODIFY `oss_key` varchar(1024) COMMENT 'OSS 文件key';
ALTER TABLE `emas_pubserver_file` MODIFY `cdn_url` varchar(1024) COMMENT '文件CDN地址';
ALTER TABLE `emas_pubserver_file` MODIFY `https_url` varchar(1024) COMMENT 'HTTPS下载地址，与CDN下载地址相对，可选字段';
COMMIT;