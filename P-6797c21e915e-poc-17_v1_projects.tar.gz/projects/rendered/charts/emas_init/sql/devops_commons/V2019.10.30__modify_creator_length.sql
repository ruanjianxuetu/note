USE `emas`;
ALTER TABLE `emas_build_signature` MODIFY `creator` varchar(100) NOT NULL COMMENT '创建人';
ALTER TABLE `emas_build_signature` MODIFY `modifier` varchar(100) NOT NULL COMMENT '修改人';