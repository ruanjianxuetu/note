USE `emas`;
# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 10.125.13.65 (MySQL 5.7.20)
# Database: emas
# Generation Time: 2018-03-28 12:57:02 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table emas_action_recorddo
# ------------------------------------------------------------

DROP TABLE IF EXISTS `emas_action_recorddo`;

CREATE TABLE `emas_action_recorddo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'record ID',
  `action_error_output` varchar(8000) DEFAULT NULL COMMENT '错误输出',
  `action_output` varchar(8000) DEFAULT NULL COMMENT '全部输出',
  `action_return_code` int(11) DEFAULT NULL COMMENT '返回code',
  `action_status` int(11) DEFAULT NULL COMMENT '行动状态',
  `execute_type` int(11) DEFAULT NULL COMMENT '行动执行类型',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_end` datetime DEFAULT NULL COMMENT '结束时间',
  `machine_ip` varchar(255) DEFAULT NULL COMMENT '机器IP',
  `operator` varchar(64) DEFAULT NULL COMMENT '操作人',
  `action_id` bigint(20) DEFAULT NULL COMMENT 'action ID',
  `monitor_task_id` bigint(20) DEFAULT NULL COMMENT 'monitor ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table emas_actiondo
# ------------------------------------------------------------

DROP TABLE IF EXISTS `emas_actiondo`;

CREATE TABLE `emas_actiondo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'action ID',
  `action_name` varchar(255) DEFAULT NULL COMMENT '行动名称',
  `action_param_json` varchar(255) DEFAULT NULL COMMENT '行动参数 json',
  `action_type` int(11) DEFAULT NULL COMMENT '行动状态',
  `creator` varchar(64) DEFAULT NULL COMMENT '创建人',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `modifier` varchar(64) DEFAULT NULL COMMENT '修改人',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table emas_app_build_configdo
# ------------------------------------------------------------

DROP TABLE IF EXISTS `emas_app_build_configdo`;

CREATE TABLE `emas_app_build_configdo` (
  `id` bigint(20) NOT NULL COMMENT 'app id',
  `creator` varchar(64) DEFAULT NULL COMMENT '创建人',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `modifier` varchar(64) DEFAULT NULL COMMENT '修改人',
  `priority` int(11) DEFAULT NULL COMMENT '构建优先级',
  `use_default_group` bit(1) DEFAULT NULL COMMENT '是否使用default分组',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table emas_app_build_configdo_group_info_id_set
# ------------------------------------------------------------

DROP TABLE IF EXISTS `emas_app_build_configdo_group_info_id_set`;

CREATE TABLE `emas_app_build_configdo_group_info_id_set` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键 ID',
  `emas_app_build_configdo_id` bigint(20) NOT NULL COMMENT 'appBuildConfig ID',
  `group_info_id_set` bigint(20) DEFAULT NULL COMMENT 'group ID',
  KEY `FK7j9jfrts01yqdp2s94746slnj` (`emas_app_build_configdo_id`),
  CONSTRAINT `FK7j9jfrts01yqdp2s94746slnj` FOREIGN KEY (`emas_app_build_configdo_id`) REFERENCES `emas_app_build_configdo` (`id`),
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table emas_group_infodo
# ------------------------------------------------------------

DROP TABLE IF EXISTS `emas_group_infodo`;

CREATE TABLE `emas_group_infodo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'group ID',
  `build_type` int(11) DEFAULT NULL COMMENT '构建类型',
  `creator` varchar(64) DEFAULT NULL COMMENT '创建人',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `group_name` varchar(255) DEFAULT NULL COMMENT '分组名称',
  `group_status` int(11) DEFAULT NULL COMMENT '分组状态',
  `modifier` varchar(64) DEFAULT NULL COMMENT '修改人',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table emas_group_infodo_app_build_config_id_set
# ------------------------------------------------------------

DROP TABLE IF EXISTS `emas_group_infodo_app_build_config_id_set`;

CREATE TABLE `emas_group_infodo_app_build_config_id_set` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键 ID',
  `emas_group_infodo_id` bigint(20) NOT NULL COMMENT 'group ID',
  `app_build_config_id_set` bigint(20) DEFAULT NULL COMMENT 'appBuildConfig ID',
  KEY `FKh9hydlfo85o8prxdud85t8l26` (`emas_group_infodo_id`),
  CONSTRAINT `FKh9hydlfo85o8prxdud85t8l26` FOREIGN KEY (`emas_group_infodo_id`) REFERENCES `emas_group_infodo` (`id`),
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table emas_group_infodo_machine_info_id_set
# ------------------------------------------------------------

DROP TABLE IF EXISTS `emas_group_infodo_machine_info_id_set`;

CREATE TABLE `emas_group_infodo_machine_info_id_set` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键 ID',
  `emas_group_infodo_id` bigint(20) NOT NULL COMMENT 'group ID',
  `machine_info_id_set` bigint(20) DEFAULT NULL COMMENT 'machine ID',
  KEY `FK93ojye24bani4w0lbvnsku64p` (`emas_group_infodo_id`),
  CONSTRAINT `FK93ojye24bani4w0lbvnsku64p` FOREIGN KEY (`emas_group_infodo_id`) REFERENCES `emas_group_infodo` (`id`),
      PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table emas_machine_infodo
# ------------------------------------------------------------

DROP TABLE IF EXISTS `emas_machine_infodo`;

CREATE TABLE `emas_machine_infodo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'machine ID',
  `ability_count` int(11) DEFAULT NULL COMMENT '能力总量',
  `build_platform` int(11) DEFAULT NULL COMMENT '构建平台',
  `creator` varchar(64) DEFAULT NULL COMMENT '创建人',
  `executor_port` varchar(255) DEFAULT NULL COMMENT '机器port',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `hard_diskgb` double DEFAULT NULL COMMENT '硬盘GB',
  `ip` varchar(255) DEFAULT NULL COMMENT 'IP',
  `java_version` varchar(255) DEFAULT NULL COMMENT 'java version',
  `logical_cpu_count` int(11) DEFAULT NULL COMMENT '逻辑CPU数量',
  `machine_status` int(11) DEFAULT NULL COMMENT '机器状态',
  `max_file_descriptor` bigint(20) DEFAULT NULL COMMENT 'fd总量',
  `max_memorymb` double DEFAULT NULL COMMENT '内存总量MB',
  `modifier` varchar(64) DEFAULT NULL COMMENT '修改人',
  `os_name` varchar(255) DEFAULT NULL COMMENT '系统名称',
  `os_version` varchar(255) DEFAULT NULL COMMENT '系统版本',
  `other_build_environment_json` varchar(8000) DEFAULT NULL COMMENT '其他参数',
  `x64orx86` varchar(255) DEFAULT NULL COMMENT 'x64 or x86',
  `xcode_version` varchar(255) DEFAULT NULL COMMENT 'xcode 版本',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table emas_machine_infodo_group_info_id_set
# ------------------------------------------------------------

DROP TABLE IF EXISTS `emas_machine_infodo_group_info_id_set`;

CREATE TABLE `emas_machine_infodo_group_info_id_set` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键 ID',
  `emas_machine_infodo_id` bigint(20) NOT NULL COMMENT 'machine ID',
  `group_info_id_set` bigint(20) DEFAULT NULL COMMENT 'group ID',
  KEY `FK951oe6ykfb5b9k4pw9kyf9wcw` (`emas_machine_infodo_id`),
  CONSTRAINT `FK951oe6ykfb5b9k4pw9kyf9wcw` FOREIGN KEY (`emas_machine_infodo_id`) REFERENCES `emas_machine_infodo` (`id`),
        PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table emas_machine_infodo_monitor_task_id_set
# ------------------------------------------------------------

DROP TABLE IF EXISTS `emas_machine_infodo_monitor_task_id_set`;

CREATE TABLE `emas_machine_infodo_monitor_task_id_set` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键 ID',
  `emas_machine_infodo_id` bigint(20) NOT NULL COMMENT 'machine ID',
  `monitor_task_id_set` bigint(20) DEFAULT NULL COMMENT 'monitor ID',
  KEY `FK9vvbe2oamahikmbwskaw8j8qp` (`emas_machine_infodo_id`),
  CONSTRAINT `FK9vvbe2oamahikmbwskaw8j8qp` FOREIGN KEY (`emas_machine_infodo_id`) REFERENCES `emas_machine_infodo` (`id`),
          PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table emas_machine_real_time_info_daydo
# ------------------------------------------------------------

DROP TABLE IF EXISTS `emas_machine_real_time_info_daydo`;

CREATE TABLE `emas_machine_real_time_info_daydo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `cpu_usage_percentage_avg` decimal(10,10) DEFAULT NULL COMMENT 'CPU使用百分比-平均',
  `cpu_usage_percentage_max` decimal(10,10) DEFAULT NULL COMMENT 'CPU使用百分比-最大',
  `cpu_usage_percentage_min` decimal(10,10) DEFAULT NULL COMMENT 'CPU使用百分比-最小',
  `current_ability_reserved_avg` decimal(10,10) DEFAULT NULL COMMENT '能力留存值-平均',
  `current_ability_reserved_max` decimal(10,10) DEFAULT NULL COMMENT '能力留存值-最大',
  `current_ability_reserved_min` decimal(10,10) DEFAULT NULL COMMENT '能力留存值-最小',
  `current_ability_used_avg` decimal(10,10) DEFAULT NULL COMMENT '能力使用值-平均',
  `current_ability_used_max` decimal(10,10) DEFAULT NULL COMMENT '能力使用值-最大',
  `current_ability_used_min` decimal(10,10) DEFAULT NULL COMMENT '能力使用值-最小',
  `free_memory_avg` decimal(10,10) DEFAULT NULL COMMENT '内存存余量-平均',
  `free_memory_max` decimal(10,10) DEFAULT NULL COMMENT '内存存余量-最大',
  `free_memory_min` decimal(10,10) DEFAULT NULL COMMENT '内存存余量-最小',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `hard_disk_leftgbavg` decimal(10,10) DEFAULT NULL COMMENT '硬盘存余量-平均',
  `hard_disk_leftgbmax` decimal(10,10) DEFAULT NULL COMMENT '硬盘存余量-最大',
  `hard_disk_leftgbmin` decimal(10,10) DEFAULT NULL COMMENT '硬盘存余量-最小',
  `ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'IP',
  `load_for_last1minute_avg` decimal(10,10) DEFAULT NULL COMMENT '1分钟load值-平均',
  `load_for_last1minute_max` decimal(10,10) DEFAULT NULL COMMENT '1分钟load值-最大',
  `load_for_last1minute_min` decimal(10,10) DEFAULT NULL COMMENT '1分钟load值-最小',
  `memory_used_percentage_avg` decimal(10,10) DEFAULT NULL COMMENT '内存使用百分比-平均',
  `memory_used_percentage_max` decimal(10,10) DEFAULT NULL COMMENT '内存使用百分比-最大',
  `memory_used_percentage_min` decimal(10,10) DEFAULT NULL COMMENT '内存使用百分比-最小',
  `used_file_descriptor_count_avg` decimal(10,10) DEFAULT NULL COMMENT 'fd使用量-平均',
  `used_file_descriptor_count_max` decimal(10,10) DEFAULT NULL COMMENT 'fd使用量-最大',
  `used_file_descriptor_count_min` decimal(10,10) DEFAULT NULL COMMENT 'fd使用量-最小',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table emas_machine_real_time_info_hourdo
# ------------------------------------------------------------

DROP TABLE IF EXISTS `emas_machine_real_time_info_hourdo`;

CREATE TABLE `emas_machine_real_time_info_hourdo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `cpu_usage_percentage_avg` decimal(10,10) DEFAULT NULL COMMENT 'CPU使用百分比-平均',
  `cpu_usage_percentage_max` decimal(10,10) DEFAULT NULL COMMENT 'CPU使用百分比-最大',
  `cpu_usage_percentage_min` decimal(10,10) DEFAULT NULL COMMENT 'CPU使用百分比-最小',
  `current_ability_reserved_avg` decimal(10,10) DEFAULT NULL COMMENT '能力留存值-平均',
  `current_ability_reserved_max` decimal(10,10) DEFAULT NULL COMMENT '能力留存值-最大',
  `current_ability_reserved_min` decimal(10,10) DEFAULT NULL COMMENT '能力留存值-最小',
  `current_ability_used_avg` decimal(10,10) DEFAULT NULL COMMENT '能力使用值-平均',
  `current_ability_used_max` decimal(10,10) DEFAULT NULL COMMENT '能力使用值-最大',
  `current_ability_used_min` decimal(10,10) DEFAULT NULL COMMENT '能力使用值-最小',
  `free_memory_avg` decimal(10,10) DEFAULT NULL COMMENT '内存存余量-平均',
  `free_memory_max` decimal(10,10) DEFAULT NULL COMMENT '内存存余量-最大',
  `free_memory_min` decimal(10,10) DEFAULT NULL COMMENT '内存存余量-最小',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `hard_disk_leftgbavg` decimal(10,10) DEFAULT NULL COMMENT '硬盘存余量-平均',
  `hard_disk_leftgbmax` decimal(10,10) DEFAULT NULL COMMENT '硬盘存余量-最大',
  `hard_disk_leftgbmin` decimal(10,10) DEFAULT NULL COMMENT '硬盘存余量-最小',
  `ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'IP',
  `load_for_last1minute_avg` decimal(10,10) DEFAULT NULL COMMENT '1分钟load值-平均',
  `load_for_last1minute_max` decimal(10,10) DEFAULT NULL COMMENT '1分钟load值-最大',
  `load_for_last1minute_min` decimal(10,10) DEFAULT NULL COMMENT '1分钟load值-最小',
  `memory_used_percentage_avg` decimal(10,10) DEFAULT NULL COMMENT '内存使用百分比-平均',
  `memory_used_percentage_max` decimal(10,10) DEFAULT NULL COMMENT '内存使用百分比-最大',
  `memory_used_percentage_min` decimal(10,10) DEFAULT NULL COMMENT '内存使用百分比-最小',
  `used_file_descriptor_count_avg` decimal(10,10) DEFAULT NULL COMMENT 'fd使用量-平均',
  `used_file_descriptor_count_max` decimal(10,10) DEFAULT NULL COMMENT 'fd使用量-最大',
  `used_file_descriptor_count_min` decimal(10,10) DEFAULT NULL COMMENT 'fd使用量-最小',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table emas_machine_real_time_info_minutedo
# ------------------------------------------------------------

DROP TABLE IF EXISTS `emas_machine_real_time_info_minutedo`;

CREATE TABLE `emas_machine_real_time_info_minutedo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `cpu_usage_percentage_avg` decimal(10,10) DEFAULT NULL COMMENT 'CPU使用百分比-平均',
  `cpu_usage_percentage_max` decimal(10,10) DEFAULT NULL COMMENT 'CPU使用百分比-最大',
  `cpu_usage_percentage_min` decimal(10,10) DEFAULT NULL COMMENT 'CPU使用百分比-最小',
  `current_ability_reserved_avg` decimal(10,10) DEFAULT NULL COMMENT '能力留存值-平均',
  `current_ability_reserved_max` decimal(10,10) DEFAULT NULL COMMENT '能力留存值-最大',
  `current_ability_reserved_min` decimal(10,10) DEFAULT NULL COMMENT '能力留存值-最小',
  `current_ability_used_avg` decimal(10,10) DEFAULT NULL COMMENT '能力使用值-平均',
  `current_ability_used_max` decimal(10,10) DEFAULT NULL COMMENT '能力使用值-最大',
  `current_ability_used_min` decimal(10,10) DEFAULT NULL COMMENT '能力使用值-最小',
  `free_memory_avg` decimal(10,10) DEFAULT NULL COMMENT '内存存余量-平均',
  `free_memory_max` decimal(10,10) DEFAULT NULL COMMENT '内存存余量-最大',
  `free_memory_min` decimal(10,10) DEFAULT NULL COMMENT '内存存余量-最小',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `hard_disk_leftgbavg` decimal(10,10) DEFAULT NULL COMMENT '硬盘存余量-平均',
  `hard_disk_leftgbmax` decimal(10,10) DEFAULT NULL COMMENT '硬盘存余量-最大',
  `hard_disk_leftgbmin` decimal(10,10) DEFAULT NULL COMMENT '硬盘存余量-最小',
  `ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'IP',
  `load_for_last1minute_avg` decimal(10,10) DEFAULT NULL COMMENT '1分钟load值-平均',
  `load_for_last1minute_max` decimal(10,10) DEFAULT NULL COMMENT '1分钟load值-最大',
  `load_for_last1minute_min` decimal(10,10) DEFAULT NULL COMMENT '1分钟load值-最小',
  `memory_used_percentage_avg` decimal(10,10) DEFAULT NULL COMMENT '内存使用百分比-平均',
  `memory_used_percentage_max` decimal(10,10) DEFAULT NULL COMMENT '内存使用百分比-最大',
  `memory_used_percentage_min` decimal(10,10) DEFAULT NULL COMMENT '内存使用百分比-最小',
  `used_file_descriptor_count_avg` decimal(10,10) DEFAULT NULL COMMENT 'fd使用量-平均',
  `used_file_descriptor_count_max` decimal(10,10) DEFAULT NULL COMMENT 'fd使用量-最大',
  `used_file_descriptor_count_min` decimal(10,10) DEFAULT NULL COMMENT 'fd使用量-最小',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table emas_machine_real_time_infodo
# ------------------------------------------------------------

DROP TABLE IF EXISTS `emas_machine_real_time_infodo`;

CREATE TABLE `emas_machine_real_time_infodo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `cpu_usage_percentage` decimal(10,10) DEFAULT NULL COMMENT 'CPU使用百分比',
  `free_memory` decimal(10,10) DEFAULT NULL COMMENT '内存存余量',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `hard_disk_leftgb` decimal(10,10) DEFAULT NULL COMMENT '硬盘存余量',
  `ip` varchar(255) DEFAULT NULL COMMENT 'IP',
  `load_for_last1minute` decimal(10,10) DEFAULT NULL COMMENT '1分钟load值',
  `memory_used_percentage` decimal(10,10) DEFAULT NULL COMMENT '内存使用百分比',
  `used_file_descriptor_count` bigint(20) DEFAULT NULL COMMENT 'fd使用量',
  `current_ability_reserved` int(11) DEFAULT NULL COMMENT '能力存余量',
  `current_ability_used` int(11) DEFAULT NULL COMMENT '能力使用量',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table emas_monitor_taskdo
# ------------------------------------------------------------

DROP TABLE IF EXISTS `emas_monitor_taskdo`;

CREATE TABLE `emas_monitor_taskdo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'monitor ID',
  `condition_json` varchar(255) DEFAULT NULL COMMENT '条件 json',
  `condition_type` int(11) DEFAULT NULL COMMENT '条件类型',
  `creator` varchar(64) DEFAULT NULL COMMENT '创建人',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `modifier` varchar(64) DEFAULT NULL COMMENT '修改人',
  `monitor_task_name` varchar(255) DEFAULT NULL COMMENT '监控名称',
  `monitor_task_status` int(11) DEFAULT NULL COMMENT '监控状态',
  `action_id` bigint(20) DEFAULT NULL COMMENT '行动ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table emas_monitor_taskdo_machine_info_id_set
# ------------------------------------------------------------

DROP TABLE IF EXISTS `emas_monitor_taskdo_machine_info_id_set`;

CREATE TABLE `emas_monitor_taskdo_machine_info_id_set` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键 ID',
  `emas_monitor_taskdo_id` bigint(20) NOT NULL COMMENT 'monitor ID',
  `machine_info_id_set` bigint(20) DEFAULT NULL COMMENT 'machine ID',
  KEY `FKp6r0hh73s4rl1syjoo0vp8uw9` (`emas_monitor_taskdo_id`),
  CONSTRAINT `FKp6r0hh73s4rl1syjoo0vp8uw9` FOREIGN KEY (`emas_monitor_taskdo_id`) REFERENCES `emas_monitor_taskdo` (`id`),
            PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
