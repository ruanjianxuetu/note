USE `emas`;
-- 发现之前直接在create语句改的字段属性，这里重新把Alter SQL补充上去
BEGIN;
ALTER TABLE `emas_certificate` MODIFY `certificate_file` mediumblob NOT NULL COMMENT '实际文件';
ALTER TABLE `emas_profile` MODIFY `profile_file` mediumblob NOT NULL COMMENT '实际文件';

ALTER TABLE `emas_profile` MODIFY `last_modify_time` datetime NOT NULL COMMENT '最后修改时间';
ALTER TABLE `emas_certificate` MODIFY `last_modify_time` datetime NOT NULL COMMENT '最后修改时间';
COMMIT;
