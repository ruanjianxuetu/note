USE `emas`;
INSERT INTO `emas_build_error_solution` (`gmt_create`, `gmt_modified`, `creator`, `modifier`, `is_deleted`, `title`, `keyword`, `solution`, `platform`, `phase`, `category`, `error_type_id`, `hit_count`, `up_count`, `down_count`, `rate`)
VALUES
	(now(), now(), '10000', '10000', 0, 'Android更新用户协议', 'Failed to install the following Android SDK packages as some licences have not been accepted', '联系系统管理员解决', 'ANDROID', 'BUILD', 'PLATFORM', 5, 0, 0, 0, 0);
