USE `emas`;
BEGIN;

alter table emas_publish_operation_log modify old_value varchar(255);
alter table emas_publish_operation_log modify new_value varchar(255);

COMMIT;