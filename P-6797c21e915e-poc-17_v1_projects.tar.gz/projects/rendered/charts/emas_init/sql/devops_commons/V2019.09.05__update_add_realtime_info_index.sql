USE `emas`;
-- 打包机状态统计的4张表增加查询索引
BEGIN;
ALTER TABLE `emas_machine_real_time_infodo` ADD INDEX index_gmt_create(`gmt_create` DESC);
ALTER TABLE `emas_machine_real_time_info_minutedo` ADD INDEX index_gmt_create(`gmt_create` DESC);
ALTER TABLE `emas_machine_real_time_info_hourdo` ADD INDEX index_gmt_create(`gmt_create` DESC);
ALTER TABLE `emas_machine_real_time_info_daydo` ADD INDEX index_gmt_create(`gmt_create` DESC);
COMMIT;