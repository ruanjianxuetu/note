USE `emas`;
ALTER TABLE  `emas_build_task_detail` ADD COLUMN `xcode_version` VARCHAR (30);