USE `emas`;
DELETE FROM `emas_build_script` WHERE `id` = 3;

INSERT INTO `emas_build_script` (`id`, `func_name`, `display_name`, `version`, `content`, `gmt_create`, `gmt_modified`, `creator`, `modifier`, `status`, `func_type`, `fatal`)
VALUES
	(3, 'git_clone', '下载代码', '1.0', 'local build_task_id=$!{buildTask.id}\nlocal work_dir=~/.emas/build/${build_task_id}\ncd \"$work_dir\"\npwd\n\n#if($!buildTask.buildConfig.scmAddress)\nlocal scm_address=$!buildTask.buildConfig.scmAddress\nlocal scm_branch=$!buildTask.buildConfig.scmBranch\nif [ -d workspace ]; then\nrm -rf workspace\nfi\ngit clone -b $scm_branch --depth 1 $scm_address workspace\ncd workspace\nGIT_COMMIT=`git rev-parse HEAD`\necho GIT_COMMIT=$(echo $GIT_COMMIT) > ../gitRevision.properties\n#//get git commit\nexport GLOBAL_GIT_COMMIT=$GIT_COMMIT\nif [ -f .gitmodules ] && [ ! -f .muppignoresubmodule ]; then\ngit submodule update --init --recursive\nfi\n#else\nmkdir workspace\n#end', NULL, NULL, NULL, NULL, 0, 'PRE_INIT', 1);
