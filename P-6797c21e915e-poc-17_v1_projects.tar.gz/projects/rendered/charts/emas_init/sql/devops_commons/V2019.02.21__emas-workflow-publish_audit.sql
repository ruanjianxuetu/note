USE `emas`;
BEGIN;
-- 插入发布审核工作流系统模板
INSERT INTO `emas_workflow_service_list` (`modifier`, `creator`, `gmt_create`, `gmt_modified`, `is_deleted`, `foreign_id`, `app_id`, `config_id`, `project_id`, `name`, `type`, `source`, `enabled`, `module_id`, `node_list`, `context`, `is_default`, `category`, `is_template`)
VALUES
	(NULL, NULL, now(), now(), 0, NULL, NULL, NULL, NULL, NULL, 'PUBLISH', 'SYSTEM', 0, NULL, '[{\"enabled\":true,\"name\":\"PUBLISH_CREATE_BATCH_NODE\",\"type\":\"NODE_FLAG\"},{\"enabled\":true,\"name\":\"PUBLISH_BATCH_AUDIT_NODE\",\"type\":\"PUBLISH_BATCH_AUDIT\"}]', NULL, 1, 'PUBLISH_AREA', 1);
COMMIT;