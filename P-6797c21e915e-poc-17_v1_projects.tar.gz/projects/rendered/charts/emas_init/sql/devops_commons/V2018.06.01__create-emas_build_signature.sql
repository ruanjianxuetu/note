USE `emas`;
# 构建签名表
CREATE TABLE `emas_build_signature` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `app_id` bigint(20) unsigned NOT NULL COMMENT '应用ID',
  `enabled` tinyint(4) NOT NULL COMMENT '是否启用',
  `key_store_type` varchar(32) NOT NULL COMMENT 'KeyStore类型',
  `key_store_file` blob NOT NULL COMMENT 'KeyStore文件',
  `key_store_password` varchar(512) NOT NULL COMMENT 'KeyStore密码',
  `key_alias` varchar(512) NOT NULL COMMENT 'KeyStore别名',
  `key_password` varchar(512) NOT NULL COMMENT 'Key密码',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `creator` varchar(16) NOT NULL COMMENT '创建人',
  `modifier` varchar(16) NOT NULL COMMENT '修改人',
  `is_deleted` tinyint(4) NOT NULL COMMENT '是否删除',
  PRIMARY KEY (`id`),
  KEY `idx_app_id` (`app_id`) USING BTREE COMMENT '应用ID索引',
  KEY `idx_gmt_create` (`gmt_create`) USING BTREE COMMENT '应用创建时间索引'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Android证书文件表';
