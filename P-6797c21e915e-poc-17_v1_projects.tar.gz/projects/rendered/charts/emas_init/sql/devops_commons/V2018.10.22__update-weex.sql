USE `emas`;
DELETE FROM `emas_build_config` WHERE `id` in (21);

INSERT INTO `emas_build_config` (`id`, `app_id`, `project_id`, `config_type`, `scm_address`, `scm_branch`, `template_name`, `param_json`, `timer_config_json`, `trigger_types`, `extra`, `gmt_create`, `gmt_modified`, `creator`, `modifier`, `status`, `cr_id`, `template_id`)
VALUES
	(21, 0, 0, 1028, '', '', 'weex系统模板', '{\"tasks\":[{\"abortIfError\":false,\"label\":\"模块发布默认模板\",\"params\":[{\"desc\":\"\",\"id\":\"commands\",\"label\":\"打包脚本\",\"type\":\"textarea\",\"value\":\"npm install\\nnpm run build\"},{\"desc\":\"\",\"id\":\"result.match.names\",\"label\":\"构建产物名称\",\"type\":\"text\",\"value\":\"*.js\"},{\"desc\":\"\",\"id\":\"result.match.paths\",\"label\":\"构建产物路径\",\"type\":\"text\",\"value\":\"dist/*\"}],\"retryTimes\":0,\"taskType\":1,\"value\":\"true\"}]}', NULL, NULL, NULL, now(), now(), '10000', NULL, 0, NULL, NULL);
