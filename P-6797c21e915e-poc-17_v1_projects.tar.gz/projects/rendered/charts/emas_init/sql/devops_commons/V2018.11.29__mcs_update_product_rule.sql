USE `emas`;
update emas_mcs_product_rule set  scan_type = 'ALI_DSL_SCAN' where scan_type = 'ALI_WEEX_SCAN';
update emas_mcs_global_rule set  scan_type = 'ALI_DSL_SCAN' where scan_type = 'ALI_WEEX_SCAN';