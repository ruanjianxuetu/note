USE `emas`;
BEGIN;
-- 删除初始化的 ios证书、profile
delete from emas_profile where id in (56,59,63,65,66,67,68) and expire_time < "2018-01-01";
delete from emas_certificate where id in (69,70,73,75) and expire_time < "2018-01-01";
COMMIT;
