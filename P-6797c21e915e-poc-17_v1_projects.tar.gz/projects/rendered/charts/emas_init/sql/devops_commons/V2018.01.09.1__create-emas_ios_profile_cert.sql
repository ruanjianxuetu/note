USE `emas`;
CREATE TABLE `emas_certificate` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `administrators_set` text NOT NULL COMMENT '管理员列表',
  `applications_set` text COMMENT '应用列表',
  `certificate_file` mediumblob NOT NULL COMMENT '实际文件',
  `create_time` timestamp NOT NULL COMMENT '创建时间',
  `creator` text NOT NULL COMMENT '创建人',
  `expire_time` date NOT NULL COMMENT '过期时间',
  `full_name` text NOT NULL COMMENT '证书全名',
  `is_private` tinyint(1) NOT NULL COMMENT '是否私有',
  `last_modifier` text NOT NULL COMMENT '最后修改人',
  `last_modify_time` datetime NOT NULL COMMENT '最后修改时间',
  `name` text NOT NULL COMMENT '名称',
  `organization_unit` text NOT NULL COMMENT '组织单位',
  `password` varchar(255) NOT NULL DEFAULT '' COMMENT '密码',
  `type` text NOT NULL COMMENT '证书类型',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8;

CREATE TABLE `emas_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `administrators_set` text NOT NULL COMMENT '管理员列表',
  `create_time` timestamp NOT NULL COMMENT '创建时间',
  `creator` text NOT NULL COMMENT '创建人',
  `expire_time` date NOT NULL COMMENT '过期时间',
  `identifier` varchar(255) NOT NULL DEFAULT '' COMMENT '标识',
  `last_modifier` text NOT NULL COMMENT '最后修改人',
  `last_modify_time` datetime NOT NULL COMMENT '最后修改时间',
  `name` text NOT NULL COMMENT '名字',
  `profile_file` mediumblob NOT NULL COMMENT '实际文件',
  `certificateid` bigint(20) NOT NULL COMMENT '对应的证书',
  PRIMARY KEY (`id`),
  KEY `FKri9yslq9ooxle6kacc5ybd1f` (`certificateid`),
  CONSTRAINT `FKri9yslq9ooxle6kacc5ybd1f` FOREIGN KEY (`certificateid`) REFERENCES `emas_certificate` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8;
