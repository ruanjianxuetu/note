USE `emas`;
CREATE TABLE IF NOT EXISTS `emas_publish_config_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code_repository` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '仓库地址',
  `default_branch` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '默认分支',
  `default_notify_count` int(11) NOT NULL COMMENT '默认通知人数',
  `default_description` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '默认描述',
  `current_app_version` varchar(1024) COLLATE utf8_unicode_ci NOT NULL COMMENT 'appversion',
  `current_app_version_code` int(11) NOT NULL COMMENT '当前 version code',
  `least_support_api_level` int(11) NOT NULL COMMENT '最低支持版本',
  `applicationId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci
;

CREATE TABLE IF NOT EXISTS `emas_publish_file` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `product_id` bigint(20) NOT NULL COMMENT '产品ID',
  `project_id` bigint(20) NOT NULL COMMENT '项目ID',
  `build_config_id` bigint(20) NOT NULL COMMENT '构建配置ID',
  `build_task_id` bigint(20) NOT NULL COMMENT '构建任务ID',
  `file_type` varchar(64) COLLATE utf8_unicode_ci NOT NULL COMMENT '文件的类型',
  `file_name` varchar(1024) COLLATE utf8_unicode_ci NOT NULL COMMENT '文件名',
  `digest` varchar(64) COLLATE utf8_unicode_ci NOT NULL COMMENT '文件摘要串',
  `size` bigint(24) NOT NULL COMMENT '文件字节数',
  `oss_url` varchar(1024) COLLATE utf8_unicode_ci NOT NULL COMMENT 'OSS文件URL',
  `cdn_url` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '文件的cdn地址',
  `file_json` text COLLATE utf8_unicode_ci COMMENT '文件详情',
  `params` text COLLATE utf8_unicode_ci COMMENT '文件参数',
  `remark` text COLLATE utf8_unicode_ci COMMENT '文件评论',
  `file_status` varchar(64) COLLATE utf8_unicode_ci NOT NULL COMMENT '文件状态',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `offical_cdn_url` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '官网发布cdn地址',
  `persistence_status` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '持久化的状态',
  `is_oss_deleted` tinyint(4) DEFAULT NULL COMMENT '是否被OSS删除',
  `cdn_status` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'CDN 上传状态',
  `md5` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '文件的 md5 值',
  `creator` varchar(64) COLLATE utf8_unicode_ci NOT NULL COMMENT 'CDN 上传者',
  PRIMARY KEY (`id`),
  KEY `build_task_id_idx` (`build_task_id`),
  KEY `project_id_idx` (`project_id`),
  KEY `product_id_idx` (`product_id`),
  KEY `build_config_id_idx` (`build_config_id`),
  KEY `digest_idx` (`digest`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci
;

CREATE TABLE IF NOT EXISTS `emas_publish_operation_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `operation_type` varchar(64) NOT NULL COMMENT '操作类型',
  `operator` varchar(64) NOT NULL COMMENT '操作人',
  `old_value` varchar(64) DEFAULT NULL COMMENT '旧值',
  `new_value` varchar(64) DEFAULT NULL COMMENT '新值',
  `json_msg` text COMMENT '操作的JSON信息',
  `msg` text COMMENT '操作备注',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `foreign_id` bigint(20) unsigned NOT NULL COMMENT '关联对象的ID',
  `category` varchar(64) NOT NULL COMMENT '关联对象的类型',
  PRIMARY KEY (`id`),
  KEY `idx_operationtype_foreignid` (`operation_type`,`foreign_id`),
  KEY `idx_foreignd_category` (`foreign_id`,`category`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000  DEFAULT CHARSET=utf8 COMMENT='用户操作记录通用表'
;

CREATE TABLE IF NOT EXISTS `emas_publish_project` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `foreign_id` bigint(20) DEFAULT NULL COMMENT '创建者元项目ID',
  `app_key` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '创建应用生成的 appkey',
  `is_intg` int(11) DEFAULT NULL COMMENT '是否是集成区',
  `publish_intg_area_id` bigint(20) DEFAULT NULL COMMENT '项目集成区 id',
  `expect_version_name` varchar(1024) COLLATE utf8_unicode_ci NOT NULL COMMENT '预期版本号, 创建发布单时填写的版本号',
  `expect_publish_date` datetime DEFAULT NULL COMMENT '预期发布时间',
  `publish_status` varchar(1024) COLLATE utf8_unicode_ci NOT NULL COMMENT '项目发布状态',
  `description` varchar(2048) COLLATE utf8_unicode_ci NOT NULL COMMENT '项目描述',
  `gmt_finish` datetime DEFAULT NULL COMMENT '项目发布成功时间',
  `cdn_folder` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'cdn 上传目录',
  `publish_date` datetime DEFAULT NULL COMMENT '实际发布时间',
  `is_dynamic_deploy` int(11) DEFAULT NULL COMMENT '是否是动态部署 Main, hotpatch, andfix',
  `target_update_versions` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '动态部署版本列表',
  `start_publish_time` datetime DEFAULT NULL COMMENT '开始发布时间, 第一次冻结集成区的时间',
  `package_type` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '整包或者动态部署补丁',
  `project_status` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '项目状态',
  `project_name` varchar(45) COLLATE utf8_unicode_ci NOT NULL COMMENT '发布单名称 --> project_name',
  `code_branch` varchar(1024) COLLATE utf8_unicode_ci NOT NULL COMMENT '分支',
  `publish_file_id` varchar(2048) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '最终归档的文件',
  `platform_type` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '平台类型',
  `outer_publish_id` bigint(20) DEFAULT NULL COMMENT '发布服务的 id',
  `current_ui_status` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '当前发布单显示的界面',
  `publish_type` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '发布类型.. 整包, 动态部署',
  `app_id` bigint(20) NOT NULL COMMENT '应用 Id',
  `creator` bigint(20) NOT NULL COMMENT '项目创建人',
  `modifier` bigint(20) DEFAULT NULL COMMENT '修改人',
  `is_deleted` tinyint(4) NOT NULL COMMENT '是否已被删除',
  `gmt_create` datetime NOT NULL COMMENT '项目创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '项目修改时间',
  `version_code` int(11) DEFAULT NULL COMMENT '版本序号(Android) ios 为空',
  `version` varchar(45) COLLATE utf8_unicode_ci NOT NULL COMMENT '版本',
  `secret_type` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '项目保密类型',
  `beta_type` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'beta 类型',
  `increment_comparison_version` bigint(20) DEFAULT NULL COMMENT '增量回归的对比发布单 id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci
;

CREATE TABLE IF NOT EXISTS `emas_publish_project_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` tinyint(4) NOT NULL COMMENT '是否已经删除',
  `creator` bigint(20) unsigned NOT NULL COMMENT '创建人',
  `modifier` bigint(20) unsigned NOT NULL COMMENT '修改人',
  `user_id` bigint(20) unsigned NOT NULL COMMENT '用户ID',
  `publish_project_id` bigint(20) unsigned NOT NULL COMMENT '发布单ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci
;

CREATE TABLE IF NOT EXISTS `emas_publish_regression_item` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `publish_regression_id` bigint(20) unsigned DEFAULT NULL COMMENT 'publish_regression_main的外键',
  `foreign_id` bigint(20) unsigned DEFAULT NULL COMMENT '发布项目id',
  `project_id` bigint(20) unsigned DEFAULT NULL COMMENT '项目id',
  `project_name` varchar(128) DEFAULT NULL COMMENT '项目名称',
  `ptm` varchar(128) DEFAULT NULL COMMENT '工号列表，以逗号分隔',
  `regression_status` varchar(32) DEFAULT NULL COMMENT '回归状态',
  `remark` varchar(256) DEFAULT NULL COMMENT '备注',
  `module_id` bigint(20) unsigned DEFAULT NULL COMMENT 'module id',
  `module_name_ch` varchar(128) DEFAULT NULL COMMENT 'module中文名',
  `type` varchar(32) DEFAULT NULL COMMENT '类型，项目/module',
  `module_name_en` varchar(128) DEFAULT NULL COMMENT 'module英文名',
  `start_regression_time` datetime DEFAULT NULL COMMENT '开始回归的时间',
  `end_regression_time` datetime DEFAULT NULL COMMENT '结束回归的时间',
  `start_regression_user` varchar(64) DEFAULT NULL COMMENT '开始回归的用户id',
  `end_regression_user` varchar(64) DEFAULT NULL COMMENT '结束回归的用户id',
  PRIMARY KEY (`id`),
  KEY `foreign_id_idx` (`foreign_id`),
  KEY `regression_id_idx` (`publish_regression_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='发布回归包含的项目及module'
;

CREATE TABLE IF NOT EXISTS `emas_publish_regression_main` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `foreign_id` bigint(20) unsigned DEFAULT NULL COMMENT '发布项目id',
  `build_id` bigint(20) unsigned DEFAULT NULL COMMENT '构建号，对应打包id',
  `version` varchar(32) DEFAULT NULL COMMENT '发布版本号',
  `channel_id` varchar(32) DEFAULT NULL COMMENT '渠道号',
  `regression_status` varchar(32) DEFAULT NULL COMMENT '回归状态，初始化/回归中/回归成功/回归失败',
  `creator` varchar(32) DEFAULT NULL COMMENT '创建人',
  `modifier` varchar(32) DEFAULT NULL COMMENT '最后修改人',
  `round` int(11) DEFAULT NULL COMMENT '回归轮次',
  `version_code` varchar(16) DEFAULT NULL COMMENT 'versionCode',
  `regression_type` varchar(32) DEFAULT NULL COMMENT '回归类型，增量/全量',
  `inc_regression_main_id` bigint(20) DEFAULT NULL COMMENT '增量回归对比的id',
  `start_regression_time` datetime DEFAULT NULL,
  `end_regression_time` datetime DEFAULT NULL,
  `start_regression_user` varchar(64) DEFAULT NULL,
  `end_regression_user` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `foreign_id_idx` (`foreign_id`),
  KEY `build_id_idx` (`build_id`),
  KEY `foreignid_round_idx` (`foreign_id`,`round`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='项目发布回归主表'
;
