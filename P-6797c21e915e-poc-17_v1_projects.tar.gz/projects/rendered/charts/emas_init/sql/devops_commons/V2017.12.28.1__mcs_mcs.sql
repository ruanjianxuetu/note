USE `emas`;
/*
 Navicat Premium Data Transfer

 Source Server         : scancode
 Source Server Type    : MySQL
 Source Server Version : 50720
 Source Host           : 10.101.105.3:3306
 Source Schema         : test

 Target Server Type    : MySQL
 Target Server Version : 50720
 File Encoding         : 65001

 Date: 02/02/2018 20:56:33
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for emas_mcs_app
-- ----------------------------
DROP TABLE IF EXISTS `emas_mcs_app`;
CREATE TABLE `emas_mcs_app` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` tinyint(4) NOT NULL COMMENT '是否删除',
  `name` varchar(1024) NOT NULL COMMENT '名称',
  `parent_product_id` bigint(20) NOT NULL COMMENT '基座的产品ID',
  `platform` varchar(128) NOT NULL COMMENT '平台',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_id_platform` (`parent_product_id`,`platform`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='应用表';

-- ----------------------------
-- Table structure for emas_mcs_app_module
-- ----------------------------
DROP TABLE IF EXISTS `emas_mcs_app_module`;
CREATE TABLE `emas_mcs_app_module` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gmt_create` datetime NOT NULL,
  `gmt_modified` datetime NOT NULL,
  `app_id` bigint(20) NOT NULL,
  `module_id` bigint(20) NOT NULL,
  `is_active` tinyint(4) NOT NULL COMMENT '是否绑定',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_app_module` (`app_id`,`module_id`) USING BTREE,
  KEY `idx_app_id` (`app_id`) USING BTREE,
  KEY `idx_module_id` (`module_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='应用模块关系表';

-- ----------------------------
-- Table structure for emas_mcs_global_rule
-- ----------------------------
DROP TABLE IF EXISTS `emas_mcs_global_rule`;
CREATE TABLE `emas_mcs_global_rule` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '规则id',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `rule_name` varchar(255) NOT NULL COMMENT '规则名称',
  `rule_description` longtext NOT NULL COMMENT '规则简要描述',
  `rule_description_detail` longtext COMMENT '规则详细描述',
  `is_enabled` varchar(20) NOT NULL COMMENT '是否开启',
  `rule_creator` varchar(128) NOT NULL COMMENT '规则创建人',
  `rule_modifier` varchar(128) NOT NULL COMMENT '规则修改人',
  `rule_category` varchar(128) NOT NULL COMMENT '规则类别',
  `rule_level` varchar(20) NOT NULL COMMENT '规则登记',
  `platform` varchar(128) NOT NULL COMMENT '规则适用平台，可以是Android、IOS、Weex',
  `scan_type` varchar(128) NOT NULL COMMENT '规则类型：比如AndroidLint、Windbags、ScanBuild、WeexLint等',
  `is_deleted` tinyint(4) DEFAULT '0' COMMENT '逻辑删除字段\n',
  PRIMARY KEY (`id`),
  UNIQUE KEY `rule_name_is_deleted_UNIQUE` (`rule_name`,`is_deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='全局规则表';

-- ----------------------------
-- Table structure for emas_mcs_issue
-- ----------------------------
DROP TABLE IF EXISTS `emas_mcs_issue`;
CREATE TABLE `emas_mcs_issue` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `issue_category` varchar(128) DEFAULT NULL COMMENT 'issue分类，暂时用不到，以后会有白盒、黑盒、安全等等',
  `issue_title` varchar(255) DEFAULT NULL COMMENT 'issue标题',
  `modifier` varchar(128) NOT NULL COMMENT 'issue最后修改人\n',
  `submitor` varchar(128) NOT NULL COMMENT 'issue提交人',
  `handler` varchar(128) NOT NULL COMMENT 'issue处理人',
  `priority` varchar(128) NOT NULL COMMENT 'issue优先级',
  `description` longtext COMMENT 'issue 描述',
  `status` varchar(128) NOT NULL COMMENT 'issue状态',
  `platform` varchar(128) NOT NULL COMMENT '平台',
  `project_id` bigint(20) DEFAULT NULL COMMENT '项目ID',
  `product_id` bigint(20) DEFAULT NULL COMMENT '产品ID',
  `scm_branch` varchar(255) NOT NULL COMMENT 'scm 分支',
  `scm_address` varchar(255) NOT NULL COMMENT 'scm 地址',
  `scm_commit` varchar(255) DEFAULT NULL COMMENT 'scm commit',
  `is_deleted` tinyint(4) DEFAULT NULL COMMENT '是否删除',
  `scan_record_id` bigint(20) NOT NULL COMMENT '构件号',
  `foreign_url` varchar(512) DEFAULT NULL COMMENT '外部调用地址',
  `scan_type` varchar(128) NOT NULL COMMENT '扫描工具类型',
  `class_name` varchar(255) NOT NULL COMMENT '类名',
  `rule_name` varchar(128) NOT NULL COMMENT '规则名',
  `rule_category` varchar(128) NOT NULL COMMENT '规则类型',
  `row_start_num` int(11) NOT NULL COMMENT '行开始',
  `column_start_num` int(11) NOT NULL COMMENT '列开始',
  `row_end_num` int(11) NOT NULL COMMENT '行结束',
  `column_end_num` int(11) NOT NULL COMMENT '列结束',
  `issue_md5` varchar(128) DEFAULT NULL COMMENT '问题MD5码',
  `code_scan_identify` varchar(255) NOT NULL COMMENT '唯一标示',
  `scm_type` varchar(128) DEFAULT NULL COMMENT 'git,svn,url等',
  `code_part_content` longtext NOT NULL COMMENT '问题代码段',
  `parent_product_id` bigint(20) DEFAULT NULL COMMENT '父产品Id',
  `expect_fix_time` datetime DEFAULT NULL COMMENT '期望修复时间',
  PRIMARY KEY (`id`),
  KEY `idx_scm_scan` (`scm_address`,`scm_branch`,`status`,`scan_type`) COMMENT 'findresult',
  KEY `idx_product_id` (`product_id`,`parent_product_id`),
  KEY `idx_project_id` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for emas_mcs_issue_operation
-- ----------------------------
DROP TABLE IF EXISTS `emas_mcs_issue_operation`;
CREATE TABLE `emas_mcs_issue_operation` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '更新时间',
  `issue_id` bigint(20) DEFAULT NULL COMMENT 'issue id',
  `operation_json` text COMMENT '操作记录，操作对象的JSON串',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `idx_issue_id` (`issue_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for emas_mcs_issue_statistics_children
-- ----------------------------
DROP TABLE IF EXISTS `emas_mcs_issue_statistics_children`;
CREATE TABLE `emas_mcs_issue_statistics_children` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `type_distribution` text COMMENT 'bug问题分布描述',
  `product_name` varchar(255) DEFAULT '' COMMENT '子产品名',
  `scan_type` varchar(255) NOT NULL DEFAULT '' COMMENT '扫描工具类型',
  `datetime` varchar(255) NOT NULL COMMENT '问题发现日期',
  `issue_fixed_count` int(11) DEFAULT '0' COMMENT '已修复issue数',
  `issue_new_count` int(11) DEFAULT '0' COMMENT '未修复issue数',
  `issue_sum` int(11) DEFAULT '0' COMMENT '总问题统计',
  `project_id` varchar(255) DEFAULT '' COMMENT '项目Id',
  `scm_branch` varchar(255) DEFAULT '' COMMENT '分支',
  `platform` varchar(32) NOT NULL COMMENT '平台类型',
  `exception_distribution` text COMMENT '规则分布描述',
  `parent_product_id` bigint(20) NOT NULL COMMENT '父产品id',
  `product_id` bigint(20) NOT NULL COMMENT '子产品id',
  `project_name` varchar(255) DEFAULT '' COMMENT 'mtl项目名',
  `p1_sum` int(11) DEFAULT '0',
  `p2_sum` int(11) DEFAULT '0',
  `p3_sum` int(11) DEFAULT '0',
  `p4_sum` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_product_date` (`parent_product_id`,`platform`,`datetime`,`product_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='每日数据统计表-子产品表';

-- ----------------------------
-- Table structure for emas_mcs_issue_statistics_parent
-- ----------------------------
DROP TABLE IF EXISTS `emas_mcs_issue_statistics_parent`;
CREATE TABLE `emas_mcs_issue_statistics_parent` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `scan_bundle_number` int(11) DEFAULT '0' COMMENT '参与扫描的bundle数',
  `total_bundle_number` int(11) DEFAULT '0' COMMENT '总bundle数',
  `scan_branch_sum` int(11) DEFAULT '0' COMMENT '扫描分支数',
  `total_scan_sum` int(11) DEFAULT '0' COMMENT '扫描总次数',
  `issue_sum` bigint(20) DEFAULT '0' COMMENT '发现问题数',
  `issue_fixed` bigint(20) DEFAULT '0' COMMENT '修复问题总数',
  `issue_new` bigint(20) DEFAULT '0' COMMENT '未修复问题总数',
  `issue_p1_sum` bigint(20) DEFAULT '0' COMMENT 'P1',
  `issue_p2_sum` bigint(20) DEFAULT '0' COMMENT 'P2',
  `issue_p3_sum` bigint(20) DEFAULT '0' COMMENT 'P3',
  `issue_p4_sum` bigint(20) DEFAULT '0' COMMENT 'P4',
  `parent_product_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '父产品Id',
  `parent_product_name` varchar(255) DEFAULT '' COMMENT '父产品名',
  `scan_type` varchar(128) NOT NULL COMMENT '扫描类型',
  `platform` varchar(255) DEFAULT '' COMMENT '平台',
  `datetime` varchar(255) NOT NULL DEFAULT '' COMMENT '日期',
  `type_distribution` text COMMENT '类型分布',
  `exception_distribution` text COMMENT '自定义问题分布',
  PRIMARY KEY (`id`),
  KEY `idx_product_date` (`parent_product_id`,`platform`,`datetime`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='每日数据统计表-父产品表';

-- ----------------------------
-- Table structure for emas_mcs_issue_statistics_record
-- ----------------------------
DROP TABLE IF EXISTS `emas_mcs_issue_statistics_record`;
CREATE TABLE `emas_mcs_issue_statistics_record` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `scan_type` varchar(255) NOT NULL COMMENT '扫描类型',
  `date_time` varchar(20) NOT NULL COMMENT '表示统计的哪一天',
  `status` varchar(20) NOT NULL DEFAULT '0' COMMENT '执行状态',
  `reason` text COMMENT '错误原因',
  PRIMARY KEY (`id`),
  KEY `idx_scan_date` (`scan_type`,`date_time`) USING BTREE,
  KEY `idx_gmt_create` (`gmt_create`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='数据大盘统计任务记录';

-- ----------------------------
-- Table structure for emas_mcs_module
-- ----------------------------
DROP TABLE IF EXISTS `emas_mcs_module`;
CREATE TABLE `emas_mcs_module` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` tinyint(4) NOT NULL COMMENT '是否删除',
  `product_id` bigint(20) NOT NULL COMMENT '基座模块子产品id',
  `name` varchar(255) NOT NULL COMMENT '名称',
  `platform` varchar(255) NOT NULL COMMENT '平台',
  `module_type` varchar(255) NOT NULL COMMENT '模块类型',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_id_platform` (`product_id`,`platform`) USING BTREE,
  KEY `idx_name` (`name`) USING BTREE,
  KEY `idx_platform` (`platform`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='模块表';

-- ----------------------------
-- Table structure for emas_mcs_product_rule
-- ----------------------------
DROP TABLE IF EXISTS `emas_mcs_product_rule`;
CREATE TABLE `emas_mcs_product_rule` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `product_id` bigint(20) DEFAULT NULL COMMENT '产品标识id（可以是EMAX平台中的模块或者JSBundle）',
  `parent_product_id` bigint(20) DEFAULT NULL COMMENT '父产品标识id（可以是EMAX中的应用）',
  `rule_id` bigint(20) DEFAULT NULL COMMENT '对应的规则id',
  `rule_category` varchar(128) NOT NULL COMMENT '规则类别',
  `link_creator` varchar(128) DEFAULT NULL,
  `link_modifier` varchar(128) DEFAULT NULL,
  `is_enabled` varchar(20) NOT NULL COMMENT '是否开启',
  `rule_level` varchar(20) NOT NULL COMMENT '规则等级',
  `rule_name` varchar(255) NOT NULL COMMENT '规则名称',
  `rule_description` longtext NOT NULL COMMENT '规则简要描述',
  `is_deleted` tinyint(4) DEFAULT '0' COMMENT '逻辑删除字段',
  `platform` varchar(128) NOT NULL COMMENT '规则适用平台',
  `scan_type` varchar(128) NOT NULL COMMENT '规则对应的扫描类型',
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_rule_UNIQUE` (`product_id`,`parent_product_id`,`rule_id`,`is_deleted`,`gmt_modified`),
  KEY `rule_id_INDEX` (`rule_id`),
  KEY `parent_product_id_INDEX` (`parent_product_id`),
  KEY `product_id_INDEX` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for EMAS_MCS_QRTZ_BLOB_TRIGGERS
-- ----------------------------
DROP TABLE IF EXISTS `EMAS_MCS_QRTZ_BLOB_TRIGGERS`;
CREATE TABLE `EMAS_MCS_QRTZ_BLOB_TRIGGERS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `BLOB_DATA` blob,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for EMAS_MCS_QRTZ_CALENDARS
-- ----------------------------
DROP TABLE IF EXISTS `EMAS_MCS_QRTZ_CALENDARS`;
CREATE TABLE `EMAS_MCS_QRTZ_CALENDARS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `CALENDAR_NAME` varchar(200) NOT NULL,
  `CALENDAR` blob NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`CALENDAR_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for EMAS_MCS_QRTZ_CRON_TRIGGERS
-- ----------------------------
DROP TABLE IF EXISTS `EMAS_MCS_QRTZ_CRON_TRIGGERS`;
CREATE TABLE `EMAS_MCS_QRTZ_CRON_TRIGGERS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `CRON_EXPRESSION` varchar(200) NOT NULL,
  `TIME_ZONE_ID` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for EMAS_MCS_QRTZ_FIRED_TRIGGERS
-- ----------------------------
DROP TABLE IF EXISTS `EMAS_MCS_QRTZ_FIRED_TRIGGERS`;
CREATE TABLE `EMAS_MCS_QRTZ_FIRED_TRIGGERS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `ENTRY_ID` varchar(95) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `INSTANCE_NAME` varchar(200) NOT NULL,
  `FIRED_TIME` bigint(13) NOT NULL,
  `SCHED_TIME` bigint(13) NOT NULL,
  `PRIORITY` int(11) NOT NULL,
  `STATE` varchar(16) NOT NULL,
  `JOB_NAME` varchar(200) DEFAULT NULL,
  `JOB_GROUP` varchar(200) DEFAULT NULL,
  `IS_NONCONCURRENT` varchar(1) DEFAULT NULL,
  `REQUESTS_RECOVERY` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`ENTRY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for EMAS_MCS_QRTZ_JOB_DETAILS
-- ----------------------------
DROP TABLE IF EXISTS `EMAS_MCS_QRTZ_JOB_DETAILS`;
CREATE TABLE `EMAS_MCS_QRTZ_JOB_DETAILS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `JOB_NAME` varchar(200) NOT NULL,
  `JOB_GROUP` varchar(200) NOT NULL,
  `DESCRIPTION` varchar(250) DEFAULT NULL,
  `JOB_CLASS_NAME` varchar(250) NOT NULL,
  `IS_DURABLE` varchar(1) NOT NULL,
  `IS_NONCONCURRENT` varchar(1) NOT NULL,
  `IS_UPDATE_DATA` varchar(1) NOT NULL,
  `REQUESTS_RECOVERY` varchar(1) NOT NULL,
  `JOB_DATA` blob,
  PRIMARY KEY (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for EMAS_MCS_QRTZ_LOCKS
-- ----------------------------
DROP TABLE IF EXISTS `EMAS_MCS_QRTZ_LOCKS`;
CREATE TABLE `EMAS_MCS_QRTZ_LOCKS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `LOCK_NAME` varchar(40) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`LOCK_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for EMAS_MCS_QRTZ_PAUSED_TRIGGER_GRPS
-- ----------------------------
DROP TABLE IF EXISTS `EMAS_MCS_QRTZ_PAUSED_TRIGGER_GRPS`;
CREATE TABLE `EMAS_MCS_QRTZ_PAUSED_TRIGGER_GRPS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for EMAS_MCS_QRTZ_SCHEDULER_STATE
-- ----------------------------
DROP TABLE IF EXISTS `EMAS_MCS_QRTZ_SCHEDULER_STATE`;
CREATE TABLE `EMAS_MCS_QRTZ_SCHEDULER_STATE` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `INSTANCE_NAME` varchar(200) NOT NULL,
  `LAST_CHECKIN_TIME` bigint(13) NOT NULL,
  `CHECKIN_INTERVAL` bigint(13) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`INSTANCE_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for EMAS_MCS_QRTZ_SIMPLE_TRIGGERS
-- ----------------------------
DROP TABLE IF EXISTS `EMAS_MCS_QRTZ_SIMPLE_TRIGGERS`;
CREATE TABLE `EMAS_MCS_QRTZ_SIMPLE_TRIGGERS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `REPEAT_COUNT` bigint(7) NOT NULL,
  `REPEAT_INTERVAL` bigint(12) NOT NULL,
  `TIMES_TRIGGERED` bigint(10) NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for EMAS_MCS_QRTZ_SIMPROP_TRIGGERS
-- ----------------------------
DROP TABLE IF EXISTS `EMAS_MCS_QRTZ_SIMPROP_TRIGGERS`;
CREATE TABLE `EMAS_MCS_QRTZ_SIMPROP_TRIGGERS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `STR_PROP_1` varchar(512) DEFAULT NULL,
  `STR_PROP_2` varchar(512) DEFAULT NULL,
  `STR_PROP_3` varchar(512) DEFAULT NULL,
  `INT_PROP_1` int(11) DEFAULT NULL,
  `INT_PROP_2` int(11) DEFAULT NULL,
  `LONG_PROP_1` bigint(20) DEFAULT NULL,
  `LONG_PROP_2` bigint(20) DEFAULT NULL,
  `DEC_PROP_1` decimal(13,4) DEFAULT NULL,
  `DEC_PROP_2` decimal(13,4) DEFAULT NULL,
  `BOOL_PROP_1` varchar(1) DEFAULT NULL,
  `BOOL_PROP_2` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for EMAS_MCS_QRTZ_TRIGGERS
-- ----------------------------
DROP TABLE IF EXISTS `EMAS_MCS_QRTZ_TRIGGERS`;
CREATE TABLE `EMAS_MCS_QRTZ_TRIGGERS` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `JOB_NAME` varchar(200) NOT NULL,
  `JOB_GROUP` varchar(200) NOT NULL,
  `DESCRIPTION` varchar(250) DEFAULT NULL,
  `NEXT_FIRE_TIME` bigint(13) DEFAULT NULL,
  `PREV_FIRE_TIME` bigint(13) DEFAULT NULL,
  `PRIORITY` int(11) DEFAULT NULL,
  `TRIGGER_STATE` varchar(16) NOT NULL,
  `TRIGGER_TYPE` varchar(8) NOT NULL,
  `START_TIME` bigint(13) NOT NULL,
  `END_TIME` bigint(13) DEFAULT NULL,
  `CALENDAR_NAME` varchar(200) DEFAULT NULL,
  `MISFIRE_INSTR` smallint(2) DEFAULT NULL,
  `JOB_DATA` blob,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `SCHED_NAME` (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for emas_mcs_rule_statistics_parent
-- ----------------------------
DROP TABLE IF EXISTS `emas_mcs_rule_statistics_parent`;
CREATE TABLE `emas_mcs_rule_statistics_parent` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `parent_product_id` bigint(20) NOT NULL COMMENT '父产品名称',
  `scan_type` varchar(255) NOT NULL COMMENT '扫描类型',
  `platform` varchar(16) NOT NULL DEFAULT '0' COMMENT '平台类型',
  `rule_name` varchar(128) NOT NULL COMMENT '规则名称',
  `trigger_count` bigint(20) DEFAULT '0' COMMENT '触发次数',
  `datetime` varchar(32) NOT NULL COMMENT '统计时间',
  PRIMARY KEY (`id`),
  KEY `idx_rule` (`rule_name`),
  KEY `idx_product_date` (`parent_product_id`,`platform`,`datetime`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8mb4 COMMENT='缺陷概览';

-- ----------------------------
-- Table structure for emas_mcs_scan_record
-- ----------------------------
DROP TABLE IF EXISTS `emas_mcs_scan_record`;
CREATE TABLE `emas_mcs_scan_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '更新时间',
  `begin_time` datetime NOT NULL COMMENT '开始执行时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `build_id` bigint(20) DEFAULT NULL COMMENT '构建id',
  `buildservice_id` bigint(20) DEFAULT NULL COMMENT 'buildservice id',
  `scm_address` varchar(255) NOT NULL COMMENT 'scm address',
  `scm_branch` varchar(255) NOT NULL COMMENT 'scm branch',
  `scm_commit` varchar(255) DEFAULT NULL COMMENT 'commit',
  `product_id` bigint(20) DEFAULT '0' COMMENT '产品ID',
  `project_id` bigint(20) DEFAULT NULL COMMENT '项目ID',
  `status` varchar(20) DEFAULT NULL COMMENT '执行状态',
  `plugin_result_param` text COMMENT '结果JSON串',
  `P1` int(11) DEFAULT NULL COMMENT 'FATAL问题个数',
  `P2` int(11) DEFAULT NULL COMMENT 'ERROR问题个数',
  `P3` int(11) DEFAULT NULL COMMENT 'WARNING问题个数',
  `P4` int(11) DEFAULT NULL COMMENT 'INFO问题个数',
  `extend_id` bigint(20) DEFAULT NULL COMMENT '对应task_config_id。0是jsbundle扫描',
  `build_param` text COMMENT '透传的参数',
  `trigger_type` varchar(128) NOT NULL COMMENT '触发来源，定时触发/webhook/手动触发',
  `parent_product_id` bigint(20) NOT NULL COMMENT '父产品ID',
  `creator` varchar(128) NOT NULL COMMENT '触发人',
  `task_type` varchar(128) NOT NULL COMMENT '扫描类型',
  `product_name` varchar(1024) DEFAULT NULL COMMENT '子产品名称',
  `logUrl` varchar(255) DEFAULT NULL COMMENT '执行log',
  `ip` varchar(255) DEFAULT NULL COMMENT '执行机器',
  `source` varchar(255) DEFAULT NULL COMMENT '来源',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `parent_product_branch` (`parent_product_id`,`product_id`,`scm_branch`),
  KEY `idx_buildservice_id` (`buildservice_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for emas_mcs_task_config
-- ----------------------------
DROP TABLE IF EXISTS `emas_mcs_task_config`;
CREATE TABLE `emas_mcs_task_config` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `parent_product_id` bigint(20) NOT NULL COMMENT '父产品id，关联product.id',
  `product_id` bigint(20) NOT NULL COMMENT '产品id',
  `task_type` varchar(20) NOT NULL COMMENT '任务类型',
  `status` varchar(20) NOT NULL COMMENT '是否启用',
  `modifier` varchar(150) DEFAULT '' COMMENT '修改者',
  `notice_config` text COMMENT '通知配置',
  `is_deleted` tinyint(4) NOT NULL COMMENT '是否删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_task` (`parent_product_id`,`product_id`,`task_type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COMMENT='任务配置表';

SET FOREIGN_KEY_CHECKS = 1;
