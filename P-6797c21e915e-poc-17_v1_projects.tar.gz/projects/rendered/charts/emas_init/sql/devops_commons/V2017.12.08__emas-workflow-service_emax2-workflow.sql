USE `emas`;
CREATE TABLE IF NOT EXISTS `emas_workflow_service_list` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `modifier` varchar(50) DEFAULT NULL COMMENT '修改者',
  `creator` varchar(50) DEFAULT NULL COMMENT '创建者',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '逻辑删除字段',
  `foreign_id` bigint(20) unsigned COMMENT '工作流克隆时所复制的工作流id',
  `app_id` bigint(20) DEFAULT 0 COMMENT '应用id',
  `config_id` bigint(20) DEFAULT 0 COMMENT '配置项ID，如果是模板的时候为空',
  `project_id` bigint(20) DEFAULT 0 COMMENT '项目ID，如果是模板的时候为空',
  `name` varchar(64) DEFAULT NULL COMMENT '工作流名称',
  `type` varchar(32) DEFAULT NULL COMMENT '工作流服务类型: build/integrate/publish',
  `source` varchar(32) DEFAULT NULL COMMENT '工作流来源: SYSTEM/APP/CUSTOM',
  `enabled` tinyint(1) NOT NULL COMMENT '是否启用',
  `module_id` varchar(64) DEFAULT NULL COMMENT '模块ID',
  `node_list` text COMMENT '工作流节点(插件服务)json列表',
  `context` text COMMENT '工作流实例必要的参数信息',
  `is_default` tinyint(1) DEFAULT 0 COMMENT '是否为默认工作流, 仅在source为APP时有效',
  `category` varchar(16) DEFAULT NULL COMMENT '工作流所属分类：PROJECT_AREA/INTEGRATE_AREA',
  `is_template` tinyint(1) DEFAULT 1 COMMENT '是否为模板，工作流抽象为：模板/实例',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_config_id` (`config_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8 COMMENT='emas工作流执行流程表';

CREATE TABLE IF NOT EXISTS `emas_workflow_node_config` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `modifier` varchar(50) DEFAULT NULL COMMENT '修改者',
  `creator` varchar(50) DEFAULT NULL COMMENT '创建者',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '逻辑删除字段',
  `workflow_id` bigint(20) unsigned COMMENT '插件节点所属的工作流id',
  `type` varchar(64) NOT NULL COMMENT '插件工作流节点键值',
  `config` text COMMENT '插件工作流节点的规则配置',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8 COMMENT='emas工作流节点存储表';

CREATE TABLE IF NOT EXISTS `emas_workflow_task_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `modifier` varchar(50) DEFAULT NULL COMMENT '修改者',
  `creator` varchar(50) DEFAULT NULL COMMENT '创建者',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '逻辑删除字段',
  `workflow_id` bigint(20) unsigned COMMENT '工作流id',
  `config_id` bigint(20) unsigned COMMENT '工作流所属的configId',
  `type` varchar(64) NULL COMMENT '所属工作流类型',
  `instance_id` varchar(64) NULL COMMENT 'buildId/IntgId根据不同类型',
  `status` varchar(64) NOT NULL COMMENT '任务状态，RUNNING/SUCCESS/FAIL',
  `current_key` varchar(64) COMMENT '当前正在执行的工作流节点key',
  `context` text COMMENT '插件任务执行的参数信息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8 COMMENT='工作流任务执行状态表';

CREATE TABLE IF NOT EXISTS `emas_workflow_node_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `modifier` varchar(50) DEFAULT NULL COMMENT '修改者',
  `creator` varchar(50) DEFAULT NULL COMMENT '创建者',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '逻辑删除字段',
  `task_id` bigint(20) unsigned COMMENT '任务id',
  `workflow_id` bigint(20) unsigned COMMENT '工作流id',
  `type` varchar(50) COMMENT '当前执行工作流节点类型',
  `status` varchar(64) NOT NULL COMMENT '节点执行的状态：RUNNING/SUCCESS/FAIL/TIMEOUT/IGNORE',
  `config_id` bigint(20) unsigned COMMENT '工作流所属的configId',
  `context` text COMMENT '插件任务执行的参数信息',
  PRIMARY KEY (`id`),
  KEY `uk_type_task` (`type`,`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8 COMMENT='工作流任务执行状态表';

INSERT INTO `emas_workflow_service_list` (`id`, `modifier`, `creator`, `gmt_create`, `gmt_modified`, `is_deleted`, `foreign_id`, `app_id`, `config_id`, `project_id`, `name`, `type`, `source`, `enabled`, `module_id`, `node_list`, `context`, `is_default`, `category`, `is_template`)
VALUES
	(1, NULL, '', '2017-12-26 12:07:41', '2017-12-26 12:07:41', 0, NULL, NULL, NULL, NULL, NULL, 'INTEGRATE', 'SYSTEM', 1, NULL, '[{\"enabled\":true,\"name\":\"INTG_CREATE\",\"type\":\"NODE_FLAG\"},{\"enabled\":true,\"name\":\"SERVICE_INTG_STATIC_SCAN_CHECK\",\"type\":\"SERVICE_INTG_STATIC_SCAN_CHECK\"},{\"enabled\":true,\"name\":\"INTG_CREATE_SUCCESS\",\"type\":\"NODE_FLAG\"},{\"enabled\":true,\"name\":\"SERVICE_BUILD_RELEASE_CHECK\",\"type\":\"SERVICE_BUILD_RELEASE_CHECK\"},{\"name\":\"INTG_SUBMIT_SUCCESS\",\"type\":\"NODE_FLAG\"}]', NULL, 1, 'PROJECT_AREA', 1),
	(2, NULL, '', '2017-12-26 12:07:41', '2017-12-26 12:07:41', 0, NULL, NULL, NULL, NULL, NULL, 'BUILD', 'SYSTEM', 1, NULL, '[{\"enabled\":true,\"name\":\"CONFIG_BUILD_TRIGGER\",\"type\":\"CONFIG_BUILD_TRIGGER\"},{\"enabled\":true,\"name\":\"SERVICE_BUILD_EXECUTE\",\"type\":\"SERVICE_BUILD_EXECUTE\"},{\"enabled\":true,\"name\":\"SERVICE_BUILD_CALLBACK\",\"type\":\"SERVICE_BUILD_CALLBACK\"},{\"enabled\":true,\"name\":\"SERVICE_BUILD_NOTICE\",\"type\":\"SERVICE_BUILD_NOTICE\"}]', NULL, 1, 'PROJECT_AREA', 1),
	(3, NULL, '', '2017-12-26 12:07:41', '2017-12-26 12:07:41', 0, NULL, NULL, NULL, NULL, NULL, 'BUILD', 'SYSTEM', 1, NULL, '[{\"enabled\":true,\"name\":\"CONFIG_BUILD_TRIGGER\",\"type\":\"CONFIG_BUILD_TRIGGER\"},{\"enabled\":true,\"name\":\"SERVICE_BUILD_EXECUTE\",\"type\":\"SERVICE_BUILD_EXECUTE\"},{\"enabled\":true,\"name\":\"SERVICE_BUILD_CALLBACK\",\"type\":\"SERVICE_BUILD_CALLBACK\"},{\"enabled\":true,\"name\":\"SERVICE_BUILD_NOTICE\",\"type\":\"SERVICE_BUILD_NOTICE\"}]', NULL, 1, 'INTEGRATE_AREA', 1),
	(4, NULL, '', '2017-12-26 12:07:41', '2017-12-26 12:07:41', 0, NULL, NULL, NULL, NULL, NULL, 'BUILD', 'SYSTEM', 1, NULL, '[{\"enabled\":true,\"name\":\"CONFIG_BUILD_TRIGGER\",\"type\":\"CONFIG_BUILD_TRIGGER\"},{\"enabled\":true,\"name\":\"SERVICE_BUILD_EXECUTE\",\"type\":\"SERVICE_BUILD_EXECUTE\"},{\"enabled\":true,\"name\":\"SERVICE_BUILD_CALLBACK\",\"type\":\"SERVICE_BUILD_CALLBACK\"},{\"enabled\":true,\"name\":\"SERVICE_BUILD_NOTICE\",\"type\":\"SERVICE_BUILD_NOTICE\"}]', NULL, 1, 'PUBLISH_AREA', 1);
