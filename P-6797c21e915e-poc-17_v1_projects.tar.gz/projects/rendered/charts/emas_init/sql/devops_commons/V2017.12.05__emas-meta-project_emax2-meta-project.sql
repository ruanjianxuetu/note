USE `emas`;
CREATE TABLE IF NOT EXISTS `emas_meta_project_info` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `app_id` bigint(20) unsigned NOT NULL COMMENT '应用id',
  `app_type` varchar(50) COMMENT 'app类型',
  `foreign_id` bigint(20) unsigned COMMENT '关联的其他元项目id',
  `project_name` varchar(50) COMMENT '项目名称',
  `beta_type` varchar(20) COMMENT '灰度发布类型：DEPENDENT_BETA/SELF_BETA/BIZ_BETA',
  `meta_type` varchar(20) COMMENT '包含元项目基础字段：SNAPSHOT/BETA/RELEASE/HOT_PATCH/DYNAMIC_BUNDLE/AND_FIX/DEX_PATCH/OC_PATCH',
  `secret_type` varchar(20) COMMENT '保密类型：PUBLIC/PRIVATE',
  `meta_project_status` varchar(20) COMMENT '元项目状态：DEVELOP/TEST/INTEGRATE/PUBLISHED/CLOSED',
  `meta_project_type` varchar(20) COMMENT '元项目类型：NORMAL/SDK/INTG/INTG_BETA/EMERGENCY/PUBLISH；',
  `base_project_id` bigint(20) unsigned COMMENT '容器项目ID',
  `version` varchar(20) COMMENT '发布版本',
  `version_code` varchar(20) COMMENT '发布版本code',
  `publish_status` varchar(20) COMMENT '发布状态：PUBLISH_SUCCESS',
  `description` varchar(2048) COMMENT '元项目描述',
  `base_version` varchar(20) COMMENT '基础版本',
  `scm_branch` varchar(50) COMMENT 'scm分支',
  `ext` varchar(2000) COMMENT '扩展字段',
  `modifier` varchar(50) COMMENT '修改者',
  `creator` varchar(50) COMMENT '创建者',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `is_deleted` smallint(6) NOT NULL DEFAULT false COMMENT '逻辑删除字段',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=50000000 COMMENT='元项目基础信息表';

CREATE TABLE IF NOT EXISTS `emas_meta_project_auth` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `project_id` bigint(20) unsigned NOT NULL COMMENT '元项目id',
  `app_id` bigint(20) unsigned NOT NULL COMMENT '项目所属的应用id',
  `user_id` bigint(20) unsigned NOT NULL COMMENT '权限用户id',
  `role` varchar(50) COMMENT '用户角色',
  `modifier` varchar(50) COMMENT '修改者',
  `creator` varchar(50) COMMENT '创建者',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `is_deleted` smallint(6) NOT NULL DEFAULT false COMMENT '逻辑删除字段',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=50000000 COMMENT='元项目权限列表';