USE `emas`;
DROP TABLE IF EXISTS `emas_machine_real_time_info_daydo`;

CREATE TABLE `emas_machine_real_time_info_daydo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `cpu_usage_percentage_avg` decimal(12,5) DEFAULT NULL COMMENT 'CPU使用百分比-平均',
  `cpu_usage_percentage_max` decimal(12,5) DEFAULT NULL COMMENT 'CPU使用百分比-最大',
  `cpu_usage_percentage_min` decimal(12,5) DEFAULT NULL COMMENT 'CPU使用百分比-最小',
  `current_ability_reserved_avg` decimal(12,5) DEFAULT NULL COMMENT '能力留存值-平均',
  `current_ability_reserved_max` decimal(12,5) DEFAULT NULL COMMENT '能力留存值-最大',
  `current_ability_reserved_min` decimal(12,5) DEFAULT NULL COMMENT '能力留存值-最小',
  `current_ability_used_avg` decimal(12,5) DEFAULT NULL COMMENT '能力使用值-平均',
  `current_ability_used_max` decimal(12,5) DEFAULT NULL COMMENT '能力使用值-最大',
  `current_ability_used_min` decimal(12,5) DEFAULT NULL COMMENT '能力使用值-最小',
  `free_memory_avg` decimal(12,5) DEFAULT NULL COMMENT '内存存余量-平均',
  `free_memory_max` decimal(12,5) DEFAULT NULL COMMENT '内存存余量-最大',
  `free_memory_min` decimal(12,5) DEFAULT NULL COMMENT '内存存余量-最小',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `hard_disk_leftgbavg` decimal(12,5) DEFAULT NULL COMMENT '硬盘存余量-平均',
  `hard_disk_leftgbmax` decimal(12,5) DEFAULT NULL COMMENT '硬盘存余量-最大',
  `hard_disk_leftgbmin` decimal(12,5) DEFAULT NULL COMMENT '硬盘存余量-最小',
  `ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'IP',
  `load_for_last1minute_avg` decimal(12,5) DEFAULT NULL COMMENT '1分钟load值-平均',
  `load_for_last1minute_max` decimal(12,5) DEFAULT NULL COMMENT '1分钟load值-最大',
  `load_for_last1minute_min` decimal(12,5) DEFAULT NULL COMMENT '1分钟load值-最小',
  `memory_used_percentage_avg` decimal(12,5) DEFAULT NULL COMMENT '内存使用百分比-平均',
  `memory_used_percentage_max` decimal(12,5) DEFAULT NULL COMMENT '内存使用百分比-最大',
  `memory_used_percentage_min` decimal(12,5) DEFAULT NULL COMMENT '内存使用百分比-最小',
  `used_file_descriptor_count_avg` decimal(12,5) DEFAULT NULL COMMENT 'fd使用量-平均',
  `used_file_descriptor_count_max` decimal(12,5) DEFAULT NULL COMMENT 'fd使用量-最大',
  `used_file_descriptor_count_min` decimal(12,5) DEFAULT NULL COMMENT 'fd使用量-最小',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table emas_machine_real_time_info_hourdo
# ------------------------------------------------------------

DROP TABLE IF EXISTS `emas_machine_real_time_info_hourdo`;

CREATE TABLE `emas_machine_real_time_info_hourdo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `cpu_usage_percentage_avg` decimal(12,5) DEFAULT NULL COMMENT 'CPU使用百分比-平均',
  `cpu_usage_percentage_max` decimal(12,5) DEFAULT NULL COMMENT 'CPU使用百分比-最大',
  `cpu_usage_percentage_min` decimal(12,5) DEFAULT NULL COMMENT 'CPU使用百分比-最小',
  `current_ability_reserved_avg` decimal(12,5) DEFAULT NULL COMMENT '能力留存值-平均',
  `current_ability_reserved_max` decimal(12,5) DEFAULT NULL COMMENT '能力留存值-最大',
  `current_ability_reserved_min` decimal(12,5) DEFAULT NULL COMMENT '能力留存值-最小',
  `current_ability_used_avg` decimal(12,5) DEFAULT NULL COMMENT '能力使用值-平均',
  `current_ability_used_max` decimal(12,5) DEFAULT NULL COMMENT '能力使用值-最大',
  `current_ability_used_min` decimal(12,5) DEFAULT NULL COMMENT '能力使用值-最小',
  `free_memory_avg` decimal(12,5) DEFAULT NULL COMMENT '内存存余量-平均',
  `free_memory_max` decimal(12,5) DEFAULT NULL COMMENT '内存存余量-最大',
  `free_memory_min` decimal(12,5) DEFAULT NULL COMMENT '内存存余量-最小',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `hard_disk_leftgbavg` decimal(12,5) DEFAULT NULL COMMENT '硬盘存余量-平均',
  `hard_disk_leftgbmax` decimal(12,5) DEFAULT NULL COMMENT '硬盘存余量-最大',
  `hard_disk_leftgbmin` decimal(12,5) DEFAULT NULL COMMENT '硬盘存余量-最小',
  `ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'IP',
  `load_for_last1minute_avg` decimal(12,5) DEFAULT NULL COMMENT '1分钟load值-平均',
  `load_for_last1minute_max` decimal(12,5) DEFAULT NULL COMMENT '1分钟load值-最大',
  `load_for_last1minute_min` decimal(12,5) DEFAULT NULL COMMENT '1分钟load值-最小',
  `memory_used_percentage_avg` decimal(12,5) DEFAULT NULL COMMENT '内存使用百分比-平均',
  `memory_used_percentage_max` decimal(12,5) DEFAULT NULL COMMENT '内存使用百分比-最大',
  `memory_used_percentage_min` decimal(12,5) DEFAULT NULL COMMENT '内存使用百分比-最小',
  `used_file_descriptor_count_avg` decimal(12,5) DEFAULT NULL COMMENT 'fd使用量-平均',
  `used_file_descriptor_count_max` decimal(12,5) DEFAULT NULL COMMENT 'fd使用量-最大',
  `used_file_descriptor_count_min` decimal(12,5) DEFAULT NULL COMMENT 'fd使用量-最小',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table emas_machine_real_time_info_minutedo
# ------------------------------------------------------------

DROP TABLE IF EXISTS `emas_machine_real_time_info_minutedo`;

CREATE TABLE `emas_machine_real_time_info_minutedo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `cpu_usage_percentage_avg` decimal(12,5) DEFAULT NULL COMMENT 'CPU使用百分比-平均',
  `cpu_usage_percentage_max` decimal(12,5) DEFAULT NULL COMMENT 'CPU使用百分比-最大',
  `cpu_usage_percentage_min` decimal(12,5) DEFAULT NULL COMMENT 'CPU使用百分比-最小',
  `current_ability_reserved_avg` decimal(12,5) DEFAULT NULL COMMENT '能力留存值-平均',
  `current_ability_reserved_max` decimal(12,5) DEFAULT NULL COMMENT '能力留存值-最大',
  `current_ability_reserved_min` decimal(12,5) DEFAULT NULL COMMENT '能力留存值-最小',
  `current_ability_used_avg` decimal(12,5) DEFAULT NULL COMMENT '能力使用值-平均',
  `current_ability_used_max` decimal(12,5) DEFAULT NULL COMMENT '能力使用值-最大',
  `current_ability_used_min` decimal(12,5) DEFAULT NULL COMMENT '能力使用值-最小',
  `free_memory_avg` decimal(12,5) DEFAULT NULL COMMENT '内存存余量-平均',
  `free_memory_max` decimal(12,5) DEFAULT NULL COMMENT '内存存余量-最大',
  `free_memory_min` decimal(12,5) DEFAULT NULL COMMENT '内存存余量-最小',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `hard_disk_leftgbavg` decimal(12,5) DEFAULT NULL COMMENT '硬盘存余量-平均',
  `hard_disk_leftgbmax` decimal(12,5) DEFAULT NULL COMMENT '硬盘存余量-最大',
  `hard_disk_leftgbmin` decimal(12,5) DEFAULT NULL COMMENT '硬盘存余量-最小',
  `ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'IP',
  `load_for_last1minute_avg` decimal(12,5) DEFAULT NULL COMMENT '1分钟load值-平均',
  `load_for_last1minute_max` decimal(12,5) DEFAULT NULL COMMENT '1分钟load值-最大',
  `load_for_last1minute_min` decimal(12,5) DEFAULT NULL COMMENT '1分钟load值-最小',
  `memory_used_percentage_avg` decimal(12,5) DEFAULT NULL COMMENT '内存使用百分比-平均',
  `memory_used_percentage_max` decimal(12,5) DEFAULT NULL COMMENT '内存使用百分比-最大',
  `memory_used_percentage_min` decimal(12,5) DEFAULT NULL COMMENT '内存使用百分比-最小',
  `used_file_descriptor_count_avg` decimal(12,5) DEFAULT NULL COMMENT 'fd使用量-平均',
  `used_file_descriptor_count_max` decimal(12,5) DEFAULT NULL COMMENT 'fd使用量-最大',
  `used_file_descriptor_count_min` decimal(12,5) DEFAULT NULL COMMENT 'fd使用量-最小',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


# Dump of table emas_machine_real_time_infodo
# ------------------------------------------------------------

DROP TABLE IF EXISTS `emas_machine_real_time_infodo`;

CREATE TABLE `emas_machine_real_time_infodo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `cpu_usage_percentage` decimal(12,5) DEFAULT NULL COMMENT 'CPU使用百分比',
  `free_memory` decimal(12,5) DEFAULT NULL COMMENT '内存存余量',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `hard_disk_leftgb` decimal(12,5) DEFAULT NULL COMMENT '硬盘存余量',
  `ip` varchar(255) DEFAULT NULL COMMENT 'IP',
  `load_for_last1minute` decimal(12,5) DEFAULT NULL COMMENT '1分钟load值',
  `memory_used_percentage` decimal(12,5) DEFAULT NULL COMMENT '内存使用百分比',
  `used_file_descriptor_count` bigint(20) DEFAULT NULL COMMENT 'fd使用量',
  `current_ability_reserved` int(11) DEFAULT NULL COMMENT '能力存余量',
  `current_ability_used` int(11) DEFAULT NULL COMMENT '能力使用量',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;