USE `emas`;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table emas_machine_infodo_group_info_id_set
# ------------------------------------------------------------



CREATE TABLE `emas_machine_infodo_group_info_id_set` (
  `emas_machine_infodo_id` bigint(20) NOT NULL,
  `group_info_id_set` bigint(20) DEFAULT NULL,
  KEY `FK951oe6ykfb5b9k4pw9kyf9wcw` (`emas_machine_infodo_id`),
  CONSTRAINT `FK951oe6ykfb5b9k4pw9kyf9wcw` FOREIGN KEY (`emas_machine_infodo_id`) REFERENCES `emas_machine_infodo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


# Dump of table emas_monitor_taskdo_machine_info_id_set
# ------------------------------------------------------------



CREATE TABLE `emas_monitor_taskdo_machine_info_id_set` (
  `emas_monitor_taskdo_id` bigint(20) NOT NULL,
  `machine_info_id_set` bigint(20) DEFAULT NULL,
  KEY `FKp6r0hh73s4rl1syjoo0vp8uw9` (`emas_monitor_taskdo_id`),
  CONSTRAINT `FKp6r0hh73s4rl1syjoo0vp8uw9` FOREIGN KEY (`emas_monitor_taskdo_id`) REFERENCES `emas_monitor_taskdo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


# Dump of table emas_machine_infodo_monitor_task_id_set
# ------------------------------------------------------------



CREATE TABLE `emas_machine_infodo_monitor_task_id_set` (
  `emas_machine_infodo_id` bigint(20) NOT NULL,
  `monitor_task_id_set` bigint(20) DEFAULT NULL,
  KEY `FK9vvbe2oamahikmbwskaw8j8qp` (`emas_machine_infodo_id`),
  CONSTRAINT `FK9vvbe2oamahikmbwskaw8j8qp` FOREIGN KEY (`emas_machine_infodo_id`) REFERENCES `emas_machine_infodo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


# Dump of table emas_group_infodo_app_build_config_id_set
# ------------------------------------------------------------



CREATE TABLE `emas_group_infodo_app_build_config_id_set` (
  `emas_group_infodo_id` bigint(20) NOT NULL,
  `app_build_config_id_set` bigint(20) DEFAULT NULL,
  KEY `FKh9hydlfo85o8prxdud85t8l26` (`emas_group_infodo_id`),
  CONSTRAINT `FKh9hydlfo85o8prxdud85t8l26` FOREIGN KEY (`emas_group_infodo_id`) REFERENCES `emas_group_infodo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


# Dump of table emas_group_infodo_machine_info_id_set
# ------------------------------------------------------------



CREATE TABLE `emas_group_infodo_machine_info_id_set` (
  `emas_group_infodo_id` bigint(20) NOT NULL,
  `machine_info_id_set` bigint(20) DEFAULT NULL,
  KEY `FK93ojye24bani4w0lbvnsku64p` (`emas_group_infodo_id`),
  CONSTRAINT `FK93ojye24bani4w0lbvnsku64p` FOREIGN KEY (`emas_group_infodo_id`) REFERENCES `emas_group_infodo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




# Dump of table emas_app_build_configdo_group_info_id_set
# ------------------------------------------------------------



CREATE TABLE `emas_app_build_configdo_group_info_id_set` (
  `emas_app_build_configdo_id` bigint(20) NOT NULL,
  `group_info_id_set` bigint(20) DEFAULT NULL,
  KEY `FK7j9jfrts01yqdp2s94746slnj` (`emas_app_build_configdo_id`),
  CONSTRAINT `FK7j9jfrts01yqdp2s94746slnj` FOREIGN KEY (`emas_app_build_configdo_id`) REFERENCES `emas_app_build_configdo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table emas_action_recorddo
# ------------------------------------------------------------



CREATE TABLE `emas_action_recorddo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `action_error_output` varchar(8000) DEFAULT NULL,
  `action_output` varchar(8000) DEFAULT NULL,
  `action_return_code` int(11) DEFAULT NULL,
  `action_status` int(11) DEFAULT NULL,
  `execute_type` int(11) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_end` datetime DEFAULT NULL,
  `machine_ip` varchar(255) DEFAULT NULL,
  `operator` varchar(64) DEFAULT NULL,
  `actiondo_id` bigint(20) DEFAULT NULL,
  `monitor_taskdo_id` bigint(20) DEFAULT NULL,
  `action_id` bigint(20) DEFAULT NULL,
  `monitor_task_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKh0nab7e9e2op9citaria4s2cf` (`actiondo_id`),
  KEY `FK9rusbcugvsm7lw4r0w699ftf5` (`monitor_taskdo_id`),
  CONSTRAINT `FK9rusbcugvsm7lw4r0w699ftf5` FOREIGN KEY (`monitor_taskdo_id`) REFERENCES `emas_monitor_taskdo` (`id`),
  CONSTRAINT `FKh0nab7e9e2op9citaria4s2cf` FOREIGN KEY (`actiondo_id`) REFERENCES `emas_actiondo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8;



# Dump of table emas_actiondo
# ------------------------------------------------------------



CREATE TABLE `emas_actiondo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `action_name` varchar(255) DEFAULT NULL,
  `action_param_json` varchar(255) DEFAULT NULL,
  `action_type` int(11) DEFAULT NULL,
  `creator` varchar(64) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  `modifier` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8;


# Dump of table emas_app_build_configdo
# ------------------------------------------------------------



CREATE TABLE `emas_app_build_configdo` (
  `id` bigint(20) NOT NULL,
  `creator` varchar(64) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  `modifier` varchar(64) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `use_default_group` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8;



# Dump of table emas_group_infodo
# ------------------------------------------------------------



CREATE TABLE `emas_group_infodo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `build_type` int(11) DEFAULT NULL,
  `creator` varchar(64) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  `group_name` varchar(255) DEFAULT NULL,
  `group_status` int(11) DEFAULT NULL,
  `modifier` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8;




# Dump of table emas_machine_infodo
# ------------------------------------------------------------



CREATE TABLE `emas_machine_infodo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ability_count` int(11) DEFAULT NULL,
  `build_platform` int(11) DEFAULT NULL,
  `creator` varchar(64) DEFAULT NULL,
  `executor_port` varchar(255) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  `hard_diskgb` double DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `java_version` varchar(255) DEFAULT NULL,
  `logical_cpu_count` int(11) DEFAULT NULL,
  `machine_status` int(11) DEFAULT NULL,
  `max_file_descriptor` bigint(20) DEFAULT NULL,
  `max_memorymb` double DEFAULT NULL,
  `modifier` varchar(64) DEFAULT NULL,
  `os_name` varchar(255) DEFAULT NULL,
  `os_version` varchar(255) DEFAULT NULL,
  `other_build_environment_json` varchar(8000) DEFAULT NULL,
  `x64orx86` varchar(255) DEFAULT NULL,
  `xcode_version` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8;


# Dump of table emas_machine_real_time_infodo
# ------------------------------------------------------------



CREATE TABLE `emas_machine_real_time_infodo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cpu_usage_percentage` double DEFAULT NULL,
  `free_memory` double DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `hard_disk_leftgb` double DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `load_for_last1minute` double DEFAULT NULL,
  `memory_used_percentage` double DEFAULT NULL,
  `used_file_descriptor_count` bigint(20) DEFAULT NULL,
  `current_ability_reserved` int(11) DEFAULT NULL,
  `current_ability_used` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8;


# Dump of table emas_monitor_taskdo
# ------------------------------------------------------------



CREATE TABLE `emas_monitor_taskdo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `condition_json` varchar(255) DEFAULT NULL,
  `condition_type` int(11) DEFAULT NULL,
  `creator` varchar(64) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  `modifier` varchar(64) DEFAULT NULL,
  `monitor_task_name` varchar(255) DEFAULT NULL,
  `monitor_task_status` int(11) DEFAULT NULL,
  `actiondo_id` bigint(20) DEFAULT NULL,
  `action_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKoe8i2o07fyuh4wwq3iknu9se1` (`actiondo_id`),
  CONSTRAINT `FKoe8i2o07fyuh4wwq3iknu9se1` FOREIGN KEY (`actiondo_id`) REFERENCES `emas_actiondo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8;


/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
