USE `emas`;
CREATE TABLE `emas_build_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `app_id` bigint(20) NOT NULL COMMENT '应用ID',
  `project_id` bigint(20) NOT NULL COMMENT '项目ID',
  `config_type` int(11) NOT NULL COMMENT '模板类型',
  `scm_address` varchar(128) DEFAULT NULL COMMENT '代码地址',
  `scm_branch` varchar(64) DEFAULT NULL COMMENT '代码分支',
  `template_name` varchar(128) NOT NULL DEFAULT '' COMMENT '模板名称',
  `param_json` text NOT NULL COMMENT '构建模板详细数据',
  `timer_config_json` text COMMENT '保留',
  `trigger_types` int(11) DEFAULT NULL COMMENT '保留',
  `extra` text COMMENT '保留',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `creator` varchar(64) DEFAULT NULL COMMENT '创建者',
  `modifier` varchar(64) DEFAULT NULL COMMENT '修改者',
  `status` int(11) NOT NULL COMMENT '是否删除',
  PRIMARY KEY (`id`),
  KEY `app_id` (`app_id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8;



CREATE TABLE `emas_build_solution` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `user_id` bigint(20) NOT NULL COMMENT '用户ID',
  `type` int(11) NOT NULL COMMENT '错误的类型',
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `rule_order` int(11) DEFAULT NULL COMMENT '匹配的优先级',
  `rules` text COMMENT '错误日志的匹配规则',
  `solution` text COMMENT '错误日志的对应解决方案',
  `extra` varchar(255) DEFAULT NULL COMMENT '保留',
  `stop` bit(1) NOT NULL COMMENT '是否中断匹配',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `status` int(11) NOT NULL COMMENT '是否删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8;



CREATE TABLE `emas_build_task_detail` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `app_id` bigint(20) DEFAULT NULL COMMENT '应用ID',
  `project_id` bigint(20) DEFAULT NULL COMMENT '项目ID',
  `build_config_id` bigint(20) DEFAULT NULL COMMENT '构建模板ID',
  `cr_id` bigint(20) DEFAULT NULL COMMENT '变更ID',
  `intg_id` bigint(20) DEFAULT NULL COMMENT '集成单ID',
  `build_config_type` int(11) DEFAULT NULL COMMENT '构建模板类型',
  `error_type` int(11) NOT NULL COMMENT '错误类型',
  `version_code` varchar(255) DEFAULT NULL COMMENT '版本code',
  `version_name` varchar(255) DEFAULT NULL COMMENT '版本名称',
  `build_status` varchar(50) NOT NULL DEFAULT '' COMMENT '构建状态',
  `ip` varchar(255) DEFAULT NULL COMMENT 'ip地址',
  `wait_start_time` datetime DEFAULT NULL COMMENT '等待开始时间',
  `wait_end_time` datetime DEFAULT NULL COMMENT '等待结束时间',
  `build_start_time` datetime DEFAULT NULL COMMENT '构建开始时间',
  `build_end_time` datetime DEFAULT NULL COMMENT '构建结束时间',
  `custom_template` text COMMENT '自定义模板',
  `params` text COMMENT '环境变量的参数，JSON',
  `trigger_type` varchar(24) DEFAULT NULL COMMENT '触发类型',
  `trigger_source` varchar(255) DEFAULT NULL COMMENT '构建来源',
  `creator` varchar(64) DEFAULT NULL COMMENT '创建者',
  `modifier` varchar(64) DEFAULT NULL COMMENT '修改者',
  `is_delete` bit(1) DEFAULT NULL COMMENT '是否删除',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `app_id` (`app_id`),
  KEY `project_id` (`project_id`),
  KEY `build_config_id` (`build_config_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8;



CREATE TABLE `emas_build_task_result` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `task_id` bigint(20) DEFAULT NULL COMMENT '任务ID',
  `scm_address` varchar(128) DEFAULT NULL COMMENT 'scm代码地址',
  `scm_branch` varchar(128) DEFAULT NULL COMMENT 'scm代码分支',
  `scm_log` text COMMENT '代码的tag',
  `log_url` varchar(128) DEFAULT NULL COMMENT '实时日志url',
  `build_files` text COMMENT '构建产物的json数据',
  `error_info` text COMMENT '错误信息',
  `stacktrace` text COMMENT '堆栈',
  `error_times` int(11) NOT NULL COMMENT '错误次数',
  `solution_ids` varchar(255) DEFAULT NULL COMMENT '解决方案列表',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8;


INSERT INTO `emas_build_config` (`id`, `app_id`, `project_id`, `config_type`, `scm_address`, `scm_branch`, `template_name`, `param_json`, `timer_config_json`, `trigger_types`, `extra`, `gmt_create`, `gmt_modified`, `creator`, `modifier`, `status`)
VALUES
	(1, 0, 0, 11, '', '', 'android构建系统模板', '{\"params\":[{\"desc\":\"\",\"id\":\"jdk.version\",\"label\":\"JDK版本\",\"type\":\"select\",\"value\":\"1.8\",\"options\":[{\"label\":\"1.8\",\"value\":\"1.8\"},{\"label\":\"1.7\",\"value\":\"1.7\"}]}],\"tasks\":[{\"abortIfError\":false,\"label\":\"debug默认构建\",\"params\":[{\"desc\":\"\",\"id\":\"commands\",\"label\":\"打包脚本\",\"type\":\"textarea\",\"value\":\"./gradlew assembleRelease\"},{\"desc\":\"\",\"id\":\"result.match.names\",\"label\":\"构建产物名称\",\"type\":\"text\",\"value\":\"*.apk\"},{\"desc\":\"\",\"id\":\"result.match.paths\",\"label\":\"构建产物路径\",\"type\":\"text\",\"value\":\"build/outputs/apk\"}],\"retryTimes\":0,\"taskType\":1,\"value\":\"true\"}]}', NULL, NULL, NULL, now(), now(), '10000', NULL, 0),
	(2, 0, 0, 16395, '', '', 'android动态部署系统模板', '{\"params\":[{\"desc\":\"\",\"id\":\"jdk.version\",\"label\":\"JDK版本\",\"type\":\"select\",\"value\":\"1.8\",\"options\":[{\"label\":\"1.8\",\"value\":\"1.8\"},{\"label\":\"1.7\",\"value\":\"1.7\"}]}],\"tasks\":[{\"abortIfError\":false,\"label\":\"release默认构建\",\"params\":[{\"desc\":\"\",\"id\":\"commands\",\"label\":\"打包脚本\",\"type\":\"textarea\",\"value\":\"./gradlew assembleRelease\"},{\"desc\":\"\",\"id\":\"result.match.names\",\"label\":\"构建产物名称\",\"type\":\"text\",\"value\":\"*.apk,*.tpatch,*.json\"},{\"desc\":\"\",\"id\":\"result.match.paths\",\"label\":\"构建产物路径\",\"type\":\"text\",\"value\":\"build/outputs/apk,build/outputs,build/outputs/tpatch-debug,build/outputs,build/outputs/tpatch-release\"}],\"retryTimes\":0,\"taskType\":1,\"value\":\"true\"}]}', NULL, NULL, NULL, now(), now(), '10000', NULL, 0),
	(3, 0, 0, 8203, '', '', 'dexpatch系统模板', '{\"params\":[{\"desc\":\"\",\"id\":\"jdk.version\",\"label\":\"JDK版本\",\"type\":\"select\",\"value\":\"1.8\",\"options\":[{\"label\":\"1.8\",\"value\":\"1.8\"},{\"label\":\"1.7\",\"value\":\"1.7\"}]}],\"tasks\":[{\"abortIfError\":false,\"label\":\"release默认构建\",\"params\":[{\"desc\":\"\",\"id\":\"commands\",\"label\":\"打包脚本\",\"type\":\"textarea\",\"value\":\"./gradlew assembleRelease\"},{\"desc\":\"\",\"id\":\"result.match.names\",\"label\":\"构建产物名称\",\"type\":\"text\",\"value\":\"*.apk,*.tpatch,*.json\"},{\"desc\":\"\",\"id\":\"result.match.paths\",\"label\":\"构建产物路径\",\"type\":\"text\",\"value\":\"build/outputs/apk,build/outputs,build/outputs/tpatch-debug,build/outputs,build/outputs/tpatch-release\"}],\"retryTimes\":0,\"taskType\":1,\"value\":\"true\"}]}', NULL, NULL, NULL, now(), now(), '10000', NULL, 0),
	(5, 0, 0, 131083, '', '', 'sophix系统模板', '{\"params\":[{\"desc\":\"\",\"id\":\"jdk.version\",\"label\":\"JDK版本\",\"type\":\"select\",\"value\":\"1.8\",\"options\":[{\"label\":\"1.8\",\"value\":\"1.8\"},{\"label\":\"1.7\",\"value\":\"1.7\"}]}],\"tasks\":[{\"abortIfError\":false,\"label\":\"release默认构建\",\"params\":[{\"desc\":\"\",\"id\":\"commands\",\"label\":\"打包脚本\",\"type\":\"textarea\",\"value\":\"./gradlew assembleRelease\"},{\"desc\":\"\",\"id\":\"result.match.names\",\"label\":\"构建产物名称\",\"type\":\"text\",\"value\":\"*.apk\"},{\"desc\":\"\",\"id\":\"result.match.paths\",\"label\":\"构建产物路径\",\"type\":\"text\",\"value\":\"build/outputs/apk\"}],\"retryTimes\":0,\"taskType\":1,\"value\":\"true\"}]}', NULL, NULL, NULL, now(), now(), '10000', NULL, 0),
	(6, 0, 0, 4109, '', '', 'android模块发系统布模板', '{\"params\":[{\"desc\":\"\",\"id\":\"jdk.version\",\"label\":\"JDK版本\",\"type\":\"select\",\"value\":\"1.8\",\"options\":[{\"label\":\"1.8\",\"value\":\"1.8\"},{\"label\":\"1.7\",\"value\":\"1.7\"}]}],\"tasks\":[{\"abortIfError\":false,\"label\":\"模块发布默认模板\",\"params\":[{\"desc\":\"\",\"id\":\"commands\",\"label\":\"打包脚本\",\"type\":\"textarea\",\"value\":\"./gradlew assembleRelease publish\"},{\"desc\":\"\",\"id\":\"result.match.names\",\"label\":\"构建产物名称\",\"type\":\"text\",\"value\":\"*.aar\"},{\"desc\":\"\",\"id\":\"result.match.paths\",\"label\":\"构建产物路径\",\"type\":\"text\",\"value\":\"build/outputs/aar\"}],\"retryTimes\":0,\"taskType\":1,\"value\":\"true\"}]}', NULL, NULL, NULL, now(), now(), '10000', NULL, 0),
	(11, 0, 0, 19, '', '', 'ios app构建系统模板', '{\"params\":[{\"desc\":\"\",\"id\":\"buildConfigBuildXcode\",\"label\":\"xcode 版本\",\"type\":\"text\",\"required\":true,\"value\":\"9.0\"},{\"desc\":\"\",\"id\":\"buildXcodeCocoapodsVersion\",\"label\":\"是否使用cocoapods\",\"options\":[{\"label\":\"不使用\",\"value\":\"0\"},{\"label\":\"使用\",\"value\":\"1.3.1\"}],\"required\":true,\"type\":\"select\",\"value\":\"0\"},{\"desc\":\"\",\"id\":\"buildXcodeBuildType\",\"label\":\"打包类型\",\"type\":\"text\",\"required\":true,\"value\":\"ipa\"},{\"desc\":\"放置mupp_build_env_init.sh放置文件在工程目录\",\"id\":\"buildInitScript\",\"label\":\"是否执行初始化脚本\",\"type\":\"select\",\"required\":true,\"options\":[{\"label\":\"不使用\",\"value\":\"0\"},{\"label\":\"使用\",\"value\":\"1\"}],\"value\":\"0\"},{\"desc\":\"\",\"descLink\":\"/certificate\",\"id\":\"buildXcodeIosCertId\",\"label\":\"证书\",\"options\":[{\"label\":\"淘宝企业证书\",\"value\":\"8\"},{\"label\":\"淘宝客服证书\",\"value\":\"9\"}],\"required\":true,\"type\":\"select\",\"value\":\"\",\"api\":\"/api/v1/build/certificate/listSelect/\",\"query\":[{\"key\":\"appId\",\"value\":\"appId\"}],\"linkTo\":\"buildXcodeIosProfileIds\"},{\"desc\":\"\",\"descLink\":\"/profile\",\"id\":\"buildXcodeIosProfileIds\",\"label\":\"Profile\",\"notFoundContent\":\"\",\"options\":[{\"label\":\"AnyApp\",\"value\":\"6\"},{\"label\":\"Alibaba Enterprise Software Distribution\",\"value\":\"6\"}],\"required\":true,\"type\":\"multi-select\",\"value\":\"\",\"api\":\"/api/v1/build/profile/listSelectByCertificateID/\",\"query\":[{\"key\":\"key\",\"value\":\"buildXcodeIosCertId\"}],\"linkFrom\":\"buildXcodeIosCertId\"},{\"desc\":\"工程配置，例如Release、Debug\",\"id\":\"buildXcodeConfiguration\",\"label\":\"配置\",\"required\":true,\"type\":\"text\",\"value\":\"Release\"},{\"desc\":\"工程schema/target两者最好命名一致\",\"id\":\"buildXcodeSchema\",\"label\":\"Schema\",\"required\":true,\"type\":\"text\",\"value\":\"test\"},{\"desc\":\"\",\"id\":\"xcodeBuildMode\",\"label\":\"打包方式\",\"options\":[{\"label\":\"build\",\"value\":\"build\"},{\"label\":\"archive\",\"value\":\"archive\"}],\"required\":true,\"type\":\"select\",\"value\":\"build\"},{\"desc\":\"\",\"id\":\"buildXcodeBuildSdkType\",\"label\":\"sdk类型\",\"options\":[{\"label\":\"iphoneos\",\"value\":\"iphoneos\"},{\"label\":\"withwatchos\",\"value\":\"withwatchos\"},{\"label\":\"iphonesimulator\",\"value\":\"iphonesimulator\"}],\"required\":true,\"type\":\"select\",\"value\":\"iphoneos\"},{\"desc\":\"proj文件，例如test.xcodeproj\",\"id\":\"buildXcodeProjectFile\",\"label\":\"project file\",\"type\":\"text\",\"required\":true,\"value\":\"\"},{\"desc\":\"使用pod时或包含workspace则填写，例如test.xcworkspace\",\"id\":\"buildXcodeWorkspaceFile\",\"label\":\"workspace file\",\"required\":false,\"type\":\"text\",\"value\":\"\"},{\"desc\":\"源码相对于工程目录的位置\",\"id\":\"buildXcodeProjectDirectory\",\"label\":\"projectDirectory\",\"type\":\"text\",\"required\":false,\"value\":\"\"},{\"desc\":\"自定义bundleid\",\"id\":\"buildXcodeCustomizedBundleId\",\"label\":\"自定义bundleid\",\"required\":false,\"type\":\"text\",\"value\":\"\"},{\"desc\":\"TechnicalVersion\",\"id\":\"buildXcodeTechnicalVersion\",\"label\":\"TechnicalVersion\",\"required\":false,\"type\":\"text\",\"value\":\"\"},{\"desc\":\"构建参数，没有可以不填\",\"id\":\"buildXcodeArguments\",\"label\":\"构建参数\",\"type\":\"text\",\"value\":\"\"}],\"tasks\":[{\"abortIfError\":false,\"params\":[{\"desc\":\"\",\"id\":\"result.match.names\",\"label\":\"构建产物名称\",\"type\":\"text\",\"value\":\"*.json,*.zip,*.ipa\"},{\"desc\":\"\",\"id\":\"result.match.paths\",\"label\":\"构建产物路径\",\"type\":\"text\",\"value\":\"workspace/cocoaFramework/Release-universal/\"}],\"label\":\"\",\"retryTimes\":0,\"taskType\":1,\"value\":\"true\"}]}', NULL, NULL, NULL, '2018-01-18 19:20:44', '2018-01-18 19:20:44', '10000', NULL, 0),
	(13, 0, 0, 65555, '', '', 'wax系统模板', '{\"params\":[{\"desc\":\"\",\"id\":\"buildConfigBuildXcode\",\"label\":\"xcode 版本\",\"type\":\"text\",\"required\":true,\"value\":\"9.0\"},{\"desc\":\"工程配置，例如Release、Debug\",\"id\":\"buildXcodeConfiguration\",\"label\":\"配置\",\"required\":true,\"type\":\"text\",\"value\":\"Release\"}],\"tasks\":[{\"abortIfError\":false,\"label\":\"wax打包模板\",\"params\":[{\"desc\":\"\",\"id\":\"commands\",\"label\":\"打包脚本\",\"type\":\"textarea\",\"value\":\"./build.sh\"},{\"desc\":\"\",\"id\":\"result.match.names\",\"label\":\"构建产物名称\",\"type\":\"text\",\"value\":\"patch.zip\"},{\"desc\":\"\",\"id\":\"result.match.paths\",\"label\":\"构建产物路径\",\"type\":\"text\",\"value\":\"./\"}],\"retryTimes\":0,\"taskType\":1,\"value\":\"true\"}]}', NULL, NULL, NULL, now(), now(), '10000', NULL, 0),
  (14, 0, 0, 4117, '', '', 'ios framework 发布系统模板', '{\"params\":[{\"desc\":\"\",\"id\":\"buildConfigBuildXcode\",\"label\":\"xcode 版本\",\"type\":\"text\",\"required\":true,\"value\":\"9.0\"},{\"desc\":\"\",\"id\":\"buildXcodeBuildType\",\"label\":\"打包类型\",\"type\":\"text\",\"required\":true,\"value\":\"framework\"},{\"desc\":\"放置mupp_build_env_init.sh文件在工程目录\",\"id\":\"buildInitScript\",\"options\":[{\"label\":\"不使用\",\"value\":\"0\"},{\"label\":\"使用\",\"value\":\"1\"}],\"label\":\"是否执行初始化脚本\",\"type\":\"select\",\"required\":true,\"value\":\"0\"},{\"desc\":\"打包配置，例如Release、Debug\",\"id\":\"buildXcodeConfiguration\",\"label\":\"配置\",\"required\":true,\"type\":\"text\",\"value\":\"Release\"},{\"desc\":\"schema/target 工程中两者最好保持一致\",\"id\":\"buildXcodeSchema\",\"label\":\"schema\",\"required\":true,\"type\":\"text\",\"value\":\"haoxuanFrameworkTest\"},{\"desc\":\"\",\"id\":\"buildXcodeCocoapodsVersion\",\"label\":\"是否使用cocoapods\",\"options\":[{\"label\":\"不使用\",\"value\":\"0\"},{\"label\":\"使用\",\"value\":\"1.3.1\"}],\"required\":true,\"type\":\"select\",\"value\":\"0\"},{\"desc\":\"proj文件，例如test.xcodeproj\",\"id\":\"buildXcodeProjectFile\",\"label\":\"project file\",\"type\":\"text\",\"required\":true,\"value\":\"haoxuanFrameworkTest.xcodeproj\"},{\"desc\":\"使用pod时或包含workspace则填写，例如test.xcworkspace\",\"id\":\"buildXcodeWorkspaceFile\",\"label\":\"workspace file\",\"required\":false,\"type\":\"text\",\"value\":\"\"},{\"desc\":\"源码相对于工程目录的位置\",\"id\":\"buildXcodeProjectDirectory\",\"label\":\"projectDirectory\",\"type\":\"text\",\"required\":false,\"value\":\"\"}],\"tasks\":[{\"abortIfError\":false,\"params\":[{\"desc\":\"\",\"id\":\"result.match.names\",\"label\":\"构建产物名称\",\"type\":\"text\",\"value\":\"*.json,*.zip\"},{\"desc\":\"\",\"id\":\"result.match.paths\",\"label\":\"构建产物路径\",\"type\":\"text\",\"value\":\"workspace/cocoaFramework/Release-universal/\"}],\"label\":\"\",\"retryTimes\":0,\"taskType\":1,\"value\":\"true\"}]}', NULL, NULL, NULL, '2018-01-12 14:35:57', '2018-01-12 14:35:57', '10000', NULL, 0),
	(21, 0, 0, 1028, '', '', 'weex系统模板', '{\"tasks\":[{\"abortIfError\":false,\"label\":\"模块发布默认模板\",\"params\":[{\"desc\":\"\",\"id\":\"commands\",\"label\":\"打包脚本\",\"type\":\"textarea\",\"value\":\"npm install\\nnpm run build\"},{\"desc\":\"\",\"id\":\"result.match.names\",\"label\":\"构建产物名称\",\"type\":\"text\",\"value\":\"*.js\"},{\"desc\":\"\",\"id\":\"result.match.paths\",\"label\":\"构建产物路径\",\"type\":\"text\",\"value\":\"public\"}],\"retryTimes\":0,\"taskType\":1,\"value\":\"true\"}]}', NULL, NULL, NULL, now(), now(), '10000', NULL, 0);


