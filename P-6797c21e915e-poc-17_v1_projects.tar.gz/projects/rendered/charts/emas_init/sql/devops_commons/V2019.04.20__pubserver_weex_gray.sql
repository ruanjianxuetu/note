USE `emas`;
CREATE TABLE `emas_pubserver_dy_batch_strategy` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `publish_id` bigint(20) NOT NULL COMMENT '发布单ID',
  `batch_id` bigint(20) DEFAULT NULL COMMENT '批次ID',
  `strategy_type` varchar(64) NOT NULL COMMENT '策略类型',
  `params` text NOT NULL COMMENT '策略参数',
  `creator` varchar(64) NOT NULL COMMENT '创建人',
  `modifier` varchar(64) NOT NULL COMMENT '修改人',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_acup` tinyint(1) NOT NULL COMMENT '是否ACUP平台的数据',
  PRIMARY KEY (`id`),
  KEY `publish_id_strategy_type_idx` (`publish_id`,`strategy_type`),
  KEY `batch_id_strategy_type_idx` (`batch_id`,`strategy_type`),
  KEY `batch_id_idx` (`batch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000  DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='dy批次策略'
;