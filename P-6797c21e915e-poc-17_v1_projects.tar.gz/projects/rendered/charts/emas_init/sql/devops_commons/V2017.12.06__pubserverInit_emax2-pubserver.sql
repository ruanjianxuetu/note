USE `emas`;
/******************************************/
/*   数据库全名 = emas_pubserver   */
/*   表名称 = emas_pubserver_accs_task   */
/******************************************/
CREATE TABLE `emas_pubserver_accs_task` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `product_id` bigint(20) unsigned NOT NULL COMMENT 'MUDP产品ID',
  `publish_id` bigint(20) unsigned NOT NULL COMMENT '发布单ID',
  `batch_id` bigint(20) unsigned NOT NULL COMMENT '批次ID',
  `accs_task_id` varchar(128) NOT NULL COMMENT 'ACCS任务ID',
  `accs_send_str` text NOT NULL COMMENT 'ACCS发送字符串',
  `accs_send_count` bigint(20) NOT NULL COMMENT 'ACCS发送数',
  `accs_ack_count` bigint(20) NOT NULL COMMENT 'ACCS响应数',
  `creator` varchar(64) NOT NULL COMMENT '创建人',
  `modifier` varchar(64) NOT NULL COMMENT '修改人',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `in_batch_order` int(11) DEFAULT NULL COMMENT '任务在批次中的序号，从1开始',
  `accs_search_str` text COMMENT 'ACCS任务搜索字符串',
  `batch_dimension` text COMMENT '批次的维度字符串',
  PRIMARY KEY (`id`),
  KEY `product_id_idx` (`product_id`),
  KEY `publish_id_idx` (`publish_id`),
  KEY `batch_id_idx` (`batch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='ACCS数据任务信息'
;

/******************************************/
/*   数据库全名 = emas_pubserver   */
/*   表名称 = emas_pubserver_attribute   */
/******************************************/
CREATE TABLE `emas_pubserver_attribute` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `entity_type` varchar(64) NOT NULL COMMENT '实体类型',
  `entity_id` bigint(20) NOT NULL COMMENT '实体ID',
  `attribute_name` varchar(128) NOT NULL COMMENT '属性名',
  `attribute_value` text NOT NULL COMMENT '属性值',
  `creator` varchar(64) NOT NULL COMMENT '创建人',
  `modifier` varchar(64) NOT NULL COMMENT '修改人',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `entity_type_id_idx` (`entity_type`,`entity_id`),
  KEY `entity_type_id_attr_name_idx` (`entity_type`,`entity_id`,`attribute_name`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='发布平台统一属性表'
;

/******************************************/
/*   数据库全名 = emas_pubserver   */
/*   表名称 = emas_pubserver_batch_strategy   */
/******************************************/
CREATE TABLE `emas_pubserver_batch_strategy` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `publish_id` bigint(20) NOT NULL COMMENT '发布单ID',
  `batch_id` bigint(20) DEFAULT NULL COMMENT '批次ID',
  `strategy_type` varchar(64) NOT NULL COMMENT '策略类型',
  `params` text NOT NULL COMMENT '策略参数',
  `creator` varchar(64) NOT NULL COMMENT '创建人',
  `modifier` varchar(64) NOT NULL COMMENT '修改人',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_acup` tinyint(1) NOT NULL COMMENT '是否ACUP平台的数据',
  PRIMARY KEY (`id`),
  KEY `publish_id_strategy_type_idx` (`publish_id`,`strategy_type`),
  KEY `batch_id_strategy_type_idx` (`batch_id`,`strategy_type`),
  KEY `batch_id_idx` (`batch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000  DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='批次策略'
;

/******************************************/
/*   数据库全名 = emas_pubserver   */
/*   表名称 = emas_pubserver_batch_strategy_meta   */
/******************************************/
CREATE TABLE `emas_pubserver_batch_strategy_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `product_id` bigint(20) DEFAULT NULL COMMENT '产品ID',
  `name` varchar(128) NOT NULL COMMENT '策略的标识',
  `identifer` varchar(128) NOT NULL COMMENT '策略参数标识',
  `expression` text NOT NULL COMMENT '数据规则',
  `data_type` varchar(64) NOT NULL COMMENT '数据类型',
  `creator` varchar(64) NOT NULL COMMENT '创建人',
  `modifier` varchar(64) NOT NULL COMMENT '修改人',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `show_type` varchar(64) NOT NULL COMMENT '展示为',
  PRIMARY KEY (`id`),
  KEY `product_id_idx` (`product_id`),
  KEY `product_id_identifier_idx` (`product_id`,`identifer`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='更新策略元数据'
;

/******************************************/
/*   数据库全名 = emas_pubserver   */
/*   表名称 = emas_pubserver_bundle   */
/******************************************/
CREATE TABLE `emas_pubserver_bundle` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `publish_id` bigint(20) NOT NULL COMMENT '关联发布单ID',
  `batch_id` bigint(20) DEFAULT NULL COMMENT '关联批次ID',
  `file_id` bigint(20) DEFAULT NULL COMMENT '关联文件ID',
  `is_main_dex` tinyint(1) NOT NULL COMMENT '是否主DEX',
  `is_new` tinyint(1) NOT NULL COMMENT '是否新bundle',
  `bundle_name` varchar(1024) NOT NULL COMMENT 'bundle名字',
  `version` varchar(64) NOT NULL COMMENT 'bundle版本',
  `package_name` varchar(1024) NOT NULL COMMENT 'bundle包名',
  `artifact_id` varchar(1024) NOT NULL COMMENT 'artifactId',
  `dependency` varchar(2048) DEFAULT NULL COMMENT '对其他bundle的依赖',
  `creator` varchar(64) NOT NULL COMMENT '创建人',
  `modifier` varchar(64) NOT NULL COMMENT '修改人',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `md5` varchar(64) DEFAULT NULL COMMENT 'bundle对应的文件MD5',
  `file_size` int(11) DEFAULT NULL COMMENT 'bundle对应的文件字节数',
  `url` varchar(2048) DEFAULT NULL COMMENT 'bundle对应的文件地址',
  `is_acup` tinyint(1) NOT NULL COMMENT '是否ACUP平台数据',
  `bundle_use_type` varchar(64) DEFAULT NULL COMMENT 'bundle用途（主包动态下载、动态部署、动态lib等）',
  `is_deleted` tinyint(1) DEFAULT NULL COMMENT '是否删除',
  `https_url` text COMMENT 'https文件地址，可选',
  `src_version` varchar(64) DEFAULT NULL COMMENT 'tpatch使用的src_version',
  `src_unit_tag` varchar(64) DEFAULT NULL COMMENT 'bundle中srcUnitTag字段',
  `unit_tag` varchar(64) DEFAULT NULL COMMENT 'bundle中unitTag字段',
  `reset` tinyint(1) DEFAULT NULL COMMENT 'bundle中reset字段',
  `dexpatch_version` int(11) DEFAULT NULL COMMENT 'bundle中dexpatchVersion字段',
  `product_identifier_version` varchar(64) DEFAULT NULL COMMENT 'product_identifier@version',
  `inherit` tinyint(1) DEFAULT NULL COMMENT '是否继承上个版本的patch',
  `patch_type` int(11) DEFAULT NULL COMMENT 'patchType',
  PRIMARY KEY (`id`),
  KEY `publish_id_idx` (`publish_id`),
  KEY `batch_id_idx` (`batch_id`),
  KEY `file_id_idx` (`file_id`),
  KEY `idx_product_identifier_version` (`product_identifier_version`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='关联到文件或批次发布的bundle信息'
;


/******************************************/
/*   数据库全名 = emas_pubserver   */
/*   表名称 = emas_pubserver_dy_accs_task   */
/******************************************/
CREATE TABLE `emas_pubserver_dy_accs_task` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `dy_product_id` bigint(20) unsigned NOT NULL COMMENT '动态化产品id',
  `dy_publish_id` bigint(20) unsigned NOT NULL COMMENT '动态化发布单id',
  `dy_batch_id` bigint(20) unsigned NOT NULL COMMENT '动态化批次id',
  `accs_task_id` varchar(128) NOT NULL COMMENT 'accs任务id',
  `accs_send_str` text COMMENT 'accs发送字符串',
  `accs_send_count` bigint(20) DEFAULT NULL COMMENT 'accs发送数',
  `accs_ack_count` bigint(20) DEFAULT NULL COMMENT 'accs应答数',
  `creator` varchar(64) NOT NULL COMMENT '创建人',
  `modifier` varchar(64) NOT NULL COMMENT '修改人',
  `in_batch_order` int(11) DEFAULT NULL COMMENT '任务在批次中的序号，从1开始',
  `accs_search_str` text COMMENT 'ACCS任务搜索字符串',
  `batch_dimension` text COMMENT '批次的维度字符串',
  PRIMARY KEY (`id`),
  KEY `idx_batch_id` (`dy_batch_id`),
  KEY `idx_publish_id` (`dy_publish_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='动态化accs任务表'
;

/******************************************/
/*   数据库全名 = emas_pubserver   */
/*   表名称 = emas_pubserver_dy_publish   */
/******************************************/
CREATE TABLE `emas_pubserver_dy_publish` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `outer_dy_product_id` bigint(20) unsigned NOT NULL COMMENT '动态化平台产品id',
  `dy_product_id` bigint(20) unsigned NOT NULL COMMENT '动态化发布平台产品id',
  `dy_publish_status` varchar(64) NOT NULL COMMENT '状态',
  `version` varchar(64) NOT NULL COMMENT '版本',
  `priority` int(11) NOT NULL COMMENT '优先级',
  `publish_range_type` varchar(64) DEFAULT NULL COMMENT '发布类型',
  `creator` varchar(64) NOT NULL COMMENT '创建人',
  `modifier` varchar(64) NOT NULL COMMENT '修改人',
  `discription` text COMMENT '补充信息',
  `first_batch_time` datetime DEFAULT NULL COMMENT '第一次发布批次时间',
  `latest_batch_time` datetime DEFAULT NULL COMMENT '最新一次发布批次时间',
  PRIMARY KEY (`id`),
  KEY `idx_outer_product_id` (`outer_dy_product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='动态化发布单表'
;

/******************************************/
/*   数据库全名 = emas_pubserver   */
/*   表名称 = emas_pubserver_dy_publish_batch   */
/******************************************/
CREATE TABLE `emas_pubserver_dy_publish_batch` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `dy_publish_id` bigint(20) unsigned NOT NULL COMMENT '发布单id',
  `batch_type` varchar(64) NOT NULL COMMENT '批次类型',
  `batch_status` varchar(64) NOT NULL COMMENT '批次状态',
  `planned_notify_count` int(11) NOT NULL COMMENT '计划通知人数',
  `start_time` datetime NOT NULL COMMENT '起始时间',
  `stop_time` datetime NOT NULL COMMENT '结束时间',
  `priority` int(11) NOT NULL COMMENT '优先级',
  `notified_count` int(11) DEFAULT NULL COMMENT '已通知人数',
  `creator` varchar(64) NOT NULL COMMENT '创建人',
  `modifier` varchar(64) NOT NULL COMMENT '修改人',
  `accs_task_id` varchar(256) DEFAULT NULL COMMENT 'accs任务id',
  `accs_send_count` int(11) DEFAULT NULL COMMENT 'accs已发送人数',
  `accs_ack_count` int(11) DEFAULT NULL COMMENT 'accs已应答人数',
  `finish_reason` varchar(64) DEFAULT NULL COMMENT '结束原因',
  `fact_finish_time` datetime DEFAULT NULL COMMENT '实际结束时间',
  `has_accs_task` tinyint(1) NOT NULL COMMENT '是否包含accs任务',
  PRIMARY KEY (`id`),
  KEY `idx_publish_id` (`dy_publish_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='动态化批次表'
;

/******************************************/
/*   数据库全名 = emas_pubserver   */
/*   表名称 = emas_pubserver_dy_publish_config   */
/******************************************/
CREATE TABLE `emas_pubserver_dy_publish_config` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `version` varchar(64) NOT NULL COMMENT '版本',
  `config_meta_ids` text NOT NULL COMMENT '配置id集合',
  `identifier` varchar(64) NOT NULL COMMENT '标识',
  `outer_dy_product_id` bigint(20) unsigned NOT NULL COMMENT '动态化平台产品id',
  `dy_product_id` bigint(20) unsigned NOT NULL COMMENT '产品id',
  `creator` varchar(64) NOT NULL COMMENT '创建人',
  `modifier` varchar(64) NOT NULL COMMENT '修改人',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='配置版本关系表'
;

/******************************************/
/*   数据库全名 = emas_pubserver   */
/*   表名称 = emas_pubserver_dy_publish_config_meta   */
/******************************************/
CREATE TABLE `emas_pubserver_dy_publish_config_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `jsbundle_cdn_url` varchar(1024) NOT NULL COMMENT '发布jsbundle的cdn地址',
  `jsbundle_delivery_url` text NOT NULL COMMENT 'jsbundle投放地址',
  `jsbundle_name` varchar(1024) DEFAULT NULL COMMENT '名称',
  `version` varchar(1024) DEFAULT NULL COMMENT '版本',
  `type` varchar(64) NOT NULL COMMENT '类型',
  `dy_product_id` bigint(20) unsigned DEFAULT NULL COMMENT 'dy产品id',
  `outer_dy_product_id` bigint(20) unsigned DEFAULT NULL COMMENT '动态化平台产品id',
  `dy_publish_id` bigint(20) unsigned NOT NULL COMMENT '发布单id',
  `dy_batch_id` bigint(20) unsigned DEFAULT NULL COMMENT '批次id',
  `creator` varchar(64) NOT NULL COMMENT '创建人',
  `modifier` varchar(64) NOT NULL COMMENT '修改人',
  PRIMARY KEY (`id`),
  KEY `idx_batch_id` (`dy_batch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='配置信息表'
;

/******************************************/
/*   数据库全名 = emas_pubserver   */
/*   表名称 = emas_pubserver_file   */
/******************************************/
CREATE TABLE `emas_pubserver_file` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `publish_id` bigint(20) NOT NULL COMMENT '发布单ID',
  `outer_file_id` bigint(20) NOT NULL COMMENT '外部文件ID',
  `oss_bucket` varchar(512) DEFAULT NULL COMMENT 'OSS bucket',
  `oss_key` text COMMENT 'OSS 文件key',
  `cdn_url` text COMMENT '文件CDN地址',
  `file_type` varchar(64) NOT NULL COMMENT '文件类型',
  `file_status` varchar(64) NOT NULL COMMENT '文件状态',
  `version` varchar(128) DEFAULT NULL COMMENT '包版本（可选）',
  `differential_url` varchar(2048) DEFAULT NULL COMMENT '差量发布的文件地址',
  `file_size` int(11) NOT NULL COMMENT '文件大小',
  `publish_file_name` varchar(1024) NOT NULL COMMENT '发布文件标识',
  `md5` varchar(64) NOT NULL COMMENT 'MD5摘要值',
  `creator` varchar(64) NOT NULL COMMENT '创建人',
  `modifier` varchar(64) NOT NULL COMMENT '修改人',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `channel_num` varchar(64) DEFAULT NULL COMMENT '渠道号',
  `dependency` varchar(1024) DEFAULT NULL COMMENT '依赖（针对Bundle）',
  `bundle_info` text COMMENT '文件相关bundle信息（针对动态部署产物）',
  `is_acup` tinyint(1) NOT NULL COMMENT '是否ACUP平台数据',
  `https_url` text COMMENT 'HTTPS下载地址，与CDN下载地址相对，可选字段',
  PRIMARY KEY (`id`),
  KEY `outer_file_id_idx` (`outer_file_id`),
  KEY `publish_id_idx` (`publish_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='发布单文件'
;


/******************************************/
/*   数据库全名 = emas_pubserver   */
/*   表名称 = emas_pubserver_operation_log   */
/******************************************/
CREATE TABLE `emas_pubserver_operation_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `entity_type` varchar(64) NOT NULL COMMENT '动作对象实体类型',
  `entity_id` bigint(20) NOT NULL COMMENT '实体ID',
  `operation_type` varchar(64) NOT NULL COMMENT '操作类型',
  `old_value` text COMMENT '旧值',
  `new_value` text COMMENT '新值',
  `context` text COMMENT '操作上下文记录',
  `result_json` text COMMENT '结果记录',
  `operate_user` varchar(64) NOT NULL COMMENT '操作人',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `entity_type_entity_id_idx` (`entity_type`,`entity_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='用户操作日志'
;

/******************************************/
/*   数据库全名 = emas_pubserver   */
/*   表名称 = emas_pubserver_product   */
/******************************************/
CREATE TABLE `emas_pubserver_product` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `is_emas` tinyint(1) NOT NULL COMMENT '是否EMAS中的产品',
  `outer_product_id` bigint(20) DEFAULT NULL COMMENT '外部产品ID',
  `product_name` varchar(128) NOT NULL COMMENT '产品名',
  `main_product_id` bigint(20) NOT NULL COMMENT '主产品ID',
  `product_type` varchar(64) NOT NULL COMMENT '产品类型',
  `identifier` varchar(128) NOT NULL COMMENT '产品唯一标识',
  `main_channel_num` varchar(64) DEFAULT NULL COMMENT '发布主渠道',
  `creator` varchar(64) NOT NULL COMMENT '创建人',
  `modifier` varchar(64) NOT NULL COMMENT '修改人',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_deleted` tinyint(1) NOT NULL COMMENT '是否删除',
  `accs_service_id` varchar(128) DEFAULT NULL COMMENT 'ACCS的服务ID',
  `support_differential` tinyint(1) DEFAULT NULL COMMENT '支持差量发布',
  `default_remind_count` int(11) DEFAULT NULL COMMENT '默认提醒次数',
  `exclude_channel_nums` varchar(2048) DEFAULT NULL COMMENT '排除渠道号',
  `locales` varchar(2048) DEFAULT NULL COMMENT '语言选项',
  `platform_type` varchar(64) NOT NULL COMMENT '平台类型',
  `current_appkey` varchar(64) DEFAULT NULL COMMENT '当前appkey',
  `basic_appkey` varchar(64) DEFAULT NULL COMMENT '基础appkey',
  `app_store_id` bigint(20) DEFAULT NULL COMMENT 'AppStore的APP ID',
  `package_name` varchar(128) DEFAULT NULL COMMENT '产品的包名',
  `support_accs_mass` tinyint(1) DEFAULT NULL COMMENT '是否支持accs mass发布',
  `use_accs_mass_hotpatch` tinyint(1) DEFAULT NULL COMMENT '是否使用accs mass发布hotpatch',
  `use_accs_mass_andfix` tinyint(1) DEFAULT NULL COMMENT '是否是用accs mass发布andfix',
  `jailbreak_main_channel_num` bigint(20) unsigned DEFAULT NULL COMMENT '废弃字段不再使用',
  `jailbreak_main_channel_num2` varchar(64) DEFAULT NULL COMMENT '越狱主渠道',
  `is_ios_enterprise` tinyint(1) DEFAULT NULL COMMENT '是否iOS企业包产品',
  `use_accs_mass_main` tinyint(1) DEFAULT NULL COMMENT '是否支持accs mass发布完整包',
  `use_accs_mass_dynamic` tinyint(1) DEFAULT NULL COMMENT '是否支持accs mass发布动态部署',
  PRIMARY KEY (`id`),
  KEY `product_id_idx` (`outer_product_id`),
  KEY `main_product_id_idx` (`main_product_id`),
  KEY `identifier_idx` (`identifier`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='发布平台产品'
;

/******************************************/
/*   数据库全名 = emas_pubserver   */
/*   表名称 = emas_pubserver_publish   */
/******************************************/
CREATE TABLE `emas_pubserver_publish` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `outer_product_id` bigint(20) NOT NULL COMMENT '外部产品ID',
  `outer_project_id` bigint(20) NOT NULL COMMENT '外部发布项目ID',
  `product_id` bigint(20) NOT NULL COMMENT '产品ID',
  `product_type` varchar(64) NOT NULL COMMENT '产品类型',
  `publish_type` varchar(64) NOT NULL COMMENT '发布类型（灰度/正式）',
  `publish_status` varchar(64) NOT NULL COMMENT '发布单的状态',
  `freeze_status` varchar(64) NOT NULL COMMENT '冻结状态',
  `version` varchar(128) NOT NULL COMMENT '版本',
  `remind_text` text COMMENT '提醒文案',
  `creator` varchar(64) NOT NULL COMMENT '创建人',
  `modifier` varchar(64) NOT NULL COMMENT '修改人',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `outer_publish_status` varchar(64) NOT NULL COMMENT '发布业务的发布状态',
  `int_version` int(11) DEFAULT NULL COMMENT '某些发布单使用的数字版本（如hotpatch）',
  `bundle_etag` varchar(64) DEFAULT NULL COMMENT '发布单对应的bundle列表的标记',
  `priority` int(11) NOT NULL COMMENT '发布单优先级',
  `publish_range_type` varchar(64) DEFAULT NULL COMMENT '发布单的发布类型（灰度/正式）',
  `is_acup` tinyint(1) NOT NULL COMMENT '是否ACUP平台数据',
  `first_batch_time` datetime DEFAULT NULL COMMENT '首次批次时间',
  `latest_batch_time` datetime DEFAULT NULL COMMENT '最近批次时间',
  PRIMARY KEY (`id`),
  KEY `product_id_idx` (`product_id`),
  KEY `product_id_publish_status_idx` (`product_id`,`publish_status`),
  KEY `product_id_version_idx` (`product_id`,`version`),
  KEY `bundle_etag_idx` (`bundle_etag`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='发布单'
;

/******************************************/
/*   数据库全名 = emas_pubserver   */
/*   表名称 = emas_pubserver_publish_andfix   */
/******************************************/
CREATE TABLE `emas_pubserver_publish_andfix` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `product_id` bigint(20) NOT NULL COMMENT '产品ID',
  `publish_id` bigint(20) NOT NULL COMMENT '发布单ID',
  `target_versoin` varchar(128) NOT NULL COMMENT '目标版本',
  `creator` varchar(64) NOT NULL COMMENT '创建人',
  `modifier` varchar(64) NOT NULL COMMENT '修改人',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `product_id_idx` (`product_id`),
  KEY `publish_id_idx` (`publish_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='发布扩展表之andfix'
;

/******************************************/
/*   数据库全名 = emas_pubserver   */
/*   表名称 = emas_pubserver_publish_batch   */
/******************************************/
CREATE TABLE `emas_pubserver_publish_batch` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `publish_id` bigint(20) NOT NULL COMMENT '发布单ID',
  `batch_type` varchar(64) NOT NULL COMMENT '批次类型',
  `batch_status` varchar(64) NOT NULL COMMENT '批次状态',
  `planned_notify_count` int(11) DEFAULT NULL COMMENT '计划通知数',
  `planned_update_count` int(11) DEFAULT NULL COMMENT '计划更新数',
  `crash_stop_rate` decimal(2,2) DEFAULT NULL COMMENT '计划停止的crash率',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `stop_time` datetime DEFAULT NULL COMMENT '截止时间',
  `priority` int(11) NOT NULL COMMENT '优先级',
  `notified_count` int(11) NOT NULL COMMENT '当前已通知数',
  `updated_count` int(11) NOT NULL COMMENT '已更新数',
  `creator` varchar(64) NOT NULL COMMENT '创建人',
  `modifier` varchar(64) NOT NULL COMMENT '修改人',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `etag` varchar(64) DEFAULT NULL COMMENT '批次的etag标识',
  `is_acup` tinyint(1) NOT NULL COMMENT '是否ACUP平台数据',
  `accs_task_id` varchar(256) DEFAULT NULL COMMENT '废弃字段，关联的accs发送任务的ID',
  `accs_send_count` int(11) DEFAULT NULL COMMENT '废弃字段',
  `accs_ack_count` int(11) DEFAULT NULL COMMENT '废弃字段',
  `finish_reason` varchar(64) DEFAULT NULL COMMENT '批次结束原因',
  `fact_finish_time` datetime DEFAULT NULL COMMENT '实际结束时间',
  `has_accs_task` tinyint(1) DEFAULT NULL COMMENT '是否有accs任务',
  PRIMARY KEY (`id`),
  KEY `publish_id_idx` (`publish_id`),
  KEY `publish_id_batch_status_idx` (`publish_id`,`batch_status`),
  KEY `etag_idx` (`etag`),
  KEY `accs_task_id_idx` (`accs_task_id`(255))
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='发布批次'
;

/******************************************/
/*   数据库全名 = emas_pubserver   */
/*   表名称 = emas_pubserver_publish_batch_file   */
/******************************************/
CREATE TABLE `emas_pubserver_publish_batch_file` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `publish_id` bigint(20) NOT NULL COMMENT '发布单ID',
  `batch_id` bigint(20) NOT NULL COMMENT '批次ID',
  `file_id` bigint(20) NOT NULL COMMENT '文件ID',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_acup` tinyint(1) NOT NULL COMMENT '是否ACUP平台数据',
  PRIMARY KEY (`id`),
  KEY `batch_id_idx` (`batch_id`),
  KEY `file_id_idx` (`file_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='批次与文件关系'
;

/******************************************/
/*   数据库全名 = emas_pubserver   */
/*   表名称 = emas_pubserver_publish_command   */
/******************************************/
CREATE TABLE `emas_pubserver_publish_command` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `publish_id` bigint(20) unsigned NOT NULL COMMENT '关联的发布单',
  `command_name` varchar(256) NOT NULL COMMENT 'command名',
  `param` varchar(1024) DEFAULT NULL COMMENT 'command参数',
  `creator` varchar(64) NOT NULL COMMENT '创建人',
  `modifier` varchar(64) NOT NULL COMMENT '修改人',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `command_etag` varchar(64) DEFAULT NULL COMMENT 'command etag',
  `user_group_id` int(10) unsigned DEFAULT NULL COMMENT '发布到用户分组',
  PRIMARY KEY (`id`),
  KEY `publish_id_idx` (`publish_id`),
  KEY `user_group_id_idx` (`user_group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='发布单相关的command'
;

/******************************************/
/*   数据库全名 = emas_pubserver   */
/*   表名称 = emas_pubserver_publish_dynamic_deploy   */
/******************************************/
CREATE TABLE `emas_pubserver_publish_dynamic_deploy` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `product_id` bigint(20) NOT NULL COMMENT '产品ID',
  `publish_id` bigint(20) NOT NULL COMMENT '发布单ID',
  `container_version` varchar(128) NOT NULL COMMENT '容器版本',
  `target_version` varchar(128) NOT NULL COMMENT '发布目标版本',
  `cover_versions` text COMMENT '覆盖版本列表',
  `creator` varchar(64) NOT NULL COMMENT '创建人',
  `modifier` varchar(64) NOT NULL COMMENT '修改人',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_acup` tinyint(1) NOT NULL COMMENT '是否ACUP平台数据',
  `diff_bundle_dex` tinyint(1) NOT NULL COMMENT '是否差量bundle Dex',
  PRIMARY KEY (`id`),
  KEY `publish_id_idx` (`publish_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='发布扩展表之动态发布'
;

/******************************************/
/*   数据库全名 = emas_pubserver   */
/*   表名称 = emas_pubserver_publish_hotpatch   */
/******************************************/
CREATE TABLE `emas_pubserver_publish_hotpatch` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `product_id` bigint(20) NOT NULL COMMENT '产品ID',
  `publish_id` bigint(20) NOT NULL COMMENT '发布单ID',
  `target_versoin` varchar(128) NOT NULL COMMENT '目标版本',
  `creator` varchar(64) NOT NULL COMMENT '创建人',
  `modifier` varchar(64) NOT NULL COMMENT '修改人',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `is_acup` tinyint(1) NOT NULL COMMENT '是否ACUP平台数据',
  PRIMARY KEY (`id`),
  KEY `product_id_idx` (`product_id`),
  KEY `publish_id_idx` (`publish_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='发布扩展表之Hotpatch'
;
