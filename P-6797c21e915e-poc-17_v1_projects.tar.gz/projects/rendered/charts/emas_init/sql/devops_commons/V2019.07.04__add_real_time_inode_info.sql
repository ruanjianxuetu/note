USE `emas`;
ALTER TABLE `emas_machine_real_time_infodo` ADD `hard_disk_left_percent` DOUBLE DEFAULT NULL COMMENT '磁盘空间剩余百分比';
ALTER TABLE `emas_machine_real_time_infodo` ADD `inodes_left_count` bigint(20) DEFAULT NULL COMMENT 'i-node剩余总量';
ALTER TABLE `emas_machine_real_time_infodo` ADD `inodes_left_percent` DOUBLE DEFAULT NULL COMMENT 'i-node剩余百分比';