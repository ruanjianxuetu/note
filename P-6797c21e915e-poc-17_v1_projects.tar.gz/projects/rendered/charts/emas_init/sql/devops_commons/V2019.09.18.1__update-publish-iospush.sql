USE `emas`;
BEGIN;
-- IOS更新推送功能，发布配置新增 ios最低操作系统 字段
alter table emas_publish_config_info add least_support_os_version varchar(64) NOT NULL default '4.0' comment '最低支持操作系统';
-- IOS更新推送功能，发布单新增 测试状态 字段
alter table emas_publish_project add test_status varchar(64) default 'NOT_STARTED' comment '当前发布单测试状态';
COMMIT;