USE `emas`;
ALTER TABLE `emas_publish_project` MODIFY `project_name` varchar(100) NOT NULL COMMENT '发布单名称';