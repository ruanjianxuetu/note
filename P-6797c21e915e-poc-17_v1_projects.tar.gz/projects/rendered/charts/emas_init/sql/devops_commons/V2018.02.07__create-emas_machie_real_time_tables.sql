USE `emas`;
# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 10.125.13.65 (MySQL 5.7.20)
# Database: emas
# Generation Time: 2018-02-07 03:04:38 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table emas_machine_real_time_info_daydo
# ------------------------------------------------------------

DROP TABLE IF EXISTS `emas_machine_real_time_info_daydo`;

CREATE TABLE `emas_machine_real_time_info_daydo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cpu_usage_percentage_avg` double DEFAULT NULL,
  `cpu_usage_percentage_max` double DEFAULT NULL,
  `cpu_usage_percentage_min` double DEFAULT NULL,
  `current_ability_reserved_avg` double DEFAULT NULL,
  `current_ability_reserved_max` double DEFAULT NULL,
  `current_ability_reserved_min` double DEFAULT NULL,
  `current_ability_used_avg` double DEFAULT NULL,
  `current_ability_used_max` double DEFAULT NULL,
  `current_ability_used_min` double DEFAULT NULL,
  `free_memory_avg` double DEFAULT NULL,
  `free_memory_max` double DEFAULT NULL,
  `free_memory_min` double DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `hard_disk_leftgbavg` double DEFAULT NULL,
  `hard_disk_leftgbmax` double DEFAULT NULL,
  `hard_disk_leftgbmin` double DEFAULT NULL,
  `ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `load_for_last1minute_avg` double DEFAULT NULL,
  `load_for_last1minute_max` double DEFAULT NULL,
  `load_for_last1minute_min` double DEFAULT NULL,
  `memory_used_percentage_avg` double DEFAULT NULL,
  `memory_used_percentage_max` double DEFAULT NULL,
  `memory_used_percentage_min` double DEFAULT NULL,
  `used_file_descriptor_count_avg` double DEFAULT NULL,
  `used_file_descriptor_count_max` double DEFAULT NULL,
  `used_file_descriptor_count_min` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table emas_machine_real_time_info_hourdo
# ------------------------------------------------------------

DROP TABLE IF EXISTS `emas_machine_real_time_info_hourdo`;

CREATE TABLE `emas_machine_real_time_info_hourdo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cpu_usage_percentage_avg` double DEFAULT NULL,
  `cpu_usage_percentage_max` double DEFAULT NULL,
  `cpu_usage_percentage_min` double DEFAULT NULL,
  `current_ability_reserved_avg` double DEFAULT NULL,
  `current_ability_reserved_max` double DEFAULT NULL,
  `current_ability_reserved_min` double DEFAULT NULL,
  `current_ability_used_avg` double DEFAULT NULL,
  `current_ability_used_max` double DEFAULT NULL,
  `current_ability_used_min` double DEFAULT NULL,
  `free_memory_avg` double DEFAULT NULL,
  `free_memory_max` double DEFAULT NULL,
  `free_memory_min` double DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `hard_disk_leftgbavg` double DEFAULT NULL,
  `hard_disk_leftgbmax` double DEFAULT NULL,
  `hard_disk_leftgbmin` double DEFAULT NULL,
  `ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `load_for_last1minute_avg` double DEFAULT NULL,
  `load_for_last1minute_max` double DEFAULT NULL,
  `load_for_last1minute_min` double DEFAULT NULL,
  `memory_used_percentage_avg` double DEFAULT NULL,
  `memory_used_percentage_max` double DEFAULT NULL,
  `memory_used_percentage_min` double DEFAULT NULL,
  `used_file_descriptor_count_avg` double DEFAULT NULL,
  `used_file_descriptor_count_max` double DEFAULT NULL,
  `used_file_descriptor_count_min` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table emas_machine_real_time_info_minutedo
# ------------------------------------------------------------

DROP TABLE IF EXISTS `emas_machine_real_time_info_minutedo`;

CREATE TABLE `emas_machine_real_time_info_minutedo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cpu_usage_percentage_avg` double DEFAULT NULL,
  `cpu_usage_percentage_max` double DEFAULT NULL,
  `cpu_usage_percentage_min` double DEFAULT NULL,
  `current_ability_reserved_avg` double DEFAULT NULL,
  `current_ability_reserved_max` double DEFAULT NULL,
  `current_ability_reserved_min` double DEFAULT NULL,
  `current_ability_used_avg` double DEFAULT NULL,
  `current_ability_used_max` double DEFAULT NULL,
  `current_ability_used_min` double DEFAULT NULL,
  `free_memory_avg` double DEFAULT NULL,
  `free_memory_max` double DEFAULT NULL,
  `free_memory_min` double DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `hard_disk_leftgbavg` double DEFAULT NULL,
  `hard_disk_leftgbmax` double DEFAULT NULL,
  `hard_disk_leftgbmin` double DEFAULT NULL,
  `ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `load_for_last1minute_avg` double DEFAULT NULL,
  `load_for_last1minute_max` double DEFAULT NULL,
  `load_for_last1minute_min` double DEFAULT NULL,
  `memory_used_percentage_avg` double DEFAULT NULL,
  `memory_used_percentage_max` double DEFAULT NULL,
  `memory_used_percentage_min` double DEFAULT NULL,
  `used_file_descriptor_count_avg` double DEFAULT NULL,
  `used_file_descriptor_count_max` double DEFAULT NULL,
  `used_file_descriptor_count_min` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
