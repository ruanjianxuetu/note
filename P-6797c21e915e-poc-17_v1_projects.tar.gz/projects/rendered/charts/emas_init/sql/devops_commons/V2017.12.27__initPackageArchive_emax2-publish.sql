USE `emas`;
/******************************************/
/*   数据库全名 = emas   */
/*   表名称 = emas_app_package_archive   */
/******************************************/
CREATE TABLE `emas_app_package_archive` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `app_id` bigint(20) unsigned NOT NULL COMMENT '应用ID',
  `project_id` bigint(20) unsigned NOT NULL COMMENT '项目ID',
  `product_version` varchar(64) NOT NULL COMMENT '所属产品版本',
  `build_task_id` bigint(20) unsigned NOT NULL COMMENT '归档包所属构建ID',
  `file_id` bigint(20) unsigned NOT NULL COMMENT '归档包ID',
  `archive_source` varchar(64) NOT NULL COMMENT '归档来源（发布单，手工等）',
  `archive_user` varchar(64) DEFAULT NULL COMMENT '归档触发人',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `archive_publish_type` varchar(64) DEFAULT NULL COMMENT '归档发布类型',
  `memo` varchar(1024) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  KEY `app_id_idx` (`app_id`),
  KEY `project_id_idx` (`project_id`),
  KEY `file_id_idx` (`file_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50000000 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='产品包归档';

