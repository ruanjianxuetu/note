USE `emas`;
DELETE FROM emas_actiondo where action_name = 'hard disk default action';

INSERT INTO `emas_actiondo` ( `action_name`, `action_param_json`, `action_type`, `creator`, `gmt_create`, `gmt_modified`, `modifier`)
VALUES
  ('hard disk default action', '{\"shellContent\": \"sh $CLEAN_SHELL_PATH/emasCleanFiles.sh\",\"extendParams\": \"\"}', 0, 'asdf17128', '2018-01-09 15:38:25', '2018-01-09 17:32:59', 'asdf17128');