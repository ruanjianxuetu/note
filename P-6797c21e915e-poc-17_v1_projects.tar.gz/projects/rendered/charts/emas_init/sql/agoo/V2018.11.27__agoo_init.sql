
CREATE DATABASE IF NOT EXISTS `emas-agoolite`;
USE `emas-agoolite`;

CREATE TABLE `agoo_service_token` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID列，主键',
  `app_key` varchar(255) NOT NULL COMMENT '所属appKey',
  `title` varchar(255) NOT NULL COMMENT 'Token名称',
  `token` varchar(255) NOT NULL COMMENT 'Token值',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_app_key_token` (`app_key`,`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='服务端访问Token表';

CREATE TABLE `app_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `appkey` varchar(100) DEFAULT NULL COMMENT 'appkey',
  `app_name` varchar(64) NOT NULL COMMENT 'app应用名',
  `type` varchar(32) NOT NULL COMMENT 'App应用类型。IOS Android',
  `gmt_create` datetime NOT NULL COMMENT '记录创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '记录最后修改时间',
  `package_name` varchar(128) DEFAULT NULL COMMENT 'APP包名称',
  `package_names` text COMMENT '多包名白名单',
  `key_info` text COMMENT '通用字段存放泛化后的pushtoken，苹果还是小米还是gcm都可以使用这个来表达。',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_app_appkey` (`appkey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='APP信息表';

CREATE TABLE `global_config` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `config_id` varchar(128) NOT NULL COMMENT 'configID',
  `group_id` varchar(128) NOT NULL COMMENT 'groupID',
  `value` text NOT NULL COMMENT 'value',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_config_group` (`config_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='全局配置';

CREATE TABLE `batch_main_task` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gmt_create` datetime NOT NULL,
  `gmt_modified` datetime NOT NULL,
  `source` varchar(100) DEFAULT NULL,
  `target_service` varchar(100) DEFAULT NULL,
  `data_id` varchar(200) DEFAULT NULL,
  `range_condition` varchar(500) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `data` text,
  `total_count` bigint(20) unsigned DEFAULT NULL,
  `device_info_base` smallint(6) NOT NULL,
  `task_from` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `batch_sub_task` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `main_task_id` bigint(20) unsigned NOT NULL COMMENT '主任务Id',
  `task_url` varchar(1000) NOT NULL COMMENT '子任务URL',
  `status` tinyint(4) NOT NULL COMMENT '-1:删除 0:初始 1: 待运行 2:执行中 3:暂停 4:完成',
  `last_tag` varchar(500) DEFAULT NULL COMMENT '任务完成标记，续传',
  `scan_count` bigint(20) unsigned DEFAULT NULL COMMENT '子任务扫描量',
  `retry_num` tinyint(3) unsigned DEFAULT NULL COMMENT '子任务重试次数',
  PRIMARY KEY (`id`),
  KEY `idx_main_task_id` (`main_task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `agoo_job_fw_job` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `job_id` varchar(24) NOT NULL COMMENT '由框架生成的id，分布式id',
  `type_key` varchar(30) NOT NULL COMMENT '任务的类型，对应任务处理器的类型',
  `state` smallint(6) NOT NULL COMMENT ' /**\n         * 新创建,可重试\n         */\n        NEW(0),\n        /**\n         * 已接收并且存储，可重试\n         */\n        SAVED(1),\n        /**\n         * 任务已拆分切存储,不可重试\n         */\n        TASK_SAVED(2),\n        /**\n         * 任务已分发,不可重试\n         */\n        DISPATCHED(3),\n        /**\n         * 任务已完成,不可重试\n         */\n        COMPLETE(4),\n        /**\n         * 任务已取消,不可重试\n         */\n        CANCELED(5),\n        /**\n         * 任务处理发生错误(分解Task并存储之前)，可重试\n         */\n        FAILED_BEFORE_TASK_SAVED(6),\n        /**\n         * 任务本身发生错误，不可重试\n         */\n        FATAL(7),\n        /**\n         * 延迟中,可重试\n         */\n        DELAY(8),\n        /**\n         * 任务处理发生错误(分解Task并存储之前)且重试到最大次数,不可重试\n         */\n        FAILED_BEFORE_TASK_SAVED_MAX_RETRIED(9);
',
  `memo` mediumtext COMMENT 'job的描述信息，一般用于展示，json',
  `blocks` mediumtext NOT NULL COMMENT 'job的逻辑数据块，一般用于展示',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `hosting` varchar(200) NOT NULL COMMENT '处理job的节点:\nip:port:id',
  `min_divide_len` bigint(20) NOT NULL COMMENT '最小切分长度',
  `retry` smallint(6) NOT NULL COMMENT '重试次数',
  `job_group` varchar(100) NOT NULL COMMENT '业务自定义分组类型：\n如appKey',
  `biz_id` varchar(100) DEFAULT NULL COMMENT '业务传进来的唯一性ID，用于做幂等校验',
  `delay` datetime DEFAULT NULL COMMENT '延迟任务，字段表示执行任务的时间点',
  `gmt_process` datetime DEFAULT NULL COMMENT '开始处理时间',
  `env` varchar(50) NOT NULL DEFAULT 'prod' COMMENT '所处环境标识，如pre、prod等',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_job_id` (`job_id`(18)),
  UNIQUE KEY `uk_biz_id_type_key` (`biz_id`,`type_key`),
  KEY `idx_gmt_create` (`gmt_create`),
  KEY `idx_state_gmt_create` (`state`,`gmt_create`),
  KEY `idx_job_group_gmt_create_state_type_key` (`job_group`,`gmt_create`,`type_key`,`state`),
  KEY `idx_env` (`env`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='agoo-job框架的主任务存储';

CREATE TABLE `agoo_job_fw_task` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `task_id` varchar(24) NOT NULL COMMENT '框架生成的分布式ID',
  `job_id` varchar(24) NOT NULL COMMENT '关联job的id',
  `state` smallint(6) NOT NULL COMMENT ' /**\n         * 新Task已创建\n         */\n        NEW(0),\n        /**\n         * worker接收，并且正在worker处理\n         */\n        ACCEPTED(1),\n        /**\n         * 正在worker处理\n         */\n        RUNNING(2),\n        /**\n         * 运行时的错误，可以重试\n         */\n        FAILED(3),\n        /**\n         * 完成\n         */\n        COMPLETE(4),\n        /**\n         * 被取消，不可以重试\n         */\n        CANCELED(5),\n        /**\n         * 不能重试的错误，如Job信息本身有问题的错误。\n         */\n        FATAL(6),\n        /**\n         * 运行时的错误，且重试到最大次数的，不可重试\n         */\n        FAILED_MAX_RETRIED(7);
',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `hosting` varchar(200) NOT NULL COMMENT '任务执行节点：\nip:port:id',
  `retry` smallint(6) NOT NULL COMMENT '重试次数',
  `gmt_process` datetime DEFAULT NULL COMMENT '开始处理时间',
  `env` varchar(50) NOT NULL DEFAULT 'prod' COMMENT '所处环境标识，如pre、prod等',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_task_id` (`task_id`),
  KEY `idx_state_gmt_create` (`state`,`gmt_create`),
  KEY `idx_job_id` (`job_id`),
  KEY `idx_gmt_create` (`gmt_create`),
  KEY `idx_env` (`env`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='agoo-job框架存储子任务信息task';

CREATE TABLE `agoo_job_fw_task_block` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `block_id` varchar(24) NOT NULL COMMENT '框架分配的分布式ID',
  `task_id` varchar(24) NOT NULL COMMENT '关联task的id\n',
  `job_id` varchar(24) NOT NULL COMMENT '关联job的ID',
  `divide_id` varchar(100) NOT NULL COMMENT 'block的切分传递标识，block切分时会一直传递这个属性',
  `offset` bigint(20) unsigned NOT NULL COMMENT '已处理的位移',
  `state` smallint(6) NOT NULL COMMENT ' NEW(1),\n ON_PROCESS(2),\n COMPLETE(3),\n ERROR(4);
',
  `start` bigint(20) NOT NULL COMMENT 'block的起始位移',
  `end` bigint(20) NOT NULL COMMENT 'block的结束位移',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `memo` mediumtext COMMENT '扩展字段',
  `context` mediumtext COMMENT '上下文信息',
  `gmt_process` datetime DEFAULT NULL COMMENT '开始处理时间',
  `env` varchar(50) NOT NULL DEFAULT 'prod' COMMENT '所处环境标识，如pre、prod等',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_block_id` (`block_id`),
  KEY `idx_job_id_divide_id` (`job_id`,`divide_id`),
  KEY `idx_gmt_create` (`gmt_create`),
  KEY `idx_task_id` (`task_id`),
  KEY `idx_env` (`env`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='agoo-job框架，存储切分后block';

CREATE TABLE `agoo_metrics_arrive_logs` (
  `id` bigint(64) NOT NULL AUTO_INCREMENT COMMENT '虚拟主键，没有实际业务意义',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'INSERT TIME',
  `msg_key` varchar(80) NOT NULL COMMENT '设置的唯一KEY sent_msg_key = md5(appkey+device_id+msg_id+alias_name+channel)',
  `appkey` varchar(20) NOT NULL COMMENT 'Appkey',
  `device_id` varchar(128) NOT NULL,
  `msg_id` varchar(255) NOT NULL,
  `alias_name` varchar(64) DEFAULT NULL COMMENT '别名',
  `channel` varchar(10) DEFAULT 'accs' COMMENT '发送类型为枚举值：1 bydevice 2 为by alias_name',
  `statics_tag` varchar(64) DEFAULT NULL COMMENT '统计标记，如果存在则需要按照统计标记进行统计字段',
  `arrive_time` bigint(64) NOT NULL DEFAULT '0' COMMENT '到达时间',
  `result` int(11) NOT NULL DEFAULT '0' COMMENT '到达结果，枚举：0 为正常 1为被关闭',
  `result_detail` varchar(200) NOT NULL DEFAULT '' COMMENT '送达结果说明',
  `props` varchar(2048) DEFAULT '' COMMENT '发送参数（暂时没有明确用处和统计关系不大）',
  PRIMARY KEY (`id`),
  UNIQUE KEY `udx_metrics_uniq` (`msg_key`) USING BTREE COMMENT '消息唯一去重key',
  KEY `idx_metrics_query_by_time` (`arrive_time`) USING BTREE COMMENT '查询时使用的索引',
  KEY `idx_createtime` (`create_time`) USING BTREE COMMENT 'delete'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `agoo_metrics_clean_logs` (
  `id` bigint(64) NOT NULL AUTO_INCREMENT COMMENT '虚拟主键，没有实际业务意义',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'INSERT TIME',
  `msg_key` varchar(80) NOT NULL COMMENT '设置的唯一KEY sent_msg_key = md5(appkey+device_id+msg_id+alias_name+channel)',
  `appkey` varchar(20) NOT NULL COMMENT 'Appkey',
  `device_id` varchar(128) NOT NULL,
  `msg_id` varchar(255) NOT NULL,
  `alias_name` varchar(64) DEFAULT NULL COMMENT '别名',
  `statics_tag` varchar(64) DEFAULT NULL COMMENT '统计标记，如果存在则需要按照统计标记进行统计字段',
  `clean_time` bigint(64) NOT NULL DEFAULT '0' COMMENT '到达时间',
  `props` varchar(2048) DEFAULT '' COMMENT '发送参数（暂时没有明确用处和统计关系不大）',
  PRIMARY KEY (`id`),
  UNIQUE KEY `udx_metrics_uniq` (`msg_key`) USING BTREE COMMENT '消息唯一去重key',
  KEY `idx_metrics_query_by_time` (`clean_time`) USING BTREE COMMENT '查询时使用的索引',
  KEY `idx_createtime` (`create_time`) USING BTREE COMMENT 'delete'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `agoo_metrics_click_logs` (
  `id` bigint(64) NOT NULL AUTO_INCREMENT COMMENT '虚拟主键，没有实际业务意义',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'INSERT TIME',
  `msg_key` varchar(80) NOT NULL COMMENT '设置的唯一KEY sent_msg_key = md5(appkey+device_id+msg_id+alias_name+channel)',
  `appkey` varchar(20) NOT NULL COMMENT 'Appkey',
  `device_id` varchar(128) NOT NULL,
  `msg_id` varchar(255) NOT NULL,
  `alias_name` varchar(64) DEFAULT NULL COMMENT '别名',
  `statics_tag` varchar(64) DEFAULT NULL COMMENT '统计标记，如果存在则需要按照统计标记进行统计字段',
  `click_time` bigint(64) NOT NULL DEFAULT '0' COMMENT '点击时间',
  `props` varchar(2048) DEFAULT '' COMMENT '发送参数（暂时没有明确用处和统计关系不大）',
  PRIMARY KEY (`id`),
  UNIQUE KEY `udx_metrics_uniq` (`msg_key`) USING BTREE COMMENT '消息唯一去重key',
  KEY `idx_metrics_query_by_time` (`click_time`) USING BTREE COMMENT '查询时使用的索引',
  KEY `idx_createtime` (`create_time`) USING BTREE COMMENT 'delete'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `agoo_metrics_general_results` (
  `id` bigint(64) NOT NULL AUTO_INCREMENT,
  `appkey` varchar(20) NOT NULL COMMENT 'Appkey',
  `date_key` bigint(20) NOT NULL COMMENT '业务时间的KEY：YYYYMMDDHHMI',
  `send` int(11) NOT NULL DEFAULT '0',
  `sent` int(11) NOT NULL DEFAULT '0',
  `arrive` int(11) NOT NULL DEFAULT '0',
  `click` int(11) NOT NULL DEFAULT '0',
  `clean` int(11) NOT NULL DEFAULT '0',
  `forbidden` int(11) NOT NULL DEFAULT '0',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `udx_update_index` (`date_key`,`appkey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `agoo_metrics_send_fail_results` (
  `id` bigint(64) NOT NULL AUTO_INCREMENT,
  `appkey` varchar(20) NOT NULL,
  `date_key` bigint(20) NOT NULL COMMENT 'date_key YYYYMMDDHHMI',
  `failure_reason` varchar(30) NOT NULL COMMENT '错误代码',
  `failure_count` int(11) NOT NULL DEFAULT '0' COMMENT '错误数量',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `udx_update` (`appkey`,`date_key`,`failure_reason`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `agoo_metrics_send_logs` (
  `id` bigint(64) NOT NULL AUTO_INCREMENT COMMENT '虚拟主键，没有实际业务意义',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'INSERT TIME',
  `msg_key` varchar(80) NOT NULL COMMENT '设置的唯一KEY send_msg_key = md5 appkey+device_id+msg_id+alias_name ',
  `appkey` varchar(20) NOT NULL COMMENT 'Appkey',
  `device_id` varchar(128) NOT NULL,
  `msg_id` varchar(255) NOT NULL,
  `alias_name` varchar(64) DEFAULT NULL COMMENT '别名',
  `send_type` tinyint(4) DEFAULT '1' COMMENT '发送类型为枚举值：1 bydevice 2 为by alias_name',
  `statics_tag` varchar(64) DEFAULT NULL COMMENT '统计标记，如果存在则需要按照统计标记进行统计字段',
  `send_time` bigint(64) NOT NULL DEFAULT '0' COMMENT '发送时间',
  `result` int(11) NOT NULL DEFAULT '0' COMMENT '送出结果',
  `result_detail` varchar(200) DEFAULT 'SUCCESS' COMMENT '结果详细信息',
  `extra_info` varchar(2048) DEFAULT '' COMMENT '消息扩展信息，目前暂时还没用，统计中不会明确用到',
  `props` varchar(2048) DEFAULT '' COMMENT '发送参数（暂时没有明确用处和统计关系不大）',
  PRIMARY KEY (`id`),
  UNIQUE KEY `udx_metrics_uniq` (`msg_key`) USING BTREE COMMENT '消息唯一去重key',
  KEY `idx_metrics_query_by_time` (`send_time`) USING BTREE COMMENT '查询时使用的索引',
  KEY `idx_createtime` (`create_time`) USING BTREE COMMENT 'delete'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `agoo_metrics_sent_fail_results` (
  `id` bigint(64) NOT NULL AUTO_INCREMENT,
  `appkey` varchar(20) NOT NULL,
  `date_key` bigint(20) NOT NULL COMMENT 'date_key YYYYMMDDHHMI',
  `failure_reason` varchar(30) NOT NULL COMMENT '错误代码',
  `failure_count` int(11) NOT NULL DEFAULT '0' COMMENT '错误数量',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `udx_update` (`appkey`,`date_key`,`failure_reason`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `agoo_metrics_sent_logs` (
  `id` bigint(64) NOT NULL AUTO_INCREMENT COMMENT '虚拟主键，没有实际业务意义',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'INSERT TIME',
  `msg_key` varchar(80) NOT NULL COMMENT '设置的唯一KEY sent_msg_key = md5(appkey+device_id+msg_id+alias_name+channel)',
  `appkey` varchar(20) NOT NULL COMMENT 'Appkey',
  `device_id` varchar(128) NOT NULL,
  `msg_id` varchar(255) NOT NULL,
  `alias_name` varchar(64) DEFAULT NULL COMMENT '别名',
  `channel` varchar(1000) DEFAULT 'accs' COMMENT '发送类型为枚举值：1 bydevice 2 为by alias_name',
  `sent_type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '发送类型 0为托管 1为透传',
  `statics_tag` varchar(64) DEFAULT NULL COMMENT '统计标记，如果存在则需要按照统计标记进行统计字段',
  `sent_time` bigint(64) NOT NULL DEFAULT '0' COMMENT '送出时间',
  `result` int(11) NOT NULL DEFAULT '0' COMMENT '送出结果',
  `result_detail` varchar(200) NOT NULL DEFAULT 'SUCCESS' COMMENT '结果详细信息',
  PRIMARY KEY (`id`),
  UNIQUE KEY `udx_metrics_uniq` (`msg_key`) USING BTREE COMMENT '消息唯一去重key',
  KEY `idx_metrics_query_by_time` (`sent_time`) USING BTREE COMMENT '查询时使用的索引',
  KEY `idx_createtime` (`create_time`) USING BTREE COMMENT 'delete'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `agoo_metrics_tagkey_results` (
  `id` bigint(64) NOT NULL AUTO_INCREMENT,
  `appkey` varchar(20) NOT NULL,
  `date_key` bigint(20) NOT NULL COMMENT '日期KEY，格式为 YYYYMMDDHHMI，单位是分钟级别的',
  `statics_tag` varchar(64) NOT NULL,
  `send` int(11) DEFAULT '0' COMMENT '发送数\n',
  `sent` int(11) DEFAULT '0' COMMENT '已发送数\n',
  `arrive` int(11) DEFAULT '0' COMMENT '到达数',
  `click` int(11) DEFAULT '0' COMMENT '点击数',
  `clean` int(11) DEFAULT '0' COMMENT '清除数',
  `forbidden` int(11) DEFAULT '0' COMMENT '关闭数',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_update_index` (`appkey`,`statics_tag`,`date_key`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


INSERT INTO global_config (gmt_create, gmt_modified, config_id, group_id, value) VALUES (NOW(), NOW(), 'MQ_CONSUME_SINGLE', 'MQ_CONSUME_GROUP', '[{"group":"agoolite_gw_single_group","topic":"agoolite_gw_single","tag":"*","threadNum":"5","batchSize":"10",}]');
INSERT INTO global_config (gmt_create, gmt_modified, config_id, group_id, value) VALUES (NOW(), NOW(), 'MQ_CONSUME_BATCH', 'MQ_CONSUME_GROUP', '[{"group":"agoolite_gw_batch_group","topic":"agoolite_gw_batch","tag":"*","threadNum":"5","batchSize":"10",}]');
INSERT INTO global_config (gmt_create, gmt_modified, config_id, group_id, value) VALUES (NOW(), NOW(), 'MQ_CONSUME_MULTI', 'MQ_CONSUME_GROUP', '[{"group":"agoolite_gw_multi_group","topic":"agoolite_gw_multi","tag":"*","threadNum":"5","batchSize":"10",}]');
INSERT INTO global_config (gmt_create, gmt_modified, config_id, group_id, value) VALUES (NOW(), NOW(), 'MQ_CONSUME_TASK', 'MQ_CONSUME_GROUP', '[{"group":"agoolite_gw_task_group","topic":"agoolite_gw_task","tag":"*","threadNum":"5","batchSize":"10",}]');
INSERT INTO global_config (gmt_create, gmt_modified, config_id, group_id, value) VALUES (NOW(), NOW(), 'MQ_PRODUCE_ROUTE_TASK', 'MQ_PRODUCE_ROUTE', '[{"target":"default","topic":"agoolite_gw_task","tag":"common"},{"target":"4272.*","topic":"agoolite_gw_task","tag":"tb"}]');
INSERT INTO global_config (gmt_create, gmt_modified, config_id, group_id, value) VALUES (NOW(), NOW(), 'MQ_PRODUCE_ROUTE_XIAOMI', 'MQ_PRODUCE_ROUTE_GROUP', '[{"target":"default","topic":"agoolite_sender_xiaomi","tag":"common"}]');
INSERT INTO global_config (gmt_create, gmt_modified, config_id, group_id, value) VALUES (NOW(), NOW(), 'MQ_PRODUCE_ROUTE_HUAWEI', 'MQ_PRODUCE_ROUTE_GROUP', '[{"target":"default","topic":"agoolite_sender_huawei","tag":"common"}]');
INSERT INTO global_config (gmt_create, gmt_modified, config_id, group_id, value) VALUES (NOW(), NOW(), 'MQ_PRODUCE_ROUTE_MEIZU', 'MQ_PRODUCE_ROUTE_GROUP', '[{"target":"default","topic":"agoolite_sender_meizu","tag":"common"}]');
INSERT INTO global_config (gmt_create, gmt_modified, config_id, group_id, value) VALUES (NOW(), NOW(), 'MQ_PRODUCE_ROUTE_OPPO', 'MQ_PRODUCE_ROUTE_GROUP', '[{"target":"default","topic":"agoolite_sender_oppo","tag":"common"}]');
INSERT INTO global_config (gmt_create, gmt_modified, config_id, group_id, value) VALUES (NOW(), NOW(), 'MQ_PRODUCE_ROUTE_GCM', 'MQ_PRODUCE_ROUTE_GROUP', '[{"target":"default","topic":"agoolite_sender_gcm","tag":"common"}]');
INSERT INTO global_config (gmt_create, gmt_modified, config_id, group_id, value) VALUES (NOW(), NOW(), 'MQ_PRODUCE_ROUTE_ACCS', 'MQ_PRODUCE_ROUTE_GROUP', '[{"target":"default","topic":"agoolite_sender_accs","tag":"common"}]');
INSERT INTO global_config (gmt_create, gmt_modified, config_id, group_id, value) VALUES (NOW(), NOW(), 'MQ_PRODUCE_ROUTE_STORE', 'MQ_PRODUCE_ROUTE_GROUP', '[{"target":"default","topic":"agoolite_sender_store","tag":"common"}]');
INSERT INTO global_config (gmt_create, gmt_modified, config_id, group_id, value) VALUES (NOW(), NOW(), 'MQ_PRODUCE_ROUTE_APNS', 'MQ_PRODUCE_ROUTE_GROUP', '[{"target":"default","topic":"agoolite_sender_apns","tag":"common"}]');
INSERT INTO global_config (gmt_create, gmt_modified, config_id, group_id, value) VALUES (NOW(), NOW(), 'MQ_PRODUCE_ROUTE_SINGLE', 'MQ_PRODUCE_ROUTE_GROUP', '[{"target":"default","topic":"agoolite_gw_single","tag":"common"}]');
INSERT INTO global_config (gmt_create, gmt_modified, config_id, group_id, value) VALUES (NOW(), NOW(), 'MQ_PRODUCE_ROUTE_BATCH', 'MQ_PRODUCE_ROUTE_GROUP', '[{"target":"default","topic":"agoolite_gw_batch","tag":"common"}]');
INSERT INTO global_config (gmt_create, gmt_modified, config_id, group_id, value) VALUES (NOW(), NOW(), 'MQ_PRODUCE_ROUTE_MULTI', 'MQ_PRODUCE_ROUTE_GROUP', '[{"target":"default","topic":"agoolite_gw_multi","tag":"common"}]');
INSERT INTO global_config (gmt_create, gmt_modified, config_id, group_id, value) VALUES (NOW(), NOW(), 'MQ_CONSUME_APNS', 'MQ_CONSUME_GROUP', '[{"group":"agoolite_sender_apns_group","topic":"agoolite_sender_apns","tag":"*","threadNum":"5","batchSize":"1",}]');
INSERT INTO global_config (gmt_create, gmt_modified, config_id, group_id, value) VALUES (NOW(), NOW(), 'MQ_CONSUME_ACCS', 'MQ_CONSUME_GROUP', '[{"group":"agoolite_sender_accs_group","topic":"agoolite_sender_accs","tag":"*","threadNum":"5","batchSize":"1",}]');
INSERT INTO global_config (gmt_create, gmt_modified, config_id, group_id, value) VALUES (NOW(), NOW(), 'MQ_CONSUME_STORE', 'MQ_CONSUME_GROUP', '[{"group":"agoolite_sender_store_group","topic":"agoolite_sender_store","tag":"*","threadNum":"5","batchSize":"1",}]');
INSERT INTO global_config (gmt_create, gmt_modified, config_id, group_id, value) VALUES (NOW(), NOW(), 'MQ_CONSUME_XIAOMI', 'MQ_CONSUME_GROUP', '[{"group":"agoolite_sender_xiaomi_group","topic":"agoolite_sender_xiaomi","tag":"*","threadNum":"5","batchSize":"1",}]');
INSERT INTO global_config (gmt_create, gmt_modified, config_id, group_id, value) VALUES (NOW(), NOW(), 'MQ_CONSUME_HUAWEI', 'MQ_CONSUME_GROUP', '[{"group":"agoolite_sender_huawei_group","topic":"agoolite_sender_huawei","tag":"*","threadNum":"5","batchSize":"1",}]');
INSERT INTO global_config (gmt_create, gmt_modified, config_id, group_id, value) VALUES (NOW(), NOW(), 'MQ_CONSUME_MEIZU', 'MQ_CONSUME_GROUP', '[{"group":"agoolite_sender_meizu_group","topic":"agoolite_sender_meizu","tag":"*","threadNum":"5","batchSize":"1",}]');
INSERT INTO global_config (gmt_create, gmt_modified, config_id, group_id, value) VALUES (NOW(), NOW(), 'MQ_CONSUME_OPPO', 'MQ_CONSUME_GROUP', '[{"group":"agoolite_sender_oppo_group","topic":"agoolite_sender_oppo","tag":"*","threadNum":"5","batchSize":"1",}]');
INSERT INTO global_config (gmt_create, gmt_modified, config_id, group_id, value) VALUES (NOW(), NOW(), 'MQ_CONSUME_GCM', 'MQ_CONSUME_GROUP', '[{"group":"agoolite_sender_gcm_group","topic":"agoolite_sender_gcm","tag":"*","threadNum":"5","batchSize":"1",}]');