
UPDATE `emas-agoolite`.global_config
SET value = '[{"group":"agoolite_gw_batch_group","topic":"agoolite_gw_batch","tag":"*","threadNum":"20","batchSize":"10",}]'
WHERE config_id = 'MQ_CONSUME_BATCH' AND group_id = 'MQ_CONSUME_GROUP';

UPDATE `emas-agoolite`.global_config
SET value = '[{"group":"agoolite_gw_task_group","topic":"agoolite_gw_task","tag":"*","threadNum":"20","batchSize":"10",}]'
WHERE config_id = 'MQ_CONSUME_TASK' AND group_id = 'MQ_CONSUME_GROUP';

UPDATE `emas-agoolite`.global_config
SET value = '[{"group":"agoolite_sender_apns_group","topic":"agoolite_sender_apns","tag":"*","threadNum":"20","batchSize":"1",}]'
WHERE config_id = 'MQ_CONSUME_APNS' AND group_id = 'MQ_CONSUME_GROUP';

UPDATE `emas-agoolite`.global_config
SET value = '[{"group":"agoolite_sender_accs_group","topic":"agoolite_sender_accs","tag":"*","threadNum":"20","batchSize":"1",}]'
WHERE config_id = 'MQ_CONSUME_ACCS' AND group_id = 'MQ_CONSUME_GROUP';

UPDATE `emas-agoolite`.global_config
SET value = '[{"group":"agoolite_sender_xiaomi_group","topic":"agoolite_sender_xiaomi","tag":"*","threadNum":"20","batchSize":"1",}]'
WHERE config_id = 'MQ_CONSUME_XIAOMI' AND group_id = 'MQ_CONSUME_GROUP';

UPDATE `emas-agoolite`.global_config
SET value = '[{"group":"agoolite_sender_huawei_group","topic":"agoolite_sender_huawei","tag":"*","threadNum":"20","batchSize":"1",}]'
WHERE config_id = 'MQ_CONSUME_HUAWEI' AND group_id = 'MQ_CONSUME_GROUP';

UPDATE `emas-agoolite`.global_config
SET value = '[{"group":"agoolite_sender_meizu_group","topic":"agoolite_sender_meizu","tag":"*","threadNum":"20","batchSize":"1",}]'
WHERE config_id = 'MQ_CONSUME_MEIZU' AND group_id = 'MQ_CONSUME_GROUP';

UPDATE `emas-agoolite`.global_config
SET value = '[{"group":"agoolite_sender_oppo_group","topic":"agoolite_sender_oppo","tag":"*","threadNum":"20","batchSize":"1",}]'
WHERE config_id = 'MQ_CONSUME_OPPO' AND group_id = 'MQ_CONSUME_GROUP';
