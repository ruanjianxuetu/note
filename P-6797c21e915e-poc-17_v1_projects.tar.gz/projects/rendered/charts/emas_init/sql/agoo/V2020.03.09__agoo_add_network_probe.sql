CREATE TABLE `emas-agoolite`.`agoo_monitor_network_results`
(
`id`                    bigint(64) NOT NULL AUTO_INCREMENT,
`rt_apns_development`   int(11)    NOT NULL DEFAULT '-2' COMMENT 'APNs开发环境域名RT',
`rt_apns_production`    int(11)    NOT NULL DEFAULT '-2' COMMENT 'APNs生产环境域名RT',
`rt_huawei_push`        int(11)    NOT NULL DEFAULT '-2' COMMENT '华为推送域名RT',
`rt_huawei_login`       int(11)    NOT NULL DEFAULT '-2' COMMENT '华为鉴权域名RT',
`rt_xiaomi_development` int(11)    NOT NULL DEFAULT '-2' COMMENT '小米推送开发域名RT',
`rt_xiaomi_production`  int(11)    NOT NULL DEFAULT '-2' COMMENT '小米推送生产域名RT',
`rt_oppo`               int(11)    NOT NULL DEFAULT '-2' COMMENT 'OPPO推送域名RT',
`rt_vivo`               int(11)    NOT NULL DEFAULT '-2' COMMENT 'VIVO推送域名RT',
`rt_meizu`              int(11)    NOT NULL DEFAULT '-2' COMMENT '魅族推送域名RT',
`rt_fcm`                int(11)    NOT NULL DEFAULT '-2' COMMENT 'FCM推送域名RT',
`create_time`           datetime   NOT NULL DEFAULT CURRENT_TIMESTAMP,
PRIMARY KEY (`id`)
) ENGINE = InnoDB
DEFAULT CHARSET = utf8;