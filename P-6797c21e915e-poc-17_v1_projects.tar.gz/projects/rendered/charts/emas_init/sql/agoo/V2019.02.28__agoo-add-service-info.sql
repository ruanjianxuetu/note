
insert into `accs_lite`.`accs_service_info`(`service_name`, `type`, `gmt_create`, `gmt_modified`)
  values('agooKick', 0, now(), now());
insert into `accs_lite`.`accs_service_info`(`service_name`, `type`, `gmt_create`, `gmt_modified`)
  values('agooTokenReport', 0, now(), now());
insert into `accs_lite`.`accs_service_info`(`service_name`, `type`, `gmt_create`, `gmt_modified`)
  values('AgooDeviceCmd', 0, now(), now());
insert into `accs_lite`.`accs_service_info`(`service_name`, `type`, `gmt_create`, `gmt_modified`)
  values('agooSend', 0, now(), now());
insert into `accs_lite`.`accs_service_info`(`service_name`, `type`, `gmt_create`, `gmt_modified`)
  values('agooAck', 0, now(), now());