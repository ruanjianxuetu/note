USE `emas`;
INSERT INTO `emas_native_dep_archive` (`id`,`app_id`,`project_id`,`version`,`scm_commit`,`publish_type`,`archive_type`,`creator`,`modifier`,`is_deleted`,`gmt_create`,`gmt_modified`,`build_id`) VALUES (25200,19300,1044400,'1.0.0','20f87ad87499dd4defe0bc9bb6d40492b31ddc3d','RELEASE','PUBLISH','9999','9999',0,'2018-02-02 19:36:29','2018-02-02 19:39:16',3151000),
(25000,19400,1044000,'1.0.4','f993674d615ab522a76521a723d659a666022384','RELEASE','PUBLISH','9999','9999',0,'2018-02-01 20:15:43','2018-02-01 20:28:54',3042600), 
(25100,19400,1045000,'1.0.5','f993674d615ab522a76521a723d659a666022384','RELEASE','DYN_PUBLISH','9999','9999',0,'2018-02-01 21:06:11','2018-02-01 21:10:41',3049200);

INSERT INTO `emas_native_dep_archive_detail` (`id`,`archive_id`,`module_id`,`version`,`dep_key`,`compile_type`,`classifier`,`creator`,`modifier`,`is_deleted`,`gmt_create`,`gmt_modified`) VALUES (103700,25000,4600,'1.1.2.4','com.taobao.android:FirstBundle:awb',1,NULL,'9999','9999',0,'2018-02-01 20:15:43','2018-02-01 20:15:43'), 
(103800,25000,7100,'2.1.3','com.taobao.android:SecondBundle:awb',1,NULL,'9999','9999',0,'2018-02-01 20:15:43','2018-02-01 20:15:43'), 
(103900,25100,4600,'1.1.2.5','com.taobao.android:FirstBundle:awb',1,NULL,'9999','9999',0,'2018-02-01 21:06:11','2018-02-01 21:06:11'), 
(104000,25100,7100,'2.1.4','com.taobao.android:SecondBundle:awb',1,NULL,'9999','9999',0,'2018-02-01 21:06:11','2018-02-01 21:06:11'), 
(104100,25200,4200,'1.2.4.12','EMASFirstBundle',1,NULL,'9999','9999',0,'2018-02-02 19:36:29','2018-02-02 19:36:29');

