USE `emas`;
INSERT INTO `emas_services_role_user` (`gmt_create`,`gmt_modified`,`creator`,`modifier`,`is_deleted`,`user_id`,`role_id`,`role_context_id`) VALUES ('2018-02-05 14:35:31','2018-02-05 14:35:31','9999','9999',0,'9999',30,1043900);
INSERT INTO `emas_services_role_user` (`gmt_create`,`gmt_modified`,`creator`,`modifier`,`is_deleted`,`user_id`,`role_id`,`role_context_id`) VALUES ('2018-02-05 14:35:31','2018-02-05 14:35:31','9999','9999',0,'9999',35,30600);

