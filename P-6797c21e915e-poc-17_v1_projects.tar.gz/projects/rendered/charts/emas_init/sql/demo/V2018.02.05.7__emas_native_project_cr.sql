USE `emas`;
INSERT INTO `emas_native_project_cr` (`id`,`project_id`,`module_id`,`build_config_id`,`dep_key`,`version`,`compile_type`,`cr_type`,`cr_status`,`cr_branch`,`description`,`creator`,`modifier`,`is_deleted`,`gmt_create`,`gmt_modified`) VALUES (20700,1043900,4600,111500,'com.taobao.android:FirstBundle:awb','1.1.2.3',1,'SOURCE','DEVELOPING','master',NULL,'9999','9999',0,'2018-01-31 17:42:36','2018-01-31 17:42:36'),
(21600,1043900,7100,113900,'com.taobao.android:SecondBundle:awb','2.1.3',1,'SOURCE','DEVELOPING','master',NULL,'9999','9999',0,'2018-02-01 19:53:16','2018-02-01 19:53:16'), 
(21700,1044100,7100,114100,'com.taobao.android:SecondBundle:awb','2.1.4',17,'SOURCE','DEVELOPING','master',NULL,'9999','9999',0,'2018-02-01 20:35:15','2018-02-01 20:35:15'), 
(21800,1044100,4600,114200,'com.taobao.android:FirstBundle:awb','1.1.2.5',17,'SOURCE','DEVELOPING','master',NULL,'9999','9999',0,'2018-02-01 20:35:24','2018-02-01 20:35:24'), 
(22000,1044300,4200,114900,'EMASFirstBundle','1.2.4.10',1,'SOURCE','DEVELOPING','master',NULL,'9999','9999',0,'2018-02-01 21:11:36','2018-02-01 21:11:36');

