USE `emas`;
update `emas_hotfix_apply` set status = 1 where id = 29800;
