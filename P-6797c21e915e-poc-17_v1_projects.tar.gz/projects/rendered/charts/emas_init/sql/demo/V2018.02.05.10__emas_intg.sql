USE `emas`;
INSERT INTO `emas_native_intg_area` (`id`,`gmt_create`,`gmt_modified`,`is_deleted`,`creator`,`modifier`,`name`,`app_id`,`intg_area_type`,`intg_area_status`,`meta_project_id`,`scm_branch`,`module_white_list`,`freezing_schedule_time`) VALUES (12900,'2018-01-31 21:04:45','2018-01-31 21:04:45',0,'9999','9999','演示集成区',19300,'NORMAL','OPEN',1044400,'master','[]',NULL),
(12800,'2018-01-31 18:33:37','2018-01-31 18:33:37',0,'9999','9999','体验演示集成区',19400,'NORMAL','OPEN',1044000,'master','[]',NULL), 
(13000,'2018-02-01 21:03:16','2018-02-01 21:03:16',0,'9999','9999','动态部署集成区1010',19400,'DYNAMIC_DEPLOY','OPEN',1045000,'master','[]',NULL);

INSERT INTO `emas_native_intg_area_dep` (`id`,`gmt_create`,`gmt_modified`,`is_deleted`,`creator`,`modifier`,`intg_area_id`,`module_id`,`intg_count`,`cr_id`,`doc_cr_id`,`cr_type`,`doc_id`,`project_id`,`intg_dep_status`,`intg_dep_type`,`intg_dep_lock_status`,`dep_key`,`version`,`compile_type`) VALUES (11100,'2018-02-02 19:36:10','2018-02-02 19:36:10',0,'9999','9999',12900,4200,1,22000,27400,'SOURCE',9900,1044300,'SUCCESS','NORMAL','UNLOCKED','EMASFirstBundle','1.2.4.12',1), 
(10700,'2018-02-01 20:15:21','2018-02-01 20:15:21',0,'9999','9999',12800,4600,1,20700,27100,'SOURCE',9700,1043900,'SUCCESS','NORMAL','UNLOCKED','com.taobao.android:FirstBundle:awb','1.1.2.4',1), 
(10800,'2018-02-01 20:15:21','2018-02-01 20:15:21',0,'9999','9999',12800,7100,1,21600,27000,'SOURCE',9700,1043900,'SUCCESS','NORMAL','UNLOCKED','com.taobao.android:SecondBundle:awb','2.1.3',1), 
(10900,'2018-02-01 21:03:39','2018-02-01 21:03:39',0,'9999','9999',13000,7100,1,21700,27300,'SOURCE',9800,1044100,'SUCCESS','NORMAL','UNLOCKED','com.taobao.android:SecondBundle:awb','2.1.4',1), 
(11000,'2018-02-01 21:03:39','2018-02-01 21:03:39',0,'9999','9999',13000,4600,1,21800,27200,'SOURCE',9800,1044100,'SUCCESS','NORMAL','UNLOCKED','com.taobao.android:FirstBundle:awb','1.1.2.5',1);

INSERT INTO `emas_native_intg_area_log` (`id`,`gmt_create`,`gmt_modified`,`is_deleted`,`creator`,`modifier`,`intg_area_id`,`operation`,`old_value`,`new_value`,`remark`) VALUES (40700,'2018-01-31 21:04:45','2018-01-31 21:04:45',0,'9999','9999',12900,'INTG_AREA_CREATE',NULL,NULL,'crete integration area'), 
(41300,'2018-02-02 19:36:10','2018-02-02 19:36:10',0,'9999','9999',12900,'INTG_AREA_SUBMIT_DOC',NULL,NULL,'submit integration request'), 
(40500,'2018-01-31 18:33:37','2018-01-31 18:33:37',0,'9999','9999',12800,'INTG_AREA_CREATE',NULL,NULL,'crete integration area'), 
(40600,'2018-01-31 18:38:43','2018-01-31 18:38:43',0,'9999','9999',12800,'INTG_AREA_SUBMIT_DOC',NULL,NULL,'submit integration request'), 
(40800,'2018-02-01 14:30:29','2018-02-01 14:30:29',0,'9999','9999',12800,'INTG_AREA_DEP_REMOVE','46(1.1.2.3)',NULL,'remove dependency, description: 移除模块'), 
(40900,'2018-02-01 14:30:33','2018-02-01 14:30:33',0,'9999','9999',12800,'INTG_AREA_DEP_REMOVE','71(2.1.1)',NULL,'remove dependency, description: 移除模块移除模块'), 
(41000,'2018-02-01 20:15:21','2018-02-01 20:15:21',0,'9999','9999',12800,'INTG_AREA_SUBMIT_DOC',NULL,NULL,'submit integration request'), 
(41100,'2018-02-01 21:03:16','2018-02-01 21:03:16',0,'9999','9999',13000,'INTG_AREA_CREATE',NULL,NULL,'crete integration area'), 
(41200,'2018-02-01 21:03:39','2018-02-01 21:03:39',0,'9999','9999',13000,'INTG_AREA_SUBMIT_DOC',NULL,NULL,'submit integration request');

INSERT INTO `emas_native_intg_area_user` (`id`,`gmt_create`,`gmt_modified`,`is_deleted`,`creator`,`modifier`,`user_id`,`intg_area_id`,`intg_area_user_type`,`is_active`) VALUES (19600,'2018-01-31 21:04:45','2018-01-31 21:04:45',0,'9999','9999','9999',12900,'INTG_AREA',1), 
(19500,'2018-01-31 18:33:37','2018-01-31 18:33:37',0,'9999','9999','9999',12800,'INTG_AREA',1), 
(19700,'2018-02-01 21:03:16','2018-02-01 21:03:16',0,'9999','9999','9999',13000,'INTG_AREA',1);

