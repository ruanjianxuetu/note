USE `emas`;
INSERT INTO `emas_native_intg_doc` (`id`,`project_id`,`area_id`,`status`,`reason`,`description`,`creator`,`modifier`,`is_deleted`,`gmt_create`,`gmt_modified`,`attributes`) VALUES (9600,1043900,12800,'INTG_SUCCESS','NORMAL_INTG','集成演示集成演示集成演示集成演示','9999','9999',0,'2018-01-31 18:36:31','2018-01-31 18:38:43',NULL),
(9700,1043900,12800,'INTG_SUCCESS','NORMAL_INTG','提交集成提交集成提交集成','9999','9999',0,'2018-02-01 20:14:21','2018-02-01 20:15:21',NULL), 
(9800,1044100,13000,'INTG_SUCCESS','DEMAND_CHANGE','动态部署集成区动态部署集成区','9999','9999',0,'2018-02-01 21:03:38','2018-02-01 21:03:39',NULL), 
(9900,1044300,12900,'INTG_SUCCESS','NORMAL_INTG','集成体验集成体验集成体验','9999','9999',0,'2018-02-02 19:36:08','2018-02-02 19:36:10',NULL);

INSERT INTO `emas_native_intg_doc_cr` (`id`,`doc_id`,`cr_id`,`dep_key`,`version`,`compile_type`,`status`,`attributes`,`app_id`,`module_id`,`module_name`,`cr_type`,`gmt_create`,`gmt_modified`,`creator`,`modifier`,`is_deleted`) VALUES (26800,9600,21100,'com.taobao.android:SecondBundle:awb','2.1.1',1,'DELETE','',19400,7100,'SecondBundle','DEPENDENCY','2018-01-31 18:36:31','2018-02-01 14:30:33','9999','9999',0), 
(26900,9600,20700,'com.taobao.android:FirstBundle:awb','1.1.2.3',1,'DELETE','',19400,4600,'YS_FirstBundle','SOURCE','2018-01-31 18:36:31','2018-02-01 14:30:29','9999','9999',0), 
(27000,9700,21600,'com.taobao.android:SecondBundle:awb','2.1.3',1,'INTGED','',19400,7100,'SecondBundle','SOURCE','2018-02-01 20:14:21','2018-02-01 20:14:21','9999','9999',0), 
(27100,9700,20700,'com.taobao.android:FirstBundle:awb','1.1.2.4',1,'INTGED','',19400,4600,'YS_FirstBundle','SOURCE','2018-02-01 20:14:21','2018-02-01 20:14:21','9999','9999',0), 
(27200,9800,21800,'com.taobao.android:FirstBundle:awb','1.1.2.5',1,'INTGED','',19400,4600,'YS_FirstBundle','SOURCE','2018-02-01 21:03:38','2018-02-01 21:03:38','9999','9999',0), 
(27300,9800,21700,'com.taobao.android:SecondBundle:awb','2.1.4',1,'INTGED','',19400,7100,'SecondBundle','SOURCE','2018-02-01 21:03:38','2018-02-01 21:03:38','9999','9999',0), 
(27400,9900,22000,'EMASFirstBundle','1.2.4.12',1,'INTGED','',19300,4200,'EMASFirstBundle','SOURCE','2018-02-02 19:36:08','2018-02-02 19:36:08','9999','9999',0);

