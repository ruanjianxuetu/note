USE `emas`;
update `emas_hotfix_workspace` set `patch_type` = 3 where `id`= 16100;