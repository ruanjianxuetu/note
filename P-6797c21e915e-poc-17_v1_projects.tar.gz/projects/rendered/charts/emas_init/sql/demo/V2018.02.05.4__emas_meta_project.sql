USE `emas`;
INSERT INTO `emas_meta_project_info` (`id`,`app_id`,`app_type`,`foreign_id`,`project_name`,`beta_type`,`meta_type`,`secret_type`,`meta_project_status`,`meta_project_type`,`base_project_id`,`version`,`version_code`,`publish_status`,`description`,`base_version`,`scm_branch`,`ext`,`modifier`,`creator`,`gmt_create`,`gmt_modified`,`is_deleted`) VALUES (1044300,19300,'IOS',NULL,'iOS体验项目',NULL,'0','PUBLIC','DEVELOP','NORMAL',NULL,NULL,NULL,NULL,'iOS体验项目iOS体验项目iOS体验项目',NULL,'master',NULL,'9999','9999','2018-01-31 21:02:18','2018-01-31 21:02:18',0),
(1044400,19300,'IOS',NULL,'演示集成区',NULL,'0','PUBLIC','INTEGRATE','INTG',NULL,'1.0.0',NULL,NULL,'演示集成区演示集成区',NULL,'master',NULL,'9999','9999','2018-01-31 21:04:45','2018-01-31 21:04:45',0);

INSERT INTO `emas_meta_project_info` (`id`,`app_id`,`app_type`,`foreign_id`,`project_name`,`beta_type`,`meta_type`,`secret_type`,`meta_project_status`,`meta_project_type`,`base_project_id`,`version`,`version_code`,`publish_status`,`description`,`base_version`,`scm_branch`,`ext`,`modifier`,`creator`,`gmt_create`,`gmt_modified`,`is_deleted`) VALUES (1043900,19400,'ANDROID',NULL,'演示项目',NULL,'0','PUBLIC','DEVELOP','NORMAL',NULL,NULL,NULL,NULL,'演示项目演示项目演示项目演示项目演示项目',NULL,'master',NULL,'9999','9999','2018-01-31 17:41:15','2018-01-31 17:41:15',0), 
(1044000,19400,'ANDROID',NULL,'体验演示集成区',NULL,'0','PUBLIC','PUBLISHED','INTG',NULL,'1.0.4','5','PUBLISH_SUCCESS','体验演示集成区体验演示集成区',NULL,'master',NULL,'9999','9999','2018-01-31 18:33:38','2018-02-01 20:28:54',0), 
(1044100,19400,'ANDROID',25000,'动态部署项目',NULL,'40','PUBLIC','DEVELOP','NORMAL',NULL,'1.0.0',NULL,NULL,'动态部署项目动态部署项目','1.0.4','master',NULL,'9999','9999','2018-01-31 19:45:54','2018-02-01 20:55:33',0), 
(1045000,19400,'ANDROID',25000,'动态部署集成区1010',NULL,'40','PUBLIC','PUBLISHED','INTG',NULL,'1.0.5','5','PUBLISH_SUCCESS','动态部署集成区动态部署集成区','1.0.4','master',NULL,'9999','9999','2018-02-01 21:03:16','2018-02-01 21:10:41',0);

INSERT INTO `emas_meta_project_auth` (`id`,`project_id`,`user_id`,`role`,`modifier`,`creator`,`gmt_create`,`gmt_modified`,`is_deleted`,`app_id`) VALUES (1045500,1044300,9999,'31',NULL,NULL,'2018-01-31 21:02:18','2018-01-31 21:02:18',0,19300);

INSERT INTO `emas_meta_project_auth` (`id`,`project_id`,`user_id`,`role`,`modifier`,`creator`,`gmt_create`,`gmt_modified`,`is_deleted`,`app_id`) VALUES (1045200,1043900,9999,'31',NULL,NULL,'2018-01-31 17:41:15','2018-01-31 17:41:15',0,19400), 
(1045300,1044100,9999,'31',NULL,NULL,'2018-01-31 19:45:54','2018-01-31 19:45:54',0,19400);

