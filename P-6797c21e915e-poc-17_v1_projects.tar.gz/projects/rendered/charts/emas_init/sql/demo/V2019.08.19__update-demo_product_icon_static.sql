USE `emas`;
update `emas_product` set `icon`='/emas-static/emas-demo-icon.svg' where `id`=14100;