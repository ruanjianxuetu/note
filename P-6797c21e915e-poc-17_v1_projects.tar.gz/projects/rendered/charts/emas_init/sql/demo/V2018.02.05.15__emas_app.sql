USE `emas`;
INSERT INTO `emas_product` (`id`,`gmt_create`,`gmt_modified`,`creator`,`modifier`,`is_deleted`,`name`,`description`,`icon`,`en_name`) VALUES (14100,'2018-01-31 16:42:46','2018-02-01 13:52:21','9999','9999',0,'EMAS-DEMO','EMAS的演示产品，用于EMAS功能探索','http://mobile-hub-dev-packagefiles.oss-cn-shenzhen.aliyuncs.com/image-56af5eb7-5ccd-4487-9460-344d785f6e7f-1517388161928.png', 'emasdemo');

INSERT INTO `emas_app` (`id`,`creator`,`modifier`,`is_deleted`,`name`,`app_type`,`product_id`,`platform`,`package_name`,`bundle_id`,`app_key`,`app_key_secret`,`identifier`,`current_app_key`,`description`,`gmt_create`,`gmt_modified`,`secret_type`) VALUES (19300,'9999','9999',0,'iOS演示应用','COMPLEX',14100,'IOS',NULL,'com.emasiOSDemo','20000000','4c19bf52e9fa9dfc3da3dad53a57054e','20000000@iphoneos','20000000','这是EMAS iOS演示应用，用户可进行应用内功能探索，但无法进行实际操作哦～','2018-01-31 16:44:17','2018-01-31 17:33:11','PUBLIC'), 
(19400,'9999','9999',0,'Android演示应用','COMPLEX',14100,'ANDROID','com.emasAndroidDemo',NULL,'20000001','2e05fceeecbb5271170ff82d62605104','20000001@android','20000001','这是EMAS Android演示应用，用户可进行应用内功能探索，但无法进行实际操作哦～','2018-01-31 16:44:58','2018-02-01 19:47:16','PUBLIC');

INSERT INTO `emas_app_config` (`id`,`gmt_create`,`gmt_modified`,`is_deleted`,`creator`,`modifier`,`app_id`,`scm_address`,`scm_branch`) VALUES (17500,'2018-01-31 16:44:17','2018-01-31 21:00:54',0,'9999','9999',19300,'git@47.96.131.244:root/EMASDemo.git','master'), 
(17600,'2018-01-31 16:44:58','2018-01-31 17:40:46',0,'9999','9999',19400,'git@47.96.131.244:root/Android-EMAS-Demo.git','master');

INSERT INTO `emas_app_module` (`id`,`gmt_create`,`gmt_modified`,`is_deleted`,`creator`,`modifier`,`app_id`,`module_id`,`is_active`) VALUES (12500,'2018-01-31 21:02:41','2018-01-31 21:02:41',0,'9999','9999',19300,7700,1), 
(12600,'2018-01-31 21:03:02','2018-01-31 21:03:02',0,'9999','9999',19300,4200,1), 
(12200,'2018-01-31 17:41:31','2018-01-31 17:41:31',0,'9999','9999',19400,4600,1), 
(12300,'2018-01-31 17:41:48','2018-01-31 17:41:48',0,'9999','9999',19400,7100,1);

INSERT INTO `emas_module` (`id`,`name`,`platform`,`module_type`,`scm_address`,`dep_key`,`cocoapods_name`,`group_id`,`artifact_id`,`gav_type`,`description`,`gmt_create`,`gmt_modified`,`is_deleted`,`creator`,`modifier`,`private_app_id`,`module_dep_type`) VALUES (7700,'dependencyProject','IOS','PUBLIC','git@47.96.131.244:root/dependencyProject.git','dependencyProject','dependencyProject',NULL,NULL,NULL,'依赖关系测试模块','2018-01-08 16:01:20','2018-01-08 16:01:20',0,'9999','9999',NULL,'SOURCE_DEP'), 
(4200,'EMASFirstBundle','IOS','PUBLIC','git@47.96.131.244:root/EMASFirstBundle.git','EMASFirstBundle','EMASFirstBundle',NULL,NULL,NULL,'emas ios first bundle','2018-01-04 14:36:52','2018-01-05 10:29:09',0,'9999','10013',NULL,'SOURCE_DEP'), 
(4600,'YS_FirstBundle','ANDROID','PUBLIC','git@47.96.131.244:root/FirstBundle.git','com.taobao.android:FirstBundle:awb',NULL,'com.taobao.android','FirstBundle','AWB',NULL,'2018-01-05 15:21:57','2018-01-09 19:22:33',0,'9999','9999',NULL,'SOURCE_DEP'), 
(7100,'SecondBundle','ANDROID','PUBLIC','git@47.96.131.244:root/SecondBundle.git','com.taobao.android:SecondBundle:awb',NULL,'com.taobao.android','SecondBundle','AWB',NULL,'2018-01-06 21:00:31','2018-01-09 18:48:13',0,'9999','9999',NULL,'SOURCE_DEP');

INSERT INTO `emas_app_user` (`id`,`creator`,`modifier`,`gmt_create`,`gmt_modified`,`is_deleted`,`app_id`,`user_id`,`role_context`) VALUES (37100,'9999','9999','2018-01-31 16:44:17','2018-01-31 16:44:17',0,19300,'9999','NATIVE_APPLICATION'), 
(37200,'9999','9999','2018-01-31 16:44:17','2018-01-31 16:44:17',0,19300,'9999','WEEX_APPLICATION'), 
(37300,'9999','9999','2018-01-31 16:44:17','2018-01-31 16:44:17',0,19300,'9999','HA_APPLICATION'), 
(37400,'9999','9999','2018-01-31 16:44:58','2018-01-31 16:44:58',0,19400,'9999','NATIVE_APPLICATION'), 
(37500,'9999','9999','2018-01-31 16:44:58','2018-01-31 16:44:58',0,19400,'9999','WEEX_APPLICATION'), 
(37600,'9999','9999','2018-01-31 16:44:58','2018-01-31 16:44:58',0,19400,'9999','HA_APPLICATION');

